
package org.hl7.v3;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 *             Defines the basic properties of every data value. This
 *             is an abstract type, meaning that no value can be just
 *             a data value without belonging to any concrete type.
 *             Every concrete type is a specialization of this
 *             general abstract DataValue type.
 *          
 * 
 * <p>Java class for ANY complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ANY">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="nullFlavor" type="{urn:hl7-org:v3}NullFlavor" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ANY", propOrder = {
    "content"
})
//@XmlType(name = "ANY")
@XmlSeeAlso({
    BL.class,
    SLISTPQ.class,
    CR.class,
    II.class,
    SLISTTS.class,
    ANYNonNull.class,
    GLISTTS.class,
    URL.class,
    CD.class,
    QTY.class,
    GLISTPQ.class,
    BIN.class,
    EN.class
})
public abstract class ANY {

    @XmlMixed
    protected List<Serializable> content;
    @XmlAttribute
    protected NullFlavor nullFlavor;

    /**
     * Gets the value of the nullFlavor property.
     * 
     * @return
     *     possible object is
     *     {@link NullFlavor }
     *     
     */
    public NullFlavor getNullFlavor() {
        return nullFlavor;
    }

    /**
     * Sets the value of the nullFlavor property.
     * 
     * @param value
     *     allowed object is
     *     {@link NullFlavor }
     *     
     */
    public void setNullFlavor(NullFlavor value) {
        this.nullFlavor = value;
    }
    
        public List<Serializable> getContent() {
                if (content == null) {
                    content = new ArrayList<Serializable>();
                }
                return this.content;
        }

}
