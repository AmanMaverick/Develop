Put these back into DocXCommons\src\main\java\org\hl7\v3 once you regenerate the jaxb and use the old ANY.java that has getContent(), not the one that jaxb generates. 



Updating WSDL for web services:

	1) Use the datatypes-base-V3_0_old.xsd and datatypes-V3_0_old.xsd. Nehta updated the datatype xsd around 2012 August where they add some restrictions on IVL_** data types to bring it inline with the specification. These restrictions cause issues with JAXB. We are better off using the older datatype xsd since it generates the JAXB objects we need. Usage of the older datatype xsd is assuming there are no changes in the 2 xsd other then the IVL_** objects being changed to have choices of valid combinations of low high center and width rather then just low high center and width.
	2) wsimport.sh -extension -Xnocompile -keep -d generated HTB_PCEHR_ViewWS.wsdl
	3) copy Struct classes
	4) copy previous ANY class
	5) Add jaxb id2 element in 3 places in POCD_MT000040-AU-V1_0.xsd
	6) Add the following to AD.java so that addr can have NullFlavor
	
	@XmlAttribute
    protected NullFlavor nullFlavor;

    /**
     * Gets the value of the nullFlavor property.
     *
     * @return
     *     possible object is
     *     {@link NullFlavor }
     *
     */
    public NullFlavor getNullFlavor() {
        return nullFlavor;
    }

    /**
     * Sets the value of the nullFlavor property.
     *
     * @param value
     *     allowed object is
     *     {@link NullFlavor }
     *
     */
    public void setNullFlavor(NullFlavor value) {
        this.nullFlavor = value;
    }
    
    
    
    
More Info

- run wsimport
- replace ANY.java with no_mixed_ANY.java on SVN JAXB folder
- replace the struct java files
- compile the code
- generate ear file and deploy on a 'nomixed' endpoint, OSB will use this endpoint to get their WSDL
- Replace contents of ANY.java with ANY.java on SVN JAXB folder
- compile the code
- generate ear file and deploy, OSB will use this endpoint for functionality

