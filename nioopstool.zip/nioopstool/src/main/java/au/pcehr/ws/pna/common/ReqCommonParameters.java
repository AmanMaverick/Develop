
package au.pcehr.ws.pna.common;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for reqCommonParameters complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="reqCommonParameters">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="transactionID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sourceSystemID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pcehrIdentity" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="IHI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "reqCommonParameters", propOrder = {
    "transactionID",
    "sourceSystemID",
    "pcehrIdentity",
    "ihi"
})
public class ReqCommonParameters {

    @XmlElement(required = true)
    protected String transactionID;
    @XmlElement(required = true)
    protected String sourceSystemID;
    protected BigInteger pcehrIdentity;
    @XmlElement(name = "IHI")
    @XmlSchemaType(name = "anyURI")
    protected String ihi;

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }

    /**
     * Gets the value of the sourceSystemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceSystemID() {
        return sourceSystemID;
    }

    /**
     * Sets the value of the sourceSystemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceSystemID(String value) {
        this.sourceSystemID = value;
    }

    /**
     * Gets the value of the pcehrIdentity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPcehrIdentity() {
        return pcehrIdentity;
    }

    /**
     * Sets the value of the pcehrIdentity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPcehrIdentity(BigInteger value) {
        this.pcehrIdentity = value;
    }

    /**
     * Gets the value of the iHI property.
     *
     * @return
     * possible object is
     * {@link String}
     *
     */
    public String getIHI() {
        return ihi;
    }

    /**
     * Sets the value of the iHI property.
     *
     * @param value
     * allowed object is
     * {@link String}
     *
     */
    public void setIHI(String value) {
        this.ihi = value;
    }

}
