
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for unitType.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="unitType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ANT"/>
 *     &lt;enumeration value="APT"/>
 *     &lt;enumeration value="ATM"/>
 *     &lt;enumeration value="BBQ"/>
 *     &lt;enumeration value="BTSD"/>
 *     &lt;enumeration value="BLDG"/>
 *     &lt;enumeration value="BNGW"/>
 *     &lt;enumeration value="CAGE"/>
 *     &lt;enumeration value="CARP"/>
 *     &lt;enumeration value="CARS"/>
 *     &lt;enumeration value="CLUB"/>
 *     &lt;enumeration value="COOL"/>
 *     &lt;enumeration value="CTGE"/>
 *     &lt;enumeration value="DUP"/>
 *     &lt;enumeration value="FY"/>
 *     &lt;enumeration value="F"/>
 *     &lt;enumeration value="GRGE"/>
 *     &lt;enumeration value="HALL"/>
 *     &lt;enumeration value="HSE"/>
 *     &lt;enumeration value="KSK"/>
 *     &lt;enumeration value="LSE"/>
 *     &lt;enumeration value="LBBY"/>
 *     &lt;enumeration value="LOFT"/>
 *     &lt;enumeration value="LOT"/>
 *     &lt;enumeration value="MSNT"/>
 *     &lt;enumeration value="MB"/>
 *     &lt;enumeration value="OFF"/>
 *     &lt;enumeration value="PTHS"/>
 *     &lt;enumeration value="RESV"/>
 *     &lt;enumeration value="RM"/>
 *     &lt;enumeration value="SHED"/>
 *     &lt;enumeration value="SHOP"/>
 *     &lt;enumeration value="SIGN"/>
 *     &lt;enumeration value="SITE"/>
 *     &lt;enumeration value="SL"/>
 *     &lt;enumeration value="STOR"/>
 *     &lt;enumeration value="STR"/>
 *     &lt;enumeration value="STU"/>
 *     &lt;enumeration value="SUBS"/>
 *     &lt;enumeration value="SE"/>
 *     &lt;enumeration value="TNCY"/>
 *     &lt;enumeration value="TWR"/>
 *     &lt;enumeration value="TNHS"/>
 *     &lt;enumeration value="U"/>
 *     &lt;enumeration value="VLLA"/>
 *     &lt;enumeration value="WARD"/>
 *     &lt;enumeration value="WE"/>
 *     &lt;enumeration value="WKSH"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "unitType")
@XmlEnum
public enum UnitType {

    ANT,
    APT,
    ATM,
    BBQ,
    BTSD,
    BLDG,
    BNGW,
    CAGE,
    CARP,
    CARS,
    CLUB,
    COOL,
    CTGE,
    DUP,
    FY,
    F,
    GRGE,
    HALL,
    HSE,
    KSK,
    LSE,
    LBBY,
    LOFT,
    LOT,
    MSNT,
    MB,
    OFF,
    PTHS,
    RESV,
    RM,
    SHED,
    SHOP,
    SIGN,
    SITE,
    SL,
    STOR,
    STR,
    STU,
    SUBS,
    SE,
    TNCY,
    TWR,
    TNHS,
    U,
    VLLA,
    WARD,
    WE,
    WKSH;

    public String value() {
        return name();
    }

    public static UnitType fromValue(String v) {
        return valueOf(v);
    }

}
