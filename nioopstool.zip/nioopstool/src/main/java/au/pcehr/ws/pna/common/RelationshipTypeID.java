
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for relationshipTypeID.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="relationshipTypeID">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="sensitiveDocumentOrganisationalAcces"/>
 *     &lt;enumeration value="generalOrganisationalAccess"/>
 *     &lt;enumeration value="Parent"/>
 *     &lt;enumeration value="Authorised Representative"/>
 *     &lt;enumeration value="Self Access"/>
 *     &lt;enumeration value="Complaint Investigation"/>
 *     &lt;enumeration value="Court Instructed Access"/>
 *     &lt;enumeration value="Emergency Created Non Specific Relationship"/>
 *     &lt;enumeration value="Revoked Organisational Access"/>
 *     &lt;enumeration value="Nominated Representative"/>
 *     &lt;enumeration value="Individual Provider Access"/>
 *     &lt;enumeration value="Nominated Care Provider"/>
 *     &lt;enumeration value="Legally Appointed Authorised Representative"/>
 *     &lt;enumeration value="Guardian"/>
 *     &lt;enumeration value="Full Access Nominated Representative"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "relationshipTypeID")
@XmlEnum
public enum RelationshipTypeID {

    @XmlEnumValue("sensitiveDocumentOrganisationalAcces")
    SENSITIVE_DOCUMENT_ORGANISATIONAL_ACCES("sensitiveDocumentOrganisationalAcces"),
    @XmlEnumValue("generalOrganisationalAccess")
    GENERAL_ORGANISATIONAL_ACCESS("generalOrganisationalAccess"),
    @XmlEnumValue("Parent")
    PARENT("Parent"),
    @XmlEnumValue("Authorised Representative")
    AUTHORISED_REPRESENTATIVE("Authorised Representative"),
    @XmlEnumValue("Self Access")
    SELF_ACCESS("Self Access"),
    @XmlEnumValue("Complaint Investigation")
    COMPLAINT_INVESTIGATION("Complaint Investigation"),
    @XmlEnumValue("Court Instructed Access")
    COURT_INSTRUCTED_ACCESS("Court Instructed Access"),
    @XmlEnumValue("Emergency Created Non Specific Relationship")
    EMERGENCY_CREATED_NON_SPECIFIC_RELATIONSHIP("Emergency Created Non Specific Relationship"),
    @XmlEnumValue("Revoked Organisational Access")
    REVOKED_ORGANISATIONAL_ACCESS("Revoked Organisational Access"),
    @XmlEnumValue("Nominated Representative")
    NOMINATED_REPRESENTATIVE("Nominated Representative"),
    @XmlEnumValue("Individual Provider Access")
    INDIVIDUAL_PROVIDER_ACCESS("Individual Provider Access"),
    @XmlEnumValue("Nominated Care Provider")
    NOMINATED_CARE_PROVIDER("Nominated Care Provider"),
    @XmlEnumValue("Legally Appointed Authorised Representative")
    LEGALLY_APPOINTED_AUTHORISED_REPRESENTATIVE("Legally Appointed Authorised Representative"),
    @XmlEnumValue("Guardian")
    GUARDIAN("Guardian"),
    @XmlEnumValue("Full Access Nominated Representative")
    FULL_ACCESS_NOMINATED_REPRESENTATIVE("Full Access Nominated Representative");
    private final String value;

    RelationshipTypeID(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RelationshipTypeID fromValue(String v) {
        for (RelationshipTypeID c: RelationshipTypeID.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
