
package au.pcehr.ws.pna.common;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for sePcehrProfile complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="sePcehrProfile">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="demographics" type="{http://common.pna.ws.pcehr.au/}demographics" minOccurs="0"/>
 *         &lt;element name="pcehrrecord" type="{http://common.pna.ws.pcehr.au/}pcehrrecord" minOccurs="0"/>
 *         &lt;element name="consentAttributeListConsidered" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ecnAttributeListConsidered" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="accessNotifcationAttributeListConsidered" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="consentAttributeList" type="{http://common.pna.ws.pcehr.au/}consentAttributeList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ecnAttributeList" type="{http://common.pna.ws.pcehr.au/}ecnAttributeList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="accessNotificationAttributeList" type="{http://common.pna.ws.pcehr.au/}accessNotifcation" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sePcehrProfile", propOrder = {
    "demographics",
    "pcehrrecord",
    "consentAttributeListConsidered",
    "ecnAttributeListConsidered",
    "accessNotifcationAttributeListConsidered",
    "consentAttributeList",
    "ecnAttributeList",
    "accessNotificationAttributeList"
})
public class SePcehrProfile {

    protected Demographics demographics;
    protected Pcehrrecord pcehrrecord;
    protected Boolean consentAttributeListConsidered;
    protected Boolean ecnAttributeListConsidered;
    protected Boolean accessNotifcationAttributeListConsidered;
    protected List<ConsentAttributeList> consentAttributeList;
    protected List<EcnAttributeList> ecnAttributeList;
    protected List<AccessNotifcation> accessNotificationAttributeList;

    /**
     * Gets the value of the demographics property.
     * 
     * @return
     *     possible object is
     *     {@link Demographics }
     *     
     */
    public Demographics getDemographics() {
        return demographics;
    }

    /**
     * Sets the value of the demographics property.
     * 
     * @param value
     *     allowed object is
     *     {@link Demographics }
     *     
     */
    public void setDemographics(Demographics value) {
        this.demographics = value;
    }

    /**
     * Gets the value of the pcehrrecord property.
     * 
     * @return
     *     possible object is
     *     {@link Pcehrrecord }
     *     
     */
    public Pcehrrecord getPcehrrecord() {
        return pcehrrecord;
    }

    /**
     * Sets the value of the pcehrrecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link Pcehrrecord }
     *     
     */
    public void setPcehrrecord(Pcehrrecord value) {
        this.pcehrrecord = value;
    }

    /**
     * Gets the value of the consentAttributeListConsidered property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConsentAttributeListConsidered() {
        return consentAttributeListConsidered;
    }

    /**
     * Sets the value of the consentAttributeListConsidered property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConsentAttributeListConsidered(Boolean value) {
        this.consentAttributeListConsidered = value;
    }

    /**
     * Gets the value of the ecnAttributeListConsidered property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEcnAttributeListConsidered() {
        return ecnAttributeListConsidered;
    }

    /**
     * Sets the value of the ecnAttributeListConsidered property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEcnAttributeListConsidered(Boolean value) {
        this.ecnAttributeListConsidered = value;
    }

    /**
     * Gets the value of the accessNotifcationAttributeListConsidered property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAccessNotifcationAttributeListConsidered() {
        return accessNotifcationAttributeListConsidered;
    }

    /**
     * Sets the value of the accessNotifcationAttributeListConsidered property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAccessNotifcationAttributeListConsidered(Boolean value) {
        this.accessNotifcationAttributeListConsidered = value;
    }

    /**
     * Gets the value of the consentAttributeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the consentAttributeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConsentAttributeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConsentAttributeList }
     * 
     * 
     */
    public List<ConsentAttributeList> getConsentAttributeList() {
        if (consentAttributeList == null) {
            consentAttributeList = new ArrayList<ConsentAttributeList>();
        }
        return this.consentAttributeList;
    }

    /**
     * Gets the value of the ecnAttributeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ecnAttributeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEcnAttributeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EcnAttributeList }
     * 
     * 
     */
    public List<EcnAttributeList> getEcnAttributeList() {
        if (ecnAttributeList == null) {
            ecnAttributeList = new ArrayList<EcnAttributeList>();
        }
        return this.ecnAttributeList;
    }

    /**
     * Gets the value of the accessNotificationAttributeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accessNotificationAttributeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccessNotificationAttributeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AccessNotifcation }
     * 
     * 
     */
    public List<AccessNotifcation> getAccessNotificationAttributeList() {
        if (accessNotificationAttributeList == null) {
            accessNotificationAttributeList = new ArrayList<AccessNotifcation>();
        }
        return this.accessNotificationAttributeList;
    }

}
