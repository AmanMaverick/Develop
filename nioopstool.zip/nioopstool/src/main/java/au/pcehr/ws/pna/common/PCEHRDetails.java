
package au.pcehr.ws.pna.common;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PCEHRDetails complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="PCEHRDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="demographics" type="{http://common.pna.ws.pcehr.au/}DetailedDemographics" minOccurs="0"/>
 *         &lt;element name="pcehrrecord" type="{http://common.pna.ws.pcehr.au/}DetailedPcehrRecord" minOccurs="0"/>
 *         &lt;element name="consentAttributeList" type="{http://common.pna.ws.pcehr.au/}consentAttributeList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ecnAttributeList" type="{http://common.pna.ws.pcehr.au/}ecnAttributeList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="accessNotifcationAttributeList" type="{http://common.pna.ws.pcehr.au/}accessNotifcation" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="selfRelationship" type="{http://common.pna.ws.pcehr.au/}selfrelationship" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PCEHRDetails", propOrder = {
    "demographics",
    "pcehrrecord",
    "consentAttributeList",
    "ecnAttributeList",
    "accessNotifcationAttributeList",
    "selfRelationship"
})
public class PCEHRDetails {

    protected DetailedDemographics demographics;
    protected DetailedPcehrRecord pcehrrecord;
    protected List<ConsentAttributeList> consentAttributeList;
    protected List<EcnAttributeList> ecnAttributeList;
    protected List<AccessNotifcation> accessNotifcationAttributeList;
    protected Selfrelationship selfRelationship;

    /**
     * Gets the value of the demographics property.
     * 
     * @return
     *     possible object is
     *     {@link DetailedDemographics }
     *     
     */
    public DetailedDemographics getDemographics() {
        return demographics;
    }

    /**
     * Sets the value of the demographics property.
     * 
     * @param value
     *     allowed object is
     *     {@link DetailedDemographics }
     *     
     */
    public void setDemographics(DetailedDemographics value) {
        this.demographics = value;
    }

    /**
     * Gets the value of the pcehrrecord property.
     * 
     * @return
     *     possible object is
     *     {@link DetailedPcehrRecord }
     *     
     */
    public DetailedPcehrRecord getPcehrrecord() {
        return pcehrrecord;
    }

    /**
     * Sets the value of the pcehrrecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link DetailedPcehrRecord }
     *     
     */
    public void setPcehrrecord(DetailedPcehrRecord value) {
        this.pcehrrecord = value;
    }

    /**
     * Gets the value of the consentAttributeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the consentAttributeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConsentAttributeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConsentAttributeList }
     * 
     * 
     */
    public List<ConsentAttributeList> getConsentAttributeList() {
        if (consentAttributeList == null) {
            consentAttributeList = new ArrayList<ConsentAttributeList>();
        }
        return this.consentAttributeList;
    }

    /**
     * Gets the value of the ecnAttributeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ecnAttributeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEcnAttributeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EcnAttributeList }
     * 
     * 
     */
    public List<EcnAttributeList> getEcnAttributeList() {
        if (ecnAttributeList == null) {
            ecnAttributeList = new ArrayList<EcnAttributeList>();
        }
        return this.ecnAttributeList;
    }

    /**
     * Gets the value of the accessNotifcationAttributeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accessNotifcationAttributeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccessNotifcationAttributeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AccessNotifcation }
     * 
     * 
     */
    public List<AccessNotifcation> getAccessNotifcationAttributeList() {
        if (accessNotifcationAttributeList == null) {
            accessNotifcationAttributeList = new ArrayList<AccessNotifcation>();
        }
        return this.accessNotifcationAttributeList;
    }

    /**
     * Gets the value of the selfRelationship property.
     * 
     * @return
     *     possible object is
     *     {@link Selfrelationship }
     *     
     */
    public Selfrelationship getSelfRelationship() {
        return selfRelationship;
    }

    /**
     * Sets the value of the selfRelationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link Selfrelationship }
     *     
     */
    public void setSelfRelationship(Selfrelationship value) {
        this.selfRelationship = value;
    }

}
