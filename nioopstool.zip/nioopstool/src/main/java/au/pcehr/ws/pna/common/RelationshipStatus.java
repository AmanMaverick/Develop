
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for relationshipStatus.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="relationshipStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="active"/>
 *     &lt;enumeration value="inActive"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "relationshipStatus")
@XmlEnum
public enum RelationshipStatus {

    @XmlEnumValue("active")
    ACTIVE("active"),
    @XmlEnumValue("inActive")
    IN_ACTIVE("inActive");
    private final String value;

    RelationshipStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RelationshipStatus fromValue(String v) {
        for (RelationshipStatus c: RelationshipStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
