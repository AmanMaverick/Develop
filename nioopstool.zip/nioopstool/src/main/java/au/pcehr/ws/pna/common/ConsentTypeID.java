
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for consentTypeID.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="consentTypeID">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CONSENTED TO LOAD MBS"/>
 *     &lt;enumeration value="CONSENTED TO LOAD ACIR"/>
 *     &lt;enumeration value="CONSENTED TO LOAD AODR"/>
 *     &lt;enumeration value="CONSENTED TO LOAD DISCHARGE SUMMARY"/>
 *     &lt;enumeration value="CONSENTED FOR PBS PAST ASSIMILATION"/>
 *     &lt;enumeration value="CONSENTED FOR MBS PAST ASSIMILATION"/>
 *     &lt;enumeration value="CONSENTED TO LOAD PBS"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "consentTypeID")
@XmlEnum
public enum ConsentTypeID {

    @XmlEnumValue("CONSENTED TO LOAD MBS")
    CONSENTED_TO_LOAD_MBS("CONSENTED TO LOAD MBS"),
    @XmlEnumValue("CONSENTED TO LOAD ACIR")
    CONSENTED_TO_LOAD_ACIR("CONSENTED TO LOAD ACIR"),
    @XmlEnumValue("CONSENTED TO LOAD AODR")
    CONSENTED_TO_LOAD_AODR("CONSENTED TO LOAD AODR"),
    @XmlEnumValue("CONSENTED TO LOAD DISCHARGE SUMMARY")
    CONSENTED_TO_LOAD_DISCHARGE_SUMMARY("CONSENTED TO LOAD DISCHARGE SUMMARY"),
    @XmlEnumValue("CONSENTED FOR PBS PAST ASSIMILATION")
    CONSENTED_FOR_PBS_PAST_ASSIMILATION("CONSENTED FOR PBS PAST ASSIMILATION"),
    @XmlEnumValue("CONSENTED FOR MBS PAST ASSIMILATION")
    CONSENTED_FOR_MBS_PAST_ASSIMILATION("CONSENTED FOR MBS PAST ASSIMILATION"),
    @XmlEnumValue("CONSENTED TO LOAD PBS")
    CONSENTED_TO_LOAD_PBS("CONSENTED TO LOAD PBS");
    private final String value;

    ConsentTypeID(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ConsentTypeID fromValue(String v) {
        for (ConsentTypeID c: ConsentTypeID.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
