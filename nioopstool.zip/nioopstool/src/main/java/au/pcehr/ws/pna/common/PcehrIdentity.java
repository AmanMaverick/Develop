
package au.pcehr.ws.pna.common;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for pcehrIdentity complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="pcehrIdentity">
 * &lt;complexContent>
 * &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 * &lt;sequence>
 * &lt;element name="identityTCAcceptionStatus" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 * &lt;element name="identityTCAcceptedDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 * &lt;element name="identityTCAcceptedVersion" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 * &lt;element name="iHI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/>
 * &lt;element name="ivcCode" minOccurs="0">
 * &lt;simpleType>
 * &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 * &lt;length value="7"/>
 * &lt;/restriction>
 * &lt;/simpleType>
 * &lt;/element>
 * &lt;element name="identityIndependentMinor" type="{http://common.pna.ws.pcehr.au/}IdentityIndependentMinor"/>
 * &lt;/sequence>
 * &lt;/restriction>
 * &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pcehrIdentity", propOrder = {
    "identityTCAcceptionStatus",
    "identityTCAcceptedDate",
    "identityTCAcceptedVersion",
    "ihi",
    "ivcCode",
    "identityIndependentMinor"
})
public class PcehrIdentity {

    protected boolean identityTCAcceptionStatus;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar identityTCAcceptedDate;
    @XmlElement(required = true)
    protected BigInteger identityTCAcceptedVersion;
    @XmlSchemaType(name = "anyURI")
    protected String ihi;
    protected String ivcCode;
    @XmlElement(required = true)
    protected IdentityIndependentMinor identityIndependentMinor;

    /**
     * Gets the value of the identityTCAcceptionStatus property.
     * 
     */
    public boolean isIdentityTCAcceptionStatus() {
        return identityTCAcceptionStatus;
    }

    /**
     * Sets the value of the identityTCAcceptionStatus property.
     * 
     */
    public void setIdentityTCAcceptionStatus(boolean value) {
        this.identityTCAcceptionStatus = value;
    }

    /**
     * Gets the value of the identityTCAcceptedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIdentityTCAcceptedDate() {
        return identityTCAcceptedDate;
    }

    /**
     * Sets the value of the identityTCAcceptedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIdentityTCAcceptedDate(XMLGregorianCalendar value) {
        this.identityTCAcceptedDate = value;
    }

    /**
     * Gets the value of the identityTCAcceptedVersion property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getIdentityTCAcceptedVersion() {
        return identityTCAcceptedVersion;
    }

    /**
     * Sets the value of the identityTCAcceptedVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setIdentityTCAcceptedVersion(BigInteger value) {
        this.identityTCAcceptedVersion = value;
    }

    /**
     * Gets the value of the iHI property.
     *
     * @return
     * possible object is
     * {@link String}
     *
     */
    public String getIhi() {
        return ihi;
    }

    /**
     * Sets the value of the iHI property.
     *
     * @param value
     * allowed object is
     * {@link String}
     *
     */
    public void setIhi(String value) {
        this.ihi = value;
    }

    /**
     * Gets the value of the ivcCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIvcCode() {
        return ivcCode;
    }

    /**
     * Sets the value of the ivcCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIvcCode(String value) {
        this.ivcCode = value;
    }

    /**
     * Gets the value of the identityIndependentMinor property.
     * 
     * @return
     *     possible object is
     *     {@link IdentityIndependentMinor }
     *     
     */
    public IdentityIndependentMinor getIdentityIndependentMinor() {
        return identityIndependentMinor;
    }

    /**
     * Sets the value of the identityIndependentMinor property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentityIndependentMinor }
     *     
     */
    public void setIdentityIndependentMinor(IdentityIndependentMinor value) {
        this.identityIndependentMinor = value;
    }

}
