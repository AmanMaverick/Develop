
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IndigenousStatus.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="IndigenousStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Aboriginal but not Torres Strait Islander origin"/>
 *     &lt;enumeration value="Torres Strait Islander but not Aboriginal origin"/>
 *     &lt;enumeration value="Both Aboriginal and Torres Strait Islander origin"/>
 *     &lt;enumeration value="Neither Aboriginal nor Torres Strait Islander origin"/>
 *     &lt;enumeration value="Not stated/inadequately described"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "IndigenousStatus")
@XmlEnum
public enum IndigenousStatus {

    @XmlEnumValue("Aboriginal but not Torres Strait Islander origin")
    ABORIGINAL_BUT_NOT_TORRES_STRAIT_ISLANDER_ORIGIN("Aboriginal but not Torres Strait Islander origin"),
    @XmlEnumValue("Torres Strait Islander but not Aboriginal origin")
    TORRES_STRAIT_ISLANDER_BUT_NOT_ABORIGINAL_ORIGIN("Torres Strait Islander but not Aboriginal origin"),
    @XmlEnumValue("Both Aboriginal and Torres Strait Islander origin")
    BOTH_ABORIGINAL_AND_TORRES_STRAIT_ISLANDER_ORIGIN("Both Aboriginal and Torres Strait Islander origin"),
    @XmlEnumValue("Neither Aboriginal nor Torres Strait Islander origin")
    NEITHER_ABORIGINAL_NOR_TORRES_STRAIT_ISLANDER_ORIGIN("Neither Aboriginal nor Torres Strait Islander origin"),
    @XmlEnumValue("Not stated/inadequately described")
    NOT_STATED_INADEQUATELY_DESCRIBED("Not stated/inadequately described");
    private final String value;

    IndigenousStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static IndigenousStatus fromValue(String v) {
        for (IndigenousStatus c: IndigenousStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
