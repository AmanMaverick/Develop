
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for streetTypeCode.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="streetTypeCode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ACCS"/>
 *     &lt;enumeration value="ALLY"/>
 *     &lt;enumeration value="ALWY"/>
 *     &lt;enumeration value="AMBL"/>
 *     &lt;enumeration value="ANCG"/>
 *     &lt;enumeration value="APP"/>
 *     &lt;enumeration value="ARC"/>
 *     &lt;enumeration value="ART"/>
 *     &lt;enumeration value="AVE"/>
 *     &lt;enumeration value="BASN"/>
 *     &lt;enumeration value="BCH"/>
 *     &lt;enumeration value="BEND"/>
 *     &lt;enumeration value="BLK"/>
 *     &lt;enumeration value="BWLK"/>
 *     &lt;enumeration value="BVD"/>
 *     &lt;enumeration value="BRCE"/>
 *     &lt;enumeration value="BRAE"/>
 *     &lt;enumeration value="BRK"/>
 *     &lt;enumeration value="BDGE"/>
 *     &lt;enumeration value="BDWY"/>
 *     &lt;enumeration value="BROW"/>
 *     &lt;enumeration value="BYPA"/>
 *     &lt;enumeration value="BYWY"/>
 *     &lt;enumeration value="CAUS"/>
 *     &lt;enumeration value="CTR"/>
 *     &lt;enumeration value="CNWY"/>
 *     &lt;enumeration value="CH"/>
 *     &lt;enumeration value="CIR"/>
 *     &lt;enumeration value="CLT"/>
 *     &lt;enumeration value="CCT"/>
 *     &lt;enumeration value="CRCS"/>
 *     &lt;enumeration value="CL"/>
 *     &lt;enumeration value="CLDE"/>
 *     &lt;enumeration value="CMMN"/>
 *     &lt;enumeration value="CON"/>
 *     &lt;enumeration value="CPS"/>
 *     &lt;enumeration value="CNR"/>
 *     &lt;enumeration value="CSO"/>
 *     &lt;enumeration value="CT"/>
 *     &lt;enumeration value="CTYD"/>
 *     &lt;enumeration value="COVE"/>
 *     &lt;enumeration value="CRES"/>
 *     &lt;enumeration value="CRST"/>
 *     &lt;enumeration value="CRSS"/>
 *     &lt;enumeration value="CRSG"/>
 *     &lt;enumeration value="CRD"/>
 *     &lt;enumeration value="COWY"/>
 *     &lt;enumeration value="CUWY"/>
 *     &lt;enumeration value="CDS"/>
 *     &lt;enumeration value="CTTG"/>
 *     &lt;enumeration value="DALE"/>
 *     &lt;enumeration value="DELL"/>
 *     &lt;enumeration value="DEVN"/>
 *     &lt;enumeration value="DIP"/>
 *     &lt;enumeration value="DSTR"/>
 *     &lt;enumeration value="DR"/>
 *     &lt;enumeration value="DRWY"/>
 *     &lt;enumeration value="EDGE"/>
 *     &lt;enumeration value="ELB"/>
 *     &lt;enumeration value="END"/>
 *     &lt;enumeration value="ENT"/>
 *     &lt;enumeration value="ESP"/>
 *     &lt;enumeration value="EST"/>
 *     &lt;enumeration value="EXP"/>
 *     &lt;enumeration value="EXTN"/>
 *     &lt;enumeration value="FAWY"/>
 *     &lt;enumeration value="FTRK"/>
 *     &lt;enumeration value="FITR"/>
 *     &lt;enumeration value="FLAT"/>
 *     &lt;enumeration value="FOLW"/>
 *     &lt;enumeration value="FTWY"/>
 *     &lt;enumeration value="FSHR"/>
 *     &lt;enumeration value="FORM"/>
 *     &lt;enumeration value="FWY"/>
 *     &lt;enumeration value="FRNT"/>
 *     &lt;enumeration value="FRTG"/>
 *     &lt;enumeration value="GAP"/>
 *     &lt;enumeration value="GDN"/>
 *     &lt;enumeration value="GDNS"/>
 *     &lt;enumeration value="GTE"/>
 *     &lt;enumeration value="GTES"/>
 *     &lt;enumeration value="GLD"/>
 *     &lt;enumeration value="GLEN"/>
 *     &lt;enumeration value="GRA"/>
 *     &lt;enumeration value="GRN"/>
 *     &lt;enumeration value="GRND"/>
 *     &lt;enumeration value="GR"/>
 *     &lt;enumeration value="GLY"/>
 *     &lt;enumeration value="HTS"/>
 *     &lt;enumeration value="HRD"/>
 *     &lt;enumeration value="HWY"/>
 *     &lt;enumeration value="HILL"/>
 *     &lt;enumeration value="INTG"/>
 *     &lt;enumeration value="INTN"/>
 *     &lt;enumeration value="JNC"/>
 *     &lt;enumeration value="KEY"/>
 *     &lt;enumeration value="LDG"/>
 *     &lt;enumeration value="LANE"/>
 *     &lt;enumeration value="LNWY"/>
 *     &lt;enumeration value="LEES"/>
 *     &lt;enumeration value="LINE"/>
 *     &lt;enumeration value="LINK"/>
 *     &lt;enumeration value="LT"/>
 *     &lt;enumeration value="LKT"/>
 *     &lt;enumeration value="LOOP"/>
 *     &lt;enumeration value="LWR"/>
 *     &lt;enumeration value="MALL"/>
 *     &lt;enumeration value="MNDR"/>
 *     &lt;enumeration value="MEW"/>
 *     &lt;enumeration value="MEWS"/>
 *     &lt;enumeration value="MWY"/>
 *     &lt;enumeration value="MT"/>
 *     &lt;enumeration value="NOOK"/>
 *     &lt;enumeration value="OTLK"/>
 *     &lt;enumeration value="PDE"/>
 *     &lt;enumeration value="PARK"/>
 *     &lt;enumeration value="PKLD"/>
 *     &lt;enumeration value="PKWY"/>
 *     &lt;enumeration value="PART"/>
 *     &lt;enumeration value="PASS"/>
 *     &lt;enumeration value="PATH"/>
 *     &lt;enumeration value="PHWY"/>
 *     &lt;enumeration value="PIAZ"/>
 *     &lt;enumeration value="PL"/>
 *     &lt;enumeration value="PLAT"/>
 *     &lt;enumeration value="PLZA"/>
 *     &lt;enumeration value="PKT"/>
 *     &lt;enumeration value="PNT"/>
 *     &lt;enumeration value="PORT"/>
 *     &lt;enumeration value="PROM"/>
 *     &lt;enumeration value="QUAD"/>
 *     &lt;enumeration value="QDGL"/>
 *     &lt;enumeration value="QDRT"/>
 *     &lt;enumeration value="QY"/>
 *     &lt;enumeration value="QYS"/>
 *     &lt;enumeration value="RMBL"/>
 *     &lt;enumeration value="RAMP"/>
 *     &lt;enumeration value="RNGE"/>
 *     &lt;enumeration value="RCH"/>
 *     &lt;enumeration value="RES"/>
 *     &lt;enumeration value="REST"/>
 *     &lt;enumeration value="RTT"/>
 *     &lt;enumeration value="RIDE"/>
 *     &lt;enumeration value="RDGE"/>
 *     &lt;enumeration value="RGWY"/>
 *     &lt;enumeration value="ROWY"/>
 *     &lt;enumeration value="RING"/>
 *     &lt;enumeration value="RISE"/>
 *     &lt;enumeration value="RVR"/>
 *     &lt;enumeration value="RVWY"/>
 *     &lt;enumeration value="RVRA"/>
 *     &lt;enumeration value="RD"/>
 *     &lt;enumeration value="RDS"/>
 *     &lt;enumeration value="RDSD"/>
 *     &lt;enumeration value="RDWY"/>
 *     &lt;enumeration value="RNDE"/>
 *     &lt;enumeration value="RSBL"/>
 *     &lt;enumeration value="RTY"/>
 *     &lt;enumeration value="RND"/>
 *     &lt;enumeration value="RTE"/>
 *     &lt;enumeration value="ROW"/>
 *     &lt;enumeration value="RUE"/>
 *     &lt;enumeration value="RUN"/>
 *     &lt;enumeration value="SWY"/>
 *     &lt;enumeration value="SHUN"/>
 *     &lt;enumeration value="SDNG"/>
 *     &lt;enumeration value="SLPE"/>
 *     &lt;enumeration value="SND"/>
 *     &lt;enumeration value="SPUR"/>
 *     &lt;enumeration value="SQ"/>
 *     &lt;enumeration value="STRS"/>
 *     &lt;enumeration value="SHWY"/>
 *     &lt;enumeration value="STPS"/>
 *     &lt;enumeration value="STRA"/>
 *     &lt;enumeration value="ST"/>
 *     &lt;enumeration value="STRP"/>
 *     &lt;enumeration value="SBWY"/>
 *     &lt;enumeration value="TARN"/>
 *     &lt;enumeration value="TCE"/>
 *     &lt;enumeration value="THOR"/>
 *     &lt;enumeration value="TLWY"/>
 *     &lt;enumeration value="TOP"/>
 *     &lt;enumeration value="TOR"/>
 *     &lt;enumeration value="TWRS"/>
 *     &lt;enumeration value="TRK"/>
 *     &lt;enumeration value="TRL"/>
 *     &lt;enumeration value="TRLR"/>
 *     &lt;enumeration value="TRI"/>
 *     &lt;enumeration value="TKWY"/>
 *     &lt;enumeration value="TURN"/>
 *     &lt;enumeration value="UPAS"/>
 *     &lt;enumeration value="UPR"/>
 *     &lt;enumeration value="VALE"/>
 *     &lt;enumeration value="VDCT"/>
 *     &lt;enumeration value="VIEW"/>
 *     &lt;enumeration value="VLLS"/>
 *     &lt;enumeration value="VSTA"/>
 *     &lt;enumeration value="WADE"/>
 *     &lt;enumeration value="WALK"/>
 *     &lt;enumeration value="WKWY"/>
 *     &lt;enumeration value="WAY"/>
 *     &lt;enumeration value="WHRF"/>
 *     &lt;enumeration value="WYND"/>
 *     &lt;enumeration value="YARD"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "streetTypeCode")
@XmlEnum
public enum StreetTypeCode {

    ACCS,
    ALLY,
    ALWY,
    AMBL,
    ANCG,
    APP,
    ARC,
    ART,
    AVE,
    BASN,
    BCH,
    BEND,
    BLK,
    BWLK,
    BVD,
    BRCE,
    BRAE,
    BRK,
    BDGE,
    BDWY,
    BROW,
    BYPA,
    BYWY,
    CAUS,
    CTR,
    CNWY,
    CH,
    CIR,
    CLT,
    CCT,
    CRCS,
    CL,
    CLDE,
    CMMN,
    CON,
    CPS,
    CNR,
    CSO,
    CT,
    CTYD,
    COVE,
    CRES,
    CRST,
    CRSS,
    CRSG,
    CRD,
    COWY,
    CUWY,
    CDS,
    CTTG,
    DALE,
    DELL,
    DEVN,
    DIP,
    DSTR,
    DR,
    DRWY,
    EDGE,
    ELB,
    END,
    ENT,
    ESP,
    EST,
    EXP,
    EXTN,
    FAWY,
    FTRK,
    FITR,
    FLAT,
    FOLW,
    FTWY,
    FSHR,
    FORM,
    FWY,
    FRNT,
    FRTG,
    GAP,
    GDN,
    GDNS,
    GTE,
    GTES,
    GLD,
    GLEN,
    GRA,
    GRN,
    GRND,
    GR,
    GLY,
    HTS,
    HRD,
    HWY,
    HILL,
    INTG,
    INTN,
    JNC,
    KEY,
    LDG,
    LANE,
    LNWY,
    LEES,
    LINE,
    LINK,
    LT,
    LKT,
    LOOP,
    LWR,
    MALL,
    MNDR,
    MEW,
    MEWS,
    MWY,
    MT,
    NOOK,
    OTLK,
    PDE,
    PARK,
    PKLD,
    PKWY,
    PART,
    PASS,
    PATH,
    PHWY,
    PIAZ,
    PL,
    PLAT,
    PLZA,
    PKT,
    PNT,
    PORT,
    PROM,
    QUAD,
    QDGL,
    QDRT,
    QY,
    QYS,
    RMBL,
    RAMP,
    RNGE,
    RCH,
    RES,
    REST,
    RTT,
    RIDE,
    RDGE,
    RGWY,
    ROWY,
    RING,
    RISE,
    RVR,
    RVWY,
    RVRA,
    RD,
    RDS,
    RDSD,
    RDWY,
    RNDE,
    RSBL,
    RTY,
    RND,
    RTE,
    ROW,
    RUE,
    RUN,
    SWY,
    SHUN,
    SDNG,
    SLPE,
    SND,
    SPUR,
    SQ,
    STRS,
    SHWY,
    STPS,
    STRA,
    ST,
    STRP,
    SBWY,
    TARN,
    TCE,
    THOR,
    TLWY,
    TOP,
    TOR,
    TWRS,
    TRK,
    TRL,
    TRLR,
    TRI,
    TKWY,
    TURN,
    UPAS,
    UPR,
    VALE,
    VDCT,
    VIEW,
    VLLS,
    VSTA,
    WADE,
    WALK,
    WKWY,
    WAY,
    WHRF,
    WYND,
    YARD;

    public String value() {
        return name();
    }

    public static StreetTypeCode fromValue(String v) {
        return valueOf(v);
    }

}
