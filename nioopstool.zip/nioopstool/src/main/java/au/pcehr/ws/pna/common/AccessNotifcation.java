
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for accessNotifcation complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="accessNotifcation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="notificationChannelID" type="{http://common.pna.ws.pcehr.au/}notificationChannel"/>
 *         &lt;element name="accessChangeEventID" type="{http://common.pna.ws.pcehr.au/}accessChangeEventID"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "accessNotifcation", propOrder = {
    "notificationChannelID",
    "accessChangeEventID"
})
public class AccessNotifcation {

    @XmlElement(required = true)
    protected NotificationChannel notificationChannelID;
    @XmlElement(required = true)
    protected AccessChangeEventID accessChangeEventID;

    /**
     * Gets the value of the notificationChannelID property.
     * 
     * @return
     *     possible object is
     *     {@link NotificationChannel }
     *     
     */
    public NotificationChannel getNotificationChannelID() {
        return notificationChannelID;
    }

    /**
     * Sets the value of the notificationChannelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NotificationChannel }
     *     
     */
    public void setNotificationChannelID(NotificationChannel value) {
        this.notificationChannelID = value;
    }

    /**
     * Gets the value of the accessChangeEventID property.
     * 
     * @return
     *     possible object is
     *     {@link AccessChangeEventID }
     *     
     */
    public AccessChangeEventID getAccessChangeEventID() {
        return accessChangeEventID;
    }

    /**
     * Sets the value of the accessChangeEventID property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccessChangeEventID }
     *     
     */
    public void setAccessChangeEventID(AccessChangeEventID value) {
        this.accessChangeEventID = value;
    }

}
