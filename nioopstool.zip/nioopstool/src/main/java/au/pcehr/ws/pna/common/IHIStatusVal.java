
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IHIStatusVal.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="IHIStatusVal">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Active"/>
 *     &lt;enumeration value="Deceased"/>
 *     &lt;enumeration value="Retired"/>
 *     &lt;enumeration value="Resolved"/>
 *     &lt;enumeration value="Expired"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "IHIStatusVal")
@XmlEnum
public enum IHIStatusVal {

    @XmlEnumValue("Active")
    ACTIVE("Active"),
    @XmlEnumValue("Deceased")
    DECEASED("Deceased"),
    @XmlEnumValue("Retired")
    RETIRED("Retired"),
    @XmlEnumValue("Resolved")
    RESOLVED("Resolved"),
    @XmlEnumValue("Expired")
    EXPIRED("Expired");
    private final String value;

    IHIStatusVal(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static IHIStatusVal fromValue(String v) {
        for (IHIStatusVal c: IHIStatusVal.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
