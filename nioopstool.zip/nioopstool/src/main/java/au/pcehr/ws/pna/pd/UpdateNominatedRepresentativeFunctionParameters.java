
package au.pcehr.ws.pna.pd;

import au.pcehr.ws.pna.common.AccessType;
import au.pcehr.ws.pna.common.RelationshipStatus;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for updateNominatedRepresentativeFunctionParameters complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="updateNominatedRepresentativeFunctionParameters">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="newPreferredName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accessType" type="{http://common.pna.ws.pcehr.au/}AccessType"/>
 *         &lt;element name="relationshipStatus" type="{http://common.pna.ws.pcehr.au/}relationshipStatus" minOccurs="0"/>
 *         &lt;element name="relationshipEndedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="relationshipEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateNominatedRepresentativeFunctionParameters", propOrder = {
    "newPreferredName",
    "accessType",
    "relationshipStatus",
    "relationshipEndedBy",
    "relationshipEndDate"
})
public class UpdateNominatedRepresentativeFunctionParameters {

    protected String newPreferredName;
    @XmlElement(required = true)
    protected AccessType accessType;
    protected RelationshipStatus relationshipStatus;
    protected String relationshipEndedBy;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar relationshipEndDate;

    /**
     * Gets the value of the newPreferredName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewPreferredName() {
        return newPreferredName;
    }

    /**
     * Sets the value of the newPreferredName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewPreferredName(String value) {
        this.newPreferredName = value;
    }

    /**
     * Gets the value of the accessType property.
     * 
     * @return
     *     possible object is
     *     {@link AccessType }
     *     
     */
    public AccessType getAccessType() {
        return accessType;
    }

    /**
     * Sets the value of the accessType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccessType }
     *     
     */
    public void setAccessType(AccessType value) {
        this.accessType = value;
    }

    /**
     * Gets the value of the relationshipStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RelationshipStatus }
     *     
     */
    public RelationshipStatus getRelationshipStatus() {
        return relationshipStatus;
    }

    /**
     * Sets the value of the relationshipStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RelationshipStatus }
     *     
     */
    public void setRelationshipStatus(RelationshipStatus value) {
        this.relationshipStatus = value;
    }

    /**
     * Gets the value of the relationshipEndedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipEndedBy() {
        return relationshipEndedBy;
    }

    /**
     * Sets the value of the relationshipEndedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipEndedBy(String value) {
        this.relationshipEndedBy = value;
    }

    /**
     * Gets the value of the relationshipEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRelationshipEndDate() {
        return relationshipEndDate;
    }

    /**
     * Sets the value of the relationshipEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRelationshipEndDate(XMLGregorianCalendar value) {
        this.relationshipEndDate = value;
    }

}
