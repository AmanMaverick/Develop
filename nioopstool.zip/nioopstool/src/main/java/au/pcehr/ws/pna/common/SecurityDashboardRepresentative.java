
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for securityDashboardRepresentative complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="securityDashboardRepresentative">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="representativeID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="representativeType" type="{http://common.pna.ws.pcehr.au/}RepresentativeTypeVal"/>
 *         &lt;element name="accessLevel" type="{http://common.pna.ws.pcehr.au/}AccessLevelVal"/>
 *         &lt;element name="representativeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "securityDashboardRepresentative", propOrder = {
    "representativeID",
    "representativeType",
    "accessLevel",
    "representativeName"
})
public class SecurityDashboardRepresentative {

    @XmlElement(required = true)
    protected String representativeID;
    @XmlElement(required = true)
    protected RepresentativeTypeVal representativeType;
    @XmlElement(required = true)
    protected AccessLevelVal accessLevel;
    protected String representativeName;

    /**
     * Gets the value of the representativeID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepresentativeID() {
        return representativeID;
    }

    /**
     * Sets the value of the representativeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepresentativeID(String value) {
        this.representativeID = value;
    }

    /**
     * Gets the value of the representativeType property.
     * 
     * @return
     *     possible object is
     *     {@link RepresentativeTypeVal }
     *     
     */
    public RepresentativeTypeVal getRepresentativeType() {
        return representativeType;
    }

    /**
     * Sets the value of the representativeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RepresentativeTypeVal }
     *     
     */
    public void setRepresentativeType(RepresentativeTypeVal value) {
        this.representativeType = value;
    }

    /**
     * Gets the value of the accessLevel property.
     * 
     * @return
     *     possible object is
     *     {@link AccessLevelVal }
     *     
     */
    public AccessLevelVal getAccessLevel() {
        return accessLevel;
    }

    /**
     * Sets the value of the accessLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccessLevelVal }
     *     
     */
    public void setAccessLevel(AccessLevelVal value) {
        this.accessLevel = value;
    }

    /**
     * Gets the value of the representativeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepresentativeName() {
        return representativeName;
    }

    /**
     * Sets the value of the representativeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepresentativeName(String value) {
        this.representativeName = value;
    }

}
