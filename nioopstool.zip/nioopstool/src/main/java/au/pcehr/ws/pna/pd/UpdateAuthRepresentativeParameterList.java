
package au.pcehr.ws.pna.pd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateAuthRepresentativeParameterList complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="UpdateAuthRepresentativeParameterList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="commonParameters" type="{http://pd.pna.ws.pcehr.au/}UpdateAuthRepresentativeCommonParameters"/>
 *         &lt;element name="functionParameters" type="{http://pd.pna.ws.pcehr.au/}UpdateAuthRepresentativeFunctionParameters"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateAuthRepresentativeParameterList", propOrder = {
    "commonParameters",
    "functionParameters"
})
public class UpdateAuthRepresentativeParameterList {

    @XmlElement(required = true)
    protected UpdateAuthRepresentativeCommonParameters commonParameters;
    @XmlElement(required = true)
    protected UpdateAuthRepresentativeFunctionParameters functionParameters;

    /**
     * Gets the value of the commonParameters property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateAuthRepresentativeCommonParameters }
     *     
     */
    public UpdateAuthRepresentativeCommonParameters getCommonParameters() {
        return commonParameters;
    }

    /**
     * Sets the value of the commonParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateAuthRepresentativeCommonParameters }
     *     
     */
    public void setCommonParameters(UpdateAuthRepresentativeCommonParameters value) {
        this.commonParameters = value;
    }

    /**
     * Gets the value of the functionParameters property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateAuthRepresentativeFunctionParameters }
     *     
     */
    public UpdateAuthRepresentativeFunctionParameters getFunctionParameters() {
        return functionParameters;
    }

    /**
     * Sets the value of the functionParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateAuthRepresentativeFunctionParameters }
     *     
     */
    public void setFunctionParameters(UpdateAuthRepresentativeFunctionParameters value) {
        this.functionParameters = value;
    }

}
