
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccessChannelVal.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccessChannelVal">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NCP"/>
 *     &lt;enumeration value="NPP"/>
 *     &lt;enumeration value="CCP"/>
 *     &lt;enumeration value="CPP"/>
 *     &lt;enumeration value="CIS"/>
 *     &lt;enumeration value="CSP"/>
 *     &lt;enumeration value="CRP"/>
 *     &lt;enumeration value="HI"/>
 *     &lt;enumeration value="Medicare"/>
 *     &lt;enumeration value="ADM"/>
 *     &lt;enumeration value="SUP"/>
 *     &lt;enumeration value="RPT"/>
 *     &lt;enumeration value="CRM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "AccessChannelVal")
@XmlEnum
public enum AccessChannelVal {

    NCP("NCP"),
    NPP("NPP"),
    CCP("CCP"),
    CPP("CPP"),
    CIS("CIS"),
    CSP("CSP"),
    CRP("CRP"),
    HI("HI"),
    @XmlEnumValue("Medicare")
    MEDICARE("Medicare"),
    ADM("ADM"),
    SUP("SUP"),
    RPT("RPT"),
    CRM("CRM");
    private final String value;

    AccessChannelVal(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AccessChannelVal fromValue(String v) {
        for (AccessChannelVal c: AccessChannelVal.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
