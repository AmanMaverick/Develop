
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for pcehrrecord complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="pcehrrecord">
 * &lt;complexContent>
 * &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 * &lt;sequence>
 * &lt;element name="recordSearchable" type="{http://common.pna.ws.pcehr.au/}recordSearchable" minOccurs="0"/>
 * &lt;element name="recordNotificationStatus" type="{http://common.pna.ws.pcehr.au/}recordNotificationStatus" minOccurs="0"/>
 * &lt;element name="relationChangeNotification" type="{http://common.pna.ws.pcehr.au/}relationChangeNotification" minOccurs="0"/>
 * &lt;element name="pacc" minOccurs="0">
 * &lt;simpleType>
 * &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 * &lt;length value="20"/>
 * &lt;/restriction>
 * &lt;/simpleType>
 * &lt;/element>
 * &lt;element name="paccx" minOccurs="0">
 * &lt;simpleType>
 * &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 * &lt;length value="20"/>
 * &lt;/restriction>
 * &lt;/simpleType>
 * &lt;/element>
 * &lt;element name="iHI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/>
 * &lt;element name="recordDefaultDocAccessLevel" type="{http://common.pna.ws.pcehr.au/}recordDefaultDocAccessLevel" minOccurs="0"/>
 * &lt;element name="onlineTutorialCompleted" type="{http://common.pna.ws.pcehr.au/}onlineTutorialCompleted" minOccurs="0"/>
 * &lt;element name="accessControlPreference" type="{http://common.pna.ws.pcehr.au/}accessControlPreference" minOccurs="0"/>
 * &lt;/sequence>
 * &lt;/restriction>
 * &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pcehrrecord", propOrder = {
    "recordSearchable",
    "recordNotificationStatus",
    "relationChangeNotification",
    "pacc",
    "paccx",
    "ihi",
    "recordDefaultDocAccessLevel",
    "onlineTutorialCompleted",
    "accessControlPreference"
})
public class Pcehrrecord {

    protected RecordSearchable recordSearchable;
    protected RecordNotificationStatus recordNotificationStatus;
    protected RelationChangeNotification relationChangeNotification;
    protected String pacc;
    protected String paccx;
    @XmlSchemaType(name = "anyURI")
    protected String ihi;
    protected RecordDefaultDocAccessLevel recordDefaultDocAccessLevel;
    protected OnlineTutorialCompleted onlineTutorialCompleted;
    protected AccessControlPreference accessControlPreference;

    /**
     * Gets the value of the recordSearchable property.
     * 
     * @return
     *     possible object is
     *     {@link RecordSearchable }
     *     
     */
    public RecordSearchable getRecordSearchable() {
        return recordSearchable;
    }

    /**
     * Sets the value of the recordSearchable property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordSearchable }
     *     
     */
    public void setRecordSearchable(RecordSearchable value) {
        this.recordSearchable = value;
    }

    /**
     * Gets the value of the recordNotificationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RecordNotificationStatus }
     *     
     */
    public RecordNotificationStatus getRecordNotificationStatus() {
        return recordNotificationStatus;
    }

    /**
     * Sets the value of the recordNotificationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordNotificationStatus }
     *     
     */
    public void setRecordNotificationStatus(RecordNotificationStatus value) {
        this.recordNotificationStatus = value;
    }

    /**
     * Gets the value of the relationChangeNotification property.
     * 
     * @return
     *     possible object is
     *     {@link RelationChangeNotification }
     *     
     */
    public RelationChangeNotification getRelationChangeNotification() {
        return relationChangeNotification;
    }

    /**
     * Sets the value of the relationChangeNotification property.
     * 
     * @param value
     *     allowed object is
     *     {@link RelationChangeNotification }
     *     
     */
    public void setRelationChangeNotification(RelationChangeNotification value) {
        this.relationChangeNotification = value;
    }

    /**
     * Gets the value of the pacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPacc() {
        return pacc;
    }

    /**
     * Sets the value of the pacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPacc(String value) {
        this.pacc = value;
    }

    /**
     * Gets the value of the paccx property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaccx() {
        return paccx;
    }

    /**
     * Sets the value of the paccx property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaccx(String value) {
        this.paccx = value;
    }

    /**
     * Gets the value of the iHI property.
     *
     * @return
     * possible object is
     * {@link String}
     *
     */
    public String getIhi() {
        return ihi;
    }

    /**
     * Sets the value of the iHI property.
     *
     * @param value
     * allowed object is
     * {@link String}
     *
     */
    public void setIhi(String value) {
        this.ihi = value;
    }

    /**
     * Gets the value of the recordDefaultDocAccessLevel property.
     * 
     * @return
     *     possible object is
     *     {@link RecordDefaultDocAccessLevel }
     *     
     */
    public RecordDefaultDocAccessLevel getRecordDefaultDocAccessLevel() {
        return recordDefaultDocAccessLevel;
    }

    /**
     * Sets the value of the recordDefaultDocAccessLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordDefaultDocAccessLevel }
     *     
     */
    public void setRecordDefaultDocAccessLevel(RecordDefaultDocAccessLevel value) {
        this.recordDefaultDocAccessLevel = value;
    }

    /**
     * Gets the value of the onlineTutorialCompleted property.
     * 
     * @return
     *     possible object is
     *     {@link OnlineTutorialCompleted }
     *     
     */
    public OnlineTutorialCompleted getOnlineTutorialCompleted() {
        return onlineTutorialCompleted;
    }

    /**
     * Sets the value of the onlineTutorialCompleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link OnlineTutorialCompleted }
     *     
     */
    public void setOnlineTutorialCompleted(OnlineTutorialCompleted value) {
        this.onlineTutorialCompleted = value;
    }

    /**
     * Gets the value of the accessControlPreference property.
     * 
     * @return
     *     possible object is
     *     {@link AccessControlPreference }
     *     
     */
    public AccessControlPreference getAccessControlPreference() {
        return accessControlPreference;
    }

    /**
     * Sets the value of the accessControlPreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccessControlPreference }
     *     
     */
    public void setAccessControlPreference(AccessControlPreference value) {
        this.accessControlPreference = value;
    }

}
