
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentType.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="documentType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Birth Certificate"/>
 *     &lt;enumeration value="Secondary Document"/>
 *     &lt;enumeration value="Australian Passport"/>
 *     &lt;enumeration value="Overseas Passport"/>
 *     &lt;enumeration value="Australian Citizenship Certificate"/>
 *     &lt;enumeration value="Australian Armed Service Papers"/>
 *     &lt;enumeration value="IdentityVerificationMethod1"/>
 *     &lt;enumeration value="IdentityVerificationMethod2"/>
 *     &lt;enumeration value="IdentityVerificationMethod3"/>
 *     &lt;enumeration value="IdentityVerificationMethod4"/>
 *     &lt;enumeration value="IdentityVerificationMethod5"/>
 *     &lt;enumeration value="IdentityVerificationMethod6"/>
 *     &lt;enumeration value="IdentityVerificationMethod7"/>
 *     &lt;enumeration value="IdentityVerificationMethod8"/>
 *     &lt;enumeration value="IdentityVerificationMethod9"/>
 *     &lt;enumeration value="IdentityVerificationMethod10"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "documentType")
@XmlEnum
public enum DocumentType {

    @XmlEnumValue("Birth Certificate")
    BIRTH_CERTIFICATE("Birth Certificate"),
    @XmlEnumValue("Secondary Document")
    SECONDARY_DOCUMENT("Secondary Document"),
    @XmlEnumValue("Australian Passport")
    AUSTRALIAN_PASSPORT("Australian Passport"),
    @XmlEnumValue("Overseas Passport")
    OVERSEAS_PASSPORT("Overseas Passport"),
    @XmlEnumValue("Australian Citizenship Certificate")
    AUSTRALIAN_CITIZENSHIP_CERTIFICATE("Australian Citizenship Certificate"),
    @XmlEnumValue("Australian Armed Service Papers")
    AUSTRALIAN_ARMED_SERVICE_PAPERS("Australian Armed Service Papers"),
    @XmlEnumValue("IdentityVerificationMethod1")
    IDENTITY_VERIFICATION_METHOD_1("IdentityVerificationMethod1"),
    @XmlEnumValue("IdentityVerificationMethod2")
    IDENTITY_VERIFICATION_METHOD_2("IdentityVerificationMethod2"),
    @XmlEnumValue("IdentityVerificationMethod3")
    IDENTITY_VERIFICATION_METHOD_3("IdentityVerificationMethod3"),
    @XmlEnumValue("IdentityVerificationMethod4")
    IDENTITY_VERIFICATION_METHOD_4("IdentityVerificationMethod4"),
    @XmlEnumValue("IdentityVerificationMethod5")
    IDENTITY_VERIFICATION_METHOD_5("IdentityVerificationMethod5"),
    @XmlEnumValue("IdentityVerificationMethod6")
    IDENTITY_VERIFICATION_METHOD_6("IdentityVerificationMethod6"),
    @XmlEnumValue("IdentityVerificationMethod7")
    IDENTITY_VERIFICATION_METHOD_7("IdentityVerificationMethod7"),
    @XmlEnumValue("IdentityVerificationMethod8")
    IDENTITY_VERIFICATION_METHOD_8("IdentityVerificationMethod8"),
    @XmlEnumValue("IdentityVerificationMethod9")
    IDENTITY_VERIFICATION_METHOD_9("IdentityVerificationMethod9"),
    @XmlEnumValue("IdentityVerificationMethod10")
    IDENTITY_VERIFICATION_METHOD_10("IdentityVerificationMethod10");
    private final String value;

    DocumentType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DocumentType fromValue(String v) {
        for (DocumentType c: DocumentType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
