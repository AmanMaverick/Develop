
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the au.pcehr.ws.pna.common package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: au.pcehr.ws.pna.common
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PnaCommonParams }
     * 
     */
    public PnaCommonParams createPnaCommonParams() {
        return new PnaCommonParams();
    }

    /**
     * Create an instance of {@link PcehrCommonParameters }
     * 
     */
    public PcehrCommonParameters createPcehrCommonParameters() {
        return new PcehrCommonParameters();
    }

    /**
     * Create an instance of {@link PcehrRecordCommonParameters }
     * 
     */
    public PcehrRecordCommonParameters createPcehrRecordCommonParameters() {
        return new PcehrRecordCommonParameters();
    }

    /**
     * Create an instance of {@link PcehrIdentity }
     * 
     */
    public PcehrIdentity createPcehrIdentity() {
        return new PcehrIdentity();
    }

    /**
     * Create an instance of {@link ApplicationResponse }
     * 
     */
    public ApplicationResponse createApplicationResponse() {
        return new ApplicationResponse();
    }

    /**
     * Create an instance of {@link SecurityDashboardRepresentative }
     * 
     */
    public SecurityDashboardRepresentative createSecurityDashboardRepresentative() {
        return new SecurityDashboardRepresentative();
    }

    /**
     * Create an instance of {@link PcehrProfile }
     * 
     */
    public PcehrProfile createPcehrProfile() {
        return new PcehrProfile();
    }

    /**
     * Create an instance of {@link SePcehrProfile }
     * 
     */
    public SePcehrProfile createSePcehrProfile() {
        return new SePcehrProfile();
    }

    /**
     * Create an instance of {@link EcnAttributeList }
     * 
     */
    public EcnAttributeList createEcnAttributeList() {
        return new EcnAttributeList();
    }

    /**
     * Create an instance of {@link PCEHRDetails }
     * 
     */
    public PCEHRDetails createPCEHRDetails() {
        return new PCEHRDetails();
    }

    /**
     * Create an instance of {@link ReqCommonParameters }
     * 
     */
    public ReqCommonParameters createReqCommonParameters() {
        return new ReqCommonParameters();
    }

    /**
     * Create an instance of {@link ConsentAttributeList }
     * 
     */
    public ConsentAttributeList createConsentAttributeList() {
        return new ConsentAttributeList();
    }

    /**
     * Create an instance of {@link AccessNotifcation }
     * 
     */
    public AccessNotifcation createAccessNotifcation() {
        return new AccessNotifcation();
    }

    /**
     * Create an instance of {@link Authority }
     * 
     */
    public Authority createAuthority() {
        return new Authority();
    }

    /**
     * Create an instance of {@link Document }
     * 
     */
    public Document createDocument() {
        return new Document();
    }

    /**
     * Create an instance of {@link Name }
     * 
     */
    public Name createName() {
        return new Name();
    }

    /**
     * Create an instance of {@link DetailedPcehrIdentity }
     * 
     */
    public DetailedPcehrIdentity createDetailedPcehrIdentity() {
        return new DetailedPcehrIdentity();
    }

    /**
     * Create an instance of {@link GetPCEHRIdentityReqCommonParameters }
     * 
     */
    public GetPCEHRIdentityReqCommonParameters createGetPCEHRIdentityReqCommonParameters() {
        return new GetPCEHRIdentityReqCommonParameters();
    }

    /**
     * Create an instance of {@link DetailedAuthority }
     * 
     */
    public DetailedAuthority createDetailedAuthority() {
        return new DetailedAuthority();
    }

    /**
     * Create an instance of {@link CommonParameters }
     * 
     */
    public CommonParameters createCommonParameters() {
        return new CommonParameters();
    }

    /**
     * Create an instance of {@link DetailedDemographics }
     * 
     */
    public DetailedDemographics createDetailedDemographics() {
        return new DetailedDemographics();
    }

    /**
     * Create an instance of {@link Individual }
     * 
     */
    public Individual createIndividual() {
        return new Individual();
    }

    /**
     * Create an instance of {@link Pcehrrecord }
     * 
     */
    public Pcehrrecord createPcehrrecord() {
        return new Pcehrrecord();
    }

    /**
     * Create an instance of {@link SetPcehrIdentity }
     * 
     */
    public SetPcehrIdentity createSetPcehrIdentity() {
        return new SetPcehrIdentity();
    }

    /**
     * Create an instance of {@link CommonOIMParameters }
     * 
     */
    public CommonOIMParameters createCommonOIMParameters() {
        return new CommonOIMParameters();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link SecurityDashboardOrgList }
     * 
     */
    public SecurityDashboardOrgList createSecurityDashboardOrgList() {
        return new SecurityDashboardOrgList();
    }

    /**
     * Create an instance of {@link DetailedPcehrRecord }
     * 
     */
    public DetailedPcehrRecord createDetailedPcehrRecord() {
        return new DetailedPcehrRecord();
    }

    /**
     * Create an instance of {@link SecurityDashboardPcehrDetails }
     * 
     */
    public SecurityDashboardPcehrDetails createSecurityDashboardPcehrDetails() {
        return new SecurityDashboardPcehrDetails();
    }

    /**
     * Create an instance of {@link Demographics }
     * 
     */
    public Demographics createDemographics() {
        return new Demographics();
    }

}
