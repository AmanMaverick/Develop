
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for dateOfBirthAccuracyIndicator.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="dateOfBirthAccuracyIndicator">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="AAA"/>
 *     &lt;enumeration value="AAE"/>
 *     &lt;enumeration value="AAU"/>
 *     &lt;enumeration value="AEA"/>
 *     &lt;enumeration value="AEE"/>
 *     &lt;enumeration value="AEU"/>
 *     &lt;enumeration value="AUA"/>
 *     &lt;enumeration value="AUE"/>
 *     &lt;enumeration value="AUU"/>
 *     &lt;enumeration value="EAA"/>
 *     &lt;enumeration value="EAE"/>
 *     &lt;enumeration value="EAU"/>
 *     &lt;enumeration value="EEA"/>
 *     &lt;enumeration value="EEE"/>
 *     &lt;enumeration value="EEU"/>
 *     &lt;enumeration value="EUA"/>
 *     &lt;enumeration value="EUE"/>
 *     &lt;enumeration value="EUU"/>
 *     &lt;enumeration value="UAA"/>
 *     &lt;enumeration value="UAE"/>
 *     &lt;enumeration value="UAU"/>
 *     &lt;enumeration value="UEA"/>
 *     &lt;enumeration value="UEE"/>
 *     &lt;enumeration value="UEU"/>
 *     &lt;enumeration value="UUA"/>
 *     &lt;enumeration value="UUE"/>
 *     &lt;enumeration value="UUU"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "dateOfBirthAccuracyIndicator")
@XmlEnum
public enum DateOfBirthAccuracyIndicator {

    AAA,
    AAE,
    AAU,
    AEA,
    AEE,
    AEU,
    AUA,
    AUE,
    AUU,
    EAA,
    EAE,
    EAU,
    EEA,
    EEE,
    EEU,
    EUA,
    EUE,
    EUU,
    UAA,
    UAE,
    UAU,
    UEA,
    UEE,
    UEU,
    UUA,
    UUE,
    UUU;

    public String value() {
        return name();
    }

    public static DateOfBirthAccuracyIndicator fromValue(String v) {
        return valueOf(v);
    }

}
