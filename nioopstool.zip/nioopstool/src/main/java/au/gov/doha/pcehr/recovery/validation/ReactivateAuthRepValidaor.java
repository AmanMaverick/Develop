package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepBO;
import au.gov.doha.pcehr.recovery.dao.ReactiveAuthRepDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


/**
 * @author Vikash Kumar Singh
 * Validates Reactivate AuthRep data.
 */
public class ReactivateAuthRepValidaor implements Validator{
    
    private static Logger LOG = Logger.getLogger(ReactivateAuthRepValidaor.class);
    
    
    @Autowired
    @Qualifier("ReactiveAuthRepDAO")
    ReactiveAuthRepDAO reactiveAuthRepDAO;
    
    @Override
    public boolean supports(Class<?> class1) {
        return ReactivateAuthRepBO.class.equals(class1);
    }

    @Override
    public void validate(Object object, Errors errors) {
        if(object instanceof ReactivateAuthRepBO){
            ReactivateAuthRepBO ReactivateAuthRepObj = (ReactivateAuthRepBO)object;
            LOG.debug("Request IHI ............. = "+ReactivateAuthRepObj.getIhi());
            
            try{
                errors = ValidateUpdateOperation(ReactivateAuthRepObj,errors); 
            }catch(Exception e){
               LOG.error("Exception occured",e);
            }       
        }else {
            LOG.debug("Invalid parameter !!!");
        }
        
    }
    /**
     *
     * @param form
     * @param errors
     * @return
     */
    private Errors ValidateUpdateOperation(ReactivateAuthRepBO form, Errors errors) throws RecoveryDAOException {
        //Blank validation for ihi, rep_ihi and rel_type
        ValidationUtils.rejectIfEmpty(errors, "ihi", "ReactivateAuthRepBO");
        ValidationUtils.rejectIfEmpty(errors, "rep_ihi", "ReactivateAuthRepBO");
        ValidationUtils.rejectIfEmpty(errors, "rel_type", "ReactivateAuthRepBO");

        //IHI - 16 digit validation
        if (form.getIhi() != null && (!form.getIhi().matches("[0-9]{16}"))) {
            errors.rejectValue("ihi", "ReactivateAuthRepBO.ihiLength");
        } else if (form.getRep_ihi() != null && form.getIhi() != null && form.getRep_ihi().equals(form.getIhi()) &&
                   !form.getRep_ihi().trim().equals("") && !form.getIhi().trim().equals("")) {
            //Representative IHI and IHI should not be equal
            errors.rejectValue("ihi", "ReactivateAuthRepBO.sameValue");

        } else if(!form.getRel_type().trim().equals("")) {
            int statusCode = reactiveAuthRepDAO.getStatus(form.getIhi());
            // IHI in DB - found/not found; statusCode = 0:found
            if (statusCode > 0) {
                errors.rejectValue("ihi",statusCode == 1 ? "ReactivateAuthRepBO.IHIStatus" : "ReactivateAuthRepBO.IHINoRecord");
            }
        }
        //REP_IHI - 16 digit validation
        if (form.getRep_ihi() != null && !form.getRep_ihi().matches("[0-9]{16}")) {
            errors.rejectValue("ihi", "ReactivateAuthRepBO.RepIHILength");
        }
        return errors;
    }
}
