package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ConsumerRegistrationOIDForm;
import au.gov.doha.pcehr.recovery.service.ConsumerRegistrationOIDService;
import au.gov.doha.pcehr.recovery.validation.ConsumerRegistrationOIDValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Controller class to perform all ConsumerRegistrationOID related task.
 * Redirects to Consumer Registration OID operations and later on submit to Consumer Registration OID List.
 * @Since Apr 2015
 * @Author Dinesh Kaki, Operations, PCEHR
 * @version Change-x
 */


@Controller
@RequestMapping("/ConsumerRegistrationOID**")
public class ConsumerRegistrationOIDController {
    
    private static Logger LOG = Logger.getLogger(ConsumerRegistrationOIDController.class);
    private static final String MAIN_PAGE_LINK = "/NIO/ConsumerRegistrationOID";
    private static final String MODEL_ATTRIBUTE = "ConsumerRegistrationOID";
    private static final String FINAL_PAGE_LINK = "/NIO/ConsumerRegistrationOIDList";
    private static final String PAGE_EXCEPTION = "NIO/Exception";
   

    @Autowired
    private ConsumerRegistrationOIDService consumerRegistrationOIDService;

    @Autowired
    private ConsumerRegistrationOIDValidator consumerRegistrationOIDValidator;

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(consumerRegistrationOIDValidator);
    }
       

    /** 
     * This method is called when user clicks on Consumer Registration in Work around menu section.
     * @param consumerRegistrationOIDForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.CONSUMER_REGISTRATION_OID_LANDINGPAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/ConsumerRegistrationOID")
    public String ConsumerRegistrationOIDMenu(@ModelAttribute(MODEL_ATTRIBUTE)
        ConsumerRegistrationOIDForm consumerRegistrationOIDForm) {
        LOG.debug("Inside Consumer Registration page");
        return MAIN_PAGE_LINK;
    }

    /**
     * This method is called when user clicks submit in the Workaround Operations section.
     * @param consumerRegistrationOIDForm
     * @param result
     * @return
     * @throws RecoveryDAOException
     */
    @AuditBefore(AuditMessageConstants.GET_CONSUMER_REGISTRATION_OID_LIST)
    @RequestMapping(method = RequestMethod.POST, params = "ConsumerRegistrationOIDSubmit=Submit")
    public String getConsumerRegistrationList(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        ConsumerRegistrationOIDForm consumerRegistrationOID, BindingResult result) throws RecoveryDAOException,
                                                                           RecoveryServiceException {
        if (result.hasErrors()) {
            LOG.debug("Validation Error on ConsumerRegistrationOIDSubmit :: " + result.hasErrors());
            return MAIN_PAGE_LINK;
        }
        LOG.debug("No Errors");
        consumerRegistrationOID = consumerRegistrationOIDService.consumerRegistrationServiceMethod(consumerRegistrationOID);
        LOG.debug("Leaving Controller Class ");
        return FINAL_PAGE_LINK;
    }



    /**
     * This method is called when ServiceException occurs.
     * @param ex
     * @return model
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(Exception e) {
        LOG.info("DAO_Exception handler......");
        ModelAndView model = new ModelAndView(PAGE_EXCEPTION);
        model.addObject("errorMsg", e.getMessage());
        LOG.debug("e.getMessage().............." + e.getMessage());
        return model;
    }
}
