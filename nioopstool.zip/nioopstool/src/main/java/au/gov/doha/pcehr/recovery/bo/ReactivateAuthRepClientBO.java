package au.gov.doha.pcehr.recovery.bo;


public class ReactivateAuthRepClientBO {
    private String recordIHI;
    private String userID;
    private String created_by;
    private String rel_type;
    private int auth_type;
    private String auth_issue;
    private String auth_startdate;
    private int docType;
    private String transactionID;
    private String sourceSystemID;

    public void setRecordIHI(String recordIHI) {
        this.recordIHI = recordIHI;
    }

    public String getRecordIHI() {
        return recordIHI;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setRel_type(String rel_type) {
        this.rel_type = rel_type;
    }

    public String getRel_type() {
        return rel_type;
    }

    public void setAuth_type(int auth_type) {
        this.auth_type = auth_type;
    }

    public int getAuth_type() {
        return auth_type;
    }

    public void setAuth_issue(String auth_issue) {
        this.auth_issue = auth_issue;
    }

    public String getAuth_issue() {
        return auth_issue;
    }

    public void setAuth_startdate(String auth_startdate) {
        this.auth_startdate = auth_startdate;
    }

    public String getAuth_startdate() {
        return auth_startdate;
    }

    public void setDocType(int docType) {
        this.docType = docType;
    }

    public int getDocType() {
        return docType;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setSourceSystemID(String sourceSystemID) {
        this.sourceSystemID = sourceSystemID;
    }

    public String getSourceSystemID() {
        return sourceSystemID;
    }
}
