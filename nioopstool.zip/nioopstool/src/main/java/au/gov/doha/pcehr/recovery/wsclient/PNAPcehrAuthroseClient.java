package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.bo.AuthoriseClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.ws.pna.authorise.AuthoriseFunctionalParams;
import au.pcehr.ws.pna.authorise.AuthoriseParameterListType;
import au.pcehr.ws.pna.authorise.OESFunctionalAuthoriseRequest;
import au.pcehr.ws.pna.authorise.OESFunctionalAuthoriseResponse;
import au.pcehr.ws.pna.authorise.PNAPCEHRAuthorisePort;
import au.pcehr.ws.pna.authorise.PNAPCEHRAuthoriseWS;
import au.pcehr.ws.pna.common.AccessChannelVal;
import au.pcehr.ws.pna.common.ActionVal;
import au.pcehr.ws.pna.common.CommonParams;
import au.pcehr.ws.pna.common.SubjectTypeVal;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.Map;

import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PNAPcehrAuthroseClient {
     @Autowired
     Decrypter decrypter;
     private static Logger LOG = Logger.getLogger(PNAPcehrAuthroseClient.class);
     
    private OESFunctionalAuthoriseResponse oESFunctionalAuthoriseResponse;
    
     @Autowired
     private TestHostnameVerifier testHostnameVerifier;
     
     @Autowired
     private WSClientHandlerResolver wsClientHandlerResolver;

     public void setOESFunctionalAuthoriseResponse(OESFunctionalAuthoriseResponse oESFunctionalAuthoriseResponse) {
         this.oESFunctionalAuthoriseResponse = oESFunctionalAuthoriseResponse;
     }

     public OESFunctionalAuthoriseResponse getOESFunctionalAuthoriseResponse() {
         return oESFunctionalAuthoriseResponse;
     }
    
    /**
     * 
     */
    public void pnaPcehrAuthorise(AuthoriseClientBO authoriseClientBO){
        try{
            PNAPCEHRAuthoriseWS pNAPCEHRAuthoriseWS = new PNAPCEHRAuthoriseWS();
            pNAPCEHRAuthoriseWS.setHandlerResolver(wsClientHandlerResolver);
            PNAPCEHRAuthorisePort pNAPCEHRAuthorisePort = pNAPCEHRAuthoriseWS.getPNAPCEHRAuthorisePort();
            Map<String, Object> requestContext = ((BindingProvider) pNAPCEHRAuthorisePort).getRequestContext();
            requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,EndPointsConstants.PNA_OES_AC_ENDPOINT);
            requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_AUTH_USERNAME));
            requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_AUTH_PWD));
            OESFunctionalAuthoriseRequest oESFunctionalAuthoriseRequest = new OESFunctionalAuthoriseRequest();        
            AuthoriseParameterListType authoriseParameterListType = getAuthoriseParameterListType(authoriseClientBO);
            LOG.debug("fsdfsdfsdf"+authoriseParameterListType.getCommonParameters().getAccessChannel());
            oESFunctionalAuthoriseRequest.setParameterList(authoriseParameterListType);
            this.oESFunctionalAuthoriseResponse = pNAPCEHRAuthorisePort.oesFunctionalAuthorise(oESFunctionalAuthoriseRequest);
        }catch(Exception e){
            LOG.fatal("Exception occured",e);
        }
     
            
            
    }
  
    /**
     *
     * @return
     */
    private AuthoriseParameterListType getAuthoriseParameterListType(AuthoriseClientBO authoriseClientBO){
        AuthoriseParameterListType authoriseParameterListType = new AuthoriseParameterListType();
        
        authoriseParameterListType.setCommonParameters(getCommonParams(authoriseClientBO));
        authoriseParameterListType.setFunctionalParameters(getAuthoriseFunctionalParams());
        return authoriseParameterListType;
    }
    /**
     *
     * @return
     */
    private AuthoriseFunctionalParams getAuthoriseFunctionalParams(){
        AuthoriseFunctionalParams authoriseFunctionalParams= new AuthoriseFunctionalParams();
   
        authoriseFunctionalParams.setResourceDomain("PCEHR");
        authoriseFunctionalParams.setResourceID("PCEHRIdentity");
        authoriseFunctionalParams.setResourcePath("PARTICIPATION_DB");
        authoriseFunctionalParams.setAction(ActionVal.CHECK_AR_RESTRICTION);
      
        return authoriseFunctionalParams;
    }
    /**
     *
     * @return
     */
    private CommonParams getCommonParams(AuthoriseClientBO authoriseClientBO){
        CommonParams commonParams = new CommonParams();
        commonParams.setTransactionID("uuid:b622f90d-ec3d-41fc-a6fe-6b7caadbd5df");
        commonParams.setSourceSystemID("ADM001");
        commonParams.setSubjectID("00000000");
        commonParams.setSubjectType(SubjectTypeVal.PCEHR_IDENTITY);
        LOG.debug("authoriseClientBO.getIhi()"+authoriseClientBO.getIhi());
        commonParams.setIHI(authoriseClientBO.getIhi());
        commonParams.setAccessChannel(AccessChannelVal.ADM);
        return commonParams;
    }
    
 }

