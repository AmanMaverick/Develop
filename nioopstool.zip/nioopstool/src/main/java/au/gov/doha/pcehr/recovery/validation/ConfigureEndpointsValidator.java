package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.bo.ConfigureEndpointsBO;

import org.apache.log4j.Logger;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class ConfigureEndpointsValidator implements Validator{
    public ConfigureEndpointsValidator() {
        super();
    }
    private static Logger LOG = Logger.getLogger(ConfigureEndpointsValidator.class);

    @Override
    public boolean supports(Class<?> c) {
        // TODO Implement this method
        
        return ConfigureEndpointsBO.class.equals(c);
    }

    @Override
    public void validate(Object object, Errors errors) {
        // TODO Implement this method
        LOG.debug("entring validator method of ConfigureEndpointsValidator ");
    
        ValidationUtils.rejectIfEmpty(errors, "persistAtomicData", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "deprecateAtomicData", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "updateDocumentStatus", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "getDocumentList", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaOIMDisable", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "synchroniseIHI", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaCreateAuthRep", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "auditInsert", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaARRestrict", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaAuthoriseRestrict", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaCleanIndividualProfile", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "removeDocument", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaUpdateNominated", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "unremoveDocument", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaUpdateAuth", "ConfigureEndPointsAttribute");
    
        ValidationUtils.rejectIfEmpty(errors, "pnaEndPoint", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "getDocumentHTB", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "getDocumentOAG", "ConfigureEndPointsAttribute");
      
        ValidationUtils.rejectIfEmpty(errors, "osbPassword", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "osbUsername", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaAuthUsername", "ConfigureEndPointsAttribute"); 
        ValidationUtils.rejectIfEmpty(errors, "pnaPassword", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaUsername", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaAuthPassword", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "htbPassword", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "htbUsername", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "oagUsername", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "oagPassword", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaOIMDisablePassword", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "pnaOIMDisableUsername", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "webLogicJndiNameHTB", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "webLogicJndiNamePNA", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "webLogicJndiNameRLS", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "webLogicJndiNameOSB", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "webLogicJndiNameOIM", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "initialContextFactory", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "hostName", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "webLogicProviderUrl", "ConfigureEndPointsAttribute");
        
        //TIP
        ValidationUtils.rejectIfEmpty(errors, "searchIHI", "ConfigureEndPointsAttribute");
        ValidationUtils.rejectIfEmpty(errors, "osbRegisterPcehr", "ConfigureEndPointsAttribute");
        //product version
        ValidationUtils.rejectIfEmpty(errors, "productVersion", "ConfigureEndPointsAttribute");
        LOG.debug("Leaving validator method of ConfigureEndpointsValidator ");
        

    }
}
