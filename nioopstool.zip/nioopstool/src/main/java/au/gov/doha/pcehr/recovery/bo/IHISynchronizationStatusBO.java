package au.gov.doha.pcehr.recovery.bo;


public class IHISynchronizationStatusBO {
    private String ihi;
    private String code;
    private String status;
    private String statusMessage;


    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }
}
