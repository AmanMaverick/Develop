package au.gov.doha.pcehr.recovery.bo;

import java.sql.Date;

public class EmergencyAccessExpiryBO {
    private String relationshipParty;
    private String ihi;
    private String givenName;
    private String familyName;
    private Date dob;
    private Date relationShipStartDate;


    public void setRelationshipParty(String relationshipParty) {
        this.relationshipParty = relationshipParty;
    }

    public String getRelationshipParty() {
        return relationshipParty;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Date getDob() {
        return dob;
    }

    public void setRelationShipStartDate(Date relationShipStartDate) {
        this.relationShipStartDate = relationShipStartDate;
    }

    public Date getRelationShipStartDate() {
        return relationShipStartDate;
    }
}
