package au.gov.doha.pcehr.recovery.util;


import au.gov.doha.pcehr.recovery.bo.ARrestrictionBO;
import au.gov.doha.pcehr.recovery.bo.DocTransformationErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.bo.FileTransferBO;
import au.gov.doha.pcehr.recovery.bo.HealthRecordExtractionErrorBO;
import au.gov.doha.pcehr.recovery.bo.IdentityBlobDocs;
import au.gov.doha.pcehr.recovery.bo.IdentityRecordRemovalResponseBO;
import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;
import au.gov.doha.pcehr.recovery.constants.DTFolderLocationConstants;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.constants.HealthRecordExtractionConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.DisableEnableEntitiesForm;
import au.gov.doha.pcehr.recovery.form.IdentityRecordRemovalForm;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import weblogic.servlet.MimeTypes;


/**
 * This utility class will perform all file related stuffs
 * like - Get file from Blob bytes,Zip all the files as a single package,
 * Get file type from the file bytes.
 * @author Vikash Kumar Singh,Sumanta Kumar Saha  Operations, PCEHR
 * @since 02nd Jan 2015
 * @version Change-x
 */
@Component
public class FileUtil {

    private static Logger LOG = Logger.getLogger(FileUtil.class);
    private static final Map<String, String> mimeTypes = new HashMap<String, String>();
    private static final String DHS_FILE_FORMAT = "MHR_Opt-Out_Trial_Data_Extract";
    private static final String FILE_NAME_DATE_FORMAT = "yyyyMMddHHmmss";
    private static final String UNDERSCORE = "_";
    private static final String DOT = ".";
    private static final String ONLY_NUMBER_PATTERN = "^[0-9]*$";

    @Autowired
    Decrypter decrypter;
    @Autowired
    FileChecksum fileCheckSum;
    @Autowired
    DateTimeUtil dateTimeUtil;
    /**
     *   File transfer success message
     */
    private static final String FILE_TRANSFER_SUCCESSFULL_MESSAGE = "File Transfer is Successful";

    /**
     *   File format is not valid error message
     */
    private static final String FILE_FORMAT_ERROR = "Latest File Does not has .txt format";

    /**
     * No file found in the directory error message
     */
    private static final String FILE_TRANSFER_FILE_NOT_FOUND_MESSAGE = "No File found in the directory";

    /**
     * Checksum mismatch error message
     */
    private static final String CHECK_SUM_ERROR_MISMATCH_ERROR_MESSAGE = "CheckSum Mismatch";

    /**
     *sha-256sum checksum Command syntax
     */
    private static final String CHECKSUM_SHA256_COMMAND = "sha256sum ";

    /**
     * SCP Command syntax
     */
    private static final String SCP_COMMAND = "scp ";

    /**
     *File Read SCP Command syntax
     */
    private static final String SCP_COMMAND_FILE_READ = "scp -f ";

    /**
     *Session chanel type to open the jsch session
     */
    private static final String SESSION_CHANLE_TYPE = "exec";

    /**
     *ls Command syntax
     */
    private static final String LS_COMMAND = "ls ";

    /**
     * Character set as utf-8
     */
    private static final String CHAR_SET_UTF_8 = "UTF-8";

    /**
     *This method is used to get java.io.File from byte array of the blob document
     * @param document
     * @return
     * @throws Exception
     */
    public File getBytesFile(IdentityBlobDocs document) throws Exception {
        File file = null;
        FileOutputStream fos = null;

        String filename = getFileNameByType(document);
        if (filename == null) {
            return null;
        }
        try {
            file = new File(filename);
            fos = new FileOutputStream(file);
        } catch (Exception e) {
            LOG.error(e.getLocalizedMessage(), e);
            throw e;
        } finally {
            fos.write(document.getBlobdocs());
            fos.flush();
            fos.close();
        }

        return file;
    }

    /**
     * This method will put all files in a single zip File and propt user to save zip file
     * @param response
     * @param bundle
     */
    public void writeZipResponse(HttpServletResponse response, List<File> bundle) throws Exception {
        try {
            ByteArrayOutputStream bout = new ByteArrayOutputStream();
            ZipOutputStream zout = new ZipOutputStream(bout);
            ServletOutputStream out = response.getOutputStream();
            Date dat = new Date();
            //ddMMyyyyhhmmss
            SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd_hh_mm_ss");
            String date = ft.format(dat);

            for (File file : bundle) {
                FileInputStream fi = new FileInputStream(file);
                byte bytes[] = new byte[(int) file.length()];

                // Read in the bytes
                int offset = 0;
                int numRead = 0;
                while (offset < bytes.length && (numRead = fi.read(bytes, offset, bytes.length - offset)) >= 0) {
                    offset += numRead;
                }
                // Ensure all the bytes have been read in
                if (offset < bytes.length) {
                    throw new IOException("Could not completely read file " + file.getName());
                }
                fi.close();


                ZipEntry zipEntry = new ZipEntry(file.getName());
                //zipEntry.setCompressedSize(file.length());
                zipEntry.setSize(offset);
                CRC32 crc = new CRC32();
                crc.update(bytes);
                zipEntry.setCrc(crc.getValue());
                zout.putNextEntry(zipEntry);
                zout.write(bytes, 0, offset);
                zout.closeEntry();

                fi.close();
            }
            zout.finish();
            zout.close();

            response.setContentType("application/zip");
            response.setHeader("Content-Disposition", "attachment; filename=ARTExtract_" + date + ".zip;");
            out.write(bout.toByteArray());
            out.flush();
            out.close();

        } catch (IOException e) {
            LOG.error(e.getLocalizedMessage(), e);
            throw e;
        }
    }

    /**
     *This method is used to get the type of the file using byte Array details or name of the file.
     * @param data
     * @param name
     * @return
     */
    public static String getContentType(byte[] data, String name) {
        if (data == null) {
            return null;
        }
        byte[] header = new byte[11];
        System.arraycopy(data, 0, header, 0, Math.min(data.length, header.length));
        int c1 = header[0] & 0xff;
        int c2 = header[1] & 0xff;
        int c3 = header[2] & 0xff;
        int c4 = header[3] & 0xff;
        int c5 = header[4] & 0xff;
        int c6 = header[5] & 0xff;
        int c7 = header[6] & 0xff;
        int c8 = header[7] & 0xff;
        int c9 = header[8] & 0xff;
        int c10 = header[9] & 0xff;
        int c11 = header[10] & 0xff;
        LOG.debug(c1 + "--" + c2 + "--" + c3 + "--" + c4 + "--" + c5 + "--" + c6 + "--" + c7);
        if (c1 == 0xCA && c2 == 0xFE && c3 == 0xBA && c4 == 0xBE) {
            return "application/java-vm";
        }
        if (c1 == 0xD0 && c2 == 0xCF && c3 == 0x11 && c4 == 0xE0 && c5 == 0xA1 && c6 == 0xB1 && c7 == 0x1A &&
            c8 == 0xE1) {
            // if the name is set then check if it can be validated by name, because it could be a xls or powerpoint
            String contentType = guessContentTypeFromName(name);
            if (contentType != null) {
                return contentType;
            }
            return "application/msword";
        }
        if ((c1 == 0x25 && c2 == 0x50 && c3 == 0x44 && c4 == 0x46 && c5 == 0x2d && c6 == 0x31 && c7 == 0x2e)
            // || (c1 == 0 && c2 == 0 && c3 == 0 && c4 == 0 && c5 == 0 && c6 == 0 && c7 == 0)
            ) {
            return "application/pdf";
        }
        if (c1 == 0x38 && c2 == 0x42 && c3 == 0x50 && c4 == 0x53 && c5 == 0x00 && c6 == 0x01) {
            return "image/photoshop";
        }
        if (c1 == 0x25 && c2 == 0x21 && c3 == 0x50 && c4 == 0x53) {
            return "application/postscript";
        }
        if (c1 == 0xff && c2 == 0xfb && c3 == 0x30) {
            return "audio/mp3";
        }
        if (c1 == 0x49 && c2 == 0x44 && c3 == 0x33) {
            return "audio/mp3";
        }
        if (c1 == 0xAC && c2 == 0xED) {
            // next two bytes are version number, currently 0x00 0x05
            return "application/x-java-serialized-object";
        }
        if (c1 == '<') {
            if (c2 == '!' ||
                ((c2 == 'h' && (c3 == 't' && c4 == 'm' && c5 == 'l' || c3 == 'e' && c4 == 'a' && c5 == 'd') ||
                  (c2 == 'b' && c3 == 'o' && c4 == 'd' && c5 == 'y'))) ||
                ((c2 == 'H' && (c3 == 'T' && c4 == 'M' && c5 == 'L' || c3 == 'E' && c4 == 'A' && c5 == 'D') ||
                  (c2 == 'B' && c3 == 'O' && c4 == 'D' && c5 == 'Y')))) {
                return "text/html";
            }
            if (c2 == '?' && c3 == 'x' && c4 == 'm' && c5 == 'l' && c6 == ' ') {
                return "application/xml";
            }
        }
        // big and little endian UTF-16 encodings, with byte order mark
        if (c1 == 0xfe && c2 == 0xff) {
            if (c3 == 0 && c4 == '<' && c5 == 0 && c6 == '?' && c7 == 0 && c8 == 'x') {
                return "application/xml";
            }
        }
        if (c1 == 0xff && c2 == 0xfe) {
            if (c3 == '<' && c4 == 0 && c5 == '?' && c6 == 0 && c7 == 'x' && c8 == 0) {
                return "application/xml";
            }
        } else if (c1 == 60 && c2 == 110 && c3 == 115 && c4 == 48 && c5 == 58 && c6 == 80 && c7 == 67) {
            return "application/xml";
        }

        if (c1 == 'B' && c2 == 'M') {
            return "image/bmp";
        }
        if (c1 == 0x49 && c2 == 0x49 && c3 == 0x2a && c4 == 0x00) {
            return "image/tiff";
        }
        if (c1 == 0x4D && c2 == 0x4D && c3 == 0x00 && c4 == 0x2a) {
            return "image/tiff";
        }
        if (c1 == 'G' && c2 == 'I' && c3 == 'F' && c4 == '8') {
            return "image/gif";
        }
        if (c1 == '#' && c2 == 'd' && c3 == 'e' && c4 == 'f') {
            return "image/x-bitmap";
        }
        if (c1 == '!' && c2 == ' ' && c3 == 'X' && c4 == 'P' && c5 == 'M' && c6 == '2') {
            return "image/x-pixmap";
        }
        if (c1 == 137 && c2 == 80 && c3 == 78 && c4 == 71 && c5 == 13 && c6 == 10 && c7 == 26 && c8 == 10) {
            return "image/png";
        }
        if (c1 == 0xFF && c2 == 0xD8 && c3 == 0xFF) {
            if (c4 == 0xE0) {
                return "image/jpeg";
            }
            /**
     * File format used by digital cameras to store images. Exif Format can be read by any application supporting JPEG. Exif Spec can be found at:
     * http://www.pima.net/standards/it10/PIMA15740/Exif_2-1.PDF
     */
            if ((c4 == 0xE1) && (c7 == 'E' && c8 == 'x' && c9 == 'i' && c10 == 'f' && c11 == 0)) {
                return "image/jpeg";
            }
            if (c4 == 0xEE) {
                return "image/jpg";
            }
        }
        /**
     * According to http://www.opendesign.com/files/guestdownloads/OpenDesign_Specification_for_.dwg_files.pdf
     * first 6 bytes are of type "AC1018" (for example) and the next 5 bytes are 0x00.
     */
        if ((c1 == 0x41 && c2 == 0x43) && (c7 == 0x00 && c8 == 0x00 && c9 == 0x00 && c10 == 0x00 && c11 == 0x00)) {
            return "application/acad";
        }
        if (c1 == 0x2E && c2 == 0x73 && c3 == 0x6E && c4 == 0x64) {
            return "audio/basic"; // .au
            // format,
            // big
            // endian
        }
        if (c1 == 0x64 && c2 == 0x6E && c3 == 0x73 && c4 == 0x2E) {
            return "audio/basic"; // .au
            // format,
            // little
            // endian
        }
        if (c1 == 'R' && c2 == 'I' && c3 == 'F' && c4 == 'F') {
            /*
     * I don't know if this is official but evidence suggests that .wav files start with "RIFF" - brown
     */return "audio/x-wav";
        }
        if (c1 == 'P' && c2 == 'K') {
            // its application/zip but this could be a open office thing if name is given
            String contentType = guessContentTypeFromName(name);
            if (contentType != null) {
                return contentType;
            }
            return "application/zip";
        }
        return guessContentTypeFromName(name);
    }

    /**
     *This method is used to get the file type using name of the file.
     * @param name
     * @return
     */
    public static String guessContentTypeFromName(String name) {
        if (name == null)
            return null;
        int lastIndex = name.lastIndexOf('.');
        if (lastIndex != -1) {
            String extention = name.substring(lastIndex + 1).toLowerCase();
            if (mimeTypes.size() == 0) {
                HashMap<String, String> tempMap = new HashMap<String, String>();
                InputStream is = MimeTypes.class.getResourceAsStream("mime.types.properties");
                try {
                    Properties properties = new Properties();
                    properties.load(is);
                    for (Object key : properties.keySet()) {
                        String property = properties.getProperty((String) key);
                        StringTokenizer st = new StringTokenizer(property, " ");
                        while (st.hasMoreTokens()) {
                            tempMap.put(st.nextToken(), (String) key);
                        }
                    }
                } catch (IOException e) {
                    LOG.error(e);
                } finally {
                    try {
                        is.close();
                    } catch (IOException e) {
                        LOG.error(e);
                    }
                }
                synchronized (mimeTypes) {
                    mimeTypes.putAll(tempMap);
                }
            }
            return mimeTypes.get(extention);
        }
        return null;
    }

    public String getFileNameByType(IdentityBlobDocs document) {
        String fileName = "";
        if (document.getFileType().contains("image/jpeg")) {
            fileName = String.valueOf(document.getDocumentId()) + ".jpeg";
        } else if (document.getFileType().contains("jpg")) {
            fileName = String.valueOf(document.getDocumentId()) + ".jpg";
        } else if (document.getFileType().contains("application/octet-stream")) {
            // source should be modified
            fileName = String.valueOf(document.getDocumentId()) + ".pdf";
        } else if (document.getFileType().contains("png")) {
            fileName = String.valueOf(document.getDocumentId()) + ".png";
        } else if (document.getFileType().contains("image/gif")) {
            fileName = String.valueOf(document.getDocumentId()) + ".gif";
        } else if (document.getFileType().contains("image/tiff")) {
            fileName = String.valueOf(document.getDocumentId()) + ".tiff";
        } else if (document.getFileType().contains("image")) {
            fileName = String.valueOf(document.getDocumentId()) + ".jpeg";
        } else if (document.getFileType().contains("pdf")) {
            fileName = String.valueOf(document.getDocumentId()) + ".pdf";
        } else if (document.getFileType().contains("zip")) {
            fileName = String.valueOf(document.getDocumentId()) + ".zip";
        } else if (document.getFileType().contains("gzip")) {
            fileName = String.valueOf(document.getDocumentId()) + ".gzip";
        } else if (document.getFileType().contains("text/plain")) {
            fileName = String.valueOf(document.getDocumentId()) + ".txt";
        } else if (document.getFileType().contains("xml")) {
            fileName = String.valueOf(document.getDocumentId()) + ".xml";
        } else if (document.getFileType().contains("text/h323")) {
            fileName = String.valueOf(document.getDocumentId()) + ".323";
        } else if (document.getFileType().contains("text/html")) {
            fileName = String.valueOf(document.getDocumentId()) + ".html";
        } else if (document.getFileType().contains("application/internet-property-stream")) {
            fileName = String.valueOf(document.getDocumentId()) + ".acx";
        } else if (document.getFileType().contains("application/postscript")) {
            fileName = String.valueOf(document.getDocumentId()) + ".ai";
        } else if (document.getFileType().contains("application/x-x509-ca-cert")) {
            fileName = String.valueOf(document.getDocumentId()) + ".txt";
        } else if (document.getFileType().contains("x-world/x-vrml")) {
            fileName = String.valueOf(document.getDocumentId()) + ".flr";
        } else if (document.getFileType().contains("video/mpeg")) {
            fileName = String.valueOf(document.getDocumentId()) + ".mpeg";
        } else if (document.getFileType().contains("audio/mid")) {
            fileName = String.valueOf(document.getDocumentId()) + ".mid ";
        } else if (document.getFileType().contains("application/msword")) {
            fileName = String.valueOf(document.getDocumentId()) + ".doc";
        } else if (document.getFileType().contains("application/x-msclip")) {
            fileName = String.valueOf(document.getDocumentId()) + ".clp";
        } else if (document.getFileType().contains("image/bmp")) {
            fileName = String.valueOf(document.getDocumentId()) + ".bmp";
        } else if (document.getFileType().contains("video/x-msvideo")) {
            fileName = String.valueOf(document.getDocumentId()) + ".avi";
        } else if (document.getFileType().contains("text")) {
            fileName = String.valueOf(document.getDocumentId()) + ".txt";
        } else if (document.getFileType().contains("application/vnd.ms-excel")) {
            fileName = String.valueOf(document.getDocumentId()) + ".xls";
        } else if (document.getFileType().contains("text/x-vcard")) {
            fileName = String.valueOf(document.getDocumentId()) + ".vcf";
        } else if (document.getFileType().contains("application/rtf")) {
            fileName = String.valueOf(document.getDocumentId()) + ".rtf";
        } else if (document.getFileType().contains("application")) {
            fileName = String.valueOf(document.getDocumentId()) + ".exe";
        } else {
            fileName = String.valueOf(document.getDocumentId()) + ".jpeg";
        }
        LOG.debug("fileName ============= :: " + fileName);
        return fileName;
    }

    //Sumanta Changes...


    /**
     *Used to create a list of IHI from the input csv file
     * @param file
     * @return
     * @throws IOException
     */
    public List<String> createList(MultipartFile file) throws Exception {
        LOG.debug("Entering createList...");
        LOG.debug("Entered into readFile");
        HashSet<String> uniqIhiSet = new HashSet<String>();
        Set<String> ihiList = new HashSet<String>();
        String csvSplitBy = ",";
        String[] ihi = null;
        InputStreamReader iStreamReader = null;
        BufferedReader bReader = null;
        try {
            iStreamReader = new InputStreamReader(file.getInputStream());
            bReader = new BufferedReader(iStreamReader);
            for (String line = bReader.readLine(); line != null; line = bReader.readLine()) {
                if (line != null && !line.equals(""))
                    ihi = line.split(csvSplitBy);
                uniqIhiSet.addAll(Arrays.asList(ihi));
            }
            ihiList.addAll(uniqIhiSet);
            LOG.debug("DOc id List size ::" + ihiList.size());

        } catch (IOException e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        } finally {
            try {
                bReader.close();
                iStreamReader.close();
            } catch (Exception e) {
                LOG.fatal("Exception occured while colosing the resources..", e);

            }
        }
        return new ArrayList<String>(ihiList);
    }


    /**
     *Used to extract the zip file and store it into the given path
     * @param bytes
     * @param docID
     * @param ihi
     * @return
     * @throws IOException
     */
    public static List<String> extractAttchement(byte[] bytes, String docID, String ihi, String deIdentification,
                                                 String destinationPath) throws IOException, IOException {
        LOG.debug("Entering extractAttchement..." + docID);
        String finalFileName = null;
        ZipInputStream zis = null;
        List<String> fileNameList = new ArrayList();
        String finalEntryFileName = null;
        try {
            if (bytes != null) {
                zis = new ZipInputStream(new ByteArrayInputStream(bytes));
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    File entryFile = null;
                    if (deIdentification.equalsIgnoreCase("yes")) {
                        LOG.debug("deIdentification.equalsIgnoreCase(\"yes\"........");
                        entryFile =
                            new File(destinationPath,
                                     FilenameUtils.removeExtension(entry.getName()) + "_DE_" + ihi.substring(12, 16) +
                                     "_" + docID.substring(docID.length() - 4, docID.length()) + ".xml");
                    } else {
                        LOG.debug("deIdentification.equalsIgnoreCase(\"no\"........");
                        entryFile =
                            new File(destinationPath,
                                     FilenameUtils.removeExtension(entry.getName()) + "_ND_" + ihi.substring(12, 16) +
                                     "_" + docID.substring(docID.length() - 4, docID.length()) + ".xml");
                    }
                    if (entry.isDirectory()) {
                        if (entryFile.exists()) {
                        } else {
                            LOG.debug("entry.isDirectory() true:::" + entryFile.getName());
                        }
                    } else {
                        LOG.debug("entry name:::::" + entry.getName());
                        finalEntryFileName = entry.getName().toString();
                        LOG.debug("entryFile.getName().toString().contains(\"ROOT\")....." +
                                  entryFile.getName().toString().contains("SIGN"));
                        if (entryFile.getName().toString().contains("ROOT")) {
                            LOG.debug("entry.isDirectory() false:::" + entryFile.getName());
                            //substring to rename the name to cda
                            finalFileName = entryFile.getName();
                            LOG.debug("after rename file name:::" + entryFile.getName());
                            if (entryFile.getParentFile() != null && !entryFile.getParentFile().exists()) {
                                LOG.debug("entry.isDirectory() false inloop 2:::" + entryFile.getName());
                                entryFile.getParentFile().mkdirs();
                            }
                            if (!entryFile.exists()) {
                                LOG.debug("file name::::" + entryFile);
                                entryFile.createNewFile();
                            }
                            OutputStream os = null;
                            try {
                                os = new FileOutputStream(entryFile);
                                IOUtils.copy(zis, os);
                            } finally {
                                IOUtils.closeQuietly(os);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOG.fatal("exception occured", e);
        } finally {
            IOUtils.closeQuietly(zis);
        }
        fileNameList.add(finalFileName);
        fileNameList.add(finalEntryFileName);
        LOG.debug("Final file name:" + finalFileName);
        LOG.debug("Final finalEntryFileName name:" + finalEntryFileName);
        LOG.debug("Leaving  extractAttchement..." + docID);
        return fileNameList;
    }

    /**
     *Used to move all the extracted files from a single folder to proper named folder accroding the IHI values
     * @param xmlFileName
     * @param fileName
     */
    public boolean moveFiles(List<String> xmlFileName, String fileName) {
        boolean flag = false;
        LOG.debug("entring moveFiles....." + fileName);
        File entryFolder = null;
        try {
            if (xmlFileName != null) {
                if (xmlFileName.get(1).contains("IHE_XDM")) {

                    entryFolder =
                        new File(DTFolderLocationConstants.WITHOUT_STYLESHEET_DOCS + "/",
                                 fileName.substring(0, fileName.length() - 5));
                    if (!entryFolder.exists()) {
                        LOG.debug("folder creation..." + entryFolder.getPath());
                        entryFolder.mkdirs();
                    }
                    File oldFile = new File(DTFolderLocationConstants.DOC_LOCATION_IHE_XDM + fileName + ".xml");

                    if (oldFile.renameTo(new File(entryFolder.getAbsolutePath() + "/" + oldFile.getName()))) {
                        LOG.debug("File is moved successful!");
                        // flag for cheking file moved succesfully for making audit for success IHI
                        LOG.debug("audit required flag is true");
                        flag = true;
                    } else {
                        LOG.debug("File is failed to move!");
                    }
                } else {
                    entryFolder =
                        new File(DTFolderLocationConstants.WITHOUT_STYLESHEET_DOCS + "/",
                                 fileName.substring(0, fileName.length() - 5));
                    if (!entryFolder.exists()) {
                        LOG.debug("folder creation..." + entryFolder.getPath());
                        entryFolder.mkdirs();
                    }

                    File oldFile = new File(DTFolderLocationConstants.DOC_LOCATION_CDA + fileName + ".xml");

                    if (oldFile.renameTo(new File(entryFolder.getAbsolutePath() + "/" + oldFile.getName()))) {
                        // flag for cheking file moved succesfully for making audit for success IHI
                        LOG.debug("audit required flag is true");
                        flag = true;
                        LOG.debug("File is moved successful!");
                    } else {
                        LOG.debug("File is failed to move!");
                    }
                }
            }
        } catch (Exception e) {
            LOG.fatal("Exception occured.....", e);
        }

        LOG.debug("Leaving moveFiles.....");
        return flag;
    }

    /**
     *used to call delete file method from a directory
     * @param directoryPath
     */
    public void deleteFiles(String directoryPath) {
        LOG.debug("entering into deleteFiles..");
        final String SRC_FOLDER = directoryPath;
        File directory = new File(SRC_FOLDER);
        if (!directory.exists()) {
            LOG.debug("Directory does not exist...." + directoryPath);
        } else {
            try {
                delete(directory);
            } catch (IOException e) {
                LOG.fatal("Exceprtion occured..", e);

            }
        }
        LOG.debug("Leaving  deleteFiles..");

    }

    /**
     *used to delete files from a directory
     * @param file
     * @throws IOException
     */
    public static void delete(File file) throws IOException {
        if (file != null) {
            LOG.debug("entering into delete.." + file.getName());
            if (file.isDirectory()) {
                LOG.debug("file.isDirectory()");
                //directory is empty, then delete it
                if (file.list().length == 0) {
                    if (!("WithoutStyleSheetDocs".equalsIgnoreCase(file.getName()) ||
                          "StyleSheetApplidDocs".equalsIgnoreCase(file.getName()) ||
                          "ExtractedFilesFormWebservice".equalsIgnoreCase(file.getName()))) {
                        file.delete();
                        LOG.debug("Directory is deleted ...: " + file.getAbsolutePath());
                    }
                } else {
                    //list all the directory contents
                    String files[] = file.list();
                    for (String temp : files) {
                        //construct the file structure
                        File fileDelete = new File(file, temp);
                        //recursive delete
                        delete(fileDelete);
                    }

                    //check the directory again, if empty then delete it
                    if (file.list().length == 0) {
                        if (!("WithoutStyleSheetDocs".equalsIgnoreCase(file.getName()) ||
                              "StyleSheetApplidDocs".equalsIgnoreCase(file.getName()) ||
                              "ExtractedFilesFormWebservice".equalsIgnoreCase(file.getName()))) {
                            LOG.debug("Before deleting the file name is : " + file.getName());

                            file.delete();
                            LOG.debug("Directory is deleted : " + file.getAbsolutePath());
                        }
                    }
                }

            } else {
                //if file, then delete it
                file.delete();
                LOG.debug("File is deleted : " + file.getAbsolutePath());
            }
            LOG.debug("Leaving  delete..");
        }
    }

    /**
     *
     * @param ihi
     * @param docId
     * @param errorDescription
     * @param docType
     * @param status
     * @return
     */
    public DocTransformationErrorBO createErrorBo(String ihi, String docId, String errorDescription, String docType,
                                                  String status, String transcationDateAndTime) {

        DocTransformationErrorBO errorBo = new DocTransformationErrorBO();
        errorBo.setDocId(docId);
        errorBo.setIHI(ihi);
        errorBo.setErrorDescription(errorDescription);
        errorBo.setDocType(docType);
        errorBo.setStatus(status);
        errorBo.setTranscationDateAndTime(transcationDateAndTime);
        LOG.debug("errorCSv contained..." + docId + "...and for IHI..." + ihi);
        return errorBo;

    }

    /**
     *
     * @param ihi
     * @param errorDescription
     * @return
     */
    public HealthRecordExtractionErrorBO createErrorBo(String ihi, String errorDescription, String viewType) {
        LOG.debug("inside createErrorBo..." + ihi + "errro..." + errorDescription);
        HealthRecordExtractionErrorBO errorBo = new HealthRecordExtractionErrorBO();

        errorBo.setIHI(ihi);
        errorBo.setStatusDescription(errorDescription);
        errorBo.setViewType(viewType);
        LOG.debug("inside createErrorBo");
        return errorBo;

    }

    /**
     *
     * @param form
     */
    public void createCSV(DocumentTransformationForm form) {
        //code change for multiple csv file creation
        Date dat = new Date();
        //ddMMyyyyhhmmss
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd_hh_mm_ss");
        String date = ft.format(dat);
        LOG.debug("insied createCSV");
        String csvFolderLocation = DTFolderLocationConstants.ERROR_FILE_LOCATION;
        String csvFileName = "errors_" + date + ".csv";
        ICsvBeanWriter csvWriter = null;
        try {
            csvWriter =
                new CsvBeanWriter(new FileWriter(csvFolderLocation + csvFileName), CsvPreference.STANDARD_PREFERENCE);
            String[] header = { "IHI", "DocId", "DocType", "Status", "TranscationDateAndTime", "ErrorDescription" };
            csvWriter.writeHeader(header);
            for (DocTransformationErrorBO error : form.getErrorBoList()) {
                csvWriter.write(error, header);
                form.setErrorCsvName(csvFileName);
            }
        } catch (Exception e) {
            LOG.fatal("Exception ...", e);
        } finally {
            if (csvWriter != null) {
                try {
                    csvWriter.close();
                } catch (IOException ex) {
                    LOG.fatal("Error closing the writer: ", ex);
                }
            }
        }
        LOG.debug("Leaving createCSV");
    }

    /**
     *
     * @return
     */
    public String getDateFormat() {
        Date dat = new Date();
        //ddMMyyyyhhmmss
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd_hh_mm_ss");
        String date = ft.format(dat);
        return date;
    }

    /**
     *This method is to fetch the list of document ids
     * @param artExtractionBO
     * @return
     * @throws RecoveryServiceException
     */
    private List<String> getEntryListfromFile(DisableEnableEntitiesForm disableEnableEntities) throws RecoveryServiceException {
        Set<String> documentIdLst = new HashSet<String>();
        String csvSplitBy = ",";
        String[] ihi = null;
        InputStreamReader inStreamReader = null;
        BufferedReader bReader = null;
        try {
            inStreamReader = new InputStreamReader(disableEnableEntities.getFile().getInputStream());
            bReader = new BufferedReader(inStreamReader);
            for (String line = bReader.readLine(); line != null; line = bReader.readLine()) {
                if (line != null && !line.equals(""))
                    ihi = line.split(csvSplitBy);
                documentIdLst.addAll(Arrays.asList(ihi));
            }
        } catch (IOException e) {
            throw new RecoveryServiceException(e);
        } finally {
            try {
                bReader.close();
                inStreamReader.close();
            } catch (Exception e) {
                LOG.debug("Exception occured while colosing the resources..");
            }
        }
        return new ArrayList<String>(documentIdLst);
    }


    /*Bulk Regitration File Util for transfering files from one folder to another in Unix box
 *
 */

    /**
     *Used to transfer the file from source directory to destination directory using scp command
     * @param fileTransferBO
     * @return
     * @throws RecoveryServiceException
     */

    public FileTransferBO sshServerFileTransfer(FileTransferBO fileTransferBO) throws RecoveryServiceException {

        LOG.debug("entering sshServerFileTransfer...");
        int fileTransferStatus = 0;
        // String fileName = "";
        String fileName = fileTransferBO.getFileName();
        LOG.debug("source folder.." + fileTransferBO.getSourceFolder());
        LOG.debug("destination folder..." + fileTransferBO.getDestinationFolder());

        String transferOutputDescription = null;
        String checksumResult = "";


        LOG.debug("fileName::" + fileName);

        //call checksum
        checksumResult = genarateFileCheckSumCommand(fileTransferBO);
        if (checksumResult != null && checksumResult.equals("Success")) {
            LOG.debug("copy to destination is starting as we checksum is success ");
            Session sessionConnection = createJSCHConnection(fileTransferBO);

            Channel channel = null;

            String transferOutputDescriptionTemp = null;
            InputStream in = null;
            InputStream stderr = null;
            //command to copy the files from source to destination directory
            String fileTransferCommand =
                SCP_COMMAND + fileTransferBO.getSourceFolder() + fileName + " " +
                fileTransferBO.getDestinationFolder() + fileName;
            LOG.debug("File transfer command:::" + fileTransferCommand);
            try {
                channel = sessionConnection.openChannel(SESSION_CHANLE_TYPE);
                ((ChannelExec) channel).setCommand(fileTransferCommand);
                channel.setInputStream(null);
                ((ChannelExec) channel).setErrStream(System.err);
                stderr = ((ChannelExec) channel).getErrStream();
                in = channel.getInputStream();
                channel.connect();
                byte[] tmp = new byte[1024];
                while (true) {
                    while (in.available() > 0) {
                        int i = in.read(tmp, 0, 1024);
                        if (i < 0)
                            break;
                        LOG.debug(".." + new String(tmp, 0, i));
                    }
                    //cehecking the exist sttaus of the chanel
                    //if exist sttaus is not 0 then write the error message in the description
                    if (channel.getExitStatus() != 0) {

                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stderr));
                        if ((transferOutputDescriptionTemp = bufferedReader.readLine()) != null) {

                            LOG.debug("transferOutputDescription...." + transferOutputDescriptionTemp);
                            transferOutputDescription = transferOutputDescriptionTemp;
                        }

                    } else {
                        LOG.debug("File Transfer is Successfull......");
                        transferOutputDescription = FILE_TRANSFER_SUCCESSFULL_MESSAGE;
                    }
                    //setting the fileTransferStatus and the description when chanel is colsed
                    if (channel.isClosed()) {
                        LOG.debug("File transfer exit-status: " + channel.getExitStatus());
                        fileTransferStatus = channel.getExitStatus();
                        if (fileTransferStatus == 0)
                            transferOutputDescription = FILE_TRANSFER_SUCCESSFULL_MESSAGE;
                        break;
                    }

                }

            } catch (Exception ex) {
                LOG.fatal("Exception occured", ex);
                throw new RecoveryServiceException(ex);

            } finally {
                LOG.debug("closiing all the connections....");
                closeConnectionInputStream(in);
                closeConnectionInputStream(stderr);
                closeConnectionChanel(channel);
                closeConnectionSession(sessionConnection);

                LOG.debug("closiing connections successfull....");

            }
        } else {
            LOG.debug("checksum mismatch ::::");
            transferOutputDescription = checksumResult;
        }

        LOG.debug("Leaving sshServerFileTransfer");
        fileTransferBO.setTransferStatus(fileTransferStatus);
        fileTransferBO.setTransferOutputDescription(transferOutputDescription);
        return fileTransferBO;

    }

    /**
     *Used to  write the file in local working directory from unix diretory ...from the local file will be written and download option will be provided
     * @param fileTransferBO
     * @return
     * @throws RecoveryServiceException
     */
    public void downloadFileToLocal(FileTransferBO fileTransferBO) throws RecoveryServiceException {
        LOG.debug("Enetring downloadFileToLocal.....");

        FileOutputStream fos = null;
        //creating the session connection by calling the createJSCHConnection method
        Session sessionConnection = createJSCHConnection(fileTransferBO);
        InputStream in = null;
        OutputStream out = null;
        Channel channel = null;

        String fileName = "";
        LOG.debug("fileTransferBO.getFileName()..." + fileTransferBO.getFileName());
        //ceheking wheather the filename is alreday know or not...for status tab we are passing the file name
        if (fileTransferBO.getFileName() != null && fileTransferBO.getFileName().length() > 0) {
            LOG.debug("file name already known.." + fileName);
            fileName = fileTransferBO.getFileName();
        } else {
            //calling the getFile List to get the list of file on the server as name is unknown
            LOG.debug("file name is unknown");
            List fileList = getFileList(fileTransferBO);


            if (fileList != null && fileList.size() > 0) {
                fileName = fileList.get(fileList.size() - 1).toString();
                LOG.debug("file list :::" + fileList.size());
            }
        }
        LOG.debug("file name :::" + fileName);
        fileTransferBO.setFileName(fileName);

        //command to read a particluar file from a directory
        String command = SCP_COMMAND_FILE_READ + fileTransferBO.getSourceFolder() + fileName;
        String lfile = fileName;
        try {
            channel = sessionConnection.openChannel(SESSION_CHANLE_TYPE);
            ((ChannelExec) channel).setCommand(command);
            out = channel.getOutputStream();
            in = channel.getInputStream();
            channel.connect();
            LOG.debug("connection suuecfull...");
            //reading the file content and wriring it on the new file
            byte[] buf = new byte[1024];

            buf[0] = 0;
            out.write(buf, 0, 1);
            out.flush();
            long filesize = 0L;
            while (true) {
                //to check to char to break the loop
                int statusChcek = checkAck(in, fileTransferBO);
                if (statusChcek != 'C') {
                    break;
                }
                in.read(buf, 0, 5);
                while (true) {
                    if (in.read(buf, 0, 1) < 0) {
                        // error
                        break;
                    }

                    if (buf[0] == ' ') {
                        break;
                    }

                    filesize = filesize * 10L + (long) (buf[0] - '0');
                }
                for (int i = 0;; i++) {
                    in.read(buf, i, 1);
                    if (buf[i] == (byte) 0x0a) {
                        break;
                    }
                }

                buf[0] = 0;
                out.write(buf, 0, 1);
                out.flush();
                //creating a file with the existing file name
                fos = new FileOutputStream(lfile);
                int buffLength;
                while (true) {

                    if (buf.length < filesize) {
                        buffLength = buf.length;
                    } else {
                        buffLength = (int) filesize;
                    }
                    buffLength = in.read(buf, 0, buffLength);

                    if (buffLength < 0) {
                        break;
                    }
                    fos.write(buf, 0, buffLength);

                    filesize -= buffLength;
                    if (filesize == 0L) {
                        break;
                    }
                }

                fos.close();
                fos = null;
                buf[0] = 0;
                out.write(buf, 0, 1);
                out.flush();
            }
            LOG.debug("file copy status:::" + fileTransferBO.getValidateExtractdownloadStatus());
        } catch (Exception ex) {

            LOG.fatal(ex.getLocalizedMessage(), ex);
            throw new RecoveryServiceException(ex);
        } finally {

            LOG.debug("closiing all the connections....");
            closeConnectionInputStream(in);
            closeConnectionOutputStream(out);
            closeConnectionChanel(channel);
            closeConnectionSession(sessionConnection);

            LOG.debug("closiing connections successfull....");

        }
        LOG.debug("Leaving downloadFileToLocal....");

    }


    /**Used to check the inputsteram character to get the status of command execution
     *
     * @param in
     * @return
     * @throws IOException
     */
    private final int checkAck(final InputStream in, FileTransferBO fileTransferBO) throws IOException {
        LOG.debug("inside checkAck ...");
        int status = in.read();
        LOG.debug("char value:::" + (char) status);
        if (status == 0) {
            return status;
        }
        if (status == -1) {
            return status;
        }
        //is sttaus value is >0 then there is error with the command execution..setting the same for error description
        if (status == 1 || status == 2) {
            StringBuilder sb = new StringBuilder();
            int c;
            do {
                c = in.read();

                sb.append((char) c);
            } while (c != '\n');
            if (status == 1) {
                LOG.error("file copy error:::" + sb.toString());

            }
            if (status == 2) { // fatal error
                LOG.error("file copy error:::" + sb.toString());


            }
            fileTransferBO.setValidateExtractdownloadStatus(status);
            fileTransferBO.setValidateExtractdownloadDescription(sb.toString());
        }
        return status;
    }

    /**
     *Used to get the list of files from a directory of LInux box and returns the list of file names
     * @param fileTransferBO
     * @return
     * @throws RecoveryServiceException
     */
    private List<String> getFileList(FileTransferBO fileTransferBO) throws RecoveryServiceException {
        LOG.debug("inside getFileList ...");
        Session sessionConnection = createJSCHConnection(fileTransferBO);
        List<String> listOfFiles = new ArrayList<String>();
        Channel channel = null;
        InputStream in = null;
        OutputStream out = null;
        String sourceFolder = fileTransferBO.getSourceFolder();
        LOG.debug("Source folder for file list.." + sourceFolder);
        String command = LS_COMMAND + sourceFolder;
        LOG.debug("getFileList command:::::" + command);
        try {
            channel = sessionConnection.openChannel(SESSION_CHANLE_TYPE);
            ((ChannelExec) channel).setCommand(command);
            out = channel.getOutputStream();
            in = channel.getInputStream();
            channel.connect();
            String finalString = "";
            byte[] tmp = new byte[1024];
            while (true) {
                while (in.available() > 0) {
                    int i = in.read(tmp, 0, 1024);

                    if (i < 0) {
                        break;
                    }
                    finalString = new String(tmp, 0, i);

                }
                if (channel.isClosed()) {
                    LOG.debug("exit-status: " + channel.getExitStatus());

                    break;
                }
            }
            String arr[] = finalString.split("\n");
            for (int i = 0; i < arr.length; i++) {
                listOfFiles.add(arr[i]);
            }
        } catch (Exception e) {
            LOG.fatal("Exce:::", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        } finally {

            LOG.debug("closiing all the connections....");
            closeConnectionInputStream(in);
            closeConnectionOutputStream(out);
            closeConnectionChanel(channel);
            closeConnectionSession(sessionConnection);

            LOG.debug("closiing connections successfull....");
            return listOfFiles;

        }
    }

    /**
     *Method to perform the calculation of file checksum from java code by transfering file
     * @param fileTransferBO
     * @return
     */
    private String genarateFileChecksumFromJava(FileTransferBO fileTransferBO) throws RecoveryServiceException {
        LOG.debug("Enetring  genarateFileChecksum ::::");
        String finalCheckSumVlaue = "";
        try {
            downloadFileToLocal(fileTransferBO);
            LOG.debug("file download status:::: " + fileTransferBO.getValidateExtractdownloadStatus());
            if (!(fileTransferBO.getValidateExtractdownloadStatus() > 0)) {
                //should be set from the UI iteself
                // fileTransferBO.setChecksumMethodFromUI("md5");
                //fileTransferBO.setChecksumValueFromUI("abcd");
                //file download to local is successfull

                try {

                    finalCheckSumVlaue =
                        fileCheckSum.getFileChecksum(fileTransferBO.getChecksumValueFromUI(),
                                                     fileTransferBO.getFileName(),
                                                     fileTransferBO.getChecksumMethodFromUI());
                    LOG.debug("finalChecSumResult..." + finalCheckSumVlaue);
                } catch (Exception e) {
                    LOG.fatal("exception ", e);
                } finally {
                    //finally deleting the file that has been created in local
                    LOG.debug("calling delet file:::" + fileTransferBO.getFileName());
                    deleteFileFromLocal(fileTransferBO.getFileName());
                }
            } else {
                finalCheckSumVlaue = fileTransferBO.getValidateExtractdownloadDescription();
            }
        } catch (RecoveryServiceException e) {
            LOG.fatal("exception ", e);
            //throw new RecoveryServiceException(e.getMessage(), e);
        }
        LOG.debug("final checksum result===" + finalCheckSumVlaue);
        LOG.debug("Enetring  genarateFileChecksum ::::");
        return finalCheckSumVlaue;
    }


    /**
     *genarete checsum using linux command
     * @param fileTransferBO
     * @return
     * @throws RecoveryServiceException
     */

    private String genarateFileCheckSumCommand(FileTransferBO fileTransferBO) throws RecoveryServiceException {
        LOG.debug("inside genarateFileCheckSumCommand....");
        Session sessionConnection = createJSCHConnection(fileTransferBO);

        String chekSumValueFromCommand = "";
        String transferOutputDescriptionTemp = "";
        String finalCheckSumResult = "";
        InputStream in = null;
        OutputStream out = null;
        Channel channel = null;
        String genaratedFileChecksum = "";
        String finalFileChecksum = "";
        String fileName = fileTransferBO.getFileName();
        InputStream stderr = null;
        int commandExistStatus = 0;
        String checkSumSha256Command = CHECKSUM_SHA256_COMMAND + fileTransferBO.getSourceFolder() + fileName;
        LOG.debug("check sum command:::" + checkSumSha256Command);

        try {
            channel = sessionConnection.openChannel(SESSION_CHANLE_TYPE);
            ((ChannelExec) channel).setCommand(checkSumSha256Command);
            out = channel.getOutputStream();
            in = channel.getInputStream();
            stderr = ((ChannelExec) channel).getErrStream();
            channel.connect();
            LOG.debug("connection successfull:::");
            byte[] tmp = new byte[1024];
            while (true) {
                while (in.available() > 0) {
                    int i = in.read(tmp, 0, 1024);

                    if (i < 0) {
                        break;
                    }
                    genaratedFileChecksum = new String(tmp, 0, i);

                }
                if (channel.isClosed()) {
                    LOG.debug("exit-status: " + channel.getExitStatus());
                    if (channel.getExitStatus() != 0) {
                        commandExistStatus = channel.getExitStatus();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stderr));
                        if ((transferOutputDescriptionTemp = bufferedReader.readLine()) != null) {

                            LOG.debug("finalCheckSumResult error...." + transferOutputDescriptionTemp);
                            finalCheckSumResult = transferOutputDescriptionTemp;
                        }

                    } else {
                        commandExistStatus = channel.getExitStatus();
                        String arr[] = genaratedFileChecksum.split(" ");
                        if (arr != null && arr.length > 0)
                            chekSumValueFromCommand = arr[0];
                        LOG.debug("finalCheckSumResult genaratedFileChecksum is==" + chekSumValueFromCommand);
                    }
                    break;
                }
            }


            if (commandExistStatus == 0) {

                if (chekSumValueFromCommand.equals(fileTransferBO.getChecksumValueFromUI())) {
                    finalCheckSumResult = "Success";
                } else {
                    finalCheckSumResult = CHECK_SUM_ERROR_MISMATCH_ERROR_MESSAGE;
                }
            }
            // LOG.debug("finalFileChecksum is==" + finalCheckSumResult);
        } catch (Exception e) {
            LOG.fatal("exception", e);
        } finally {
            closeConnectionInputStream(in);
            closeConnectionOutputStream(out);
            closeConnectionInputStream(stderr);
            closeConnectionChanel(channel);
            closeConnectionSession(sessionConnection);
        }
        LOG.debug("final checksum result===" + finalCheckSumResult);
        LOG.debug("Leaving genarateChecksumFromCommand");
        return finalCheckSumResult;
    }


     /**
          *crates the JSCHConnection with the server
          * @param fileTransferBO
          * @return
          * @throws RecoveryServiceException
          */
         private Session createJSCHConnection(FileTransferBO fileTransferBO) throws RecoveryServiceException {
             LOG.debug("Enetring createJSCHConnection ...");
             JSch jschSSHChannel;
             Session sessionConnection = null;
             try {
                 Properties config = new Properties();


                 //setting the StrictHostKeyChecking as no
                 config.put("StrictHostKeyChecking", "no");
                 jschSSHChannel = new JSch();
                 //private key
                 String privateKeyLocation = EndPointsConstants.SSH_PRIVATE_KEY_LOCATION;
                 LOG.debug("private key location :::" + privateKeyLocation);
                 String privateKeyName = EndPointsConstants.SSH_PRIVATE_KEY_NAME;
                 LOG.debug("private key name :::" + privateKeyName);
                 String privateKey=privateKeyLocation+privateKeyName;
                 LOG.debug("NEW Final private key :::" + privateKey);
                 jschSSHChannel.addIdentity(privateKey);


                 sessionConnection =
                     jschSSHChannel.getSession(decrypter.decryption(fileTransferBO.getHostUserName()),
                                               fileTransferBO.getHostIp(), fileTransferBO.getHostPort());
                 LOG.debug("osb pass:::" + fileTransferBO.getHostPassowrd());
                 if (fileTransferBO.getHostPassowrd() != null || fileTransferBO.getHostPassowrd().length() > 0)
                     sessionConnection.setPassword(decrypter.decryption(fileTransferBO.getHostPassowrd()));

                 sessionConnection.setConfig(config);
                 sessionConnection.connect();
                 LOG.debug("sessionConnection Successfull ...");
                 LOG.debug("Leaving createJSCHConnection ...");

             } catch (Exception e) {
                 LOG.fatal("connection ecxception::", e);
                 throw new RecoveryServiceException(e);
             }
             return sessionConnection;
         }

    /**
     *USed to convert the file as string value to return it as the download file
     * @param fileName
     * @return
     */

    public String convertFileToString(String fileName) throws RecoveryServiceException {
        String fileLocation = getFileLocation(fileName);
        String outputFileAsString = "";
        InputStream in = null;
        try {
            in = new FileInputStream(new File(fileLocation));
            outputFileAsString = IOUtils.toString(in, CHAR_SET_UTF_8);

        } catch (Exception e) {
            LOG.fatal("Exception ..", e);
            throw new RecoveryServiceException(e);
        } finally {
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                LOG.fatal("Exception closing in::", e);
            }
        }
        return outputFileAsString;
    }


    /**
     *Get the file location form the current working directory
     * @param fileName
     * @return
     */
    private String getFileLocation(String fileName) {
        String os = System.getProperty("os.name");
        String outputFileloc = null;

        if (null != os && os.contains("Linux")) {
            outputFileloc = System.getProperty("user.dir") + "/" + fileName;

        } else {
            outputFileloc = System.getProperty("user.dir") + "\\" + fileName;

        }
        return outputFileloc;
    }
    public List<String> readFileUniqueIHI(MultipartFile file) throws RecoveryServiceException {
        LOG.debug("Entered into readFile");
        Set<String> ihiList = new HashSet<String>();
        String csvSplitBy = ",";
        String[] ihi = null;
        InputStreamReader iStreamReader = null;
        BufferedReader bReader = null;
        try {
            iStreamReader = new InputStreamReader(file.getInputStream());
            bReader = new BufferedReader(iStreamReader);
            for (String line = bReader.readLine(); line != null; line = bReader.readLine()) {
                if (line != null && !line.equals("")) {
                    ihi = line.split(csvSplitBy);
                }
                for (int i = 0; i < ihi.length; i++) {
                    ihiList.add(ihi[i].trim());
                }
            }
            LOG.debug("DOc id List size ::" + ihiList.size());

        } catch (IOException e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        } finally {
            try {
                bReader.close();
                iStreamReader.close();
            } catch (Exception e) {
                LOG.fatal("Exception occured while colosing the resources..", e);

            }
        }
        return new ArrayList<String>(ihiList);
    }
/**
     * This function is expected to return the unique list of entries from the file(.csv) provided
     * @param file
     * @return
     * @throws ParseException
     */
    public Map<String, List<ARrestrictionBO>> getARRestrictionFormSet(MultipartFile file) throws RecoveryServiceException {
        Map<String, List<ARrestrictionBO>> outputMap = new HashMap<String, List<ARrestrictionBO>>();
        List<ARrestrictionBO> arrestrictCSVEntryList = new ArrayList<ARrestrictionBO>();
        boolean validDataFlag = true;
        final String csvSplitBy = ",";
        String[] row = null;
        InputStreamReader iStreamReader = null;
        BufferedReader bReader = null;
        try {
            iStreamReader = new InputStreamReader(file.getInputStream());
            bReader = new BufferedReader(iStreamReader);
            int i = 0;
            for (String line = bReader.readLine(); line != null; line = bReader.readLine()) {
                if(i == 0){// for ignoring header
                    i++;
                    continue;
                }
                //boolean flag = true;
                if(line != null && !line.equals("")) {
                    row = line.split(csvSplitBy);
                    if(row.length >= 5){
                        StringBuilder comments = new StringBuilder();
                        String ihi = row[0];
                        String dob = row[3];
                        String firstName = row[1];
                        String lastName = row[2];
                        String nsw_qld = row[4];
                        
                    
                        ARrestrictionBO arRestrictionBO = new ARrestrictionBO();
                        //IHI validation
                        if(ihi != null && ihi.matches("[0-9]{16}")){
                            arRestrictionBO.setIHI(ihi);
                        }else{
                            validDataFlag = false;
                            arRestrictionBO.setIHI(ihi);
                            comments.append("Invalid IHI.");
                        }
                        //DOB validation
                        boolean dateFormat = dateTimeUtil.validatedate(dob, "dd/MM/yyyy");
                        if(dateFormat){
                            arRestrictionBO.setDateOfBirth(dob);
                        }else{
                            validDataFlag = false;
                            comments.append("Invalid Date Of Birth.");
                        }
                        
                        
                        //Validate and calculate Expiry Date
                        String expiryDate = "";
                        if(row.length >=6 && row[5] != null){
                            expiryDate = row[5].trim();
                                                    
                            if("18".equals(expiryDate)){
                                if(dateFormat){
                                    Date dateOfBirth =  new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).parse(dob);
                                    String dateOn18Birthday = dateTimeUtil.calculateAgeDateFromDOB(dateOfBirth);
                                    if(dateTimeUtil.validateDateForFutureDate(dateOn18Birthday, "dd.MM.yyyy")){
                                        arRestrictionBO.setExpireDate(dateOn18Birthday);
                                    }else{
                                         validDataFlag = false;
                                         arRestrictionBO.setExpireDate(expiryDate);
                                         comments.append("In valid DOB as calculated Expiry Date is less than current date. ");
                                    }
                                }else{
                                    validDataFlag = false;
                                    arRestrictionBO.setExpireDate(expiryDate);
                                    comments.append("As DOB is incorrect Expiry Date cannot be identified.");
                                }
                            }else if(dateTimeUtil.validatedate(expiryDate,"dd.MM.yyyy")) {
                                 //Validate Date in DD.MM.YYYY format
                                 boolean validFlag = dateTimeUtil.validateDateForFutureDate(expiryDate, "dd.MM.yyyy");
                                 if(validFlag){
                                    arRestrictionBO.setExpireDate(expiryDate);
                                 }else{
                                     validDataFlag = false;
                                     arRestrictionBO.setExpireDate(expiryDate);
                                     comments.append("Expiry Date cannot be today or older day.");
                                 }
                                    
                            }else{
                                validDataFlag = false;
                                arRestrictionBO.setExpireDate(expiryDate);
                                comments.append("Expiry Date format is not valid. Expected format - dd.MM.yyyy");
                            }
                        }else{
                            validDataFlag = false;
                            comments.append("Expiry Date Value Invalid.");
                        }
                        arRestrictionBO.setFirstName(firstName);
                        arRestrictionBO.setLastName(lastName);
                        arRestrictionBO.setNsw_QldID(nsw_qld);
                        arRestrictionBO.setComments(comments);
                        arrestrictCSVEntryList.add(arRestrictionBO);
                    }
                }
            }
            if(validDataFlag){
                //when all entries in CSV file are valid
                outputMap.put("ValidData", arrestrictCSVEntryList);
            }else{
                outputMap.put("InValidData", arrestrictCSVEntryList);
            }
            LOG.debug("arrestrictForm Set size ::" + arrestrictCSVEntryList.size());
        } catch (Exception e) {
            LOG.debug("Exception Occured :: " + e.getMessage());
            throw new RecoveryServiceException("Exception while validating AR Restriction Input file - ", e );
        } finally {
            try {
                bReader.close();
                iStreamReader.close();
            } catch (Exception e) {
                LOG.fatal("Exception occured while colosing the resources..", e);
                throw new RecoveryServiceException("Exception Occured ", e );
            }
        }
        return outputMap;
    }
    /**Used to delete the file from local directory
     *
     * @param fileName
     */
    public void deleteFileFromLocal(String fileName) {
        LOG.debug("Enetring  deleteFileFromLocal " + fileName);

        try {

            File file = new File(fileName);

            LOG.debug("is file:::" + file.exists());
            LOG.debug("abs path file:::" + file.getAbsolutePath());
            boolean isDeleted = file.delete();
            LOG.debug("file deletion status:::" + isDeleted);
        } catch (Exception x) {
            LOG.debug("Exception occured::", x);

        }
        LOG.debug("Leaving  deleteFileFromLocal");

    }

    /**used to return a list of IHI from a string which contains full file as string
     *
     * @return
     */
    public List getIhiListFromDHSFile(String fileAsString) {
        LOG.debug("Enetring  getIhiListFromDHSFile ");
        StringBuffer strBuf2 = new StringBuffer();
        List<StringBuffer> listList = new ArrayList<StringBuffer>();
        List<String> listIHI = new ArrayList<String>();
        for (int i = 0; i < fileAsString.length(); i++) {
            if (fileAsString.charAt(i) == '\n') {
                listList.add(strBuf2);
                strBuf2 = new StringBuffer();

            } else {
                strBuf2.append(fileAsString.charAt(i));
            }


        }
        listList.add(strBuf2);

        for (int i = 0; i < listList.size(); i++) {
            listIHI.add((listList.get(i).toString().split("\\|"))[0]);

        }
        //remove the first value as it will be IHI(text)
        if (listIHI.size() > 1)
            listIHI.remove(0);

        return listIHI;
    }


    /**
     *Closing InputStream
     * @param in
     */
    private void closeConnectionInputStream(InputStream in) {
        try {
            if (in != null) {
                LOG.debug("closing InputStream...");
                in.close();
            }
        } catch (IOException e) {
            LOG.fatal("Exception closing in::", e);
        }
    }

    /**
     *Closing OutputStream
     * @param out
     */
    private void closeConnectionOutputStream(OutputStream out) {
        try {
            if (out != null) {
                LOG.debug("closing outPutStream...");
                out.close();
            }
        } catch (IOException e) {
            LOG.fatal("Exception closing out::", e);
        }
    }

    /**
     *Closing Channel
     * @param chanel
     */
    private void closeConnectionChanel(Channel chanel) {
        if (chanel != null) {
            LOG.debug("closing sessionConnection...");
            chanel.disconnect();
        }
    }

    /**
     *Closing sessionConnection
     * @param sessionConnection
     */
    private void closeConnectionSession(Session sessionConnection) {

        if (sessionConnection != null) {

            LOG.debug("closing sessionConnection...");
            sessionConnection.disconnect();
        }

    }

    /**
     *
     * @param bytes
     * @param destinationFileLocation
     */
    public void bytesToFIleConverter(byte[] bytes, String destinationFileLocation) throws FileNotFoundException,
                                                                                          IOException {

        LOG.debug("inside ..bytesToFIleConverter");
        File file = new File(destinationFileLocation);
        FileOutputStream fileOs = null;
        ;
        try {
            fileOs = new FileOutputStream(file);

            fileOs.write(bytes);
        } catch (FileNotFoundException e) {
            LOG.fatal("exception ", e);
            throw e;
        } catch (IOException e) {
            LOG.fatal("exception ", e);
            throw e;
        } finally {

            try {
                fileOs.close();
            } catch (IOException e) {
                LOG.fatal("exception ", e);
            }
        }
        LOG.debug("leaving ..bytesToFIleConverter");
    }

    /**
     *
     * @param errorList
     */
    public String createCSVForErrorWritting(List<HealthRecordExtractionErrorBO> errorList) {
        LOG.debug("Enterring createCSVForErrorWritting...");
        Date dat = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd_hh_mm_ss");
        String date = ft.format(dat);
        LOG.debug("insied createCSV");
        String csvFolderLocation = HealthRecordExtractionConstants.ERROR_FILE_LOCATION;
        String csvFileName = "errors_" + date + ".csv";
        ICsvBeanWriter csvWriter = null;
        try {
            csvWriter =
                new CsvBeanWriter(new FileWriter(csvFolderLocation + csvFileName), CsvPreference.STANDARD_PREFERENCE);
            String[] header = { "IHI", "viewType", "StatusDescription" };
            csvWriter.writeHeader(header);
            for (HealthRecordExtractionErrorBO error : errorList) {
                csvWriter.write(error, header);
                //form.setErrorCsvName(csvFileName);
            }
        } catch (Exception e) {
            LOG.fatal("Exception ...", e);
        } finally {
            if (csvWriter != null) {
                try {
                    csvWriter.close();
                } catch (IOException ex) {
                    LOG.fatal("Error closing the writer: ", ex);
                }
            }
        }
        LOG.debug("Leaving createCSV");
        return csvFileName;
    }

    /**
     *
     * @param sourcePath
     * @param directoryName
     */
    public void createNewDirectory(String sourcePath, String directoryName) {
        LOG.debug("inside createNewDirectory...");
        new File(sourcePath + directoryName).mkdir();
        LOG.debug("Leaving createNewDirectory...");
    }

/**
       *DHS File name format validation from 
       * @param fileName
       * @return
       */
      public boolean fileNameFormatValidation(String fileName) {
          LOG.debug("inside fileNameFormatValidation..." + fileName);
          boolean fileNameFormatFlag = true;
          SimpleDateFormat f = new SimpleDateFormat(FILE_NAME_DATE_FORMAT);
          int lastIndexOfUnderscore = fileName.lastIndexOf(UNDERSCORE);
          LOG.debug("lastIndexOfUnderscore.." + lastIndexOfUnderscore);
          int indexOfDot = fileName.lastIndexOf(DOT);

          LOG.debug("IndexOfDot..." + indexOfDot);
          if (lastIndexOfUnderscore == -1 || indexOfDot == -1) {
              LOG.debug("invalid format..");
              fileNameFormatFlag = false;
          }
          //startformat check
          if (lastIndexOfUnderscore != -1) {
              String startformat = fileName.substring(0, lastIndexOfUnderscore);
              LOG.debug("startformat..." + startformat);
              if (!startformat.equals(DHS_FILE_FORMAT)) {
                  LOG.debug("invalid format");
                  fileNameFormatFlag = false;
              }
          }
          if (lastIndexOfUnderscore != -1 && indexOfDot != -1) {
              String dateFromatCheckString = fileName.substring(lastIndexOfUnderscore + 1, indexOfDot);
              LOG.debug("dateFromatCheckString..." + dateFromatCheckString);
              LOG.debug("dateFromatCheckString length::" + dateFromatCheckString.length());
              f.setLenient(false);
              //for yyyyMMddHHmmss format parse still works if date does not contain both 2 digits for ss..so checking the length
              if (dateFromatCheckString != null && dateFromatCheckString.length() < 14) {
                  LOG.debug("mismatch date format");
                  fileNameFormatFlag = false;
              }
              //for yyyyMMddHHmmss format parse still works if conatains char as the last digit for ss ..so chceking to only contain digits
              else if (!(dateFromatCheckString != null && dateFromatCheckString.matches(ONLY_NUMBER_PATTERN))) {
                  fileNameFormatFlag = false;
              } else {
                  try {
                      f.parse(dateFromatCheckString);
                  } catch (Exception e) {
                      LOG.debug("mismatch date format");
                      LOG.fatal("exception" + e);
                      fileNameFormatFlag = false;
                  }
              }


          }

          if (fileNameFormatFlag == false) {
              LOG.debug(".....final validation contains invalid format...");
          } else {
              LOG.debug("...final validation contains valid format...");
          }
          LOG.debug("leavin fileNameFormatValidation...");
          return fileNameFormatFlag;
      }
/**
     *
     * @param file
     * @return
     */
    public List<IdentityRemovalBO> getIdentityRemovalInputsFromCSV(MultipartFile file) {
        LOG.debug("Entering getIdentityRemovalInputsFromCSV");
        List<IdentityRemovalBO> listIdentityRemovalBO = new ArrayList();
        InputStreamReader iStreamReader = null;
        BufferedReader bReader = null;
        String[] row = null;
        final String csvSplitBy = ",";
        try {
            iStreamReader = new InputStreamReader(file.getInputStream());
            bReader = new BufferedReader(iStreamReader);
            int i = 0;
            for (String line = bReader.readLine(); line != null; line = bReader.readLine()) {
                if (i == 0) { // for ignoring header
                    i++;
                    continue;
                }
                if (line != null && !line.equals("")) {
                    row = line.split(csvSplitBy);
                    if (row.length == 4) {
                        IdentityRemovalBO bo=new IdentityRemovalBO();
                        String ihi = row[0];
                      
                       
                        String lastName = row[1];
                        String gender = row[2];
                        String dob = row[3];
                        bo.setIhi(ihi);
                        bo.setFamily_Name(lastName);
                        bo.setSex(gender);
                        bo.setDob(dob);
                        listIdentityRemovalBO.add(bo);
                    } else {
                        
                        LOG.debug("noty in proer format");
                    }
                }
               
            }
        } catch (Exception e) {
            LOG.fatal("exception ", e);
        }
        LOG.debug("Leaving getIdentityRemovalInputsFromCSV..."+listIdentityRemovalBO.size());
        return listIdentityRemovalBO;
    }
/*
 * Error csv for bulk validation faliyer and reosine
 */
    public void createCSVForIdentityRemoval(IdentityRecordRemovalForm form) {
        //code change for multiple csv file creation
        String filePath = null;
        String csvFileName = null;
        Date dat = new Date();
        //ddMMyyyyhhmmss
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd_hh_mm_ss");
        String date = ft.format(dat);
        LOG.debug("insied createCSV");
        //need to change to proper location
        String fileSeperator=File.separator;
        String csvFolderLocation =System.getProperty("user.dir") + fileSeperator+ "IdentityAndRecordRemoval"+ fileSeperator+"OutputCsv"+fileSeperator;
        if(form.getValidationStatus() != null && form.getValidationStatus().equals("invalidData")){
            csvFileName = "Error_" + date + ".csv";
        }else{  
            csvFileName = "Output_" + date + ".csv";
        }
            
        Path path = Paths.get(csvFolderLocation);
        ICsvBeanWriter csvWriter = null;
        try {
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
            
            filePath = csvFolderLocation + File.separator + csvFileName;
            File file = new File(filePath);
            if(!file.exists()){
                file.createNewFile();
            }
            csvWriter =
                new CsvBeanWriter(new FileWriter(csvFolderLocation + csvFileName), CsvPreference.STANDARD_PREFERENCE);
            String[] header = { "Ihi", "LastName", "Gender", "Dob", "description"};
            csvWriter.writeHeader(header);
            for (IdentityRecordRemovalResponseBO error : form.getListIdentityRecordRemovalResponseBO()) {
                csvWriter.write(error, header);
                form.setOutPutFilename(csvFolderLocation + csvFileName);
            }
        } catch (Exception e) {
            LOG.fatal("Exception ...", e);
        } finally {
            if (csvWriter != null) {
                try {
                    csvWriter.close();
                } catch (IOException ex) {
                    LOG.fatal("Error closing the writer: ", ex);
                }
            }
        }
        LOG.debug("Leaving createCSV");
    }
    /**
     *
     * @param identityRemovalBO
     * @return
     */
    
    public IdentityRecordRemovalResponseBO setErrorBo(IdentityRemovalBO identityRemovalBO ){
        IdentityRecordRemovalResponseBO errorBo=new IdentityRecordRemovalResponseBO();
        errorBo.setIhi(identityRemovalBO.getIhi());
        errorBo.setDob(identityRemovalBO.getDob());
        errorBo.setGender(identityRemovalBO.getSex());
        errorBo.setLastName(identityRemovalBO.getFamily_Name());
        return errorBo;
    }
    /**
     * 
     */
    public IdentityRecordRemovalResponseBO setErrorBo(String ihi ){
        IdentityRecordRemovalResponseBO errorBo=new IdentityRecordRemovalResponseBO();
        errorBo.setIhi(ihi);
//        errorBo.setDob(identityRemovalBO.getDob());
//        errorBo.setGender(identityRemovalBO.getSex());
//        errorBo.setLastName(identityRemovalBO.getFamily_Name());
        return errorBo;
    }
}

