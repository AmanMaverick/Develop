package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.DocTransformationErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationRLSBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationStyleSheetBO;
import au.gov.doha.pcehr.recovery.bo.GetDocumentHTBWSClientBO;
import au.gov.doha.pcehr.recovery.bo.GetDocumentListClientBO;
import au.gov.doha.pcehr.recovery.bo.GetDocumnetOAGWSClientBO;
import au.gov.doha.pcehr.recovery.constants.DTClassCodePropertiesConstants;
import au.gov.doha.pcehr.recovery.constants.DTFolderLocationConstants;
import au.gov.doha.pcehr.recovery.dao.DocumentTransformationDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.util.StyleSheetUtil;
import au.gov.doha.pcehr.recovery.util.ZipUnzipUtill;
import au.gov.doha.pcehr.recovery.wsclient.GetDocumentHTBClient;
import au.gov.doha.pcehr.recovery.wsclient.GetDocumentListClient;
import au.gov.doha.pcehr.recovery.wsclient.GetDocumnetOAGClient;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBElement;
import javax.xml.transform.stream.StreamSource;

import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryResponse;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ClassificationType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ExternalIdentifierType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ExtrinsicObjectType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.IdentifiableType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.RegistryObjectListType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.SlotType1;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Service;

/**
 * Service to perform all DocTransformation related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 29 Dec 2014
 * @version Change-x
 */
@Service
public class DocumentTransformationService {
    public DocumentTransformationService() {
        super();
    }
    private static Logger LOG = Logger.getLogger(DocumentTransformationService.class);
    private static final String HTB_REP_ID = "1.2.36.1.2001.1007.10.8003640002000050";
    private static final String DOCUMENT_STATUS_ACTIVE = "A";
    private static final String DOCUMENT_STATUS_LATEST_DEPRECATED = "L";
    private static final String DOCUMENT_STATUS_APPROVED = "Approved";
    private static final String DOCUMENT_STATUS_DEPREICATED = "Deprecated";

    @Autowired
    GetDocumentListClient getDocumentListClient;

    @Autowired
    @Qualifier("DocumentTransformationDAO")
    DocumentTransformationDAO documentTransformationDAO;
    @Autowired
    InsertAuditRecordService insertAuditRecordService;
    @Autowired
    FileUtil fileUtility;
    @Autowired
    DateTimeUtil dateTimeUtil;
    @Autowired
    StyleSheetUtil styleSheetUtil;
    @Autowired
    ZipUnzipUtill zipUnzipUtill;
    @Autowired
    GetDocumentHTBClient getDocumenthtbClient;
    @Autowired
    GetDocumnetOAGClient getDocumnetOAGClient;

    /**
     *Used to perform doc transformation work and call the other methods
     * @param form
     * @return
     * @throws IOException
     */
    public DocumentTransformationForm performDocumentTransformation(DocumentTransformationForm form) throws IOException,
                                                                                                            RecoveryDAOException {
        try {
            LOG.debug("Enetring performDocumentTransformation.. ");
            List<String> list;
            List<String> dateRangedocIdList;
            Set<String> ihiListInErrorCSV = new HashSet<String>();
            MultipartFile file = form.getFile();
            if (form.getInputType() != null && form.getInputType().length() > 0) {
                LOG.debug("Reading from file.. ");
                list = fileUtility.createList(file);
                form.setIhiList(list);
            } else {
                LOG.debug("Calling audit DB to fetch Document ID for date range as the input... ");
                //calling getDocumentListFromOSBAudit query to retrieve the distinct doc_ids with business event as upload document for a given date range
                dateRangedocIdList = documentTransformationDAO.getDocumentListFromOSBAudit(form);
                if(dateRangedocIdList!=null && dateRangedocIdList.size()==0){
                    LOG.debug("no doc found in given date range...returning form");
                    form.setDocNotFoundDateRange("no doc found in given date range");
                    return form;
                }
                //list = documentTransformationDAO.getDocumentId(form);
                form.setIhiList(dateRangedocIdList);
            }

            int failCount = 0;
            long lStartTime = new Date().getTime();
            //will call getDocumentListCall irrespective of any type of input (ihi,Document_id,date_range)
            form = getDocumentListCall(form);
            //            if(form.getInputType()!= null && form.getInputType().length()>0){
            //                form = getDocumentListCall(form);
            //            }else{
            //                //Called for increasing performance.
            //                form = documentTransformationDAO.getDocListDateRange(form);
            //            }

            long lEndTime = new Date().getTime();
            LOG.debug("time taken for DAO query in milliseconds:::...." + (lEndTime - lStartTime));

            //calling the ws for all the IHI using the HashMap
            form = perfomWsCall(form);
            if (form.getZippedFileList() != null) {
                LOG.debug("number of Zipped folder created in controller afetr perfomWsCall:::" +
                          form.getZippedFileList().size());
                form.setZipFileCount(form.getZippedFileList().size());

            }
            if (form.getErrorBoList() != null && form.getErrorBoList().size() > 0) {
                fileUtility.createCSV(form);
                for (int i = 0; i < form.getErrorBoList().size(); i++) {
                    if (form.getErrorBoList().get(i).getStatus().equalsIgnoreCase("FAIL")) {
                        ihiListInErrorCSV.add(form.getErrorBoList().get(i).getIHI());
                        failCount++;
                    }

                }
                form.setErrorCSVIhiCount(ihiListInErrorCSV.size());
                form.setErrorCSVFailCount(failCount);
                LOG.debug("number of IHI in errorCSV is :::" + ihiListInErrorCSV.size());
                LOG.debug("error occured in processing. size." + form.getErrorBoList().size());

            }
            LOG.debug("hasp map for ihi and rls size.." + form.getIhiRlsMap().size());
        } catch (Exception e) {
            LOG.fatal("exception e..", e);
        }
        LOG.debug("Leaving performDocumentTransformation ");
        return form;
    }

    private DocumentTransformationForm formErrorMsg(DocumentTransformationForm form, DocTransformationErrorBO errorBo) {

        if (form.getErrorBoList() != null) {
            form.getErrorBoList().add(errorBo);
        } else {
            ArrayList<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
            listErrorBo.add(errorBo);
            form.setErrorBoList(listErrorBo);
        }
        return form;
    }

    /**
     *
     * @param form
     * @throws WebServiceClientException
     */
    private DocumentTransformationForm getDocumentListCall(DocumentTransformationForm form) throws WebServiceClientException,
                                                                                                   ParseException {
        LOG.debug("inside getDocumentListCall...");
        HashMap<String, List<DocumentTransformationRLSBO>> getDocClntMap =
            new HashMap<String, List<DocumentTransformationRLSBO>>();
        List<GetDocumentListClientBO> listBo = getGetDocumentBO(form);
        String sysDate = fileUtility.getDateFormat();
        for (GetDocumentListClientBO getDocumentListClientBO : listBo) {
            LOG.debug("cqaliing get Doc for ihi:::" + getDocumentListClientBO.getDocumentEntryPatientId());
            LOG.debug("cqaliing get Doc for doc id:::" + getDocumentListClientBO.getDocumentEntryUniqueId());
            AdhocQueryResponse adhocQueryResponse = getDocumentListClient.getDocListWsCall(getDocumentListClientBO);
            if (adhocQueryResponse.getStatus().equals("urn:oasis:names:tc:ebxml-regrep:ResponseStatusType:Failure")) {

                String errMsg = adhocQueryResponse.getRegistryErrorList().getRegistryError().get(0).getCodeContext();
                DocTransformationErrorBO errorBo =
                    fileUtility.createErrorBo((getDocumentListClientBO.getDocumentEntryPatientId() != null) ?
                                              getDocumentListClientBO.getDocumentEntryPatientId().get(0) : "N/A",
                                              getDocumentListClientBO.getDocumentEntryUniqueId() != null ?
                                              getDocumentListClientBO.getDocumentEntryUniqueId().get(0) : "N/A", errMsg,
                                              "N/A", "FAIL", sysDate);
                form = formErrorMsg(form, errorBo);
                continue;
            }

            RegistryObjectListType rType = adhocQueryResponse.getRegistryObjectList();
            List<JAXBElement<? extends IdentifiableType>> list = rType.getIdentifiable();
            if (list.size() == 0) {
                DocTransformationErrorBO errorBo =
                    fileUtility.createErrorBo((getDocumentListClientBO.getDocumentEntryPatientId() != null) ?
                                              getDocumentListClientBO.getDocumentEntryPatientId().get(0) : "N/A",
                                              getDocumentListClientBO.getDocumentEntryUniqueId() != null ?
                                              getDocumentListClientBO.getDocumentEntryUniqueId().get(0) : "N/A",
                                              "Document Not found", "N/A", "FAIL", sysDate);
                form = formErrorMsg(form, errorBo);
                continue;
            }
            Iterator itertaor = list.iterator();
            while (itertaor.hasNext()) {
                boolean statusdoc = false;
                DocumentTransformationRLSBO bo = new DocumentTransformationRLSBO();
                JAXBElement jaxbListObj = (JAXBElement) itertaor.next();
                if (jaxbListObj != null) {
                    ExtrinsicObjectType exctrinsicObj = (ExtrinsicObjectType) jaxbListObj.getValue();
                    String status = exctrinsicObj.getStatus();

                    if (status.contains(DOCUMENT_STATUS_APPROVED) &&
                        form.getDocStatus().contains(DOCUMENT_STATUS_ACTIVE)) {
                        statusdoc = true;
                    } else if (status.contains(DOCUMENT_STATUS_DEPREICATED) &&
                               form.getDocStatus().contains(DOCUMENT_STATUS_LATEST_DEPRECATED)) {
                        statusdoc = true;
                    }
                    LOG.debug("get doclist status ::::" + status);


                    List<SlotType1> sloteType1Lst = exctrinsicObj.getSlot();
                    Iterator sloTypeIterator = sloteType1Lst.iterator();
                    while (sloTypeIterator.hasNext()) {
                        SlotType1 slotType1 = (SlotType1) sloTypeIterator.next();
                        String name = slotType1.getName();
                        LOG.debug("Slot Name:" + name);
                        if ("repositoryUniqueId".equals(name)) {
                            bo.setRepositoryID(slotType1.getValueList().getValue().get(0));
                            LOG.debug("Slot Name:" + name + ":" + bo.getRepositoryID());
                        } else if ("sourcePatientId".equals(name)) {
                            bo.setIhi(slotType1.getValueList().getValue().get(0).toString().substring(0, 16));
                            LOG.debug("Slot Name:" + name + ":" + bo.getIhi());
                        }
                    }
                    //Document ID
                    List<ExternalIdentifierType> extType = exctrinsicObj.getExternalIdentifier();
                    Iterator extIter = extType.iterator();
                    while (extIter.hasNext()) {
                        ExternalIdentifierType ext = (ExternalIdentifierType) extIter.next();

                        if (ext.getIdentificationScheme().equals("urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab")) {
                            bo.setDocumentID(ext.getValue());
                            LOG.debug("DocumentID:" + bo.getDocumentID());
                        }
                    }

                    //Document type
                    if (null != exctrinsicObj.getClassification() && !exctrinsicObj.getClassification().isEmpty()) {
                        List<ClassificationType> classList = exctrinsicObj.getClassification();
                        Iterator classIterator = classList.iterator();
                        while (classIterator.hasNext()) {
                            ClassificationType classificationType = (ClassificationType) classIterator.next();
                            String classificationScheme = classificationType.getClassificationScheme();
                            if (classificationScheme.equals("urn:uuid:41a5887f-8865-4c09-adf7-e362475b143a")) {
                                String docTypeCode = classificationType.getNodeRepresentation();
                                bo.setDocmentType(docTypeCode);
                                LOG.debug("DocmentType:" + bo.getDocmentType());
                            }
                        }
                    }
                }

                if (statusdoc) {
                    LOG.debug("document status match found");
                    List<DocumentTransformationRLSBO> listGetDocLstBo = null;
                    if (getDocClntMap.containsKey(bo.getIhi())) {
                        //Checking for the uniq
                        listGetDocLstBo = getDocClntMap.get(bo.getIhi());
                        boolean docStatus = false;
                        for (DocumentTransformationRLSBO documentTransformationRLSBO : listGetDocLstBo) {
                            if (documentTransformationRLSBO.getDocumentID().equals(bo.getDocumentID())) {
                                docStatus = true;
                            }
                        }
                        if (!docStatus) {
                            listGetDocLstBo.add(bo);
                            getDocClntMap.put(bo.getIhi(), listGetDocLstBo);
                        }
                    } else {
                        listGetDocLstBo = new ArrayList<DocumentTransformationRLSBO>();
                        listGetDocLstBo.add(bo);
                        getDocClntMap.put(bo.getIhi(), listGetDocLstBo);
                    }
                    LOG.debug("IHI key " + bo.getIhi() + "...list size.." + listGetDocLstBo.size());
                } else {
                    LOG.debug("document status mismatch found");
                    DocTransformationErrorBO errorBo =
                        fileUtility.createErrorBo((getDocumentListClientBO.getDocumentEntryPatientId() != null) ?
                                                  getDocumentListClientBO.getDocumentEntryPatientId().get(0) : "N/A",
                                                  getDocumentListClientBO.getDocumentEntryUniqueId() != null ?
                                                  getDocumentListClientBO.getDocumentEntryUniqueId().get(0) : "N/A",
                                                  "Document Not found for selected status", "N/A", "FAIL", sysDate);
                    form = formErrorMsg(form, errorBo);
                }


            }


        }
        form.setIhiRlsMap(getDocClntMap);
        return form;
    }

    /**
     * Get document list client BO
     * @param ihi
     * @return
     */
    private List<GetDocumentListClientBO> getGetDocumentBO(DocumentTransformationForm form) throws ParseException {
        //LOG.debug("entering getGetDocumentBO... " + form.getIhiList().size());
        SimpleDateFormat sdfDestination = new SimpleDateFormat("yyyyMMddHHmm");
        List<GetDocumentListClientBO> listBo = new ArrayList<GetDocumentListClientBO>();
        List<String> class_codes = getPropertiesValues(form);
        for (String ihiOrDocId : form.getIhiList()) {
            GetDocumentListClientBO getDocumentListClientBO = new GetDocumentListClientBO();

            if ("IHI".equals(form.getInputType())) {

                List<String> ihi = new ArrayList<String>();
                ihi.add(ihiOrDocId);
                getDocumentListClientBO.setDocumentEntryPatientId(ihi);
                getDocumentListClientBO.setAdhocQueryID(getDocumentListClient.ADHOC_QUERY_ID_PATIENT);
            } else {

                List<String> docid = new ArrayList<String>();
                docid.add(ihiOrDocId);
                getDocumentListClientBO.setDocumentEntryUniqueId(docid);
                getDocumentListClientBO.setAdhocQueryID(getDocumentListClient.ADHOC_QUERY_ID);
            }

            if ((form.getInputType() != null && form.getInputType().length() > 0) && form.getCreationTime() != null &&
                form.getCreationTime().length() > 0) {
                getDocumentListClientBO.setDocumentEntryServiceStartTimeFrom(sdfDestination.format(dateTimeUtil.stringToJavaDate(form.getCreationTime())));
                LOG.debug("getDocumentListClientBO..." +
                          getDocumentListClientBO.getDocumentEntryServiceStartTimeFrom());
            }
            if ((form.getInputType() != null && form.getInputType().length() > 0) && form.getEndTime() != null &&
                form.getEndTime().length() >
                0) {
                //increasing to date by 1 day to get all the documents uploaded for the whole date
                getDocumentListClientBO.setDocumentEntryServiceStartTimeTo(sdfDestination.format(dateTimeUtil.increaseDateByOne(dateTimeUtil.stringToJavaDate(form.getEndTime()))));
            }
            if (form.getDocumentType() != null) {
                getDocumentListClientBO.setDocumentEntryTypeCode(class_codes);
            }
            List<String> docEntryStatus = new ArrayList<String>();
            if (form.getDocStatus() != null && form.getDocStatus().size() > 0) {

                if (form.getDocStatus().size() == 2) {
                    docEntryStatus.add(getDocumentListClient.DOCENTRY_STATUS_APPROVED_AND_DELETED);
                } else if (form.getDocStatus().contains(DOCUMENT_STATUS_ACTIVE)) {
                    docEntryStatus.add(getDocumentListClient.DOCENTRY_STATUS_APPROVED);
                } else if (form.getDocStatus().contains(DOCUMENT_STATUS_LATEST_DEPRECATED)) {
                    docEntryStatus.add(getDocumentListClient.DOCENTRY_STATUS_DELETED);
                }

            }

            getDocumentListClientBO.setDocumentEntryStatus(docEntryStatus);
            listBo.add(getDocumentListClientBO);
        }
        LOG.debug("Leaving getGetDocumentBO... ");
        return listBo;
    }

    /**
     *Used to call the WS and peform calling the utilities
     * @param form
     */
    private DocumentTransformationForm perfomWsCall(DocumentTransformationForm form) {
        LOG.debug("entering perfomWsCall ");


        String xsltPathXML = DTFolderLocationConstants.STYLE_SHEET_LOCATION_XML;
        String xsltPathHTML = DTFolderLocationConstants.STYLE_SHEET_LOCATION_HTML;


        try {
            StreamSource xmlStreamSource = getStreamSourceForStylesheets(xsltPathXML);
            StreamSource htmlStreamSource = getStreamSourceForStylesheets(xsltPathHTML);
            LOG.debug("here...perfomWsCall" + form.getIhiRlsMap().size());
            HashMap<String, List<DocumentTransformationRLSBO>> map = form.getIhiRlsMap();
            if (map != null) {
                LOG.debug("hashmap values:::" + map.size());
                for (int k = 0; k < map.size(); k++) {
                    LOG.debug("k value:::" + k);
                }
                Set set = map.entrySet();
                Iterator i = set.iterator();

                while (i.hasNext()) {
                    Map.Entry me = (Map.Entry) i.next();
                    LOG.debug("key:::" + me.getKey() + ": ");
                    List<DocumentTransformationRLSBO> listBO = (List<DocumentTransformationRLSBO>) me.getValue();
                    LOG.debug("here..in loop 1...." + i);

                    LOG.debug("IHI value:::::" + me.getKey());
                    LOG.debug("number of doc id is ::::" + listBO.size());

                    for (int j = 0; j < listBO.size(); j++) {
                        LOG.debug("for loop values::::getDocumentID: " + listBO.get(j).getDocumentID());
                        LOG.debug("for loop values::::getRepositoryID: " + listBO.get(j).getRepositoryID());
                        byte[] docInBytes = null;
                        if (HTB_REP_ID.equals(listBO.get(j).getRepositoryID())) {
                            LOG.debug("calling client for HTB");

                            long lStartTime = new Date().getTime();
                            form =
                                getDocumenthtbClient.getDocument(form,
                                                                 setHTBWsBO(listBO.get(j).getDocumentID(),
                                                                            listBO.get(j).getRepositoryID(),
                                                                            listBO.get(j).getDocmentType(),
                                                                            me.getKey().toString()));
                            docInBytes = form.getWsResposeDoc();
                            long lEndTime = new Date().getTime();
                            LOG.debug("time taken for HTB WS call for one doc in milliseconds:::....." +
                                      (lEndTime - lStartTime));

                        } else {
                            LOG.debug("calling client for OAG");

                            //uncomment the below line to call oag client
                            long lStartTime = new Date().getTime();
                            form =
                                getDocumnetOAGClient.getExtDocument(form,
                                                                    setOAGWsBO(listBO.get(j).getDocumentID(),
                                                                               listBO.get(j).getRepositoryID(),
                                                                               listBO.get(j).getDocmentType(),
                                                                               me.getKey().toString()));
                            docInBytes = form.getWsResposeDoc();
                            long lEndTime = new Date().getTime();
                            LOG.debug("time taken for OAG WS call for one doc in milliseconds:::...." +
                                      (lEndTime - lStartTime));
                        }
                        if (docInBytes != null) {
                            if ("CDA".equals(form.getFileFormat())) {
                                LOG.debug("file format is CDA");
                                form =
                                    extarctCDA(docInBytes, form, listBO.get(j).getDocumentID(), listBO.get(j).getIhi());
                                LOG.debug("number of Zipped folder created in controller :::" +
                                          form.getZippedFileList().size());
                            } else {
                                LOG.debug("file format is xml or html");

                                long lStartTime = new Date().getTime();
                                List<String> xmlFileName =
                                    fileUtility.extractAttchement(docInBytes, listBO.get(j).getDocumentID(),
                                                                  me.getKey().toString(), form.getDe_Identification(),
                                                                  DTFolderLocationConstants.EXTRACTED_FILES_FROM_WEBSERVICE);
                                long lEndTime = new Date().getTime();
                                LOG.debug("time taken for Extracting one CDA document in milliseconds::....." +
                                          (lEndTime - lStartTime));
                                if (xmlFileName != null) {
                                    if (form.getFileFormat().equalsIgnoreCase("xml") &&
                                        form.getDe_Identification().equalsIgnoreCase("no")) {
                                        LOG.debug("file format is XML and de-identification is NO");
                                        long lStartTime1 = new Date().getTime();
                                        boolean moveFileStatus =
                                            fileUtility.moveFiles(xmlFileName,
                                                                  FilenameUtils.removeExtension(xmlFileName.get(0)));
                                        form.setAuditRequired(moveFileStatus);
                                        long lEndTime1 = new Date().getTime();
                                        LOG.debug("time taken for Moving files for XML and NO in milliseconds:::...." +
                                                  (lEndTime1 - lStartTime1));
                                    }
                                    //for stylesheets

                                    //code added
                                    else if (form.getFileFormat().equalsIgnoreCase("html") &&
                                             form.getDe_Identification().equalsIgnoreCase("yes")) {

                                        LOG.debug("file format is html and de-identification is YES");
                                        styleSheetUtil.setDocumentTransformationStyleSheetBO(setDocumentTransformationStyleSheetBO(listBO.get(j).getDocumentID(),
                                                                                                                                   listBO.get(j).getDocmentType(),
                                                                                                                                   me.getKey().toString()));
                                        //for deidentifyoing the extracted xml apply the xml stylesheet
                                        LOG.debug("calling xml stylesheet");
                                        long lStartTime1 = new Date().getTime();
                                        styleSheetUtil.applyStyleSheet(form, xmlFileName.get(0), xmlFileName.get(1),
                                                                       FilenameUtils.removeExtension(xmlFileName.get(0)),
                                                                       form.getFileFormat(),
                                                                       form.getDe_Identification(), xmlStreamSource,
                                                                       htmlStreamSource, false);
                                        long lEndTime1 = new Date().getTime();
                                        LOG.debug("time taken for applying stylesheets HTML and YES for xmlStlesheet in milliseconds:::...." +
                                                  (lEndTime1 - lStartTime1));
                                        LOG.debug("calling html stylesheet");
                                        //from deidentified xml to final html--apply html stylesheet
                                        long lStartTime2 = new Date().getTime();
                                        styleSheetUtil.applyStyleSheet(form, xmlFileName.get(0), xmlFileName.get(1),
                                                                       FilenameUtils.removeExtension(xmlFileName.get(0)),
                                                                       form.getFileFormat(),
                                                                       form.getDe_Identification(), xmlStreamSource,
                                                                       htmlStreamSource, true);
                                        long lEndTime2 = new Date().getTime();
                                        LOG.debug("time taken for applying stylesheets HTML and YES for HTMLStlesheet in milliseconds:::...." +
                                                  (lEndTime2 - lStartTime2));

                                    } else {

                                        LOG.debug("file format is" + form.getFileFormat() + "and de-identification is" +
                                                  form.getDe_Identification());
                                        styleSheetUtil.setDocumentTransformationStyleSheetBO(setDocumentTransformationStyleSheetBO(listBO.get(j).getDocumentID(),
                                                                                                                                   listBO.get(j).getDocmentType(),
                                                                                                                                   me.getKey().toString()));
                                        long lStartTime1 = new Date().getTime();
                                        styleSheetUtil.applyStyleSheet(form, xmlFileName.get(0), xmlFileName.get(1),
                                                                       FilenameUtils.removeExtension(xmlFileName.get(0)),
                                                                       form.getFileFormat(),
                                                                       form.getDe_Identification(), xmlStreamSource,
                                                                       htmlStreamSource, true);

                                        long lEndTime1 = new Date().getTime();
                                        LOG.debug("time taken for applying stylesheets HTML/XML and NO/YEs for HTMLStlesheet in milliseconds:::...." +
                                                  (lEndTime1 - lStartTime1));

                                    }
                                    //


                                }
                            }
                        }
                    }
                    //for insert audit
                    if (listBO != null && listBO.size() > 0) {
                        if (form.isAuditRequired() == true) {
                            LOG.debug("for insert audit..IHI" + me.getKey().toString());

                            AuditRecordBO auditBO = getAuditRecordBO(form, me.getKey().toString());
                            LOG.debug("calling insertAudit service" + me.getKey().toString());
                            auditBO = insertAuditRecordService.insertAudit(auditBO);
                        }

                    }
                }
            }
            //html and no for deidetifcation is not yet impleted
            if (!"CDA".equals(form.getFileFormat())) {
                if (form.getFileFormat().equalsIgnoreCase("xml") &&
                    form.getDe_Identification().equalsIgnoreCase("no")) {
                    long lStartTime1 = new Date().getTime();
                    zipUnzipUtill.zipFIles(DTFolderLocationConstants.WITHOUT_STYLESHEET_DOCS,
                                           DTFolderLocationConstants.ZIPPED_FOLDER_LOCATION, form);
                    long lEndTime1 = new Date().getTime();
                    LOG.debug("time taken for Zipping all files xml and no in milliseconds:::...." +
                              (lEndTime1 - lStartTime1));


                } else {
                    long lStartTime1 = new Date().getTime();
                    zipUnzipUtill.zipFIles(DTFolderLocationConstants.STYLE_SHEET_APPLIED_DOCS_LOCATION,
                                           DTFolderLocationConstants.ZIPPED_FOLDER_LOCATION, form);
                    long lEndTime1 = new Date().getTime();
                    LOG.debug("time taken for Zipping all files for others in milliseconds:::...." +
                              (lEndTime1 - lStartTime1));
                }
            }

        } catch (Exception e) {
            LOG.fatal("Exception ..", e);
        } finally {
            long lStartTime1 = new Date().getTime();
            fileUtility.deleteFiles(DTFolderLocationConstants.WITHOUT_STYLESHEET_DOCS);
            fileUtility.deleteFiles(DTFolderLocationConstants.STYLE_SHEET_APPLIED_DOCS_LOCATION);
            fileUtility.deleteFiles(DTFolderLocationConstants.EXTRACTED_FILES_FROM_WEBSERVICE);

            long lEndTime1 = new Date().getTime();
            LOG.debug("time taken for deleting all files in finaly block :::...." + (lEndTime1 - lStartTime1));
        }
        if (form.getZippedFileList() != null) {
            LOG.debug("number of Zipped folder created :::" + form.getZippedFileList().size());
        }
        LOG.debug("Leaving perfomWsCall ");
        return form;
    }

    /**
     *
     * @param docInBytes
     * @param form
     * @param docID
     */
    private DocumentTransformationForm extarctCDA(byte[] docInBytes, DocumentTransformationForm form, String docID,
                                                  String ihi) {
        LOG.debug("inside extarctCDA...");
        List ihiList = null;
        List<String> zippedFileList = new ArrayList<String>();
        String fileSeperator = File.separator;
        String zipFolderName = ihi + "_" + docID + "-CDA.zip";
        String destination =
            System.getProperty("user.dir") + fileSeperator + "DocumentTransformation" + fileSeperator + "ZippedFolder" +
            fileSeperator + "CDA" + fileSeperator + zipFolderName;
        LOG.debug("cda file path..." + destination);
        try {
            boolean zipStatus = zipUnzipUtill.extractZip(docInBytes, destination, docID);
            if (zipStatus == true) {
                LOG.debug("here......" + form.getZippedFileList());
                // if(!form.getCdaZippedCreatedIHIList().contains(ihi))
                //form.getCdaZippedCreatedIHIList().add(ihi);
                if (form.getZippedFileList() != null) {
                    form.getZippedFileList().add(zipFolderName);
                } else {
                    LOG.debug("here creating zippedFileList...");
                    zippedFileList.add(zipFolderName);
                    form.setZippedFileList(zippedFileList);
                }

                LOG.debug("added...");
            }
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        } catch (Exception e) {
            LOG.fatal("here exception:::", e);
        }
        //LOG.debug("number of Zipped folder created in controller :::" + form.getZippedFileList().size());
        LOG.debug("zipped count:::" + form.getZippedFileList().size());
        form.setAuditRequired(true);
        return form;
    }

    /**
     *Used to read the HashMap value and retrun the list of BO
     * @param map
     */
    private List<DocumentTransformationRLSBO> readHashMap(HashMap<String, List<DocumentTransformationRLSBO>> map) {
        LOG.debug("inside readHashMap::::" + map);
        Set set = map.entrySet();
        List<DocumentTransformationRLSBO> listBo = null;

        Iterator i = set.iterator();

        while (i.hasNext()) {
            Map.Entry me = (Map.Entry) i.next();
            System.out.print("key:::" + me.getKey() + ": ");
            listBo = (List<DocumentTransformationRLSBO>) me.getValue();
            for (int j = 0; j < listBo.size(); j++) {
                LOG.debug("hasmap qury retun value for :::" + j);
                LOG.debug("value getDocmentType:...." + listBo.get(j).getDocmentType());
                LOG.debug("value getDocumentID:...." + listBo.get(j).getDocumentID());
                LOG.debug("value getIhi:...." + listBo.get(j).getIhi());
                LOG.debug("value getRepositoryID:...." + listBo.get(j).getRepositoryID());
            }
        }
        return listBo;
    }

    /**
     *Used to create HTB Client BO
     * @param docID
     * @param repId
     */
    public GetDocumentHTBWSClientBO setHTBWsBO(String docID, String repId, String documentType, String ihi) {
        GetDocumentHTBWSClientBO bo = new GetDocumentHTBWSClientBO();
        bo.setDocumentID(docID);
        bo.setRepositoryID(repId);
        bo.setIhi(ihi);
        bo.setDocumnetType(documentType);
        return bo;
    }

    /**
     *
     * @param docID
     * @param repId
     * @return
     */
    public GetDocumnetOAGWSClientBO setOAGWsBO(String docID, String repId, String documentType, String ihi) {
        GetDocumnetOAGWSClientBO bo = new GetDocumnetOAGWSClientBO();
        bo.setDocumentID(docID);
        bo.setRepositoryID(repId);
        bo.setIhi(ihi);
        bo.setDocumnetType(documentType);
        bo.setAction(documentTransformationDAO.getWSAAction(repId));
        return bo;
    }

    /**
     *
     * @param docID
     * @param repId
     * @param documentType
     * @param ihi
     * @return
     */
    private DocumentTransformationStyleSheetBO setDocumentTransformationStyleSheetBO(String docID, String documentType,
                                                                                     String ihi) {
        DocumentTransformationStyleSheetBO bo = new DocumentTransformationStyleSheetBO();
        bo.setDocumentID(docID);
        bo.setIhi(ihi);
        bo.setDocumnetType(documentType);
        return bo;
    }

    private StreamSource getStreamSourceForStylesheets(String xsltPath) {

        return new StreamSource(new File(xsltPath));
    }

    /**
     *
     * @param docTransformationForm
     * @param username
     * @return
     */
    private AuditRecordBO getAuditRecordBO(DocumentTransformationForm docTransformationForm, String ihi) {
        AuditRecordBO auditRecordBO = new AuditRecordBO();
        auditRecordBO.setUserID(docTransformationForm.getUserID());
        //should be username
        auditRecordBO.setUsername(docTransformationForm.getSystemOperator());
        auditRecordBO.setIhi(ihi);


        auditRecordBO.setVendor("NIO");
        auditRecordBO.setProductName("OPS Tool");
        auditRecordBO.setProdoctVersion("1.1");
        auditRecordBO.setPlatForm("Jump Host");


        //check condition for failed or completed
        auditRecordBO.setTransactionStatus("COMPLETED");


        auditRecordBO.setComponentSource("NIO");

        auditRecordBO.setIhiName("");
        if (!"CDA".equals(docTransformationForm.getFileFormat())) {
            auditRecordBO.setBusinessEvent("DocumentTransformation");
            if (docTransformationForm.getDe_Identification().equalsIgnoreCase("yes")) {
                auditRecordBO.setSubject("Masked");
                auditRecordBO.setActionType("Update");
            } else if (docTransformationForm.getDe_Identification().equalsIgnoreCase("no")) {
                auditRecordBO.setSubject("Un-masked");
                auditRecordBO.setActionType("Read");
            }
        } else {
            //for CDA file format
            auditRecordBO.setBusinessEvent("DocumentTransformation-CDA");
            auditRecordBO.setSubject("Un-masked");
            auditRecordBO.setActionType("Read");
        }
        auditRecordBO.setSubjectType("IHI");

        auditRecordBO.setOperationPerfomed("DocumentTransformation");
        auditRecordBO.setReason(null);
        auditRecordBO.setAccessConditions("OpenAccess");
        auditRecordBO.setAccessLevel("Self");
        auditRecordBO.setDescription("Transaction completed");
        auditRecordBO.setMessageLogLevel("AUDIT");
        auditRecordBO.setStatus(true);
        auditRecordBO.setStatusCode("");
        auditRecordBO.setSoapMesage("");

        return auditRecordBO;
    }


    /**
     *
     * @param form
     * @return
     */
    public List<String> getPropertiesValues(DocumentTransformationForm form) {
        LOG.debug("enetring getPropertiesValues1...");
        List<String> codeList = new ArrayList();
        List<String> userSelectedclassCodes = form.getDocumentType();
        if (userSelectedclassCodes != null && userSelectedclassCodes.size() > 0) {
            for (int i = 0; i < userSelectedclassCodes.size(); i++) {
                Set set = DTClassCodePropertiesConstants.classCodeMap.entrySet();
                Iterator k = set.iterator();
                while (k.hasNext()) {
                    Map.Entry me = (Map.Entry) k.next();
                    if (me.getKey().toString().replaceAll("_", " ").equalsIgnoreCase(userSelectedclassCodes.get(i)))
                        if (me.getValue().toString().contains(",")) {
                            LOG.debug("class code with comma.." + me.getValue().toString());
                            for (int j = 0; j < me.getValue().toString().split(",").length; j++) {
                                LOG.debug("class code afetr separating comma .." +
                                          me.getValue().toString().split(",")[j]);
                                codeList.add((me.getValue().toString().split(","))[j].toString());

                            }
                        } else {
                            codeList.add(me.getValue().toString());
                        }
                }
            }
        }
        LOG.debug("Leaving getPropertiesValues1...codeList size.." + codeList.size());
        return codeList;
    }
}
