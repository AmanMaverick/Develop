package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ProviderRegistrationForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * Validates Date for Provider Registration by checking for empty date blocks and invalid dates
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Apr 2015
 * @version Change-x
 */
 
 @Component   
public class ProviderRegistrationValidator  implements Validator {
 
    private static Logger LOG = Logger.getLogger(ProviderRegistrationValidator.class);
    private static final String DATE_FORMAT="dd/MM/yyyy";
    
    @Autowired
    @Qualifier("dateTimeUtil")
    private DateTimeUtil dateTimeUtil;
    /**
    * Overriding supports method from Validator Interface
    * @param class1
    * @return
    */
    @Override
    public boolean supports(Class<?> class1) {
       return ProviderRegistrationForm.class.equals(class1);
    }

    /**
    * Overriding validate method from Validator Interface
    * @param object
    * @param errors
    */
    @Override
    public void validate(Object object, Errors errors) {

       if (object instanceof ProviderRegistrationForm) {
           ProviderRegistrationForm form = (ProviderRegistrationForm)object;
           LOG.debug("Validating the Provider Registration ");
           try {
               errors = providerRegistrationValidationMethod(form, errors);
           } catch (Exception e) {
               LOG.error("Exception occured", e);
           }
       }
    }
    
      /**
     * Calls validatedate method from DateTimeUtil() class and validates dates
     * @param providerRegistrationForm
     * @param errors
     * @return
     * @throws RecoveryDAOException
     */
    
    private Errors providerRegistrationValidationMethod(ProviderRegistrationForm providerRegistrationForm, Errors errors) throws Exception {
        LOG.debug("Inside validating Date method...");
        
        ValidationUtils.rejectIfEmpty(errors, "fromDate", "ReconciliationOps.date");
        ValidationUtils.rejectIfEmpty(errors, "toDate", "ReconciliationOps.date");
       
        
        if ((!dateTimeUtil.validatedate(providerRegistrationForm.getFromDate(),DATE_FORMAT)) || (!dateTimeUtil.validatedate(providerRegistrationForm.getToDate(),DATE_FORMAT))) 
                           errors.rejectValue("fromDate","ReconciliationOps.ValidDate");       
        // Checking if fromDate is before toDate
        if(dateTimeUtil.reconDateOrder(providerRegistrationForm.getFromDate(),providerRegistrationForm.getToDate())){
                errors.rejectValue("fromDate", "ReconciliationOps.invalidDateOrder");
            }
        LOG.debug("Leaving Validator Class");  
    return errors;
           }
 }
