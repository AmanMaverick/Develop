package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.IHISynchronizeForm;
import au.gov.doha.pcehr.recovery.service.IHIDemographicsSyncService;
import au.gov.doha.pcehr.recovery.validation.IHISynchronizationValidator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * Form class for IHI Synchronization
 * @Author Rakhi Tholia, Operations, PCEHR
 * @since 9th Apr 2015
 * @version Change-x
 */

@Controller
@RequestMapping(value = "/IHIDetailsSynchronization**")
public class IHIDemographicsSyncController {

    private static Logger LOG = Logger.getLogger(IHIDemographicsSyncController.class);
    private static final String MODEL_ATTRIBUTE = "SynchronizeIHIFormAttribute";
    private static final String IHI_SYNCHRONIZATION_HOME_PAGE = "NIO/IHIDetailsSynchronization";
    private static final String SINGLE_IHI_SYNCHRONIZE_PAGE = "NIO/IHIDetailsSynchronizationSingleIHI";
    private static final String BULK_IHI_SYNCHRONIZE_PAGE = "NIO/IHIDetailsSynchronizationBulkIHI";

    @Autowired
    IHIDemographicsSyncService ihiDemographicsSyncService;

    @Autowired
    private IHISynchronizationValidator ihiSynchronizationValidator;


    @InitBinder(MODEL_ATTRIBUTE)
    protected void initBinderConfig(WebDataBinder binder) {
        LOG.debug("Initialising the validator");
        binder.setValidator(ihiSynchronizationValidator);
    }


    /**
     * For navigation to IHI Synchronization Home page
     * @param
     * @return
     */
    @AuditBefore(AuditMessageConstants.IHI_DEMOGRAPHIC_SYNC_PAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/IHIDetailsSynchronizationCtrl")
    public String showIHISynchronizationPage(@ModelAttribute(MODEL_ATTRIBUTE)
        IHISynchronizeForm ihiSynchronizeForm) {
        LOG.debug("Inside Controller: showIHISynchronizationPage method");
        return IHI_SYNCHRONIZATION_HOME_PAGE;
    }

    /**
     * Request Mapping for Single IHI Synchronization Home page
     * @param
     * @return
     */
    @AuditBefore(AuditMessageConstants.SINGLE_IHI_DEMOGRAPHIC_SYNC_PAGE)
    @RequestMapping(method = { RequestMethod.POST }, params = "submit=SingleIHI")
    public String getSingleIHISynchronizePage(@ModelAttribute(MODEL_ATTRIBUTE)
        IHISynchronizeForm ihiSynchronizeForm, ModelMap map) {
        LOG.debug("Inside Controller: getSingleSynchronizeIHIPage method");
        map.addAttribute("IHISynchronizeForm", ihiSynchronizeForm);
        return SINGLE_IHI_SYNCHRONIZE_PAGE;
    }


    /**
     * Request Mapping for Bulk IHI Synchronization Home page
     * @param
     * @return
     */
    @AuditBefore(AuditMessageConstants.BULK_IHI_DEMOGRAPHIC_SYNC_PAGE)
    @RequestMapping(method = { RequestMethod.POST }, params = "submit=BulkIHI")
    public String getBulkIHISynchronizePage(@ModelAttribute(MODEL_ATTRIBUTE)
        IHISynchronizeForm ihiSynchronizeForm, ModelMap map) {
        LOG.debug("Inside Controller: getSingleSynchronizeIHIPage method");
        map.addAttribute("IHISynchronizeForm", ihiSynchronizeForm);
        return BULK_IHI_SYNCHRONIZE_PAGE;
    }


    /**
     * getSynchronizeIHI method is called when user requests for Single IHI synchronization
     * It first validates the input IHI using validator class. 
     * Then calls Service's singleIHISynchronize method to process it.
     * @param ihiSynchronizeForm
     * @param req
     * @param map
     * @return
     * @throws RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.SINGLE_IHI_DEMOGRAPHIC_SYNC_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, params = "SingleIHISubmit=Submit")
    public String getSynchronizeIHI(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        IHISynchronizeForm ihiSynchronizeForm, BindingResult result, ModelMap map,
        HttpServletRequest req) throws RecoveryServiceException {
        LOG.debug("Inside Controller: getDocumentList method");
        
        if (result.hasErrors()) {
            LOG.debug("Inside has errors");
            LOG.info("......" + result.hasErrors() + result.toString());
            map.addAttribute("IHISynchronizeForm", ihiSynchronizeForm);
            return SINGLE_IHI_SYNCHRONIZE_PAGE;
        }
        String user = req.getUserPrincipal().getName();
        ihiSynchronizeForm.setUserName(user);
        LOG.debug("Controller- Form status before service call " + ihiSynchronizeForm.getStatus());
        ihiSynchronizeForm= ihiDemographicsSyncService.processSingleIHI(ihiSynchronizeForm,req);
        LOG.debug("Controller- Form status after service call " + ihiSynchronizeForm.getStatus());
        map.addAttribute("IHIDemographicsSync", ihiSynchronizeForm.getStatus());
        return SINGLE_IHI_SYNCHRONIZE_PAGE;
    }


    /**
     * bulkIHIRequestHandler method is called when user requests for bulk IHI synchronization
     * It first validates the input file using validator class. 
     * Then calls Service's processBulkIHI method to process it.
     * @param ihiSynchronizeForm
     * @param req
     * @param map
     * @return
     * @throws RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.BULK_IHI_DEMOGRAPHIC_SYNC_OPERATION)
    @RequestMapping(method = RequestMethod.POST, params = "BulkIHISynchronization=Submit")
    public String bulkIHIRequestHandler(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        IHISynchronizeForm ihiSynchronizeForm, BindingResult result, ModelMap map,
        HttpServletRequest req) throws RecoveryServiceException {
        LOG.debug("Entered the controller class bulkIHIRequestHandler");
        
        if (result.hasErrors()) {
            LOG.debug("Inside has errors");
            LOG.info("......" + result.hasErrors() + result.toString());
            map.addAttribute("IHISynchronizeForm", ihiSynchronizeForm);
            return BULK_IHI_SYNCHRONIZE_PAGE;
        }
        ihiSynchronizeForm.setUserName(req.getUserPrincipal().getName());
        ihiSynchronizeForm = ihiDemographicsSyncService.processBulkIHI(ihiSynchronizeForm);
        map.addAttribute("IHIDemographicsSync", ihiSynchronizeForm);
        LOG.debug("leaving bulkIHIRequestHandler... ");
        return BULK_IHI_SYNCHRONIZE_PAGE;
    }

    /**
     * downloadSampleFile is called when user clicks on Retrieve Sample File.
     * @return
     */
    @AuditBefore(AuditMessageConstants.IHI_DEMOGRAPHIC_SYNC_TEMPLATE_DOWNLOAD)
    @RequestMapping(method = RequestMethod.POST, params = "Submit=Retrieve Sample File")
    public void downloadSampleFile(HttpSession session, HttpServletResponse response) throws ServletException,
                                                                                             IOException {
        String os = System.getProperty("os.name");
        String fileLocation = fileLocation = session.getServletContext().getRealPath("/") + File.separator+"SampleFiles"+File.separator+"IHI_List.csv";;
        LOG.debug(fileLocation);
        ServletOutputStream outputStream = null;
        try {
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=" + fileLocation);
            response.addHeader("Content-Disposition", "inline; filename=IHI_List.csv");
            File myfile = new File(fileLocation);
            FileInputStream fileIn = new FileInputStream(myfile);
            outputStream = response.getOutputStream();
            byte[] outputByte = new byte[48];
            while (fileIn.read(outputByte) > 0) {
                outputStream.write(outputByte);
            }
        } catch (IOException ioe) {
            LOG.fatal("Exception occured", ioe);
            throw new ServletException(ioe.getMessage());
        } finally {
            //close the input/output streams
            if (outputStream != null)
                outputStream.close();           
        }
    }
}
