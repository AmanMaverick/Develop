package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.IdentityRecordRemovalForm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;


/**
 * This DAO layer fetch data from PNA DB and also delete record from DB.
 * @author Rakhi Tholia, AO,  PCEHR
 * @since 10th March 2014
 * @version - x
 */
@Component
public class IdentityRecordRemovalDao {

    private static Logger LOG = Logger.getLogger(IdentityRecordRemovalDao.class);

    @Value("${IdentityRecordRemoval.VALIDATE_IDENTITY}")
    private String validate_Identity;

    @Value("${IdentityRecordRemoval.VALIDATE_RECORD}")
    private String validate_Record;

    @Value("${IdentityRecordRemoval.FETCH_DATA_IHI}")
    private String fetch_Data_IHI;

    @Value("${IdentityRecordRemoval.IHI_RESTRICTED}")
    private String ihi_Restricted;
    
    @Value("${IdentityRecordRemoval.VALIDATE_DEMOGRAPHIC_DETAILS}")
    private String validate_Demographic_Details;

    private static final String REMOVAL_IDENTITY = "REMOVAL_IDENTITY";
//    private static final String REMOVAL_RECORD = "REMOVAL_RECORD";
    //private static final String REMOVE_RECORD_AND_IDENTITY = "REMOVE_RECORD_AND_IDENTITY";
    //private static final String REMOVE_CHILD_RECORD_WITH_NO_IDENTITY = "CHILD_REC_REM_WITH_NO_IDENTITY";
    private static final String RECORD_AND_NOTIFICATIONS_REMOVAL="RECORD_NOTIFICATIONS_REMOVAL";
    private static final String REC_ID_NOTIFICATION_REMOVAL="REC_ID_NOTIFICATION_REMOVAL";
    private static final String CHILD_RECORD_NOTIFICATION_REMOVAL="CHILD_REC_NOTIF_REMOVAL";
    @Autowired
    @Qualifier("pnaJDBCTemplate")
    private JdbcTemplate pnaJdbcTemplate;
    
    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJdbcTemplate;

    @Autowired
    @Qualifier("osbNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate osbNamedParameterJdbcTemplate;
    
    @Autowired
    @Qualifier("pnaNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    
    
    @Autowired
    CleanRecordDao cleanRecordDao;

    /**
     * Deletes the identity oh given IHI from database.
     * Makes a call to Stored Procedure REMOVAL_IDENTITY for deletion purpose.
     * @param ihi
     * @throws RecoveryDAOException
     */
    public void deleteIdentity(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside DAO-Delete Identity Method");
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(pnaJdbcTemplate).withSchemaName("OES_PNADB").withProcedureName(REMOVAL_IDENTITY);
        try {
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_IHI", ihi);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            simpleJdbcCall.execute(in);
        } catch (Exception e) {
            // There is a chance of java.sql.SQLException for integrity constraint with PCEHR_RECORD
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        }
    }


    /**
     * Deletes the records for given IHI from database.
     * Makes a call to Stored Procedure REMOVAL_RECORD for deletion purpose.
     * @param ihi
     * @throws RecoveryDAOException
     */
    public void deleteRecord(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside DAO-Delete Record Method");
        SimpleJdbcCall simpleJdbcCall =
             new SimpleJdbcCall(osbJdbcTemplate).withSchemaName("PCEHR_OSB_AUDIT").withProcedureName(RECORD_AND_NOTIFICATIONS_REMOVAL);
        try {
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_IHI", ihi);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            simpleJdbcCall.execute(in);
            LOG.debug("Executed Successfully");

        }

        catch (Exception e) {
            LOG.fatal("Exception Occured in DAO..", e);
            throw new RecoveryDAOException(e);
        }
    }


    /**
     * Deletes Identity as well as Record for given IHI.
     * Makes a call to Stored Procedure REMOVE_RECORD_AND_IDENTITY for deletion purpose.
     * @param ihi
     * @throws RecoveryDAOException,Exception
     */

    public void deleteIdentityRecord(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside DAO- deleteIdentityRecord Method");
        SimpleJdbcCall simpleJdbcCall =
             new SimpleJdbcCall(osbJdbcTemplate).withSchemaName("PCEHR_OSB_AUDIT").withProcedureName(REC_ID_NOTIFICATION_REMOVAL);
        try {
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_IHI", ihi);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            simpleJdbcCall.execute(in);
            //Map<String,Object> map = simpleJdbcCall.execute(in);
            //LOG.debug("Executed Successfully" + map.get("dbms_output"));
            LOG.debug("Executed Successfully");
        }

        catch (Exception e) {
            LOG.fatal("Exception Occured in DAO..", e);
            throw new RecoveryDAOException(e);
        }

    }


    /**
     * Deletes  Child  Record having no Identity from database.
     * Makes a call to Stored Procedure CHILD_REC_REM_WITH_NO_IDENTITY for deletion purpose.
     * @param ihi
     * @throws RecoveryDAOException,Exception
     */

    public void deleteChildRecord(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside DAO- deleteIdentityRecord Method");
        SimpleJdbcCall simpleJdbcCall =
             new SimpleJdbcCall(osbJdbcTemplate).withSchemaName("PCEHR_OSB_AUDIT").withProcedureName(CHILD_RECORD_NOTIFICATION_REMOVAL);
        try {
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_IHI", ihi);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            simpleJdbcCall.execute(in);
            LOG.debug("Executed Successfully");

        }

        catch (Exception e) {
            LOG.fatal("Exception Occured in DAO..", e);
            throw new RecoveryDAOException(e);
        }
    }


    /**
     * This method fetches DEMOGRAPHICS details for given IHI from PNA database.
     * @param identityRecordRemovalForm
     * @return IdentityRecordRemovalForm
     * @throws RecoveryDAOException
     */

    public IdentityRecordRemovalForm fetchDemographicsDtls(IdentityRecordRemovalForm identityRecordRemovalForm) throws RecoveryDAOException {
        LOG.debug("Inside DAO fetchRecordIHI Method");
        Map namedParameters = new HashMap();
        try {
            String ihi = identityRecordRemovalForm.getIhi();
            LOG.debug("IHI Used in DAO Fetch:" + ihi);
            namedParameters.put("ihi", ihi);
            namedParameters.put("lastName", identityRecordRemovalForm.getLastName());
            namedParameters.put("sex", identityRecordRemovalForm.getSex());
            namedParameters.put("dob", identityRecordRemovalForm.getDob());
            List<Map<String, Object>> list = namedParameterJdbcTemplate.queryForList(fetch_Data_IHI, namedParameters);
            Map row1 = list.get(0);
            IdentityRemovalBO identitybo = new IdentityRemovalBO();
            identitybo.setIhi(ihi);
            identitybo.setFamily_Name(String.valueOf(row1.get("family_name")));
            identitybo.setGiven_Name(String.valueOf(row1.get("given_name")));
            identitybo.setDob(String.valueOf(row1.get("dob")));
            identitybo.setSex(String.valueOf(row1.get("sex")));
            identityRecordRemovalForm.setIdentityRemovalBO(identitybo);
        }

        catch (Exception e) {
            LOG.fatal("Exception Occured in DAO FetchDemographicDetails Method..", e);
            throw new RecoveryDAOException(e);
        }
        return identityRecordRemovalForm;
    }



    public boolean validateDemographicDetails(IdentityRecordRemovalForm identityRecordRemovalForm) throws RecoveryDAOException {
        LOG.debug("Inside DAO validateDemographicDetails Method");
        Map namedParameters = new HashMap();
        boolean flag = false;
        try {
            namedParameters.put("ihi", identityRecordRemovalForm.getIhi());
            namedParameters.put("lastName", identityRecordRemovalForm.getLastName());
            namedParameters.put("sex", identityRecordRemovalForm.getSex());
            namedParameters.put("dob", identityRecordRemovalForm.getDob());
            LOG.debug("Query used:" + validate_Record);
            int count = namedParameterJdbcTemplate.queryForInt(validate_Demographic_Details, namedParameters);
            if (count > 0) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("leaving validateDemographicDetails...");
        return flag;
    }
    
    
    
    /**
     *
     * @param identityRecordRemovalForm
     * @return
     * @throws RecoveryDAOException
     */
    public boolean validateDemographicDetails2(Object object) throws RecoveryDAOException {
        LOG.debug("Inside DAO validateDemographicDetails Method");
        IdentityRecordRemovalForm identityRecordRemovalForm=null;
        IdentityRemovalBO identityRemovalBO=null;
       
        Map namedParameters = new HashMap();
        boolean flag = false;
        try {
            if(object!=null && object instanceof IdentityRecordRemovalForm){
               
                 identityRecordRemovalForm=(IdentityRecordRemovalForm)object;
                LOG.debug("form ihi::::"+ identityRecordRemovalForm.getIhi());
                namedParameters.put("ihi", identityRecordRemovalForm.getIhi());
                namedParameters.put("lastName", identityRecordRemovalForm.getLastName());
                namedParameters.put("sex", identityRecordRemovalForm.getSex());
                namedParameters.put("dob", identityRecordRemovalForm.getDob());
            }else if(object!=null && object instanceof IdentityRemovalBO){
               
                identityRemovalBO=(IdentityRemovalBO)object;
                LOG.debug("BO ihi::::"+ identityRemovalBO.getIhi());
                namedParameters.put("ihi", identityRemovalBO.getIhi());
                namedParameters.put("lastName", identityRemovalBO.getFamily_Name());
                namedParameters.put("sex", identityRemovalBO.getSex());
                namedParameters.put("dob", identityRemovalBO.getDob());
            }
           
            LOG.debug("Query used:" + validate_Record);
            int count = namedParameterJdbcTemplate.queryForInt(validate_Demographic_Details, namedParameters);
            if (count > 0) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("leaving validateDemographicDetails..."+flag);
        return flag;
    }
    

    /**
     * This method checks records for the given IHI exists in the database or not.
     * @param ihi
     * @return boolean
     * @throws RecoveryDAOException
     */

    public boolean validateRecordIHI(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside DAO validateRecordIHI Method");
        Map namedParameters = new HashMap();
        boolean flag = false;
        try {
            namedParameters.put("ihi", ihi);
            LOG.debug("Query used:" + validate_Record);
            int count = namedParameterJdbcTemplate.queryForInt(validate_Record, namedParameters);
            if (count > 0) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("leaving validateRecordIHI...");
        return flag;
    }


    /**
     * This method checks Identity for the given IHI exists in the database or not.
     * @param ihi
     * @return
     * @throws RecoveryDAOException
     */
    public boolean validateIdentityIHI(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside DAO validateIdentityIHI Method");
        Map namedParameters = new HashMap();
        boolean flag = false;
        try {
            namedParameters.put("ihi", ihi);
            LOG.debug("Query used:" + validate_Identity);
            int count = namedParameterJdbcTemplate.queryForInt(validate_Identity, namedParameters);
            if (count > 0) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("leaving validateIdentityIHI...");
        return flag;
    }


    /**
     * This method validates the IHI state whether it is in baring AR state or not
     * and delegates the request to DAO.
     * @return
     * @throws RecoveryDAOException,RecoveryServiceException
     */
    public boolean arIHIRestricted(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside DAO arIHIRestricted Method");
        Map namedParameters = new HashMap();
        boolean flag = false;
        try {
            namedParameters.put("ihi", ihi);
            LOG.debug("Query used:" + ihi_Restricted);
            int count = namedParameterJdbcTemplate.queryForInt(ihi_Restricted, namedParameters);
            if (count >= 1) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("leaving validateIdentityIHI...");
        return flag;
    }


}
