package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.form.MobileApplicationToolForm;
import au.gov.doha.pcehr.recovery.service.MobileApplicationToolService;
import au.gov.doha.pcehr.recovery.validation.MobileApplicationToolValidator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.json;

@Controller
public class MobileApplicationToolController {
    @Autowired
    MobileApplicationToolService mobileApplicationToolService;
    private static Logger LOG = Logger.getLogger(MobileApplicationToolController.class);
    @InitBinder(MOBILE_APPLICATION_TOOL_ATTRIBUTE)
       protected void initBinderMetricTypeConfig(WebDataBinder binder) {
               LOG.debug("Initialising the validator");
               binder.setValidator(mobileApplicationToolValidator);
       }
    @InitBinder(MOBILE_APPLICATION_TOOL_UPDATE_ATTRIBUTE)
       protected void initBinderMetricTypeConfigUpdate(WebDataBinder binder) {
               LOG.debug("Initialising the validator");
               binder.setValidator(mobileApplicationToolValidator);
       }
       @Autowired
       @Qualifier("mobileApplicationToolValidator")
       private MobileApplicationToolValidator mobileApplicationToolValidator;
       
    private static final String MOBILE_APPLICATION_TOOL_PAGE = "/NIO/MobileApplicationTool";
    private static final String MOBILE_APPLICATION_TOOL_ATTRIBUTE = "MobileApplicationToolAttribute";
    private static final String MOBILE_APPLICATION_TOOL_UPDATE_ATTRIBUTE = "MobileApplicationToolUpdateAttribute";
    
    
    @RequestMapping(method = { RequestMethod.GET }, value = "/MobileApplicationToolCntrl")
    
    @AuditBefore(AuditMessageConstants.MOBILE_APPLICATION_TOOL_LANDIGPAGE)
    public String loadMobileApplicationToolLandingPage(@ModelAttribute(MOBILE_APPLICATION_TOOL_ATTRIBUTE) MobileApplicationToolForm mobileApplicationToolForm,@ModelAttribute(MOBILE_APPLICATION_TOOL_UPDATE_ATTRIBUTE) MobileApplicationToolForm mobileApplicationToolUpdateForm) {
       
        mobileApplicationToolUpdateForm=loadDetails(mobileApplicationToolUpdateForm);
        mobileApplicationToolForm.setApiListMap(mobileApplicationToolUpdateForm.getApiListMap());
      
        LOG.debug("inside bulk reg controller");
        return MOBILE_APPLICATION_TOOL_PAGE;
    }
    @RequestMapping(method = { RequestMethod.POST }, value = "/MobileApplicationDetails")
    public  @ResponseBody String loadApplicationsDetails(@RequestParam String applicationList ,@RequestParam String appDetails,@ModelAttribute(MOBILE_APPLICATION_TOOL_ATTRIBUTE) MobileApplicationToolForm mobileApplicationToolForm) {
        LOG.debug("inside loadApplicationsDetails");
        LOG.debug("application id from UI script is"+applicationList);
        
        LOG.debug("appDetails:::"+appDetails);
        
      
        List<String> appDetailsList=mobileApplicationToolService.retrieveApplciatonDetails(applicationList,appDetails);
        
        LOG.debug("leaving loadApplicationsDetails");
        
        return new JSONArray(appDetailsList).toString();
    }
    /**
     *This method is used to perform registering the vendor application
     * @param mobileApplicationToolForm
     * @return
     */
    @RequestMapping(method={RequestMethod.POST},value="/MobileApplicationUpdation")
    public String updateApplicationVendor(@Valid @ModelAttribute(MOBILE_APPLICATION_TOOL_UPDATE_ATTRIBUTE) MobileApplicationToolForm mobileApplicationToolForm,BindingResult result,@ModelAttribute(MOBILE_APPLICATION_TOOL_ATTRIBUTE) MobileApplicationToolForm mobileApplicationToolRegForm){
        LOG.debug("inside updateApplicationVendor");
       

        if (result.hasErrors()) {
                   LOG.debug("Inside has errors");
                   mobileApplicationToolForm=loadDetails(mobileApplicationToolForm);
                   mobileApplicationToolRegForm.setApiListMap(mobileApplicationToolForm.getApiListMap());
                   LOG.info("......"+result.hasErrors() + result.toString());
                   return MOBILE_APPLICATION_TOOL_PAGE;
               }
        mobileApplicationToolService.updateApplication(mobileApplicationToolForm);
        mobileApplicationToolForm=loadDetails(mobileApplicationToolForm);
        mobileApplicationToolRegForm.setApiListMap(mobileApplicationToolForm.getApiListMap());
       
        
      
       
        LOG.debug("leaving updateApplicationVendor");
        return MOBILE_APPLICATION_TOOL_PAGE;
    }
    /**
     *This method is used to perform updation of  the vendor application
     * @param mobileApplicationToolForm
     * @return
     */
    @RequestMapping(method={RequestMethod.POST},value="/MobileApplicationRegistration")
    public String registerApplicationVendor(@Valid @ModelAttribute(MOBILE_APPLICATION_TOOL_ATTRIBUTE) MobileApplicationToolForm mobileApplicationToolForm,BindingResult result,@ModelAttribute(MOBILE_APPLICATION_TOOL_UPDATE_ATTRIBUTE) MobileApplicationToolForm mobileApplicationTooUpdatelForm){
        LOG.debug("inside registerApplicationVendor");
       // mobileApplicationToolForm.setApiListMap(mobileApplicationToolService.retrieveApiListfromProps());
       
       
            
        if (result.hasErrors()) {
            
                    LOG.debug("Inside has errors");
                    mobileApplicationTooUpdatelForm=loadDetails(mobileApplicationTooUpdatelForm);
                    mobileApplicationToolForm.setApiListMap(mobileApplicationTooUpdatelForm.getApiListMap());
                    
                   
                    LOG.info("......"+result.hasErrors() + result.toString());
                    return MOBILE_APPLICATION_TOOL_PAGE;
                }
       
        mobileApplicationToolService.registerApplication(mobileApplicationToolForm);
        mobileApplicationTooUpdatelForm=loadDetails(mobileApplicationTooUpdatelForm);
        mobileApplicationToolForm.setApiListMap(mobileApplicationTooUpdatelForm.getApiListMap());
       // LOG.debug("form value:::"+mobileApplicationToolForm.getAppListDetailsMap().size());

       
        LOG.debug("leaving registerApplicationVendor");
        return MOBILE_APPLICATION_TOOL_PAGE;
    }

    
    @ModelAttribute("ApplicationStatus")
    public List<String> getAppStatus() throws Exception {
        LOG.debug("here in getAppStatus");
        List<String> appStatus = new ArrayList<String>();
        appStatus.add("Active");
        appStatus.add("Inactive");
        LOG.debug("Leaving getAppStatus");
        return appStatus;
    }
    /**
     *
     * @param mobileApplicationToolForm
     * @return
     */
    private MobileApplicationToolForm loadDetails(MobileApplicationToolForm mobileApplicationToolForm) {
        List<String> appList=new ArrayList<String>();
        String value="";
        Map<String,String> aplicationList = new HashMap<String,String>();
        Map<String,String> managedAppBOMap = mobileApplicationToolService.retrieveApplciatonList();
        if(managedAppBOMap!=null){
        LOG.debug("appList size::"+managedAppBOMap.size());
        
            for(String key:managedAppBOMap.keySet()){
                value=managedAppBOMap.get(key);
                if(value!=null && value.length()>0){
                    String[] appDtls = value.split("~");
                    
                    aplicationList.put(key, ((appDtls!=null && appDtls.length>2)?appDtls[2]:"")+","+((appDtls!=null && appDtls.length>0)?appDtls[0]:"")+","+((appDtls!=null && appDtls.length>1)?appDtls[1]:""));
                }
                
            }
        }
       
        mobileApplicationToolForm.setApplicationIdList(aplicationList);
       mobileApplicationToolForm.setAppListDetailsMap(managedAppBOMap);
        mobileApplicationToolForm.setApiListMap(mobileApplicationToolService.retrieveApiListfromProps());
       
        return mobileApplicationToolForm;
    }

    
     
}
