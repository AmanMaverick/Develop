package au.gov.doha.pcehr.recovery.wsclient.handlerResolver;


import au.gov.doha.pcehr.recovery.wsclient.soaphandler.WSClientHandlerUtil;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Class that implements a HandlerResolver in the handler chain, used to add the
 * wsClientHandlerUtil to the List of the type Handler.
 * This class will be used for all those clients wherever
 * WS-Addressing is enabling on a Web service client when creating a Web service proxy,
 * by passing the AddressingFeature to the getPort method.
 *
 * @author Vikash Kumar Singh      PCEHR       Operations
 * @see au.gov.doha.pcehr.recovery.wsclient.soaphandler.WSClientHandlerUtil , javax.xml.ws.soap.AddressingFeature
 * @version v0.0.0.1
 * @since 4th Aug 2015
 */
@Component
public class WSClientHandlerResolver implements HandlerResolver{
    private static Logger LOG = Logger.getLogger(WSClientHandlerResolver.class);
    @Autowired
    WSClientHandlerUtil wsClientHandlerUtil;
    
    @Override
    public List<Handler> getHandlerChain(PortInfo portInfo) {
        LOG.debug("inside getHandlerChain of WSClientHandlerResolver");
        List<Handler> handlerChain = new ArrayList<Handler>();
        handlerChain.add(wsClientHandlerUtil);
        LOG.debug("Leaving getHandlerChain of WSClientHandlerResolver");
        return handlerChain;
    }
}
