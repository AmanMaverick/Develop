package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.ProviderRegistrationBO;

import java.util.List;

public class ProviderRegistrationForm {

    private String fromDate;
    private String toDate;
    private List<ProviderRegistrationBO> errorList;
    
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setErrorList(List<ProviderRegistrationBO> errorList) {
        this.errorList = errorList;
    }

    public List<ProviderRegistrationBO> getErrorList() {
        return errorList;
    }
    
}
