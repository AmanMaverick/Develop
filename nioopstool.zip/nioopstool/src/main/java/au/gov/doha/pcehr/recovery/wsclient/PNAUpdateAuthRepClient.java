package au.gov.doha.pcehr.recovery.wsclient;


//import au.pcehr.ws.


import au.gov.doha.pcehr.recovery.bo.PNAUpdateAuthRepWSClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;

import au.pcehr.ws.pna.common.ApplicationResponse;
import au.pcehr.ws.pna.common.AuthRepRelationshipTypeID;
import au.pcehr.ws.pna.common.RelationshipStatus;
import au.pcehr.ws.pna.common.RepresentativeTypeVal;
import au.pcehr.ws.pna.pd.PDUpdateAuthorisedRepresentativeRequest;
import au.pcehr.ws.pna.pd.PDUpdateAuthorisedRepresentativeResponse;
import au.pcehr.ws.pna.pd.PNAPCEHRUpdateAuthorisedRepresentative;
import au.pcehr.ws.pna.pd.PNAPCEHRUpdateAuthorisedRepresentativeWS;
import au.pcehr.ws.pna.pd.UpdateAuthRepresentativeCommonParameters;
import au.pcehr.ws.pna.pd.UpdateAuthRepresentativeFunctionParameters;
import au.pcehr.ws.pna.pd.UpdateAuthRepresentativeParameterList;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.math.BigInteger;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;

import pcehr.recovery.LoggingHandler;
import pcehr.recovery.UtilConstants;


public class PNAUpdateAuthRepClient {
    
    
    @Autowired
    Decrypter decrypter;
    
    private static Logger LOG = Logger.getLogger(PNAUpdateAuthRepClient.class);

    private PNAUpdateAuthRepWSClientBO pnaUpdateBO;
    private StringBuffer soapMessage;

    public void setPnaUpdateBO(PNAUpdateAuthRepWSClientBO pnaUpdateBO) {
        this.pnaUpdateBO = pnaUpdateBO;
    }

    public PNAUpdateAuthRepWSClientBO getPnaUpdateBO() {
        return pnaUpdateBO;
    }


    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }

    /**
     *author sumanta
     * @return
     */
    public final ApplicationResponse update() {
        LOG.debug("Updating AR Status PNAUpdateAuthRepClient");
        PNAPCEHRUpdateAuthorisedRepresentativeWS pNAPCEHRUpdateAuthorisedRepresentativeWS;
        pNAPCEHRUpdateAuthorisedRepresentativeWS = new PNAPCEHRUpdateAuthorisedRepresentativeWS();
        pNAPCEHRUpdateAuthorisedRepresentativeWS.setHandlerResolver(new ClientHandlerResolver());
        PNAPCEHRUpdateAuthorisedRepresentative pNAPCEHRUpdateAuthorisedRepresentative;
        pNAPCEHRUpdateAuthorisedRepresentative =
                pNAPCEHRUpdateAuthorisedRepresentativeWS.getPNAPCEHRUpdateAuthorisedRepresentativePort();
        Map<String, Object> requestContext;
        requestContext = ((BindingProvider)pNAPCEHRUpdateAuthorisedRepresentative).getRequestContext();
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.PNA_UA_ENDPOINT);
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, new TestHostnameVerifier());
        requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_USERNAME));
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_PASSWORD));

        XMLGregorianCalendar xgcal = null;
        try {
            GregorianCalendar gcal = new GregorianCalendar();
            xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
        } catch (Exception e) {
            System.out.println("Exception");
        }
        UpdateAuthRepresentativeParameterList updateAuthRepresentativeParameterList;
        updateAuthRepresentativeParameterList = new UpdateAuthRepresentativeParameterList();
        UpdateAuthRepresentativeCommonParameters updateAuthRepresentativeCommonParameters;
        updateAuthRepresentativeCommonParameters = new UpdateAuthRepresentativeCommonParameters();
        BigInteger pcehrIdentity = new BigInteger(pnaUpdateBO.getUserID());
        updateAuthRepresentativeCommonParameters.setPcehrIdentity(pcehrIdentity);
        updateAuthRepresentativeCommonParameters.setRecordIHI(pnaUpdateBO.getRecordIHI());
        //Passing Dummy value.Not been used in PNA
        updateAuthRepresentativeCommonParameters.setSourceSystemID("Source System ID");
        //Passing Dummy value.Not been used in PNA
        updateAuthRepresentativeCommonParameters.setTransactionID("Transaction ID");
        UpdateAuthRepresentativeFunctionParameters updateAuthRepresentativeFunctionParameters =
            new UpdateAuthRepresentativeFunctionParameters();
        
        LOG.debug("--->"+RepresentativeTypeVal.EIGHTEEN_AND_OVER_LEGAL_AUTHORITY);
        LOG.debug("--->"+RepresentativeTypeVal.EIGHTEEN_AND_OVER_OTHERWISE_APPROPRIATE_PERSON);
        LOG.debug("--->"+RepresentativeTypeVal.UNDER_18_OTHERWISE_APPROPRIATE_PERSON);
        
        LOG.debug("--->"+au.pcehr.ws.pna.common.AuthRepRelationshipTypeID.UNDER_18_PARENTAL_RESPONSIBILITY);
        
        AuthRepRelationshipTypeID.fromValue("Parent");
        LOG.debug("--->"+AuthRepRelationshipTypeID.class);


      
        
        if (pnaUpdateBO.getRel_type() == UtilConstants.VALUE_16) {
            updateAuthRepresentativeFunctionParameters.setRelationshipType(au.pcehr.ws.pna.common.AuthRepRelationshipTypeID.UNDER_18_PARENTAL_RESPONSIBILITY);
        }
        if (pnaUpdateBO.getRel_type() == UtilConstants.VALUE_17) {
            updateAuthRepresentativeFunctionParameters.setRelationshipType(AuthRepRelationshipTypeID.UNDER_18_LEGAL_AUTHORITY);
        }
        if (pnaUpdateBO.getRel_type() == UtilConstants.VALUE_18) {
            updateAuthRepresentativeFunctionParameters.setRelationshipType(AuthRepRelationshipTypeID.UNDER_18_OTHERWISE_APPROPRIATE_PERSON);
        }
        if (pnaUpdateBO.getRel_type() == UtilConstants.VALUE_19) {
            updateAuthRepresentativeFunctionParameters.setRelationshipType(AuthRepRelationshipTypeID.EIGHTEEN_AND_OVER_LEGAL_AUTHORITY);
        }
        if (pnaUpdateBO.getRel_type() == UtilConstants.VALUE_20) {
            updateAuthRepresentativeFunctionParameters.setRelationshipType(AuthRepRelationshipTypeID.EIGHTEEN_AND_OVER_OTHERWISE_APPROPRIATE_PERSON);
        }
    
        //updated from exsisting code
        updateAuthRepresentativeFunctionParameters.setRelationshipEndedReason(pnaUpdateBO.getReason());
        updateAuthRepresentativeFunctionParameters.setRelationshipEndDate(xgcal);
        updateAuthRepresentativeFunctionParameters.setRelationshipStatus(RelationshipStatus.IN_ACTIVE);
        updateAuthRepresentativeParameterList.setCommonParameters(updateAuthRepresentativeCommonParameters);
        updateAuthRepresentativeParameterList.setFunctionParameters(updateAuthRepresentativeFunctionParameters);
        PDUpdateAuthorisedRepresentativeRequest pdUpdateAuthorisedRepresentativeRequest;
        pdUpdateAuthorisedRepresentativeRequest = new PDUpdateAuthorisedRepresentativeRequest();
        pdUpdateAuthorisedRepresentativeRequest.setParameterList(updateAuthRepresentativeParameterList);
        LOG.debug("Calling webservice.....");
        PDUpdateAuthorisedRepresentativeResponse pdUpdateAuthorisedRepresentativeResponse =
            pNAPCEHRUpdateAuthorisedRepresentative.pdUdateAuthorisedRepresentative(pdUpdateAuthorisedRepresentativeRequest);
        ApplicationResponse applicationResponse = new ApplicationResponse();
        applicationResponse = pdUpdateAuthorisedRepresentativeResponse.getResultStatus();
        getSoapRequestMsg();
        LOG.debug("Updating... AR Status" +
                  pdUpdateAuthorisedRepresentativeResponse.getResultStatus().getStatusCode());
        LOG.debug("Updating... AR Status" +
                  pdUpdateAuthorisedRepresentativeResponse.getResultStatus().getStatusDescription());
        return applicationResponse;
    }

    /**
     *
     * @return
     */
    private void getSoapRequestMsg() {
        StringBuffer soapMessagesg = new StringBuffer();
        soapMessagesg.setLength(0);
        if (null != LoggingHandler.lastSoapRequest) {
            soapMessagesg.append("PNA Update AR Status Request");
            soapMessagesg.append("\n" +
                    LoggingHandler.lastSoapRequest.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
        }
        if (null != LoggingHandler.lastSoapResponse) {
            soapMessagesg.append("---------------------------------------------------------");
            soapMessagesg.append("\n");
            soapMessagesg.append("\nPNA Update AR Status Response");
            soapMessagesg.append("\n" +
                    LoggingHandler.lastSoapResponse.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
        }
        LOG.debug("soap response:::" + soapMessagesg.toString().replaceAll("&lt;", "<").replaceAll("&gt;", ">"));

        this.soapMessage = soapMessagesg;
    }


    /**
     * This class is to verify host name.
     */
    public static class TestHostnameVerifier implements HostnameVerifier {
        /**
         *
         * @param arg0
         * @param arg1
         * @return boolean
         */
        public final boolean verify(final String arg0, final SSLSession arg1) {
            return true;
        }
    }

    /**
     * This class is to handle the SOAP Request and Response.
     */
    public static class ClientHandlerResolver implements HandlerResolver {
        /**
         *
         * @param port_info
         * @return Handler
         */
        public final List<Handler> getHandlerChain(final PortInfo port_info) {
            List<Handler> handlerChain;
            handlerChain = new ArrayList<Handler>();
            LoggingHandler loggingHandler;
            loggingHandler = new LoggingHandler(UtilConstants.PNA);
            handlerChain.add(loggingHandler);
            return handlerChain;
        }
    }
}
