package au.gov.doha.pcehr.recovery.bo;

import java.util.List;

public class DeleteDocumentWSClientBO {
    public DeleteDocumentWSClientBO() {
        super();
    }
    private String ihi;
    private List docIdList;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocIdList(List docIdList) {
        this.docIdList = docIdList;
    }

    public List getDocIdList() {
        return docIdList;
    }
}
