package au.gov.doha.pcehr.recovery.util;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.springframework.stereotype.Service;

@Service
public class TestHostnameVerifier implements HostnameVerifier{

    @Override
    public boolean verify(String string, SSLSession sSLSession) {
        // TODO Implement this method
        return true;
    }
}
