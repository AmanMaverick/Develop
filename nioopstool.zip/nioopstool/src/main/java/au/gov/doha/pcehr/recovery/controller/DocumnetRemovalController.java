package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.service.DocumentReinstateService;
import au.gov.doha.pcehr.recovery.service.DocumentRemovalService;
import au.gov.doha.pcehr.recovery.validation.DocumnetRemovalValidator;

import au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.StandardError;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import javax.validation.Valid;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


/**
 *@author Sumanta Saha
 */
@Controller
public class DocumnetRemovalController {
    private static Logger LOG = Logger.getLogger(DocumnetRemovalController.class);
    @Autowired
    DocumentRemovalService documentRemovalService;
    @Autowired
    DocumentReinstateService documentReinstateService;
    @Autowired
    @Qualifier("documnetRemovalValidator")
    private DocumnetRemovalValidator documentRemovalValidator;

    @InitBinder("DocumentRemovalAttribute")
    protected void initBinderMetricTypeConfig(WebDataBinder binder) {
        binder.setValidator(documentRemovalValidator);
    }

    @AuditBefore(AuditMessageConstants.REMOVE_REINSTATE_DOCUMENT)
    @RequestMapping(method = { RequestMethod.GET }, value = "/DocumentRemoval")
    public String documentRemovalMenuHandler(HttpSession session, ModelMap map) throws RecoveryServiceException {
        DocumentRemovalBO documentRemovalBO = new DocumentRemovalBO();
        map.addAttribute("DocumentRemovalAttribute", documentRemovalBO);
        LOG.debug("Entered the controller class DocumentRemovalMenuHandler");
        return "/NIO/DocumentRemoval";
    }
    
    @AuditBefore(AuditMessageConstants.REMOVE_DOCUMENT_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, value = "/DocumentRemoval", params = "Remove=Submit")
    public String documentRemove(@Valid
        @ModelAttribute("DocumentRemovalAttribute")
        DocumentRemovalBO documentRemovalBO, BindingResult documentRemovalResult, HttpSession session,
        ModelMap map) throws RecoveryServiceException {
        LOG.debug("inside documentRemove");
        if (documentRemovalResult.hasErrors()) {
            documentRemovalBO.setAlertMessage(new StringBuffer(""));
            LOG.debug("validation error for documentRemove ...");
            return "/NIO/DocumentRemoval";
        }
        documentRemovalBO = documentRemovalService.processDocumentRemoval(documentRemovalBO);
        return "/NIO/DocumentRemoval";
    }

    
    @AuditBefore(AuditMessageConstants.REINSTATE_DOCUMENT_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, value = "/DocumentRemoval", params = "Reinstate=Submit")
    public String documentReinstate(@Valid
        @ModelAttribute("DocumentRemovalAttribute")
        DocumentRemovalBO documentReinstateBO, BindingResult documentRemovalResult, HttpSession session,
        ModelMap map) throws RecoveryServiceException, RecoveryDAOException, StandardError {
        if (documentRemovalResult.hasErrors()) {
            documentReinstateBO.setAlertMessage(new StringBuffer(""));
            LOG.debug("validation error for documentReinstate ...");
            return "/NIO/DocumentRemoval";
        }
        LOG.debug("inside documentReinstate");
        documentReinstateBO.setUsername((String)session.getAttribute("username"));
        documentReinstateBO = documentReinstateService.processDocumentReinstate(documentReinstateBO);


        LOG.debug("soapMessage......" + documentReinstateBO.getSoapMessage());
        LOG.debug("Leaving documentReinstate");
        return "/NIO/DocumentRemoval";
    }

    @ModelAttribute("RemovalReasonList")
    public List<String> removalReasonList() throws Exception {
        List<String> removalReason = new ArrayList<String>();
        removalReason.add("Administrator Action");
        removalReason.add("Administrative Action: Untrusted Source");
        return removalReason;
    }

    @ModelAttribute("UserAction")
    public List<String> userAction() throws Exception {
        List<String> userAction = new ArrayList<String>();
        userAction.add("Remove Document");
        userAction.add("Reinstate Document");
        return userAction;
    }
    
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(ServiceException ex) {
        LOG.info("doaexception handler......");
        ModelAndView model = new ModelAndView("/NIO/DocumentRemoval");
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............."+ex.getMessage());
        return model;
    }
}
