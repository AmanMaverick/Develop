package au.gov.doha.pcehr.recovery.bo;

import java.util.Date;

public class ProviderRegistrationBO {
    private Date date;
   private String user_id;
   
  

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDate() {
        return date;
    }
}
