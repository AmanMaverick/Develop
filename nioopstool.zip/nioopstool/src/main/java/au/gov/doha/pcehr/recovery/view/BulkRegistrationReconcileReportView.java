package au.gov.doha.pcehr.recovery.view;

import au.gov.doha.pcehr.recovery.bo.ReconcileDataReportBO;
import au.gov.doha.pcehr.recovery.constants.RecoverConstants;
import au.gov.doha.pcehr.recovery.dao.BulkRegistrationDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.BulkRegistrationForm;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @desc This file generates the reports for discrepancy and reconcilation reports
 * @author Sapna
 * @since R7.1
 */
@Service
public class BulkRegistrationReconcileReportView {
    private static Logger LOG = Logger.getLogger(BulkRegistrationStatusView.class);   
    private static final String FILE_NAME = "BulkRegistration_StatusReport.xls";   
    
    @Autowired
    private BulkRegistrationDAO bulkRegistrationDAO;
    /**
     * 
     * @param bulkGenerationReconcileReport
     * @return
     * @throws RecoveryServiceException
     */
    public Workbook buildExcelDocument(BulkRegistrationForm bulkRegistrationForm)
                    throws  RecoveryServiceException {
        LOG.debug("Entered into the excel viiew");
        Workbook wb =null;
        if("reconcileRepo".equals(bulkRegistrationForm.getReconReportType())){
           wb =generateReconsileRport(bulkRegistrationForm);
           // bulkRegistrationDAO.generateReconsileRport(bulkRegistrationForm);        
        }else if("discrepancyRepo".equals(bulkRegistrationForm.getReconReportType())){
           wb =generateDescripencyRport(bulkRegistrationForm);
           // bulkRegistrationDAO.generateDescripencyRport(bulkRegistrationForm);      
        }
        return wb;
        
    }
    
    private Workbook generateReconsileRport(BulkRegistrationForm bulkRegistrationForm){
        Workbook wb = new SXSSFWorkbook(100); 
        SXSSFSheet sheet = (SXSSFSheet) wb.createSheet("Reconcile Data");
        int sheetCount = 0;
        
        SXSSFRow summaryeTitle = sheet.createRow(0);
     
        summaryeTitle.createCell(0).setCellValue("Summary report");
        SXSSFRow  summaryHeader= sheet.createRow(1);
        summaryHeader.createCell(0).setCellValue("RECORD_REQUIRED");
        summaryHeader.createCell(1).setCellValue("BULKREG_FLAG");
        summaryHeader.createCell(2).setCellValue("COUNT");
        //header.createCell(0).setCellValue("Detailed");
        int rowNum = 2;
        
        LOG.info("size of objects:::"+bulkRegistrationForm.getReconcileDataReportSummaryBOLst().size());
        List<String> flagList = new ArrayList<String>();
        flagList.add("TrueFalse");
        flagList.add("TrueTrue");
        flagList.add("FalseTrue");
        flagList.add("FalseFalse");
        for(ReconcileDataReportBO reconcileDataReportBO :  bulkRegistrationForm.getReconcileDataReportSummaryBOLst() ){   
            if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                sheet = (SXSSFSheet) wb.createSheet("Reconcile Data"+sheetCount);
                rowNum=0;
                sheetCount++;
            }
            SXSSFRow row = sheet.createRow(rowNum++);        
            String str = reconcileDataReportBO.getRecord_required().concat(reconcileDataReportBO.getBulkreg_flag());
            row.createCell(0).setCellValue(reconcileDataReportBO.getRecord_required());
            row.createCell(1).setCellValue(reconcileDataReportBO.getBulkreg_flag());
            row.createCell(2).setCellValue(reconcileDataReportBO.getCount().longValue());
            reconcileDataReportBO=null;
            if(flagList.contains(str)){
                flagList.remove(str);
            }
        }
        if(flagList.size() > 0){
            for(String flag : flagList){
                if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                    sheet = (SXSSFSheet) wb.createSheet("Reconcile Data"+sheetCount);
                    rowNum=0;
                    sheetCount++;
                }
                SXSSFRow row = sheet.createRow(rowNum++);        
                String str1 = flag.startsWith("T") ? "True" : "False";
                String str2 = str1.startsWith("T") ? flag.substring(4, flag.length()) : flag.substring(5, flag.length());//fix for eHeal00014415 
                row.createCell(0).setCellValue(str1);
                row.createCell(1).setCellValue(str2);
                row.createCell(2).setCellValue(0);
            }
        }
        int count = bulkRegistrationDAO.getRecordRequiredTrueCount();
        SXSSFRow row1 = sheet.createRow(rowNum++);
        row1.createCell(0).setCellValue("Total Count of IHI with Record Required = True");
        row1.createCell(1).setCellValue(count);
         summaryeTitle = sheet.createRow(rowNum++);
        
        summaryeTitle.createCell(0).setCellValue("Detailed report");
          summaryHeader= sheet.createRow(rowNum++);
        summaryHeader.createCell(0).setCellValue("IHI");
        summaryHeader.createCell(1).setCellValue("RECORD_REQUIRED");
        summaryHeader.createCell(2).setCellValue("RECORD_NOT_REQUIRED_REASON");
        summaryHeader.createCell(3).setCellValue("BULKREG_MESSAGE_ID");
        summaryHeader.createCell(4).setCellValue("BULKREG_INTEGRATION_ID");
        summaryHeader.createCell(5).setCellValue("BULKREG_ERROR_CODE");
        summaryHeader.createCell(6).setCellValue("BULKREG_LAST_UPDATED_DATE");
        summaryHeader.createCell(7).setCellValue("BULKREG_FLAG");
        summaryHeader.createCell(8).setCellValue("OPTOUT_FLAG");
        summaryHeader.createCell(9).setCellValue("EXTRACT_FILE_NAME");
        //header.createCell(0).setCellValue("Detailed");
         rowNum = rowNum++;
        for(ReconcileDataReportBO reconcileDataReportBO :  bulkRegistrationForm.getReconcileDataReportDetailedBOLst() ){   
            if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                sheet = (SXSSFSheet) wb.createSheet("Reconcile Data"+sheetCount);
                rowNum=0;
                sheetCount++;
            }
            SXSSFRow row = sheet.createRow(rowNum++);            
            row.createCell(0).setCellValue(reconcileDataReportBO.getIHI().toString());
            row.createCell(1).setCellValue(reconcileDataReportBO.getRecord_required());
            row.createCell(2).setCellValue(reconcileDataReportBO.getRecord_not_required());
            row.createCell(3).setCellValue(reconcileDataReportBO.getBulkreg_message_id());
            row.createCell(4).setCellValue(reconcileDataReportBO.getBulkreg_integration_id());
            row.createCell(5).setCellValue(reconcileDataReportBO.getBulkreg_error_code());
            row.createCell(6).setCellValue(reconcileDataReportBO.getBulkreg_last_updated_date());
            row.createCell(7).setCellValue(reconcileDataReportBO.getBulkreg_flag());
            row.createCell(8).setCellValue(reconcileDataReportBO.getOptout_flag());
            row.createCell(9).setCellValue(reconcileDataReportBO.getExtract_file_name());
            reconcileDataReportBO=null;
        } 
        return wb;
    }
    
  
    /**
     * @since R7.1
     * @param bulkRegistrationForm
     * @return
     */
    private Workbook generateDescripencyRport(BulkRegistrationForm bulkRegistrationForm){
        Workbook wb = new SXSSFWorkbook(100); 
        SXSSFSheet sheet = (SXSSFSheet) wb.createSheet("Discrepancy Data");
        int sheetCount = 0;
        
        SXSSFRow header = sheet.createRow(0);
        header.createCell(0).setCellValue("IHI");
        header.createCell(1).setCellValue("BULKREG_STATE");
        header.createCell(2).setCellValue("BULKREG_ERROR");
        header.createCell(3).setCellValue("BULKREG_ERROR_DESCRIPTION");
        
        int rowNum = 1;
        
        LOG.info("size of objects:::"+bulkRegistrationForm.getReconcileDataReportBOLst().size());
        
        for(ReconcileDataReportBO reconcileDataReportBO :  bulkRegistrationForm.getReconcileDataReportBOLst() ){    
            if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                sheet = (SXSSFSheet) wb.createSheet("Discrepancy Data"+sheetCount);
                rowNum=0;
                sheetCount++;
            }
            SXSSFRow row = sheet.createRow(rowNum++);            
            row.createCell(0).setCellValue(reconcileDataReportBO.getIHI().toString());
            row.createCell(1).setCellValue((reconcileDataReportBO.getBulkreg_state())==null?"":reconcileDataReportBO.getBulkreg_state().toString());
            row.createCell(2).setCellValue((reconcileDataReportBO.getBulkreg_error_code())==null?"":reconcileDataReportBO.getBulkreg_error_code().toString());
            row.createCell(3).setCellValue((reconcileDataReportBO.getBulkreg_error_desc())==null?"":reconcileDataReportBO.getBulkreg_error_desc().toString());
            reconcileDataReportBO=null;
        }        
        return wb;
    }
}
