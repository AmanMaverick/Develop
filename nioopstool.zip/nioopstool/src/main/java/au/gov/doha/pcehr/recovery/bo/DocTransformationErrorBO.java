package au.gov.doha.pcehr.recovery.bo;


public class DocTransformationErrorBO {
    public DocTransformationErrorBO() {
        super();
    }
    //variable name format iHI beacuse in error csv Header name should be IHI
    private String iHI;
    private String docId;
    private String docType;
    private String status;
    private String transcationDateAndTime;
    private String errorDescription;
    public DocTransformationErrorBO( String ihi,String docId,String docType,String errorDescription){
        this.iHI=ihi;
        this.docId=docId;
        this.docType=docType;
        this.errorDescription=errorDescription;
    }
    public void setIHI(String ihi) {
        this.iHI = ihi;
    }

    public String getIHI() {
        return iHI;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getDocType() {
        return docType;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setTranscationDateAndTime(String transcationDateAndTime) {
        this.transcationDateAndTime = transcationDateAndTime;
    }

    public String getTranscationDateAndTime() {
        return transcationDateAndTime;
    }
}
