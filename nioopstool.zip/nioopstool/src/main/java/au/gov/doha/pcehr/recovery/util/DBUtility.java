package au.gov.doha.pcehr.recovery.util;


import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

import pcehr.recovery.DataBaseConnection;


public class DBUtility {
    private static Logger LOG = Logger.getLogger(DBUtility.class);
    /**
     *Close the result set.
     * @param rs
     */
    public static final void close(ResultSet rs)  {
        try{
            rs.close();
        }catch(Exception e){
            
        }
    }
    /**
     * Close the PreparedStatement.
     * @param pStmt
     */
    public static final void close(PreparedStatement pStmt)  {
        try{
            pStmt.close();
        }catch(Exception e){
            
        }
    }
    /**
     * Close the PreparedStatement.
     * @param pStmt
     */
    public static final void close(Statement stmt)  {
        try{
            stmt.close();
        }catch(Exception e){
            
        }
    }
    /**
     * closes the connection.
     * @param conn
     */
    public static final void close(Connection conn)  {
        try{
            conn.close();
        }catch(Exception e){
            
        }
    }
    
    /**
     * closes the connection.
     * @param conn
     */
    public static final void rollback(Connection conn)  {
        try{
            conn.rollback();
        }catch(Exception e){
            
        }
    }
    
    public static final Connection getDataBaseConnectionObject(String database) throws Exception {
        DataBaseConnection dbConn = null;
        if("HTB".equals(database)){
            dbConn = new DataBaseConnection(EndPointsConstants.INITIAL_CONTEXT_FACTORY, EndPointsConstants.WEBLOGIC_PROVIDER_URL, EndPointsConstants.WEBLOGIC_JNDI_NAME_HTB);
            return dbConn.getHTBConnection();
        }else if("PNA".equals(database)){
            dbConn = new DataBaseConnection(EndPointsConstants.INITIAL_CONTEXT_FACTORY, EndPointsConstants.WEBLOGIC_PROVIDER_URL, EndPointsConstants.WEBLOGIC_JNDI_NAME_PNA);
            return dbConn.getConnectionfromOESPNA();
        }else if("OSB".equals(database)) {
            dbConn = new DataBaseConnection(EndPointsConstants.INITIAL_CONTEXT_FACTORY, EndPointsConstants.WEBLOGIC_PROVIDER_URL, EndPointsConstants.WEBLOGIC_JNDI_NAME_OSB);
            return dbConn.getConnection();
         }else if("OIM".equals(database)){
            dbConn = new DataBaseConnection(EndPointsConstants.INITIAL_CONTEXT_FACTORY, EndPointsConstants.WEBLOGIC_PROVIDER_URL, EndPointsConstants.WEBLOGIC_JNDI_NAME_OIM);
            return null;
         }else if("RLS".equals(database)){
            dbConn = new DataBaseConnection(EndPointsConstants.INITIAL_CONTEXT_FACTORY, EndPointsConstants.WEBLOGIC_PROVIDER_URL, EndPointsConstants.WEBLOGIC_JNDI_NAME_RLS);
            return dbConn.getConnectionfromRLS();
        }

        return null;
        
    }
}
