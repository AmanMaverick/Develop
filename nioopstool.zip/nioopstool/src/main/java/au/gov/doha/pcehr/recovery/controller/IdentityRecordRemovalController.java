package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.IdentityRecordRemovalForm;
import au.gov.doha.pcehr.recovery.service.IdentityRecordRemovalService;
import au.gov.doha.pcehr.recovery.util.JSONUtil;
import au.gov.doha.pcehr.recovery.validation.IdentityRecordRemovalValidator;

import java.io.IOException;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * Controller for Identity and Record Removal page.
 * @author Rakhi Tholia, AO,  PCEHR
 * @since 10th March 2015
 * @version - x
 */


@Controller
@RequestMapping(value = "/IdentityRemoval**")
public class IdentityRecordRemovalController {
    private static Logger LOG = Logger.getLogger(IdentityRecordRemovalController.class);
    private static final String MODEL_ATTRIBUTE = "identityRemovalAttribute";
    private static final String LOADING_PAGE = "NIO/IdentityRemovalNew";
    private static final String DISPLAY_RECORD = "NIO/DisplayRecord";
    private static final String DELETE_SUCCESS = "NIO/DeleteSuccess";

    @Autowired
    @Qualifier("identityRecordRemovalValidator")
    private IdentityRecordRemovalValidator identityRecordRemovalValidator;

    @Autowired
    private IdentityRecordRemovalService identityRecordRemovalservice;

    @InitBinder(MODEL_ATTRIBUTE)
    protected void initBinderConfig(WebDataBinder binder) {
        LOG.debug("Initialising the validator");
        binder.setValidator(identityRecordRemovalValidator);
    }

    /**
     * Request Mapping for Method=GET. It returns URL for displaying identity Record Removal page for
     * Identity and Record Removal
     * @param identityRecordRemovalForm
     */
    @AuditBefore(AuditMessageConstants.RECORD_IDENTITY_REMOVAL_PAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/IdentityRemoval")
    public String showRecordIdentityRemovalPg(@ModelAttribute(MODEL_ATTRIBUTE)
        IdentityRecordRemovalForm identityRecordRemovalForm) {
        LOG.debug("Inside Controller Class");
        return LOADING_PAGE;
    }

    /**
     * Method validates input data and then calls service method getDetails to fetch
     * data about IHI.
     * @param identityRecordRemoval
     * @return DISPLAY_RECORD
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.GET_IHI_DEMOGRAPHIC_DETAIL)
    @RequestMapping(method = { RequestMethod.POST }, params = "identityRecordRemovalSubmit=Select")
    public String displayData(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        IdentityRecordRemovalForm identityRecordRemoval, BindingResult result,
        ModelMap map) throws RecoveryServiceException, RecoveryDAOException,
                                                                         InstantiationException,
                                                                         IllegalAccessException,
                                                                         IOException, JsonParseException,
                                                                         JsonMappingException {
        if (result.hasErrors()) {
            map.addAttribute("identityRecordRemovalForm", identityRecordRemoval);
            return LOADING_PAGE;
        }
        if("singleInput".equals(identityRecordRemoval.getOperationTypeRemoval())){
            identityRecordRemoval = identityRecordRemovalservice.getDetails(identityRecordRemoval);
            //identityRecordRemoval.setSex(setSexDetail(identityRecordRemoval.getSex()));
            return DISPLAY_RECORD;
        }else{
            JSONUtil<IdentityRemovalBO> jsonUtil = new JSONUtil<IdentityRemovalBO>();
            identityRecordRemoval.setJsonString(jsonUtil.toJSON(identityRecordRemoval.getListIdentityRemovalBO()));
            map.addAttribute("numberOfEntries", identityRecordRemoval.getListIdentityRemovalBO().size());
            return DISPLAY_RECORD;
        }
    }


    /**
     * Method calls service's deleteRecord method to delete records for that IHI from Database
     * @param identityRecordRemoval
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.RECORD_REMOVAL_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, params = "Incorrect Record Removal=Delete")
    public String deleteRecord(@ModelAttribute(MODEL_ATTRIBUTE)
        IdentityRecordRemovalForm identityRecordRemoval) throws RecoveryServiceException, RecoveryDAOException,
                                                                                       IOException, JsonParseException,
                                                                                       JsonMappingException {
        LOG.debug("Inside delete Record method");
        //LOG.debug("Ihi list:::"+identityRecordRemoval.getListIHI().size());
        LOG.debug("Controller-- IHI:" + identityRecordRemoval.getIhi());
        LOG.debug("Controller-- Action_Type:" + identityRecordRemoval.getAction_Type());
        identityRecordRemoval = identityRecordRemovalservice.deleteRecord(identityRecordRemoval);
        return DELETE_SUCCESS;
    }
    
    /**
     * Method calls service's deleteIdentity method to delete Identity for that IHI from Database
     * @param identityRecordRemoval
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.IDENTITY_REMOVAL_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, params = "Incorrect Identity Removal=Delete")
    public String deleteIdentity(@ModelAttribute(MODEL_ATTRIBUTE)
        IdentityRecordRemovalForm identityRecordRemoval) throws RecoveryServiceException, RecoveryDAOException,
                                                                                         IOException,
                                                                                         JsonParseException,
                                                                                         JsonMappingException {
        LOG.debug("Inside delete Identity method");
        LOG.debug("Controller-- IHI:" + identityRecordRemoval.getIhi());
        LOG.debug("Controller-- Action_Type:" + identityRecordRemoval.getAction_Type());
        identityRecordRemoval = identityRecordRemovalservice.deleteIdentity(identityRecordRemoval);
        return DELETE_SUCCESS;
    }
    /**
     * Method calls service's deleteIdentityAndRecord method to delete records as well
     * as identity for that IHI from Database.
     * @param identityRecordRemoval
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.IDENTITY_RECORD_REMOVAL_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, params = "Incorrect Identity & Record Removal=Delete")
    public String deleteIdentityAndRecord(@ModelAttribute(MODEL_ATTRIBUTE)
        IdentityRecordRemovalForm identityRecordRemoval) throws RecoveryServiceException, RecoveryDAOException,
                                                                                                  IOException,
                                                                                                  JsonParseException,
                                                                                                  JsonMappingException {
        LOG.debug("Inside delete Identity and Record method");
        LOG.debug("Controller-- IHI:" + identityRecordRemoval.getJsonString());
        LOG.debug("Controller-- Action_Type:" + identityRecordRemoval.getAction_Type());
        identityRecordRemoval = identityRecordRemovalservice.deleteIdentityAndRecord(identityRecordRemoval);
        return DELETE_SUCCESS;
    }
    /**
     * Method calls service's deleteChildRecord method to delete Child record having no 
     * identity for that IHI from Database.
     * @param identityRecordRemoval
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.REMOVAL_CHILD_RECORD_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, params = "Incorrect Child Record Removal_with No Identity=Delete")
    public String deleteChildRecord(@ModelAttribute(MODEL_ATTRIBUTE)
        IdentityRecordRemovalForm identityRecordRemoval) throws RecoveryServiceException, RecoveryDAOException,
                                                                                            IOException,
                                                                                            JsonParseException,
                                                                                            JsonMappingException {
        LOG.debug("Inside delete method");
        LOG.debug("Controller-- IHI:" + identityRecordRemoval.getIhi());
        LOG.debug("Controller-- Action_Type:" + identityRecordRemoval.getAction_Type());
        identityRecordRemoval = identityRecordRemovalservice.deleteChildRecord(identityRecordRemoval);
        return DELETE_SUCCESS;
    }
   
}
