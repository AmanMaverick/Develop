package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.IdentityBlobDocs;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;


/**
 * Used to interact with oes_pnadb database tables
 * @author Vikash Kumar Singh
 * @since 15th Dec 2014
 * @version Change-x
 */
@Component
public class ARTExtractionDAO {
    
    
    @Autowired
    @Qualifier("pnaJDBCTemplate")
    private JdbcTemplate pnaJdbcTemplate;
    
    @Autowired
    private FileUtil fileUtil;
    
    @Value("${ARTEXTRACTION.GET_DOCUMENT_BY_USER_ID}") 
    private String get_document_by_user_id;
    
    @Value("${ARTEXTRACTION.GET_DOCUMENT}") 
    private String get_document;
    
    private static Logger LOG = Logger.getLogger(ARTExtractionDAO.class);
    /**
     * Get Document list with out blob of perticuler user
     * standard method
     * @param id - userId
     * @return List of IdentityBlobDocs
     */
    public List<IdentityBlobDocs> getDocumentByUserId(long id)throws RecoveryDAOException {
        List<IdentityBlobDocs> docList = new ArrayList<IdentityBlobDocs>();
        try{
            docList = pnaJdbcTemplate.query(get_document_by_user_id,
                new Object[] {id},
                new RowMapper<IdentityBlobDocs>() {
                    public IdentityBlobDocs mapRow(ResultSet rs, int rowNum) throws SQLException {
                        IdentityBlobDocs identityBlobDocs = new IdentityBlobDocs();
                        identityBlobDocs.setDocumentId(rs.getLong("IV_BLOB_DOCUMENT_ID"));
                        identityBlobDocs.setUserId(rs.getLong("USER_ID"));
                        identityBlobDocs.setFileSize(rs.getBlob("IV_BLOB_DOCUMENT") != null ? 
                                                     rs.getBlob("IV_BLOB_DOCUMENT").length() : 0);
                        identityBlobDocs.setFileName(rs.getString("IV_FILE_NAME"));
                        byte[] blobAsBytes = rs.getBlob("IV_BLOB_DOCUMENT").getBytes(1, (int)identityBlobDocs.getFileSize());
                        byte[] buffer = Base64.decodeBase64(blobAsBytes);
                        identityBlobDocs.setBlobdocs(buffer);                                    
                        identityBlobDocs.setFileType(rs.getString("IV_FILE_TYPE"));
                        LOG.debug("identityBlobDocs file type 111 :: " + identityBlobDocs.getFileType());
                        if("application/octet-stream".equals(identityBlobDocs.getFileType())){
                            //if file type is application/octet-stream, then using file bites to find file type 
                            identityBlobDocs.setFileType(fileUtil.getContentType(identityBlobDocs.getBlobdocs(),null));
                            if(identityBlobDocs.getBlobdocs() != null){
                                LOG.debug("identityBlobDocs file type 222 :: " + identityBlobDocs.getFileType());    
                            }
                            
                        }
                        return identityBlobDocs;
                    }
                });
        }catch(Exception e){
            LOG.fatal("Exception occured in getDocumentByUserId...");
            throw new RecoveryDAOException(e);
        }
        LOG.info("data loaded successfully");
        
        return docList;
    }
    
    /**
     * Get document list with out blob of argument id array
     * standard method
     * @param ids - document Ids
     * @return list of IdentityBlobDocs
     */
    public List<IdentityBlobDocs> getDocumentById(long blobDocIds)throws RecoveryDAOException {
        LOG.debug("getDocumentById started. Number of IDs - " +blobDocIds);
        try{
            List<IdentityBlobDocs> docList = new ArrayList<IdentityBlobDocs>();
            List<IdentityBlobDocs> docs = pnaJdbcTemplate.query(
                             get_document,
                             new Object[] {blobDocIds},
                             new RowMapper<IdentityBlobDocs>() {
                                 public IdentityBlobDocs mapRow(ResultSet rs, int rowNum) throws SQLException {
                                     IdentityBlobDocs identityBlobDocs = new IdentityBlobDocs();
                                     identityBlobDocs.setDocumentId(rs.getLong("IV_BLOB_DOCUMENT_ID"));
                                     identityBlobDocs.setUserId(rs.getLong("USER_ID"));
                                     identityBlobDocs.setFileSize(rs.getBlob("IV_BLOB_DOCUMENT") != null ? 
                                                                  rs.getBlob("IV_BLOB_DOCUMENT").length() : 0);
                                     byte[] blobAsBytes = rs.getBlob("IV_BLOB_DOCUMENT").getBytes(1, (int)identityBlobDocs.getFileSize());
                                     byte[] buffer = Base64.decodeBase64(blobAsBytes);
                                     identityBlobDocs.setBlobdocs(buffer);
                                     identityBlobDocs.setFileName(rs.getString("IV_FILE_NAME"));
                                     identityBlobDocs.setFileType(rs.getString("IV_FILE_TYPE"));
                                     if("application/octet-stream".equals(identityBlobDocs.getFileType())){
                                         //if file type is application/octet-stream, then using file bites to find file type 
                                         identityBlobDocs.setFileType(fileUtil.getContentType(identityBlobDocs.getBlobdocs(),null));
                                     }
                                     identityBlobDocs.setBlob((Blob)rs.getBlob("IV_BLOB_DOCUMENT"));
                                     return identityBlobDocs;
                                 }
                             });
             if(docs.size()>=0){
                 for(IdentityBlobDocs doc : docs){
                     docList.add(doc);    
                 }    
             }
            LOG.debug("docList size :  " + docList.size());
            return docList;
        }catch(Exception e){
            LOG.fatal("Exception Occured..",e);
            throw new RecoveryDAOException(e);
        }
       
       
    }  
    
    /**
     * Get Document with blob file
     * @param docId
     * @return 
     */
    public IdentityBlobDocs getDocumentWithBlob(long docId)throws RecoveryDAOException {
        LOG.debug("getDocumentWithBlob started");
        IdentityBlobDocs blobDocs = null;
        try{
            blobDocs = pnaJdbcTemplate.queryForObject(get_document,
                new Object[]{docId},
                new RowMapper<IdentityBlobDocs>() {
                    public IdentityBlobDocs mapRow(ResultSet rs, int rowNum) throws SQLException {
                        IdentityBlobDocs docs = new IdentityBlobDocs();
                        docs.setDocumentId(rs.getLong("IV_BLOB_DOCUMENT_ID"));
                        docs.setUserId(rs.getLong("USER_ID"));
                        //                docs.setBlobdocs(resultSet.getBlob("IV_BLOB_DOCUMENT"));
                        int blobLength = (int) rs.getBlob("IV_BLOB_DOCUMENT").length();
                        byte[] blobAsBytes = rs.getBlob("IV_BLOB_DOCUMENT").getBytes(1, blobLength);
                        byte[] buffer = Base64.decodeBase64(blobAsBytes);
                        docs.setBlobdocs(buffer);
                        docs.setFileName(rs.getString("IV_FILE_NAME"));
                        docs.setFileType(rs.getString("IV_FILE_TYPE"));
                        if("application/octet-stream".equals(docs.getFileType())){
                            //if file type is application/octet-stream, then using file bites to find file type
                            docs.setFileType(fileUtil.getContentType(docs.getBlobdocs(),null));
                        }
                        docs.setBlob((Blob)rs.getBlob("IV_BLOB_DOCUMENT"));
                        LOG.info("data loaded successfully");
                        if(docs==null){
                            return null;
                        }else{
                            return docs;    
                        }
                        
                    }
                });
        }catch(Exception ex){
            //LOG.fatal("Exception Occured", ex);
            LOG.info("Exception occured in getDocumentWithBlob..." + docId);
            //throw new RecoveryDAOException();
        }
        LOG.debug("getDocumentWithBlob end");
        return blobDocs;
    }
   
}
