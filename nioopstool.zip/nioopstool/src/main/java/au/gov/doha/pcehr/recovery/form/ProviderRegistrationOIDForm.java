package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.ProviderRegistrationOIDBO;

import java.util.List;

public class ProviderRegistrationOIDForm {
 
    private String fromDate;
    private String toDate;
    private List<ProviderRegistrationOIDBO> errorList;
    
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setErrorList(List<ProviderRegistrationOIDBO> errorList) {
        this.errorList = errorList;
    }

    public List<ProviderRegistrationOIDBO> getErrorList() {
        return errorList;
    }
     
}
