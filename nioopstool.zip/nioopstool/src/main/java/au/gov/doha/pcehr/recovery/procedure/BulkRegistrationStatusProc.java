package au.gov.doha.pcehr.recovery.procedure;

import au.gov.doha.pcehr.recovery.mapper.StatusMapper;

import au.gov.doha.pcehr.recovery.service.BulkRegistrationService;

import java.sql.Types;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;

import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class BulkRegistrationStatusProc extends StoredProcedure{
    private static Logger LOG = Logger.getLogger(BulkRegistrationStatusProc.class);
    public BulkRegistrationStatusProc(DataSource dataSource) {
        super(dataSource, "bulkRegistrationStatus");
        declareParameter(new SqlParameter("OPT", OracleTypes.NUMBER));
        declareParameter(new SqlParameter("ARR", OracleTypes.ARRAY, "TAB_VAR_ARRAY"));
        declareParameter(new SqlOutParameter("C_Status", OracleTypes.CURSOR, new StatusMapper()));
        compile();
    }
    public Map<String, Object> execute(String[] ihiArray,int opt) {
        LOG.debug("Option value....."+opt);                        
        Map<String, Object> inputs = new HashMap<String, Object>();
        try{
            inputs.put("OPT",opt);
            inputs.put("ARR",new SqlArrayValue(ihiArray));
            
        }catch(Exception e){
            LOG.fatal("Excception occur",e);
        }
        return super.execute(inputs);
        
    }
    
    
}
