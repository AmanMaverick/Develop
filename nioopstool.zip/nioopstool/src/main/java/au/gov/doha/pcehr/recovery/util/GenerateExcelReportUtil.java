package au.gov.doha.pcehr.recovery.util;

import au.gov.doha.pcehr.recovery.dao.BulkRegistrationDAO;

import java.util.List;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

public class GenerateExcelReportUtil {
    private static Logger LOG = Logger.getLogger(GenerateExcelReportUtil.class);   
    
    
    public class ExcelView extends AbstractExcelView{
    
        @Override
        protected void buildExcelDocument(Map<String, Object> map, HSSFWorkbook hSSFWorkbook,
                                          HttpServletRequest httpServletRequest,
                                          HttpServletResponse httpServletResponse) throws Exception {
            LOG.info("Entered into execelview");        
        
        
            
        }
    }
    
}
