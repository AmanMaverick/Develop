package au.gov.doha.pcehr.recovery.bo;


public class PNAUpdateAuthRepWSClientBO {
    private String recordIHI;
    private String userID;
    private Integer rel_type;
private String reason;

    public void setRecordIHI(String recordIHI) {
        this.recordIHI = recordIHI;
    }

    public String getRecordIHI() {
        return recordIHI;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setRel_type(Integer rel_type) {
        this.rel_type = rel_type;
    }

    public Integer getRel_type() {
        return rel_type;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return reason;
    }
}
