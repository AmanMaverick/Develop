package au.gov.doha.pcehr.recovery.bo;

import javax.xml.datatype.XMLGregorianCalendar;

public class RegisterPCEHRClientBO {
    public RegisterPCEHRClientBO() {
        super();
    }
    private String individualType;

    public void setIndividualType(String individualType) {
        this.individualType = individualType;
    }

    public String getIndividualType() {
        return individualType;
    }
    private String ihi;
    private String lastName;
    private String sex;
    private XMLGregorianCalendar dateOfBirth;
    
    private String pbsRPBS;
    private String pastPBSrpbs;
    private String mbsDVS;
    private String pastMBSdvs;
    private String acir;
    private String aodr;
    
    private String arIHI;
    private String arLastName;
    private String arSex;
    private XMLGregorianCalendar arDateOfBirth;
    private String medicareCardCheck;
    private String userId;
    
    //Notification
    private String notificationChannel;
    private String notificationDetails;
    private String healthcareProviderAssertion;


    public void setNotificationChannel(String notificationChannel) {
        this.notificationChannel = notificationChannel;
    }

    public String getNotificationChannel() {
        return notificationChannel;
    }

    public void setNotificationDetails(String notificationDetails) {
        this.notificationDetails = notificationDetails;
    }

    public String getNotificationDetails() {
        return notificationDetails;
    }

    public void setHealthcareProviderAssertion(String healthcareProviderAssertion) {
        this.healthcareProviderAssertion = healthcareProviderAssertion;
    }

    public String getHealthcareProviderAssertion() {
        return healthcareProviderAssertion;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setMedicareCardCheck(String medicareCardCheck) {
        this.medicareCardCheck = medicareCardCheck;
    }

    public String getMedicareCardCheck() {
        return medicareCardCheck;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSex() {
        return sex;
    }

    public void setDateOfBirth(XMLGregorianCalendar dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public XMLGregorianCalendar getDateOfBirth() {
        return dateOfBirth;
    }

    public void setPbsRPBS(String pbsRPBS) {
        this.pbsRPBS = pbsRPBS;
    }

    public String getPbsRPBS() {
        return pbsRPBS;
    }

    public void setPastPBSrpbs(String pastPBSrpbs) {
        this.pastPBSrpbs = pastPBSrpbs;
    }

    public String getPastPBSrpbs() {
        return pastPBSrpbs;
    }

    public void setMbsDVS(String mbsDVS) {
        this.mbsDVS = mbsDVS;
    }

    public String getMbsDVS() {
        return mbsDVS;
    }

    public void setPastMBSdvs(String pastMBSdvs) {
        this.pastMBSdvs = pastMBSdvs;
    }

    public String getPastMBSdvs() {
        return pastMBSdvs;
    }

    public void setAcir(String acir) {
        this.acir = acir;
    }

    public String getAcir() {
        return acir;
    }

    public void setAodr(String aodr) {
        this.aodr = aodr;
    }

    public String getAodr() {
        return aodr;
    }

    public void setArIHI(String arIHI) {
        this.arIHI = arIHI;
    }

    public String getArIHI() {
        return arIHI;
    }

    public void setArLastName(String arLastName) {
        this.arLastName = arLastName;
    }

    public String getArLastName() {
        return arLastName;
    }

    public void setArSex(String arSex) {
        this.arSex = arSex;
    }

    public String getArSex() {
        return arSex;
    }

    public void setArDateOfBirth(XMLGregorianCalendar arDateOfBirth) {
        this.arDateOfBirth = arDateOfBirth;
    }

    public XMLGregorianCalendar getArDateOfBirth() {
        return arDateOfBirth;
    }

    public void setRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
    }

    public String getRelationshipType() {
        return relationshipType;
    }

    public void setDocumentSighted(String documentSighted) {
        this.documentSighted = documentSighted;
    }

    public String getDocumentSighted() {
        return documentSighted;
    }

    public void setDocDetail(String docDetail) {
        this.docDetail = docDetail;
    }

    public String getDocDetail() {
        return docDetail;
    }

    public void setAuthrityStartDate(XMLGregorianCalendar authrityStartDate) {
        this.authrityStartDate = authrityStartDate;
    }

    public XMLGregorianCalendar getAuthrityStartDate() {
        return authrityStartDate;
    }

    public void setAuthrityEndDate(XMLGregorianCalendar authrityEndDate) {
        this.authrityEndDate = authrityEndDate;
    }

    public XMLGregorianCalendar getAuthrityEndDate() {
        return authrityEndDate;
    }

    public void setAuthrityReviewtDate(XMLGregorianCalendar authrityReviewtDate) {
        this.authrityReviewtDate = authrityReviewtDate;
    }

    public XMLGregorianCalendar getAuthrityReviewtDate() {
        return authrityReviewtDate;
    }
    private String relationshipType;
    private String documentSighted;
    private String docDetail;
    private XMLGregorianCalendar authrityStartDate;
    private XMLGregorianCalendar authrityEndDate;
    private XMLGregorianCalendar authrityReviewtDate;
}
