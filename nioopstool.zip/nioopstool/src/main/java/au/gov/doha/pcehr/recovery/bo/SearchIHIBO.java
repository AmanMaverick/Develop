package au.gov.doha.pcehr.recovery.bo;


/**
 * @author Sapna
 * This class is the business object for the OSB Call Search IHI.
 */
public class SearchIHIBO extends OSBIntPCEHRHeaderBO{
    private String ihi;
    private String lastName;
    private String sex;
    private String dateOfBirth;
    private String userID;
    
    
    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }
    
    
    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSex() {
        return sex;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }


}
