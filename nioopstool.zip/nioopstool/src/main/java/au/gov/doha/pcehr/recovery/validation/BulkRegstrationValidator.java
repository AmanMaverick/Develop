package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.constants.RecoverConstants;
import au.gov.doha.pcehr.recovery.dao.BulkRegistrationDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.BulkRegistrationForm;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.MultipartFile;

@Component
public class BulkRegstrationValidator implements Validator {
    private static Logger LOG = Logger.getLogger(BulkRegstrationValidator.class);
   
    @Autowired
    BulkRegistrationDAO bulkRegistrationDAO;
    @Autowired
    FileUtil fileUtil;

    @Override
    public boolean supports(Class<?> c) {
        return BulkRegistrationForm.class.equals(c);
    }

    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Entered BulkRegstrationValidator");
        if (object instanceof BulkRegistrationForm) {
            BulkRegistrationForm bulkRegistrationForm = (BulkRegistrationForm) object;
            if (bulkRegistrationForm.getValidateAction() != null) {
                LOG.debug("bulkRegistrationForm.getValidateAction is not equal to null");
                errors = validateBulkRegistrationForm(bulkRegistrationForm, errors);
            } else if (bulkRegistrationForm.getBulkrecordCreationAction() != null && bulkRegistrationForm.getBulkrecordCreationAction().equals("RecordCreation") //For Bulk Record Creation Tab
                       && bulkRegistrationForm.getRecordCreationAction() != null) {
                if (bulkRegistrationForm.getRecordCreationAction().equals("Create Record for List of IHIs")) {
                    LOG.debug("Starting validation for Bulk Record Creation Tab");
                    errors = validateRecordCreationForm(bulkRegistrationForm, errors);
                } else if (bulkRegistrationForm.getRecordCreationAction().equals("Create Records for a Specified Number of Rows")) {
                    errors = validateRecordCreationForNumberOfRows(bulkRegistrationForm, errors);
                }
            } else if (bulkRegistrationForm.getValidateAndCreateRecordAction() != null && bulkRegistrationForm.getValidateAndCreateRecordAction().equals("validateAndCreateRecordAction") //For Bulk Record Creation Tab
                       && bulkRegistrationForm.getValidateAndRecordCreation() != null) {
                if (bulkRegistrationForm.getValidateAndRecordCreation().equals("Validate and Register for a List of IHIs")) {
                    LOG.debug("Validate and Register for a List of IHIs ---- 1");
                    errors = validateCombinedValidationAndCreationForm(bulkRegistrationForm, errors);
                } else if (bulkRegistrationForm.getValidateAndRecordCreation().equals("Validate and Register for Specified Number of Rows")) {
                    LOG.debug("Validate and Register for a List of IHIs ---- 2");
                    errors = validateCombinedValidationAndCreationForNumberOfRows(bulkRegistrationForm, errors);
                }
            } else if (bulkRegistrationForm.getBulkStatusAction() != null &&
                       bulkRegistrationForm.getBulkStatusAction().equals("Status")) {
                LOG.debug("status action not null");
                errors = validateStatus(bulkRegistrationForm, errors);
            } else if (bulkRegistrationForm.getValidateAndDataExtractionAction() != null &&
                       bulkRegistrationForm.getValidateAndDataExtractionAction().equals("ValidateAndDataExtarctAction")) {
                LOG.debug("validation for validateAndDataExtract tab");
                validateValidateAndDataExtraction(bulkRegistrationForm, errors);
            }

        } else {
            LOG.fatal("");
            throw new IllegalArgumentException();
        }
        LOG.debug("Leaving BulkRegstrationValidator");
    }

    /**
     *
     * @param bulkRegistrationForm
     * @param errors
     * @return
     */
    private Errors validateValidateAndDataExtraction(BulkRegistrationForm bulkRegistrationForm, Errors errors) {
        LOG.debug("validating   validateAndDataExtract tab");
        String fileName = bulkRegistrationForm.getFileName();
        boolean fileExtensionCheck = false;
        String checkSUmFromUI = bulkRegistrationForm.getCheckSumValueFromUI();
        if (fileName != null && fileName.equals("")) {
            errors.rejectValue("fileName", "bulkRegistrationAttribute.fileNameNotNull");
        }
        if (checkSUmFromUI != null && checkSUmFromUI.equals("")) {
            errors.rejectValue("checkSumValueFromUI", "bulkRegistrationAttribute.checkSumValueFromUINotNull");
        }
        if (bulkRegistrationForm.getFileName() != null && bulkRegistrationForm.getFileName().length() > 0) {
            String fileNameFromUI = bulkRegistrationForm.getFileName();
            if (fileName.equals("")) {
                LOG.debug("File not found");
                errors.rejectValue("fileName", "bulkRegistrationAttribute.fileNotFound");
            } else if ((fileNameFromUI.indexOf(".") < 0)) {
                errors.rejectValue("fileName", "bulkRegistrationAttribute.fileFormatTxt");
            } else if (!(fileNameFromUI.substring(fileNameFromUI.indexOf('.'),
                                                  fileNameFromUI.length())).equalsIgnoreCase(".txt")) {
                errors.rejectValue("fileName", "bulkRegistrationAttribute.fileFormatTxt");
            } else {
                fileExtensionCheck = true;
            }


        }
        //checking file format
        if (fileExtensionCheck) {
            //moved to file util to validtate file name  from service layer also..Fixing pen test defect
            if (!fileUtil.fileNameFormatValidation(fileName)) {
                errors.rejectValue("fileName", "bulkRegistrationAttribute.invalidDHSFileFormat");
            }
        }
        return errors;
    }



    /**
     * This method validates the data input for the bulk registration.
     * @param bulkRegistrationForm
     * @param errors
     * @return
     */
    private Errors validateBulkRegistrationForm(BulkRegistrationForm bulkRegistrationForm, Errors errors) {
        errors = validateIHIInfo(bulkRegistrationForm, errors);
        return errors;
    }

    /**
     *
     * @param bulkRegistrationForm
     * @param errors
     * @return
     */
    private Errors validateIHIInfo(BulkRegistrationForm bulkRegistrationForm, Errors errors) {
        //Validating the Validate IHI INFO i/p
        if ("Select IHI List for Validation".equals(bulkRegistrationForm.getValidateAction())) {
            String fileName = bulkRegistrationForm.getValidateFilelUpload().getOriginalFilename();
            int fileSize = (int) bulkRegistrationForm.getValidateFilelUpload().getSize();
            if (fileName.equals("")) {
                LOG.debug("File not found");
                errors.rejectValue("validateFilelUpload", "bulkRegistrationAttribute.fileNotFound");
            } else if (!(fileName.indexOf('.') > 0) ||
                       (!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv"))) {
                LOG.debug("file name validation failed");
                errors.rejectValue("validateFilelUpload", "bulkRegistrationAttribute.invalidFile");
            } else if (fileSize >= 0 && fileSize > RecoverConstants.FILE_SIZE) {
                LOG.debug("FIle size validation failed");
                errors.rejectValue("validateFilelUpload", "bulkRegistrationAttribute.invalidFileSize");
            }

        }
        if ("Select Number of Rows for Validation".equals(bulkRegistrationForm.getValidateAction())) {
            try {
                LOG.debug("bulkRegistrationForm.getValidateNoOfRows()..." + bulkRegistrationForm.getValidateNoOfRows());
                long count = bulkRegistrationDAO.getStagingPrimaryCount();
                if (bulkRegistrationForm.getValidateNoOfRows() == null) {
                    errors.rejectValue("validateFilelUpload",
                                       "bulkRegistrationAttribute.validateInfo.validateNoOfRows");
                } else if (bulkRegistrationForm.getValidateNoOfRows() != null &&
                           bulkRegistrationForm.getValidateNoOfRows().longValue() > count) {
                    LOG.debug("Please enter the no of rows.");
                    errors.rejectValue("validateFilelUpload",
                                       "bulkRegistrationAttribute.validateInfo.validateNoOfRows");
                }else if (bulkRegistrationForm.getValidateNoOfRows() != null &&
                           bulkRegistrationForm.getValidateNoOfRows().longValue() <= 0) {
                    LOG.debug("Please enter the no of rows.");
                    errors.rejectValue("validateFilelUpload",
                                       "bulkRegistrationAttribute.validateInfo.validateNoOfRows");
                }

            } catch (RecoveryDAOException e) {

            }

        }
        return errors;
    }

    //  Validation code for  Bulk Record Creation
    private Errors validateRecordCreationForm(BulkRegistrationForm bulkRegistrationForm, Errors errors) {

        MultipartFile file = bulkRegistrationForm.getRecordCreationFilelUpload();
        String fileName = file.getOriginalFilename();
        if (fileName.equals("")) {
            LOG.debug("File not found");
            errors.rejectValue("recordCreationFilelUpload", "BulkRegistrationForm.fileNotFound");
        } else if (!(fileName.indexOf('.') > 0) ||
                   (!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv"))) {
            LOG.debug("file name validation failed");
            errors.rejectValue("recordCreationFilelUpload", "BulkRegistrationForm.invalidFile");
        } else if (file.getSize() >= 0 && file.getSize() > RecoverConstants.FILE_SIZE) {
            LOG.debug("File size validation failed");
            errors.rejectValue("recordCreationFilelUpload", "BulkRegistrationForm.invalidFileSize");
        }
        LOG.info("File Size is :: " + file.getSize());
        return errors;
    }


    /**
     * Validates the Bulk Registration status.
     * @param bulkRegistrationForm
     * @param errors
     * @return
     */
    private Errors validateStatus(BulkRegistrationForm bulkRegistrationForm, Errors errors) {
        LOG.info("Entered into the validateStatus" + bulkRegistrationForm.getStatusAction());
        if ("List of IHIs".equals(bulkRegistrationForm.getStatusAction())) {
            String fileName = bulkRegistrationForm.getStatusFilelUpload().getOriginalFilename();
            int fileSize = (int) bulkRegistrationForm.getStatusFilelUpload().getSize();
            if (fileName.equals("")) {
                LOG.debug("File not found");
                errors.rejectValue("statusFilelUpload", "bulkRegistrationAttribute.fileNotFound");
            } else if (!(fileName.indexOf('.') > 0) ||
                       (!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv"))) {
                LOG.debug("file name validation failed");
                errors.rejectValue("statusFilelUpload", "bulkRegistrationAttribute.invalidFile");
            } else if (fileSize >= 0 && fileSize > RecoverConstants.FILE_SIZE) {
                LOG.debug("FIle size validation failed");
                errors.rejectValue("statusFilelUpload", "bulkRegistrationAttribute.invalidFileSize");
            }
        }
        if ("File Name".equals(bulkRegistrationForm.getStatusAction()) &&
            bulkRegistrationForm.getInputDHSFileName() != null &&
            bulkRegistrationForm.getInputDHSFileName().length() > 0) {
            String fileName = bulkRegistrationForm.getInputDHSFileName();
            if ((fileName.indexOf(".") < 0)) {
                errors.rejectValue("inputDHSFileName", "bulkRegistrationAttribute.fileFormatTxt");
            } else if (!(fileName.substring(fileName.indexOf('.'), fileName.length())).equalsIgnoreCase(".txt")) {
                errors.rejectValue("inputDHSFileName", "bulkRegistrationAttribute.fileFormatTxt");
            }
        }

        return errors;
    }

    /**
     *
     * @param bulkRegistrationForm
     * @param errors
     * @return
     */
    private Errors validateRecordCreationForNumberOfRows(BulkRegistrationForm bulkRegistrationForm, Errors errors) {
        try {
            long count = bulkRegistrationDAO.getStagingPrimaryCount();
            if (bulkRegistrationForm.getRecordCreationNoOfRows() == null) {
                errors.rejectValue("recordCreationNoOfRows", "BulkRegistrationForm.validateNoOfRows");
            } else if (bulkRegistrationForm.getRecordCreationNoOfRows() != null &&
                       bulkRegistrationForm.getRecordCreationNoOfRows().longValue() > count) {
                LOG.debug("FIle size validation failed");
                errors.rejectValue("recordCreationNoOfRows", "BulkRegistrationForm.validateNoOfRows");
            } else if (bulkRegistrationForm.getRecordCreationNoOfRows() != null &&
                       bulkRegistrationForm.getRecordCreationNoOfRows().longValue() <=0) {
                LOG.debug("FIle size validation failed");
                errors.rejectValue("recordCreationNoOfRows", "BulkRegistrationForm.validateNoOfRows");
            }
        } catch (RecoveryDAOException e) {
        }


        return errors;
    }

    /**
     *
     * @param bulkRegistrationForm
     * @param errors
     * @return
     */
    private Errors validateCombinedValidationAndCreationForm(BulkRegistrationForm bulkRegistrationForm, Errors errors) {
        MultipartFile file = bulkRegistrationForm.getValidateAndRecordCreationFile();
        String fileName = file.getOriginalFilename();
        if (fileName.equals("")) {
            LOG.debug("File not found");
            errors.rejectValue("validateAndRecordCreationFile", "BulkRegistrationForm.fileNotFound");
        } else if (!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv")) {
            LOG.debug("file name validation failed");
            errors.rejectValue("validateAndRecordCreationFile", "BulkRegistrationForm.invalidFile");
        } else if (file.getSize() >= 0 && file.getSize() > RecoverConstants.FILE_SIZE) {
            LOG.debug("File size validation failed");
            errors.rejectValue("validateAndRecordCreationFile", "BulkRegistrationForm.invalidFileSize");
        }
        LOG.info("File Size is :: " + file.getSize());
        return errors;
    }

    /**
     *
     * @param bulkRegistrationForm
     * @param errors
     * @return
     */
    private Errors validateCombinedValidationAndCreationForNumberOfRows(BulkRegistrationForm bulkRegistrationForm,
                                                                        Errors errors) {
        try {
            long count = bulkRegistrationDAO.getStagingPrimaryCount();
            if (bulkRegistrationForm.getValidateAndCreateNoOfRows() == null) {
                errors.rejectValue("validateAndCreateNoOfRows", "BulkRegistrationForm.validateNoOfRows");
            } else if (bulkRegistrationForm.getValidateAndCreateNoOfRows() != null &&
                       bulkRegistrationForm.getValidateAndCreateNoOfRows().longValue() > count) {
                LOG.debug("FIle size validation failed");
                errors.rejectValue("validateAndCreateNoOfRows", "BulkRegistrationForm.validateNoOfRows");
            }else if (bulkRegistrationForm.getValidateAndCreateNoOfRows() != null &&
                       bulkRegistrationForm.getValidateAndCreateNoOfRows().longValue() <=0) {
                LOG.debug("FIle size validation failed");
                errors.rejectValue("validateAndCreateNoOfRows", "BulkRegistrationForm.validateNoOfRows");
            }
        } catch (RecoveryDAOException e) {
        }


        return errors;
    }
}
