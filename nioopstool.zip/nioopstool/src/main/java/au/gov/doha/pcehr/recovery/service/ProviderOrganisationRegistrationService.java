package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.dao.ProviderOrganisationRegistrationDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ProviderOrganisationRegistrationForm;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProviderOrganisationRegistrationService {
  
    private static Logger LOG = Logger.getLogger(ProviderOrganisationRegistrationService.class);

    @Autowired
    private ProviderOrganisationRegistrationDAO providerOrganisationRegistrationDAO;
 
    public ProviderOrganisationRegistrationForm providerOrganisationRegistrationServiceMethod(ProviderOrganisationRegistrationForm providerOrganisationRegistrationForm) throws RecoveryDAOException,
                                                                                                                                                                                RecoveryServiceException {
        LOG.debug("Inside Service Class method");
        
        try{
            providerOrganisationRegistrationForm = providerOrganisationRegistrationDAO.fetchProviderOrganisationRegistrationList(providerOrganisationRegistrationForm);
        }catch (RecoveryDAOException ex) {
              throw ex;   
          }catch(Exception e){
                  LOG.fatal("Exception Occured", e);
                  throw new RecoveryServiceException(e);    
          }
        LOG.debug("Leaving Service Class");
        return providerOrganisationRegistrationForm;
    }
  }
