package au.gov.doha.pcehr.recovery.bo;


public class ReactivateAuthRepBO extends ReactivateAuthRepClientBO{
    private String ihi;
    private String rep_ihi;
    private String recordId;
    private StringBuffer alertMessage;
    private StringBuffer soapMessage;


    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setRep_ihi(String rep_ihi) {
        this.rep_ihi = rep_ihi;
    }

    public String getRep_ihi() {
        return rep_ihi;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setAlertMessage(StringBuffer alertMessage) {
        this.alertMessage = alertMessage;
    }

    public StringBuffer getAlertMessage() {
        return alertMessage;
    }

    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }
}
