package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.ProviderOrganisationRegistrationBO;

import java.util.List;

public class ProviderOrganisationRegistrationForm {
   
    private String fromDate;
    private String toDate;
    private boolean existInBoth; 
    private List<ProviderOrganisationRegistrationBO> errorList;


    public void setExistInBoth(boolean existInBoth) {
        this.existInBoth = existInBoth;
    }

    public boolean isExistInBoth() {
        return existInBoth;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setErrorList(List<ProviderOrganisationRegistrationBO> errorList) {
        this.errorList = errorList;
    }

    public List<ProviderOrganisationRegistrationBO> getErrorList() {
        return errorList;
    }

}
