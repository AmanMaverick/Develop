package au.gov.doha.pcehr.recovery.form;

//import au.gov.doha.pcehr.recovery.bo.BulkRegistrationBO;
import au.gov.doha.pcehr.recovery.bo.BulkRegistrationStatusBO;
import au.gov.doha.pcehr.recovery.bo.ReconcileDataReportBO;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class BulkRegistrationForm {
    //Bulk Registration
    private String recordCreationAction; //drop down
    private MultipartFile recordCreationFilelUpload;
    private Long recordCreationNoOfRows;
    private String bulkrecordCreationAction; //hidden text box


    //Validate IHI info.
    private String validateAction;
    private MultipartFile validateFilelUpload;
    private Long validateNoOfRows;
    private String bulkRegvalidateAction;


    //ReconcileDataForm
    private String reconReportType;
    private String reconRegistrationState;
    private String reconRegistrationAction;
    private String reconRegistrationError;
    private String reconsileDataAction;
    List<ReconcileDataReportBO> reconcileDataReportBOLst; 
    List<ReconcileDataReportBO> reconcileDataReportSummaryBOLst; 
    List<ReconcileDataReportBO> reconcileDataReportDetailedBOLst; 
    //Status
    private String statusAction;
    private String bulkStatusAction;
    private MultipartFile statusFilelUpload;
    private String inputDHSFileName;
    private List<BulkRegistrationStatusBO> bulkGenerationStatusReport;
    private int statusTabFileDownloadStatus;
    private String statusTabFileDownloadDescription; ;
    
    
    private String[] ihiList;
    //Validate and data Extract
    private String validateAndDataExtractionAction;
    private int validateExtractDownloadStatus;
    private String validateExtractDownloadDescription;
    private int validateExtractFileTransferStatus;
    private String validateDataExtract;
    private String fileName;
    private String validateExtractFileTransferSDescription;
    private String checkSumValueFromUI;

    //validate And Bulk Record Creation
    private String validateAndRecordCreation;
    private String validateAndCreateRecordAction;
    private Long validateAndCreateNoOfRows;
    private MultipartFile validateAndRecordCreationFile;

    public void setRecordCreationAction(String recordCreationAction) {
        this.recordCreationAction = recordCreationAction;
    }

    public String getRecordCreationAction() {
        return recordCreationAction;
    }

    public void setRecordCreationFilelUpload(MultipartFile recordCreationFilelUpload) {
        this.recordCreationFilelUpload = recordCreationFilelUpload;
    }

    public MultipartFile getRecordCreationFilelUpload() {
        return recordCreationFilelUpload;
    }

    public void setRecordCreationNoOfRows(Long recordCreationNoOfRows) {
        this.recordCreationNoOfRows = recordCreationNoOfRows;
    }

    public Long getRecordCreationNoOfRows() {
        return recordCreationNoOfRows;
    }

    public void setBulkrecordCreationAction(String bulkrecordCreationAction) {
        this.bulkrecordCreationAction = bulkrecordCreationAction;
    }

    public String getBulkrecordCreationAction() {
        return bulkrecordCreationAction;
    }

    public void setValidateAction(String validateAction) {
        this.validateAction = validateAction;
    }

    public String getValidateAction() {
        return validateAction;
    }

    public void setValidateFilelUpload(MultipartFile validateFilelUpload) {
        this.validateFilelUpload = validateFilelUpload;
    }

    public MultipartFile getValidateFilelUpload() {
        return validateFilelUpload;
    }

    public void setValidateNoOfRows(Long validateNoOfRows) {
        this.validateNoOfRows = validateNoOfRows;
    }

    public Long getValidateNoOfRows() {
        return validateNoOfRows;
    }

    public void setBulkRegvalidateAction(String bulkRegvalidateAction) {
        this.bulkRegvalidateAction = bulkRegvalidateAction;
    }

    public String getBulkRegvalidateAction() {
        return bulkRegvalidateAction;
    }

    public void setStatusAction(String statusAction) {
        this.statusAction = statusAction;
    }

    public String getStatusAction() {
        return statusAction;
    }

    public void setBulkStatusAction(String bulkStatusAction) {
        this.bulkStatusAction = bulkStatusAction;
    }

    public String getBulkStatusAction() {
        return bulkStatusAction;
    }

    public void setStatusFilelUpload(MultipartFile statusFilelUpload) {
        this.statusFilelUpload = statusFilelUpload;
    }

    public MultipartFile getStatusFilelUpload() {
        return statusFilelUpload;
    }

   

    public void setIhiList(String[] ihiList) {
        this.ihiList = ihiList;
    }

    public String[] getIhiList() {
        return ihiList;
    }

    public void setValidateDataExtract(String validateDataExtract) {
        this.validateDataExtract = validateDataExtract;
    }

    public String getValidateDataExtract() {
        return validateDataExtract;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setReconReportType(String reconReportType) {
        this.reconReportType = reconReportType;
    }

    public String getReconReportType() {
        return reconReportType;
    }

    public void setReconRegistrationState(String reconRegistrationState) {
        this.reconRegistrationState = reconRegistrationState;
    }

    public String getReconRegistrationState() {
        return reconRegistrationState;
    }

    public void setReconRegistrationAction(String reconRegistrationAction) {
        this.reconRegistrationAction = reconRegistrationAction;
    }

    public String getReconRegistrationAction() {
        return reconRegistrationAction;
    }

    public void setReconRegistrationError(String reconRegistrationError) {
        this.reconRegistrationError = reconRegistrationError;
    }

    public String getReconRegistrationError() {
        return reconRegistrationError;
    }

    public void setValidateAndRecordCreation(String validateAndRecordCreation) {
        this.validateAndRecordCreation = validateAndRecordCreation;
    }

    public String getValidateAndRecordCreation() {
        return validateAndRecordCreation;
    }

    public void setValidateAndCreateRecordAction(String validateAndCreateRecordAction) {
        this.validateAndCreateRecordAction = validateAndCreateRecordAction;
    }

    public String getValidateAndCreateRecordAction() {
        return validateAndCreateRecordAction;
    }

    public void setValidateAndCreateNoOfRows(Long validateAndCreateNoOfRows) {
        this.validateAndCreateNoOfRows = validateAndCreateNoOfRows;
    }

    public Long getValidateAndCreateNoOfRows() {
        return validateAndCreateNoOfRows;
    }

    public void setValidateAndRecordCreationFile(MultipartFile validateAndRecordCreationFile) {
        this.validateAndRecordCreationFile = validateAndRecordCreationFile;
    }

    public MultipartFile getValidateAndRecordCreationFile() {
        return validateAndRecordCreationFile;
    }

    public void setBulkGenerationStatusReport(List<BulkRegistrationStatusBO> bulkGenerationStatusReport) {
        this.bulkGenerationStatusReport = bulkGenerationStatusReport;
    }

    public List<BulkRegistrationStatusBO> getBulkGenerationStatusReport() {
        return bulkGenerationStatusReport;
    }

    public void setValidateExtractDownloadStatus(int validateExtractDownloadStatus) {
        this.validateExtractDownloadStatus = validateExtractDownloadStatus;
    }

    public int getValidateExtractDownloadStatus() {
        return validateExtractDownloadStatus;
    }

    public void setValidateExtractDownloadDescription(String validateExtractDownloadDescription) {
        this.validateExtractDownloadDescription = validateExtractDownloadDescription;
    }

    public String getValidateExtractDownloadDescription() {
        return validateExtractDownloadDescription;
    }

    public void setValidateExtractFileTransferStatus(int validateExtractFileTransferStatus) {
        this.validateExtractFileTransferStatus = validateExtractFileTransferStatus;
    }

    public int getValidateExtractFileTransferStatus() {
        return validateExtractFileTransferStatus;
    }

    public void setValidateExtractFileTransferSDescription(String validateExtractFileTransferSDescription) {
        this.validateExtractFileTransferSDescription = validateExtractFileTransferSDescription;
    }

    public String getValidateExtractFileTransferSDescription() {
        return validateExtractFileTransferSDescription;
    }

    public void setReconsileDataAction(String reconsileDataAction) {
        this.reconsileDataAction = reconsileDataAction;
    }

    public String getReconsileDataAction() {
        return reconsileDataAction;
    }

    public void setInputDHSFileName(String inputDHSFileName) {
        this.inputDHSFileName = inputDHSFileName;
    }

    public String getInputDHSFileName() {
        return inputDHSFileName;
    }

    public void setStatusTabFileDownloadStatus(int statusTabFileDownloadStatus) {
        this.statusTabFileDownloadStatus = statusTabFileDownloadStatus;
    }

    public int getStatusTabFileDownloadStatus() {
        return statusTabFileDownloadStatus;
    }

    public void setStatusTabFileDownloadDescription(String statusTabFileDownloadDescription) {
        this.statusTabFileDownloadDescription = statusTabFileDownloadDescription;
    }

    public String getStatusTabFileDownloadDescription() {
        return statusTabFileDownloadDescription;
    }

    public void setCheckSumValueFromUI(String checkSumValueFromUI) {
        this.checkSumValueFromUI = checkSumValueFromUI;
    }

    public String getCheckSumValueFromUI() {
        return checkSumValueFromUI;
    }

    public void setValidateAndDataExtractionAction(String validateAndDataExtractionAction) {
        this.validateAndDataExtractionAction = validateAndDataExtractionAction;
    }

    public String getValidateAndDataExtractionAction() {
        return validateAndDataExtractionAction;
    }
public void setReconcileDataReportBOLst(List<ReconcileDataReportBO> reconcileDataReportBOLst) {
        this.reconcileDataReportBOLst = reconcileDataReportBOLst;
    }

    public List<ReconcileDataReportBO> getReconcileDataReportBOLst() {
        return reconcileDataReportBOLst;
    }

    public void setReconcileDataReportSummaryBOLst(List<ReconcileDataReportBO> reconcileDataReportSummaryBOLst) {
        this.reconcileDataReportSummaryBOLst = reconcileDataReportSummaryBOLst;
    }

    public List<ReconcileDataReportBO> getReconcileDataReportSummaryBOLst() {
        return reconcileDataReportSummaryBOLst;
    }

    public void setReconcileDataReportDetailedBOLst(List<ReconcileDataReportBO> reconcileDataReportDetailedBOLst) {
        this.reconcileDataReportDetailedBOLst = reconcileDataReportDetailedBOLst;
    }

    public List<ReconcileDataReportBO> getReconcileDataReportDetailedBOLst() {
        return reconcileDataReportDetailedBOLst;
    }
}
