package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class CommonValidationDAO {
    private static Logger LOG = Logger.getLogger(CommonValidationDAO.class);

    @Value("${CommonValidation.VALIDATE_DEMOGRAPHICS}")
    private String validate_Demographics;
    
    @Autowired
    @Qualifier("pnaNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public boolean validateIHIDemographics(String ihi) throws RecoveryDAOException {
        LOG.debug("Inside CommonValidationDAO : validateIHIDemographics Method");
        Map namedParameters = new HashMap();
        boolean flag = false;
        try {
            namedParameters.put("ihi", ihi);
            LOG.debug("Query used:" + validate_Demographics);
            int count = namedParameterJdbcTemplate.queryForInt(validate_Demographics, namedParameters);
            if (count > 0) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured inside CommonValidationDAO..", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("leaving CommonValidationDAO : validateIHIDemographics Method...");
        return flag;
    }
}
