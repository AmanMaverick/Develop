package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.form.DisableEnableEntitiesForm;
import au.gov.doha.pcehr.recovery.service.DisableEnableEntitieServices;
import au.gov.doha.pcehr.recovery.validation.DisableEnableEntitiesValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * To do controller operations for Disable Re-Enable Entities functionality
 * @author Vikash Kumar Singh, Operations,  PCEHR
 * @since   23rd April 2015
 */
@Controller
@RequestMapping("/DisableEnableEntities**")
public class DisableEnableEntitiesController {
   
    private static final String MODEL_ATTRIBUTE = "disableEnableEntities";
    private static final String DISABLE_ENABLE_ENTITY_PAGE = "NIO/DisableReEnableEntities";
    private static final String DISABLE_ENABLE_ENTITY_CTRL = "/DisableEnableEntitiesCtrl";
    private static Logger LOG = Logger.getLogger(DisableEnableEntitiesController.class);
    
    @Autowired
    private DisableEnableEntitiesValidator validator;
    
    @Autowired
    private DisableEnableEntitieServices disableEnableEntitiesServices;

    @InitBinder(MODEL_ATTRIBUTE)
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
    
    /**
     * For navigate to Disable Re-Enable Entities Landing page
     * @param disableEnableEntities
     * @return DISABLE_ENABLE_ENTITY_PAGE
     */
    @AuditBefore(AuditMessageConstants.DISABLE_ENABLE_ENTITY_LANDING_PAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = DISABLE_ENABLE_ENTITY_CTRL)
    public String showDisableEnableEntitiesLandingPage(@ModelAttribute(MODEL_ATTRIBUTE)DisableEnableEntitiesForm disableEnableEntities) {
        LOG.debug("Inside ARTExtraction Search page");
        return DISABLE_ENABLE_ENTITY_PAGE;
    }
    
    /**
     * 
     * @param disableEnableEntities
     * @param result
     * @param map
     * @return DISABLE_ENABLE_ENTITY_PAGE
     * @throws Exception
     */
    @AuditBefore(AuditMessageConstants.DISABLE_ENABLE_ENTITY_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, params = "submitDisableReEnableEntity=Submit")
    public String getDisableReEnableEntitiesOperationPerformed(@Valid
                                                               @ModelAttribute(MODEL_ATTRIBUTE)DisableEnableEntitiesForm disableEnableEntities, 
                                                               BindingResult result,  
                                                               ModelMap map) throws Exception {
        LOG.debug("Inside DisableEnableEntitiesController ...... ");
        if (result.hasErrors()) {
            LOG.info("...Validation failed..." + result.hasErrors() + result.toString());
            return DISABLE_ENABLE_ENTITY_PAGE;
        }
        
        disableEnableEntities = disableEnableEntitiesServices.performOperation(disableEnableEntities);
        return DISABLE_ENABLE_ENTITY_PAGE;
    }
}
