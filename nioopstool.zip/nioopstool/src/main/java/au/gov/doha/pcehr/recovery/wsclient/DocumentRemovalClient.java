package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.bo.DocumentRemovalWSClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.net.electronichealth.ns.pcehr.svc.intremovedocument._1.RemoveDocumentPortType;
import au.net.electronichealth.ns.pcehr.svc.intremovedocument._1.RemoveDocumentService;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.removedocument._1.RemoveDocument;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.removedocument._1.RemoveDocumentResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocumentRemovalClient {
    @Autowired
    TestHostnameVerifier testHostnameVerifier;

    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    @Autowired
    SOAPMessageUtil soapMessageUtil;
    
    @Autowired
    Decrypter decrypter;
    
    private static Logger LOG = Logger.getLogger(DocumentRemovalClient.class);
   


   
    private String soapMessage;

    public void setSoapMessage(String soapMessage) {
        this.soapMessage = soapMessage;
    }

    public String getSoapMessage() {
        return soapMessage;
    }
    //can retrun consolidated string
    public final ResponseStatusType remove(DocumentRemovalWSClientBO documentRemovalWSClientBO) throws WebServiceClientException {
        LOG.debug("entering remove in DocumentRemovalClient ");
        
        StringBuffer response = new StringBuffer();
        ResponseStatusType responseStatusType = null;
        RemoveDocumentService removeDocumentService = new RemoveDocumentService();
        removeDocumentService.setHandlerResolver(wSClientHandlerResolver);
        //RemoveDocumentPortType removeDocumentPortType = removeDocumentService.getRemoveDocumentSOAP12Port();
        RemoveDocumentPortType removeDocumentPortType =
            removeDocumentService.getRemoveDocumentSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true, true));


        //soap message
        // SOAPMessageContext sOAPMessageContext

        Map<String, Object> ctx = ((BindingProvider) removeDocumentPortType).getRequestContext();
        ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, (EndPointsConstants.REMOVE_DOC_ENDPOINT_DEVF));
        ctx.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
        ctx.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
        ctx.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_DEVF_PASSWORD));
        

        LOG.debug("wsdl::" + EndPointsConstants.REMOVE_DOC_ENDPOINT_DEVF);
        RemoveDocument removeDocument = new RemoveDocument();
        //docid
        removeDocument.setDocumentID(documentRemovalWSClientBO.getDocumentId());
        // removeDocument.setReasonForRemoval("ElectToRemove");
        removeDocument.setReasonForRemoval(documentRemovalWSClientBO.getResonForRemoval());
        // LOG.debug("doc id"+docId.get(i));


        //IHI
        IntPCEHRHeader intPCEHRHeader = setHeader(documentRemovalWSClientBO.getIhi());

        Holder<RemoveDocumentResponse> holder = new Holder<RemoveDocumentResponse>();

        RemoveDocumentResponse removeDocumentResponse = new RemoveDocumentResponse();

        removeDocumentResponse.setResponseStatus(responseStatusType);
        Map<String, Object> messageCtx = null;
        try {
            removeDocumentPortType.removeDocument(removeDocument, holder, intPCEHRHeader);


            removeDocumentResponse = holder.value;
            responseStatusType = removeDocumentResponse.getResponseStatus();
            messageCtx = ((BindingProvider) removeDocumentPortType).getResponseContext();
            //LOG.debug("message conetxt:::"+messageCtx);
            getSoapReqRes(messageCtx);
          
        } catch (au.net.electronichealth.ns.pcehr.svc.intremovedocument._1.StandardErrorMsg standError) {
            LOG.fatal("here....exception" + standError);
            LOG.fatal("here....exception" + standError.getFaultInfo().getMessage());
            messageCtx = ((BindingProvider) removeDocumentPortType).getResponseContext();
            getSoapReqRes(messageCtx);
           
           
            response.append("\n");

            response.append("\nError Message :" + standError.getFaultInfo().getMessage());

            response.append("\n");
            throw new WebServiceClientException(response.toString(), standError);

        } catch (Exception e) {
            LOG.debug("exception::..." + e);

        }
        LOG.debug("response status" + responseStatusType.getDescription());
        LOG.debug("Leaving remove in DocumentRemovalClient ");
        return responseStatusType;
    }

    /**
     *
     * @param ihi
     * @return
     */
    public IntPCEHRHeader setHeader(String ihi) {
        LOG.debug("Entering setHeader ");
        IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
        IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
        clientSystem.setSystemID("Other001");
        clientSystem.setSystemType("Other");
        intPCEHRHeader.setIhiNumber(ihi);
        IntPCEHRHeader.ProductType producType = new IntPCEHRHeader.ProductType();
        producType.setPlatform("Ops Tool");
        producType.setProductName("Ops Tool");
        producType.setProductVersion("Ops Tool");
        producType.setVendor("Ops Tool");
        IntPCEHRHeader.User user = new IntPCEHRHeader.User();
        user.setID("00000000");
        user.setIDType("LocalSystemIdentifier");
        user.setRole("PCEHR_SYSTEM_OPERATOR");

        user.setUseRoleForAudit(false);
        user.setUserName("NIO System Operator Tool");
        intPCEHRHeader.setOverrideLogLevel(false);
        intPCEHRHeader.setClientSystem(clientSystem);
        intPCEHRHeader.setUser(user);
        intPCEHRHeader.setProductType(producType);
        LOG.debug("Leaving setHeader ");
        return intPCEHRHeader;
    }

    /**

     *
     * @return
     */

    private void getSoapReqRes(Map<String, Object> messageCtx) {


        this.soapMessage = soapMessageUtil.getSoapMessages(messageCtx);
    }
}
