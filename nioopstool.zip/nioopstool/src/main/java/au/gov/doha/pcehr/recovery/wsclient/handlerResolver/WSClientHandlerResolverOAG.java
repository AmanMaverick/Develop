package au.gov.doha.pcehr.recovery.wsclient.handlerResolver;

import au.gov.doha.pcehr.recovery.wsclient.soaphandler.WSClientHandlerUtilOAG;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class WSClientHandlerResolverOAG implements HandlerResolver{


    @Autowired
    WSClientHandlerUtilOAG wsClientHandlerUtiloag;
    
    private static Logger LOG = Logger.getLogger(WSClientHandlerResolverOAG.class);
    
 

    @Override
    public List<Handler> getHandlerChain(PortInfo portInfo) {
        
  List<Handler> handlerChain = new ArrayList<Handler>();
  
        handlerChain.add(wsClientHandlerUtiloag);
  
  // TODO Implement this method
        return handlerChain;
    }
}
