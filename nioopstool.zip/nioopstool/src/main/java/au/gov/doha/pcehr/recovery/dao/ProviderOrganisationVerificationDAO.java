package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ProviderOrganisationVerificationForm;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class ProviderOrganisationVerificationDAO {

    @Autowired
    @Qualifier("oimJDBCTemplate")
    private JdbcTemplate oimJDBCTemplate;

    @Value("${PROVIDER_ORG_VER_DAO.GET_LIST}")
    private String PROVIDER_ORG_OIM_QUERY;

    @Value("${PROVIDER_ORG_VER_DAO.GET_OID_LIST}")
    private String PROVIDER_ORG_OID_QUERY;


    private static Logger LOG = Logger.getLogger(ProviderOrganisationVerificationDAO.class);

    public ProviderOrganisationVerificationForm fetchProviderOrganisationVerificationList(ProviderOrganisationVerificationForm providerOrganisationVerificationForm) throws RecoveryDAOException {

        LOG.debug("Entered ProviderOrganisationVerificationList Method in DAO.... ");

        int oim_provcount = 0, oid_useridcount = 0,countoid=0,countoim =0;
        try {
            oim_provcount = oimJDBCTemplate.queryForObject(PROVIDER_ORG_OIM_QUERY, new Object[] {
                                                           providerOrganisationVerificationForm.getHpio() },
                                                           Integer.class);
            providerOrganisationVerificationForm.setOim_provcount(oim_provcount);
            LOG.info(" oim_provcount =" + oim_provcount);
            

            if (oim_provcount == 0) {
                countoim++;
                providerOrganisationVerificationForm.setCountoim(countoim);
            }
            else{
                try {
                    oid_useridcount = oimJDBCTemplate.queryForObject(PROVIDER_ORG_OID_QUERY, new Object[] {
                                                                     providerOrganisationVerificationForm.getHpio() },
                                                                     Integer.class);
                    providerOrganisationVerificationForm.setOid_useridcount(oid_useridcount);
                    LOG.info("oid_useridcount =  " + oid_useridcount);
                    if (oid_useridcount == 0) {
                    countoid++;
                    providerOrganisationVerificationForm.setCountoid(countoid);
                    }
                } catch (Exception e) {
                    LOG.fatal("Exception Occured Inside OID Query", e);
                    throw new RecoveryDAOException(e);
                }
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured Inside OIM Query", e);
            throw new RecoveryDAOException(e);
        }

        LOG.debug("Leaving DAO Class");
        return providerOrganisationVerificationForm;
    }
}
