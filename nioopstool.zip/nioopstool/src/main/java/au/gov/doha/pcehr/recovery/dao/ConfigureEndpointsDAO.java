package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.ConfigureEndpointsBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.Enumeration;
import java.util.Properties;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;

/**
 * This DAO layer fetch data from properties file Configure Endpoints
 * @Author Sumanta
 * @since 10 April 2015
 * @version Change-x
 */

@Component
public class ConfigureEndpointsDAO {
    public ConfigureEndpointsDAO() {
        super();
    }
    private static Logger LOG = Logger.getLogger(ConfigureEndpointsDAO.class);
    private static final String SUCCESS_RESPONSE = "Endpoints has been updated successfully";
    private static final String FAIL_RESPONSE = "Endpoints updation failed";

    public ConfigureEndpointsBO update(ConfigureEndpointsBO bo) {
        LOG.debug("entering update....");
        try {
            Properties myProp = new Properties();
            String os = System.getProperty("os.name");
            String configFileLocation1 = null;
            if (null != os && os.contains("Linux")) {
                configFileLocation1 = System.getProperty("user.dir") + "/Configuration/EndPoints.properties";
                LOG.debug("configFileLocation1" + configFileLocation1);
            } else {
                configFileLocation1 = System.getProperty("user.dir") + "\\Configuration\\EndPoints.properties";
                LOG.debug("configFileLocation1" + configFileLocation1);
            }
            myProp.load(new FileInputStream(configFileLocation1));
            Properties myNewProp = updateEndpoints(bo, myProp);
            String status = saveProperties(myNewProp, configFileLocation1);
            bo.setConfigureEndpointsResponse(status);
        } catch (Exception e) {
            LOG.fatal("Exception ....", e);
        }

        return bo;
    }

    /**
     *
     * @param bo
     * @param myProp
     * @return
     */

    private Properties updateEndpoints(ConfigureEndpointsBO bo, Properties myProp) {
        LOG.debug("entering updateEndpoints....");
        Properties newProps = new Properties();
        Enumeration enumProps = myProp.propertyNames();
        String key = "";
        while (enumProps.hasMoreElements()) {
            key = (String) enumProps.nextElement();
            if (key.equals("PersistAtomicData_EndPoint")) {
                newProps.setProperty(key, bo.getPersistAtomicData());
                EndPointsConstants.PERSITATOMIC_ENDPOINT = bo.getPersistAtomicData();
            } else if (key.equals("AuditInsert_EndPoint")) {
                newProps.setProperty(key, bo.getAuditInsert());
                EndPointsConstants.OSB_ENDPOINT = bo.getAuditInsert();
            } else if (key.equals("DeprecateAtomicData_EndPoint")) {
                newProps.setProperty(key, bo.getDeprecateAtomicData());
                EndPointsConstants.DEPRECATE_ATOMIC_DATA_ENDPOINT = bo.getDeprecateAtomicData();
            } else if (key.equals("PNA_EndPoint")) {
                newProps.setProperty(key, bo.getPnaEndPoint());
                EndPointsConstants.PNA_ENDPOINT = bo.getPnaEndPoint();
            } else if (key.equals("PNA_CreateAuthRep_EndPoint")) {
                newProps.setProperty(key, bo.getPnaCreateAuthRep());
                EndPointsConstants.PNA_CA_ENDPOINT = bo.getPnaCreateAuthRep();
            }else if (key.equals("PNA_CA_ENDPOINT")) {
                newProps.setProperty(key, bo.getPnaCreateAuthRep());
                EndPointsConstants.PNA_CA_ENDPOINT = bo.getPnaCreateAuthRep();
            }
            else if (key.equals("PNA_UpdateAuth_EndPoint")) {
                newProps.setProperty(key, bo.getPnaUpdateAuth());
                EndPointsConstants.PNA_UPDATE_ENDPOINT = bo.getPnaUpdateAuth();
            } else if (key.equals("PNA_UpdateNominated_EndPoint")) {
                newProps.setProperty(key, bo.getPnaUpdateNominated());
                EndPointsConstants.PNA_UPDATE_ENDPOINT = bo.getPnaUpdateNominated();
            } else if (key.equals("PNA_CleanIndividualProfile_EndPoint")) {
                newProps.setProperty(key, bo.getPnaCleanIndividualProfile());
                EndPointsConstants.PNA_CIP_ENDPOINT = bo.getPnaCleanIndividualProfile();
            } else if (key.equals("PNA_ARRestrict")) {
                newProps.setProperty(key, bo.getPnaARRestrict());
                EndPointsConstants.PNA_AR_RESTRICT_ENDPOINT = bo.getPnaARRestrict();
            } else if (key.equals("PNA_AuthoriseRestrict_EndPoint")) {
                newProps.setProperty(key, bo.getPnaAuthoriseRestrict());
                EndPointsConstants.PNA_OES_AC_ENDPOINT = bo.getPnaAuthoriseRestrict();
            } else if (key.equals("PNA_OIMDisable")) {
                newProps.setProperty(key, bo.getPnaOIMDisable());
                EndPointsConstants.PNA_OIM_DISABLE_ENDPOINT = bo.getPnaOIMDisable();
            } else if (key.equals("UpdateDocumentStatus_EndPoint")) {
                newProps.setProperty(key, bo.getUpdateDocumentStatus());
                EndPointsConstants.UPDATE_DOC_ENDPOINT = bo.getUpdateDocumentStatus();
            } else if (key.equals("GetDocumentList_EndPoint")) {
                newProps.setProperty(key, bo.getGetDocumentList());
                EndPointsConstants.GET_DOC_LIST_ENDPOINT = bo.getGetDocumentList();
            } else if (key.equals("UnremoveDocument_EndPoint")) {
                newProps.setProperty(key, bo.getUnremoveDocument());
                EndPointsConstants.UNREMOVE_DOC_ENDPOINT = bo.getUnremoveDocument();
            } else if (key.equals("RemoveDocument_EndPoint")) {
                newProps.setProperty(key, bo.getRemoveDocument());
                EndPointsConstants.REMOVE_DOC_ENDPOINT_DEVF = bo.getRemoveDocument();
            } else if (key.equals("RemoveDocument_EndPoint_Devf")) {
                newProps.setProperty(key, bo.getRemoveDocument());
                EndPointsConstants.REMOVE_DOC_ENDPOINT_DEVF = bo.getRemoveDocument();
            } else if (key.equals("SynchroniseIHI_EndPoint")) {
                newProps.setProperty(key, bo.getSynchroniseIHI());
                EndPointsConstants.SYNCHRONISE_IHI_ENDPOINT = bo.getSynchroniseIHI();
                EndPointsConstants.SYNC_IHI_ENDPOINT = bo.getSynchroniseIHI(); 

            } else if (key.equals("Get_DocumentOAG_Endpoint")) {
                newProps.setProperty(key, bo.getGetDocumentOAG());
                EndPointsConstants.OAG_GETDOC = bo.getGetDocumentOAG();
            } else if (key.equals("Get_DocumentHTB_Endpoint")) {
                newProps.setProperty(key, bo.getGetDocumentHTB());
                EndPointsConstants.HTB_GETDOC = bo.getGetDocumentHTB();
            } else if (key.equals("HTB_Username")) {
                newProps.setProperty(key, bo.getHtbUsername());
                EndPointsConstants.HTB_USERNAME = bo.getHtbUsername();
            } else if (key.equals("HTB_Password")) {
                newProps.setProperty(key, bo.getHtbPassword());
                EndPointsConstants.HTB_PASSWORD = bo.getHtbPassword();
            } else if (key.equals("PNA_OIMDisable_Username")) {
                newProps.setProperty(key, bo.getPnaOIMDisableUsername());
                EndPointsConstants.PNA_OIM_DISABLE_USERNAME = bo.getPnaOIMDisableUsername();
            } else if (key.equals("PNA_OIMDisable_Password")) {
                newProps.setProperty(key, bo.getPnaOIMDisablePassword());
                EndPointsConstants.PNA_OIM_DISABLE_PASSWORD = bo.getPnaOIMDisablePassword();
            } else if (key.equals("PNA_Username")) {
                newProps.setProperty(key, bo.getPnaUsername());
                EndPointsConstants.PNA_USERNAME = bo.getPnaUsername();
            } else if (key.equals("PNA_Password")) {
                newProps.setProperty(key, bo.getPnaPassword());
                EndPointsConstants.PNA_PASSWORD = bo.getPnaPassword();
            } else if (key.equals("OSB_Username")) {
                newProps.setProperty(key, bo.getOsbUsername());
                EndPointsConstants.OSB_USERNAME = bo.getOsbUsername();
            } else if (key.equals("OSB_Password")) {
                newProps.setProperty(key, bo.getOsbPassword());
                EndPointsConstants.OSB_PASSWORD = bo.getOsbPassword();
            } else if (key.equals("OSB_Devf_Password")) {
                newProps.setProperty(key, bo.getOsbPassword());
                EndPointsConstants.OSB_DEVF_PASSWORD = bo.getOsbPassword();
            } else if (key.equals("PNA_AUTH_USERNAME")) {
                newProps.setProperty(key, bo.getPnaAuthUsername());
                EndPointsConstants.PNA_AUTH_USERNAME = bo.getPnaAuthUsername();
            } else if (key.equals("PNA_AUTH_PWD")) {
                newProps.setProperty(key, bo.getPnaAuthPassword());
                EndPointsConstants.PNA_AUTH_PWD = bo.getPnaAuthPassword();
            } else if (key.equals("OAG_Username")) {
                newProps.setProperty(key, bo.getOagUsername());
                EndPointsConstants.OAG_USERNAME = bo.getOagUsername();
            } else if (key.equals("OAG_Password")) {
                newProps.setProperty(key, bo.getOagPassword());
                EndPointsConstants.OAG_PASSWORD = bo.getOagPassword();
            } else if (key.equals("Initial_Context_Factory")) {
                newProps.setProperty(key, bo.getInitialContextFactory());
                EndPointsConstants.INITIAL_CONTEXT_FACTORY = bo.getInitialContextFactory();
            } else if (key.equals("WebLogic_Provider_Url")) {
                newProps.setProperty(key, bo.getWebLogicProviderUrl());
                EndPointsConstants.WEBLOGIC_PROVIDER_URL = bo.getWebLogicProviderUrl();
            } else if (key.equals("WebLogic_Jndi_Name_OSB")) {
                newProps.setProperty(key, bo.getWebLogicJndiNameOSB());
                EndPointsConstants.WEBLOGIC_JNDI_NAME_OSB = bo.getWebLogicJndiNameOSB();
            } else if (key.equals("WebLogic_Jndi_Name_HTB")) {
                newProps.setProperty(key, bo.getWebLogicJndiNameHTB());
                EndPointsConstants.WEBLOGIC_JNDI_NAME_HTB = bo.getWebLogicJndiNameHTB();
            } else if (key.equals("WebLogic_Jndi_Name_PNA")) {
                newProps.setProperty(key, bo.getWebLogicJndiNamePNA());
                EndPointsConstants.WEBLOGIC_JNDI_NAME_PNA = bo.getWebLogicJndiNamePNA();
            } else if (key.equals("WebLogic_Jndi_Name_OIM")) {
                newProps.setProperty(key, bo.getWebLogicJndiNameOIM());
                EndPointsConstants.WEBLOGIC_JNDI_NAME_OIM = bo.getWebLogicJndiNameOIM();
            } else if (key.equals("WebLogic_Jndi_Name_RLS")) {
                newProps.setProperty(key, bo.getWebLogicJndiNameRLS());
                EndPointsConstants.WEBLOGIC_JNDI_NAME_RLS = bo.getWebLogicJndiNameRLS();
            } else if (key.equals("HostName")) {
                newProps.setProperty(key, bo.getHostName());
                EndPointsConstants.HOST_NAME = bo.getHostName();
            }
            //TIP
            else if (key.equals("OSB_Register_PCEHR")) {
                newProps.setProperty(key, bo.getOsbRegisterPcehr());
                EndPointsConstants.OSB_REGISTER_PCEHR = bo.getOsbRegisterPcehr();
            } else if (key.equals("SearchIHI_EndPoint")) {
                newProps.setProperty(key, bo.getSearchIHI());
                EndPointsConstants.SEARCH_IHI = bo.getSearchIHI();
            } else if (key.equals("Product_Version")) {
                newProps.setProperty(key, bo.getProductVersion());
                EndPointsConstants.PRODUCT_VERSION = bo.getProductVersion();
            }
            
            else {
                newProps.setProperty(key, myProp.getProperty(key));
            }
        }
        LOG.debug("Leaving updateEndpoints....");

        return newProps;
    }

    /**
     *
     * @param p
     * @param propertyFileLocation
     * @return
     */

    private String saveProperties(final Properties p, final String propertyFileLocation) {
        LOG.debug("entering saveProperties....");
        OutputStream outPropFile;
        try {
            File file = new File(propertyFileLocation);
            outPropFile = new FileOutputStream(file);
            p.store(outPropFile, "");
            outPropFile.close();
            LOG.debug("Leaving saveProperties....");
            return SUCCESS_RESPONSE;
        } catch (IOException ioe) {
            LOG.fatal("Exception ...", ioe);
            LOG.debug("Leaving saveProperties....");
            return FAIL_RESPONSE;
        }

    }

}

