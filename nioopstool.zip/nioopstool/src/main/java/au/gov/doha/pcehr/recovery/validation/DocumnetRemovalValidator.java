package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;

import org.apache.log4j.Logger;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


/**
 * @author Sumantha kumar Shaha
 * Validates Remove & Re-instate Document data.
 */
public class DocumnetRemovalValidator implements Validator{
    private static Logger LOG = Logger.getLogger(DocumnetRemovalValidator.class);
    private static final String ACTION_REMOVE_DOCUMENT="Remove Document";
    private static final String ACTION_UN_REMOVE_DOCUMENT="Reinstate Document";

    @Override
    public boolean supports(Class<?> class1) {
        return DocumentRemovalBO.class.equals(class1);
    }

    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Validating the DocumentRemovalBO");
        DocumentRemovalBO form = (DocumentRemovalBO) object;
        if(form!=null){
            LOG.debug("Validating the DocumentRemovalBO"+form.getAction());
            if(form.getAction()==null || form.getAction().length()<0){
                ValidationUtils.rejectIfEmpty(errors, "action", "DocumentRemovalAttribute");
            }else if(ACTION_REMOVE_DOCUMENT.equals(form.getAction())){
                errors = validateRemove(form,errors);
            }else if(ACTION_UN_REMOVE_DOCUMENT.equals(form.getAction())){
                errors = validateUnRemove(form,errors);
            }
        }
        
        
    }
    
    /**
     * Validates data wrt document removal.
     * @param documentRemovalBO
     * @param errors
     * @return
     */
    private Errors validateRemove(DocumentRemovalBO documentRemovalBO, Errors errors){
        ValidationUtils.rejectIfEmpty(errors, "ihi", "DocumentRemovalAttribute");
        ValidationUtils.rejectIfEmpty(errors, "resonForRemoval", "DocumentRemovalAttribute");
        ValidationUtils.rejectIfEmpty(errors, "documentId", "DocumentRemovalAttribute");
        LOG.debug("IHI length"+documentRemovalBO.getIhi().length());
        if((documentRemovalBO.getIhi()!=null) && !documentRemovalBO.getIhi().matches("[0-9]{16}")){
            LOG.debug("IHI......Match.....");
            errors.rejectValue( "ihi", "DocumentRemovalAttribute.ihiLength");
        }
        
        return errors;
    }
    
    /**
     * Validates data wrt document unremoval.
     * @param documentRemovalBO
     * @param errors
     * @return
     */
    private Errors validateUnRemove(DocumentRemovalBO documentRemovalBO, Errors errors){
        ValidationUtils.rejectIfEmpty(errors, "ihi", "DocumentRemovalAttribute");
        ValidationUtils.rejectIfEmpty(errors, "documentId", "DocumentRemovalAttribute");
            if((documentRemovalBO.getIhi()!=null) && !documentRemovalBO.getIhi().matches("[0-9]{16}")){
                LOG.debug("IHI......Match.....");
                errors.rejectValue( "ihi", "DocumentRemovalAttribute.ihiLength");
            }
        return errors;
    }
}
