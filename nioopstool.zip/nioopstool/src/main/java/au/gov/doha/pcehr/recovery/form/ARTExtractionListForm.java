package au.gov.doha.pcehr.recovery.form;


import au.gov.doha.pcehr.recovery.bo.IdentityBlobDocs;

import java.util.List;


/**
 *
 */
public class ARTExtractionListForm {
    
    private List<String> documentId;
    List<IdentityBlobDocs> docList;

    public void setDocumentId(List<String> documentId) {
        this.documentId = documentId;
    }

    public List<String> getDocumentId() {
        return documentId;
    }

    public void setDocList(List<IdentityBlobDocs> docList) {
        this.docList = docList;
    }

    public List<IdentityBlobDocs> getDocList() {
        return docList;
    }
}
