package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.form.ARTExtractionForm;
import au.gov.doha.pcehr.recovery.service.ARTExtractionService;
import au.gov.doha.pcehr.recovery.validation.ARTExtractionValidator;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;


/**
 * Controller to perform all ART Extractions related task
 * @Author Vikash Kumar Singh, Operations, PCEHR
 * @since 02nd Dec 2014
 * @version Change-x
 */
@Controller
@RequestMapping("/ARTExtraction**")
public class ARTExtractionController implements HandlerExceptionResolver {

    private static final String ART_EXTRACTION_HOME = "NIO/ART/ARTExtractionHome";
    private static final String ART_DISPLAY_DOCUMENT = "NIO/ART/ARTDisplaydocument";
    private static final String EXCEPTION_PAGE = "NIO/Exception";
    private static final String MODEL_ATTRIBUTE = "artExtraction";
    private static Logger LOG = Logger.getLogger(ARTExtractionController.class);

    @Autowired
    private ARTExtractionService artExtractionService;

    @Autowired
    @Qualifier("artExtractionValidator")
    private ARTExtractionValidator validator;

    @InitBinder("artExtraction")
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }

    /**
     * For navigate to ART Extraction Home page
     * @param artExtractionBO
     * @return
     */
    @AuditBefore(AuditMessageConstants.ART_LANDINGPAGE_MESAGGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/ARTExtractionSearch")
    public String showARTPage(@ModelAttribute(MODEL_ATTRIBUTE)
        ARTExtractionForm artExtractionBO) {
        LOG.debug("Inside ARTExtraction Search page");
        return ART_EXTRACTION_HOME;
    }

    /**
     * To perform search operation on ART Extraction Home page
     * @param artExtraction
     * @return
     */
    @AuditBefore(AuditMessageConstants.ART_SEARCH_MESAGGE)
    @RequestMapping(method = { RequestMethod.POST }, params = "SingleInputSearch=Search")
    public String getARTSearch(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        ARTExtractionForm artExtraction, BindingResult result, ModelMap map) throws Exception {
        if (result.hasErrors()) {
            LOG.info("...Validation failed..." + result.hasErrors() + result.toString());
            map.addAttribute("InValidField", true);
            return ART_EXTRACTION_HOME;
        }

        artExtraction = artExtractionService.getARTSearchDoc(artExtraction);

        if (artExtraction.getDocList().isEmpty()) {
            map.addAttribute("emptyDocList",
                             "Document is not available for the search criterion. Please try again with the valid input.");
        }

        return ART_DISPLAY_DOCUMENT;
    }

    /**
     * To perform download operation for single file
     * @param req
     * @param response
     * @throws IOException
     */
    @AuditBefore(AuditMessageConstants.ART_SINGLE_FILE_DOWNLOAD_MESAGGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/ARTExtractionDownloadDocument")
    public void viewDocument(HttpServletRequest req, HttpServletResponse response) throws Exception {

        LOG.debug("Rendering document");
        if (req.getParameter("docid") != null &&
            !req.getParameter("docid").trim().equals("")) { // single attachment download
            artExtractionService.getDocumentWithBlob(Long.parseLong(req.getParameter("docid")), response);
        } else { // display inline
            artExtractionService.getDocumentWithBlob(Long.parseLong(req.getParameter("docid")), response);

        }

        LOG.info("File Download Comleted");
    }

    /**
     * For Bulk file download
     * @param artExtraction
     *  @param response
     */
    @AuditBefore(AuditMessageConstants.ART_BULK_FILE_DOWNLOAD_MESAGGE)
    @RequestMapping(method = { RequestMethod.POST }, params = "extractDownload=Extract and Download")
    public void extractDownload(@ModelAttribute(MODEL_ATTRIBUTE)
        ARTExtractionForm artExtraction, HttpServletResponse response) throws Exception {
        LOG.debug("Inside ARTExtraction Download page :: " + artExtraction.getDocumentId().size());
        artExtractionService.getZippedDocument(artExtraction, response);

    }

    /**
     * This method will perform bulk search operation
     * @param artExtraction
     * @throws IOException      
     */
    @AuditBefore(AuditMessageConstants.ART_BULK_SEARCH_MESAGGE)
    @RequestMapping(method = { RequestMethod.POST }, params = "bulkInputSearch=Submit")
    public String extractBulkDownload(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        ARTExtractionForm artExtraction, BindingResult result, ModelMap map) throws Exception {
        if (result.hasErrors()) {
            LOG.info("...Validation failed..." + result.hasErrors() + result.toString());
            map.addAttribute("InValidFile", true);
            return ART_EXTRACTION_HOME;
        }

        artExtraction = artExtractionService.getBulkSearchDocumentList(artExtraction);

        if (artExtraction.getDocList().isEmpty()) {
            map.addAttribute("emptyDocList", "No Document found. Please try again with the valid data.");
        }
        return ART_DISPLAY_DOCUMENT;
    }

    /**
     * To handdle runtime exceptions and
     * handalling MaxUploadSizeExceededException specifically to prevent the upload limit to 100000 bytes
     * @param httpServletRequest
     * @param httpServletResponse
     * @param object
     * @param ex
     * @return
     */
    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest,
                                         HttpServletResponse httpServletResponse, Object object, Exception ex) {
        ModelAndView model = new ModelAndView(EXCEPTION_PAGE);
        if (ex instanceof MaxUploadSizeExceededException) {
            model.addObject("exception", "File size exceeded the limit of maximum size - 100000 Bytes");
        }
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex.getMessage());
        return model;
    }
}
