package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.ARrestrictionBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ARrestrictForm;
import au.gov.doha.pcehr.recovery.service.ARRestrictionsService;
import au.gov.doha.pcehr.recovery.validation.ARRestrictionsValidator;

import java.text.ParseException;

import javax.validation.Valid;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


/**
 * Controller to perform all Auth Rep Restrictions related task
 * @Author Vikash Kumar Singh, Operations, PCEHR
 * @since 28 Nov 2014
 * @version Change-x
 */
@Controller
public class ARRestrictionsController{
    
    private static Logger LOG = Logger.getLogger(ARRestrictionsController.class);
    private static final String EXCEPTION_PAGE = "NIO/Exception";
    private static final String AUTH_REP_RESTRICTION_PAGE = "NIO/ARRestrictions";
    
    
    @Autowired
    private ARRestrictionsService arRestrictionsService;
    @Autowired
    @Qualifier("aRRestrictionsValidator")
    private ARRestrictionsValidator aRRestrictionsValidator;

    @InitBinder("arRestrict")
    protected void initBinderMetricTypeConfig(WebDataBinder binder) {
        LOG.debug("Initialising the validator");
        binder.setValidator(aRRestrictionsValidator);
    }

/**
 * For navigate to Authorised Representative Restriction Page
 * @param arRestrict
 * @return
 */
    @AuditBefore(AuditMessageConstants.ARRESTRICT_LANDINGPAGE_MESAGGE)
    @RequestMapping(method = {RequestMethod.GET}, value="/ARRestrictionsCtrl" )
    public String arRestrictionsMenuHandler(@ModelAttribute("arRestrict")ARrestrictForm arRestrict) {
        return AUTH_REP_RESTRICTION_PAGE;
    }

/**
     * To perform Authorised Representative Restriction Operation
     * @param arRestrict
     * @param result
     * @param map
     * @return
     * @throws RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.ARRESTRICT_OPERATION_MESAGGE)
    @RequestMapping(method = {RequestMethod.POST}, value="/ARRestrictionsService" )
    public String ARRestrictionService(@Valid @ModelAttribute("arRestrict") ARrestrictForm arRestrict,  
                                          BindingResult result, ModelMap map) throws RecoveryServiceException,
                                                                                  ParseException,
                                                                                  DatatypeConfigurationException,
                                                                                  Exception {
        LOG.debug("Inside Constructor method");
        if (result.hasErrors()) {
            LOG.debug("Inside has errors");
            LOG.info("......"+result.hasErrors() + result.toString());
            return AUTH_REP_RESTRICTION_PAGE;
        }
        
        String operationType = arRestrict.getOperationType();
        if(operationType.equals("single")){
            LOG.debug("Executing Single AR Restriction.");
            ARrestrictionBO arRestrictionBO = new ARrestrictionBO();
            arRestrictionBO = arRestrictionsService.executeSingleARRestriction(arRestrict);
            map.addAttribute("arRestrictBO", arRestrictionBO);
            
        }else{
            String message = arRestrictionsService.executeBulkARRestriction(arRestrict);
            LOG.debug("Returning Message attribute = " + message);
            map.addAttribute("message", message);
        }        
        return AUTH_REP_RESTRICTION_PAGE;
    }

    /**
     * To handel exceptions
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleAllException(Exception ex) {
        LOG.info("Exception handler......");
        ModelAndView model = new ModelAndView(EXCEPTION_PAGE);
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex.getMessage());
        return model;
    }
}
