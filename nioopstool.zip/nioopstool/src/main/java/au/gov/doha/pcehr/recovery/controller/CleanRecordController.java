package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.CleanRecordBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.service.CleanRecordService;
import au.gov.doha.pcehr.recovery.validation.CleanRecordValidator;

import java.io.OutputStream;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.validation.Valid;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


/**
 * @author Sumanta Kumar Saha
 * @since 29 Jan 2015
 * version - x
 */
@Controller
public class CleanRecordController {

    private static final String CLEAN_RECORD_HOME = "/NIO/CleanRecord";
  
    private static Logger LOG = Logger.getLogger(CleanRecordController.class);
    @Autowired
    private CleanRecordService cleanRecordService;
    
    @Autowired
    @Qualifier("cleanRecordValidator")
    private CleanRecordValidator cleanRecordValidator;

    @InitBinder("CleanRecordAttribute")
    protected void initBinderMetricTypeConfig(WebDataBinder binder) {
        binder.setValidator(cleanRecordValidator);
    }
    
    @AuditBefore(AuditMessageConstants.CLEAN_RECORD_PAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/CleanRecordCntrl")
    public String showCleanRecordPage(@ModelAttribute("CleanRecordAttribute")
        CleanRecordBO cleanRecordBO,ModelMap map) throws RecoveryServiceException{
        LOG.debug("Inside showCleanRecordPage Search page");
        return CLEAN_RECORD_HOME;
    }

//new changes for migration
    /**
     *
     * @param cleanRecordBO
     * @param cleanRecordResults
     * @param session
     * @param map
     * @return
     * @throws RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.PERFORM_RESET_INDIVIDUAL_PROFILE)
    @RequestMapping(method={RequestMethod.POST}, value="/CleanRecordCntrl", params={"ResetIndividualProfile=Submit"})
    public String performResetIndividualProfile(@Valid @ModelAttribute("CleanRecordAttribute")
        CleanRecordBO cleanRecordBO, BindingResult cleanRecordResults, HttpSession session,
        ModelMap map) throws RecoveryServiceException{
        LOG.debug("Inside performResetIndividualProfile " );
        if(cleanRecordResults.hasErrors()){
            LOG.debug("error in validation " ); 
           return CLEAN_RECORD_HOME;
        }
        //cleanRecordBO.setOperationOnRecord(null);
        cleanRecordBO=cleanRecordService.processResetIndividualProfile(cleanRecordBO);
        
        LOG.debug("Leaving performResetIndividualProfile " );
        return CLEAN_RECORD_HOME;
    }
    /**
     *
     * @param cleanRecordBO
     * @param cleanRecordResults
     * @param session
     * @param map
     * @return
     * @throws RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.PERFORM_CLEAN_UP_PENDING_VERIFICATION)
    @RequestMapping(method={RequestMethod.POST}, value="/CleanRecordCntrl", params={"CleanupPendingVerification=Submit"})
    public String performCleanupPendingVerification(@Valid @ModelAttribute("CleanRecordAttribute")
        CleanRecordBO cleanRecordBO, BindingResult cleanRecordResults, HttpSession session,
        ModelMap map) throws RecoveryServiceException{
        LOG.debug("Inside performCleanupPendingVerification " );
        if(cleanRecordResults.hasErrors()){
            LOG.debug("error in validation" );
            return CLEAN_RECORD_HOME;
        }
        cleanRecordBO=cleanRecordService.processPendingVerification(cleanRecordBO);
        LOG.debug("Leaving performCleanupPendingVerification " );
        return CLEAN_RECORD_HOME;
    }
    /**
     *
     * @param cleanRecordBO
     * @param cleanRecordResults
     * @param session
     * @param map
     * @return
     * @throws RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.PERFORM_REMOVE_DOCUMENT)
    @RequestMapping(method={RequestMethod.POST}, value="/CleanRecordCntrl", params={"RemoveDocuments=Submit"})
    public String performRemoveDocuments(@Valid @ModelAttribute("CleanRecordAttribute")
        CleanRecordBO cleanRecordBO, BindingResult cleanRecordResults, HttpSession session,
        ModelMap map,HttpServletResponse response) throws RecoveryServiceException{
        
        LOG.debug("Inside performRemoveDocuments " );
        if(cleanRecordResults.hasErrors()){
            LOG.debug("error in validation " );    
            return CLEAN_RECORD_HOME;
        }
        cleanRecordBO=cleanRecordService.processRemoveDocuments(cleanRecordBO);
        if(cleanRecordBO.getRemoveDocIhiStatus().equalsIgnoreCase("Active")||
            (cleanRecordBO.getRemoveDocIhiRestirctedStatus().equalsIgnoreCase("yes")) ||
            (cleanRecordBO.getRemoveDocDocumentListSize().equalsIgnoreCase("noDoc"))) {
            LOG.debug("remove doc fails");
        }else{
            LOG.debug("remove doc success");
            response.setContentType("text/csv");
            response.setHeader("Content-disposition",
                               "attachment; filename=\"" + cleanRecordBO.getIhi() + "_removedoc.csv" +
                               "\"");
            try {
                OutputStream outputStream = response.getOutputStream();
                String outputResult = cleanRecordBO.getRemoveDocDeletaionCsvFile().toString();
                outputStream.write(outputResult.getBytes());
                outputStream.flush();
                outputStream.close();
                response.flushBuffer();
                return null;
            } catch (Exception e) {

                LOG.fatal("Exception... ", e);
            }
        }
        LOG.debug("Leaving performRemoveDocuments " );
        return CLEAN_RECORD_HOME;
    }


    
    /**
     *
     * @return
     * @throws Exception
     */
    @ModelAttribute("OperationOnRecord")
    public List<String> operationOnRecord() throws Exception {
        List<String> OperationOnRecord = new ArrayList<String>();
        OperationOnRecord.add("Reset the Individual Profile");
        OperationOnRecord.add("Clean-up Pending Verification Details");
         OperationOnRecord.add("Remove Documents associated with the Record");
        return OperationOnRecord;
    }
    /**
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(ServiceException ex) {
        LOG.info("doaexception handler......");
        ModelAndView model = new ModelAndView(CLEAN_RECORD_HOME);
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............."+ex.getMessage());
        return model;
    }
  
}
