package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.CleanRecordBO;
import au.gov.doha.pcehr.recovery.bo.DeleteDocumentWSClientBO;
import au.gov.doha.pcehr.recovery.bo.GetDocumentListClientBO;
import au.gov.doha.pcehr.recovery.bo.PNACleanIndividualProfileClientBO;
import au.gov.doha.pcehr.recovery.dao.CleanRecordDao;
import au.gov.doha.pcehr.recovery.wsclient.DeleteDocumentClient;
import au.gov.doha.pcehr.recovery.wsclient.GetDocumentListClient;
import au.gov.doha.pcehr.recovery.wsclient.PNACleanIndividualProfileClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service to perform all Clean Record related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 8 April 2015
 * @version Change-x
 */
@Service
public class CleanRecordService {
    private static Logger LOG = Logger.getLogger(CleanRecordService.class);
           

    private static final String SUCCESSFUL_DELETION_STATUS_MESSAGE = "Notification Records Successfully Deleted";
    private static final String UNSUCCESSFUL_DELETION_STATUS_MESSAGE = "No Notifications Records found for IHI";
    private static final String EXCEPTION_DELETION_STATUS_MESSAGE = "Notifications Records Deletion Failed";
   
    
    @Autowired
    CleanRecordDao cleanRecordDAO;
    
    @Autowired
    GetDocumentListClient getDocumentListClient;
    
    @Autowired
    DeleteDocumentClient deleteDocumentClient;
    
    @Autowired
    InsertAuditRecordService insertAuditRecordService;
    
    @Autowired
    PNACleanIndividualProfileClient pNACleanIndividualProfileClient;

//change for migration
    /**
     *
     * @param bo
     * @return
     */
    public CleanRecordBO processResetIndividualProfile(CleanRecordBO bo){
        LOG.info("Entering service method of processResetIndividualProfile");
        
         List cleanIndProfile=pNACleanIndividualProfileClient.cleanIndividualProfile(getPNACleanIndividualProfileClientBO(bo));
         if(cleanIndProfile!=null){          
            for(int i = 0; i < cleanIndProfile.size(); i++){
                String cleanIndPrfArray[]=(String[]) cleanIndProfile.get(i);
                LOG.debug("CleanIndProf stats code:::"+cleanIndPrfArray[0]+":::descrption::::"+cleanIndPrfArray[1]);
                bo.setResetIndProfStatusCode(cleanIndPrfArray[0]);
                bo.setResetIndProfStatusDescription(cleanIndPrfArray[1]);
            }
         }
        LOG.info("Leaving service method of processResetIndividualProfile");
        return bo;
    }
    /**
     *
     * @param bo
     * @return
     */
    public CleanRecordBO processPendingVerification(CleanRecordBO bo){
        LOG.info("Entering service method of processPendingVerification");
        
        String ihi = bo.getIhi();
        String operatorname = bo.getSystemOperator();
        String userID = bo.getUserID();
        int deletionStatus = 0;
        boolean auditStatus = false;
        try {
            deletionStatus = cleanRecordDAO.deleteNotificationsEntry(ihi);
            
            if (deletionStatus==1) {
                auditStatus = true;
                AuditRecordBO auditBO = getAuditRecordBO(ihi, auditStatus, operatorname, userID);
                auditBO = insertAuditRecordService.insertAudit(auditBO);
                bo.setCleanupStatusMessage(SUCCESSFUL_DELETION_STATUS_MESSAGE);
                bo.setCleanupAuditStatusMessage(auditBO.getResponseStatusMsg());
           
            } else {
                auditStatus = false;
                bo.setCleanupStatusMessage(UNSUCCESSFUL_DELETION_STATUS_MESSAGE);
            }
        
        } catch (Exception e) {
            LOG.fatal("Exception occured:::", e);
            bo.setCleanupStatusMessage(EXCEPTION_DELETION_STATUS_MESSAGE);
        }
        LOG.info("Leaving service method of processPendingVerification");
        return bo;
    }
    
    
    /**
     *
     * @param bo
     * @return
     */
    public CleanRecordBO processRemoveDocuments(CleanRecordBO bo){
        LOG.info("Entering service method of processRemoveDocuments");
        
        boolean flag = cleanRecordDAO.getStatus(bo.getIhi());
        if (flag == true) {
            LOG.debug("if loop...");
            bo.setRemoveDocIhiStatus("Active");
        
        } else if (cleanRecordDAO.checkRestricted(bo.getIhi()) == true) {
          
            LOG.debug("else if loop...");
            bo.setRemoveDocIhiRestirctedStatus("yes");
         
            bo.setRemoveDocIhiStatus("inActive");
            
           
        } else {
        
            HashMap docHashMap=getDocumentListClient.getDocListMapWsCall(getGetDocumentListClientBO(bo));
            
            List docList = getList(docHashMap);
            
            String delteDocumetRespose=null;
            if (docList.size() == 0) {
                bo.setRemoveDocIhiRestirctedStatus("no");
                bo.setRemoveDocIhiStatus("inActive");
                bo.setRemoveDocDocumentListSize("noDoc");
                LOG.debug("doclist 0");
            }else{
                bo.setRemoveDocIhiRestirctedStatus("no");
                bo.setRemoveDocIhiStatus("inActive");
                bo.setRemoveDocDocumentListSize("Doc");
                try{
                    delteDocumetRespose= deleteDocumentClient.deletDocument((getDeleteDocumentWSClientBO(bo,docList)));
                    bo.setRemoveDocDeletaionCsvFile(delteDocumetRespose); 
                }catch(Exception e){
                    LOG.fatal("Exception...",e);
                }
                LOG.debug("doclist size.."+docList.size());
            }
        }
    
        LOG.info("Leaving service method of processRemoveDocuments");
        return bo;
    }
    
    
    

    

    /**
     *
     * @param map
     * @return
     */
    public List getList(HashMap map) {
        Map.Entry me;
        String key = null;
        String value = null;
        List docList = new ArrayList();
        Set set = map.entrySet();
        Iterator iter = set.iterator();
        while (iter.hasNext()) {
            me = (Map.Entry)iter.next();
            key = me.getKey().toString();
            value = me.getValue().toString();
            if (!docList.contains(value)) {
                docList.add(value);
            }
        }
        return docList;
    }

   
    //getAuditBO
/**
     *
     * @param ihi
     * @param status
     * @param operatorname
     * @param userID
     * @return
     */
    private AuditRecordBO getAuditRecordBO(String ihi, boolean status, String operatorname, String userID) {
        AuditRecordBO auditRecordBO = new AuditRecordBO();
        //need to check
        auditRecordBO.setUserID(userID);
        //need to check
        auditRecordBO.setUsername(operatorname);
        auditRecordBO.setIhi(ihi);


        auditRecordBO.setVendor("NIO");
        auditRecordBO.setProductName("OPS Tool");
        auditRecordBO.setProdoctVersion("1.1");
        auditRecordBO.setPlatForm("Jump Host");


        //check condition for failed or completed
        auditRecordBO.setTransactionStatus("COMPLETED");

        auditRecordBO.setBusinessEvent("cleanupPendingVerificationDetails");
        auditRecordBO.setComponentSource("NIO");

        auditRecordBO.setIhiName("");

        auditRecordBO.setSubject(ihi);
        auditRecordBO.setActionType("Delete");

        auditRecordBO.setSubjectType("IHI");

        auditRecordBO.setOperationPerfomed("CleanupPendingVerificationDetails");
        auditRecordBO.setReason(null);
        auditRecordBO.setAccessConditions("OpenAccess");
        auditRecordBO.setAccessLevel("Self");
        auditRecordBO.setDescription("Transaction completed");
        auditRecordBO.setMessageLogLevel("AUDIT");
        auditRecordBO.setStatus(status);
        if (status) {
            auditRecordBO.setStatusCode("PCEHR_SUCCESS");
            auditRecordBO.setDescription("Success");
        } else {
            auditRecordBO.setStatusCode("PCEHR_ERROR");
            auditRecordBO.setDescription("Error");
        }
        auditRecordBO.setStatusCode("");
        auditRecordBO.setSoapMesage("");

        return auditRecordBO;
    }

/**
     *
     * @param bo
     * @return
     */
private PNACleanIndividualProfileClientBO getPNACleanIndividualProfileClientBO (CleanRecordBO bo){
    PNACleanIndividualProfileClientBO pNACleanIndividualProfileClientBO=new PNACleanIndividualProfileClientBO();
    pNACleanIndividualProfileClientBO.setIhi(bo.getIhi());
    return pNACleanIndividualProfileClientBO;
}
/**
     *
     * @param bo
     * @return
     */
    private GetDocumentListClientBO getGetDocumentListClientBO (CleanRecordBO bo){
        GetDocumentListClientBO getDocumentListClientBO=new GetDocumentListClientBO();
        getDocumentListClientBO.setIhi(bo.getIhi());
        
        List<String> docEntryStatus = new ArrayList<String>();
        docEntryStatus.add(getDocumentListClient.DOCENTRY_STATUS_APPROVED);
        getDocumentListClientBO.setDocumentEntryStatus(docEntryStatus);
        List<String> patientId = new ArrayList<String>();
        patientId.add(bo.getIhi());
        getDocumentListClientBO.setDocumentEntryPatientId(patientId);
        getDocumentListClientBO.setXDSDocumentEntryId(getDocumentListClient.DOCUMENT_PATIENT_ID);
        getDocumentListClientBO.setAdhocQueryID(getDocumentListClient.ADHOC_QUERY_ID_PATIENT);
        
        
        return getDocumentListClientBO;
    }
/**
     *
     * @param bo
     * @return
     */
    private DeleteDocumentWSClientBO getDeleteDocumentWSClientBO (CleanRecordBO bo,List docIdList){
        DeleteDocumentWSClientBO deleteDocumentWSClientBO=new DeleteDocumentWSClientBO();
        deleteDocumentWSClientBO.setIhi(bo.getIhi());
        deleteDocumentWSClientBO.setDocIdList(docIdList);
        return deleteDocumentWSClientBO;
    }
}
