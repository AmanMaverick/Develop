package au.gov.doha.pcehr.recovery.form;

import java.util.List;
import java.util.Map;


/**
 * @author aman.c.sharma
 * @since R7.1
 * @version 1
 *
 */
public class MobileApplicationToolForm {
    
    private String application;
    private String ihi;
    private String vendorName;
    private String appName;
    private String alternateName;
    private String version;
    private String callbackURL;
    private String intent;
    private String os;
    
    private String fullName;
    private String phone;
    private String mobile;
    private String email;
    private String businessAddress;
    private String suburb;
    private String postcode;
    private String state;
    
    private String fullNameSec;
    private String phoneSec;
    private String mobileSec;
    private String emailSec;
    private String businessAddressSec;
    private String suburbSec;
    private String postcodeSec;
    private String stateSec;
    private String intModel;
    private String intMajor;
    private List<String> apilist;
    private String applicationList;
    private String groupID;
    private String applicationStatus;
    private String callbackURLNoti;
    private String documentTypeAvailable;
    private List<String> documentType;
    private String applicationIdFromList;
    private Map<String,String> appListDetailsMap;
    private String applicationIdDetails;
    private Map<String,String> applicationIdList;
    
    private String ipRange;
    private String soapResponseCode;
    private String soapResponseDescription;
    private String submissionDate;
    private String VAMantab;
    private String VARegistrationtab;
    private String action;
    private Map<String,String> apiListMap;
    private String appIdMan;

    public void setAppIdMan(String appIdMan) {
        this.appIdMan = appIdMan;
    }

    public String getAppIdMan() {
        return appIdMan;
    }

    public void setApiListMap(Map<String, String> apiListMap) {
        this.apiListMap = apiListMap;
    }

    public Map<String, String> getApiListMap() {
        return apiListMap;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setVAMantab(String VAMantab) {
        this.VAMantab = VAMantab;
    }

    public String getVAMantab() {
        return VAMantab;
    }

    public void setVARegistrationtab(String VARegistrationtab) {
        this.VARegistrationtab = VARegistrationtab;
    }

    public String getVARegistrationtab() {
        return VARegistrationtab;
    }

    public void setSubmissionDate(String submissionDate) {
        this.submissionDate = submissionDate;
    }

    public String getSubmissionDate() {
        return submissionDate;
    }

    public void setIpRange(String ipRange) {
        this.ipRange = ipRange;
    }

    public String getIpRange() {
        return ipRange;
    }

    public void setSoapResponseDescription(String soapResponseDescription) {
        this.soapResponseDescription = soapResponseDescription;
    }

    public String getSoapResponseDescription() {
        return soapResponseDescription;
    }

    public void setSoapResponseCode(String soapResponseCode) {
        this.soapResponseCode = soapResponseCode;
    }

    public String getSoapResponseCode() {
        return soapResponseCode;
    }


    public void setApplicationIdList(Map<String, String> applicationIdList) {
        this.applicationIdList = applicationIdList;
    }

    public Map<String, String> getApplicationIdList() {
        return applicationIdList;
    }

    public void setApplicationIdFromList(String applicationIdFromList) {
        this.applicationIdFromList = applicationIdFromList;
    }

    public String getApplicationIdFromList() {
        return applicationIdFromList;
    }

    public void setAppListDetailsMap(Map<String, String> appListDetailsMap) {
        this.appListDetailsMap = appListDetailsMap;
    }

    public Map<String, String> getAppListDetailsMap() {
        return appListDetailsMap;
    }

    public void setApplicationIdDetails(String applicationIdDetails) {
        this.applicationIdDetails = applicationIdDetails;
    }

    public String getApplicationIdDetails() {
        return applicationIdDetails;
    }

    public void setDocumentType(List<String> documentType) {
        this.documentType = documentType;
    }

    public List<String> getDocumentType() {
        return documentType;
    }

    public void setDocumentTypeAvailable(String documentTypeAvailable) {
        this.documentTypeAvailable = documentTypeAvailable;
    }

    public String getDocumentTypeAvailable() {
        return documentTypeAvailable;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getApplication() {
        return application;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAlternateName(String alternateName) {
        this.alternateName = alternateName;
    }

    public String getAlternateName() {
        return alternateName;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getVersion() {
        return version;
    }

    public void setCallbackURL(String callbackURL) {
        this.callbackURL = callbackURL;
    }

    public String getCallbackURL() {
        return callbackURL;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public String getIntent() {
        return intent;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getOs() {
        return os;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return phone;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getMobile() {
        return mobile;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setFullNameSec(String fullNameSec) {
        this.fullNameSec = fullNameSec;
    }

    public String getFullNameSec() {
        return fullNameSec;
    }

    public void setPhoneSec(String phoneSec) {
        this.phoneSec = phoneSec;
    }

    public String getPhoneSec() {
        return phoneSec;
    }

    public void setMobileSec(String mobileSec) {
        this.mobileSec = mobileSec;
    }

    public String getMobileSec() {
        return mobileSec;
    }

    public void setEmailSec(String emailSec) {
        this.emailSec = emailSec;
    }

    public String getEmailSec() {
        return emailSec;
    }

    public void setBusinessAddressSec(String businessAddressSec) {
        this.businessAddressSec = businessAddressSec;
    }

    public String getBusinessAddressSec() {
        return businessAddressSec;
    }

    public void setSuburbSec(String suburbSec) {
        this.suburbSec = suburbSec;
    }

    public String getSuburbSec() {
        return suburbSec;
    }

    public void setPostcodeSec(String postcodeSec) {
        this.postcodeSec = postcodeSec;
    }

    public String getPostcodeSec() {
        return postcodeSec;
    }

    public void setStateSec(String stateSec) {
        this.stateSec = stateSec;
    }

    public String getStateSec() {
        return stateSec;
    }

    public void setIntModel(String intModel) {
        this.intModel = intModel;
    }

    public String getIntModel() {
        return intModel;
    }

    public void setIntMajor(String intMajor) {
        this.intMajor = intMajor;
    }

    public String getIntMajor() {
        return intMajor;
    }

    public void setApilist(List<String> aPIList) {
        this.apilist = aPIList;
    }

    public List<String> getApilist() {
        return apilist;
    }

    public void setApplicationList(String applicationList) {
        this.applicationList = applicationList;
    }

    public String getApplicationList() {
        return applicationList;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    public String getGroupID() {
        return groupID;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setCallbackURLNoti(String callbackURLNoti) {
        this.callbackURLNoti = callbackURLNoti;
    }

    public String getCallbackURLNoti() {
        return callbackURLNoti;
    }
}
