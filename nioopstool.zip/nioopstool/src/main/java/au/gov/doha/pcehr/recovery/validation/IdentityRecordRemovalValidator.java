package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.bo.IdentityRecordRemovalResponseBO;
import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;
import au.gov.doha.pcehr.recovery.dao.IdentityRecordRemovalDao;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.IdentityRecordRemovalForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


/**
 * This Validator Class validates the input data for IdentityRecordRemovalForm.
 * @author Rakhi Tholia, AO,  PCEHR
 * @since 10th March 2014
 * @version - x
 */

public class IdentityRecordRemovalValidator implements Validator {

    private static Logger LOG = Logger.getLogger(IdentityRecordRemovalValidator.class);

    // Fetching value from Property File and assigning it to a variable.
    @Value("${IdentityRecordRemoval.DropDown.action_Type1}")
    private String incorrect_Record_Removal;

    @Value("${IdentityRecordRemoval.DropDown.action_Type2}")
    private String incorrect_Identity_Removal;

    @Value("${IdentityRecordRemoval.DropDown.action_Type3}")
    private String incorrect_Record_Identity_Removal;

    @Value("${IdentityRecordRemoval.DropDown.action_Type4}")
    private String incorrect_Child_Record_Removal;

    @Autowired
    IdentityRecordRemovalDao identityRecordRemovalDao;
    
    @Autowired
    DateTimeUtil dateTimeUtil;
    @Autowired
    FileUtil fileUtil;
    @Override
    public boolean supports(Class<?> class1) {
        return IdentityRecordRemovalForm.class.equals(class1);
    }

    /**
     * Overriden method validates the input data for identity and record removal page
     * and returns errors.
     * @param object, errors
     */
    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Inside IdentityRecordRemovalValidator");
        if (object instanceof IdentityRecordRemovalForm) {
            IdentityRecordRemovalForm identityRecordRemovalForm = (IdentityRecordRemovalForm)object;
            try {
                LOG.debug("Inside IdentityRecordRemovalValidator1"+identityRecordRemovalForm.getSex());
                errors = validateIdentityRecordRemoval(identityRecordRemovalForm, errors);
                LOG.debug("Inside IdentityRecordRemovalValidator2"+identityRecordRemovalForm.getSex());
            } catch (Exception e) {
                LOG.error("Exception occured", e);
            }
        } else {
            LOG.debug("Invalid parameter !!!");
        }
    }


    /**
     * validateIdentityRecordRemoval method validates the input data and returns errors.
     * @param identityRecordRemovalForm, errors
     * @return Errors
     * @throws RecoveryDAOException
     */
    private Errors validateIdentityRecordRemoval(IdentityRecordRemovalForm identityRecordRemovalForm,
                                                 Errors errors) throws RecoveryDAOException {
        LOG.debug("Inside validateIdentityRecordRemoval...");
       
        //Null Validation
       
        ValidationUtils.rejectIfEmpty(errors, "action_Type", "IdentityRecordRemoval");
        ValidationUtils.rejectIfEmpty(errors, "operatorName", "IdentityRecordRemoval");
        ValidationUtils.rejectIfEmpty(errors, "userID", "IdentityRecordRemoval");
        if("singleInput".equals(identityRecordRemovalForm.getOperationTypeRemoval())){
            LOG.debug("Inside validateIdentityRecordRemoval..SEX:"+identityRecordRemovalForm.getSex());
            ValidationUtils.rejectIfEmpty(errors, "ihi", "IdentityRecordRemoval");
            ValidationUtils.rejectIfEmpty(errors, "lastName", "IdentityRecordRemoval");
            ValidationUtils.rejectIfEmpty(errors, "sex", "IdentityRecordRemoval");
            ValidationUtils.rejectIfEmpty(errors, "dob", "IdentityRecordRemoval");
            
        
        boolean dateValidate=dateTimeUtil.validatedate(identityRecordRemovalForm.getDob(),"dd/mm/yyyy");
        LOG.debug("Inside Validator- DOB: "+identityRecordRemovalForm.getDob());
        if(!(identityRecordRemovalForm.getDob().equals("")) && !dateValidate) {
            errors.rejectValue("dob", "IdentityRecordRemoval.invalidDOB");
        }
        //IHI - 16 digit validation
        if (identityRecordRemovalForm.getIhi() != null && identityRecordRemovalForm.getIhi().length() > 0 &&
            (!identityRecordRemovalForm.getIhi().matches("[0-9]{16}"))) {
            LOG.debug("IHI......Match.....");
            errors.rejectValue("ihi", "IdentityRecordRemoval.ihiLength");
        }
        
        //Demographic Details Validation
        if (errors.getErrorCount()==0){
        boolean flag = identityRecordRemovalDao.validateDemographicDetails(identityRecordRemovalForm);
        if(!flag) {
            LOG.debug("enter into if block....No Demographic Details available for such details.");
            errors.reject("IdentityRecordRemoval.noDemographicDetails");
        }
        }

         //IHI-Restrict validation
        if(errors.getErrorCount()==0 && identityRecordRemovalDao.arIHIRestricted(identityRecordRemovalForm.getIhi())){
            LOG.debug("enter into if block....IHI is currently in AR Restrict");
            errors.rejectValue("ihi", "IdentityRecordRemoval.ihirestrict");
        }

        //Validate Records before removal
        if(errors.getErrorCount()==0){
        if (incorrect_Record_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
            if (!(identityRecordRemovalDao.validateRecordIHI(identityRecordRemovalForm.getIhi()))) {
                errors.rejectValue("ihi", "IdentityRecordRemoval.noRecords");
            }
        }


        /**
         * Validate Identity before removal. If there exists any records for that IHI,
         * It asks User to remove Records first.
         */
        if (incorrect_Identity_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
            if (identityRecordRemovalDao.validateRecordIHI(identityRecordRemovalForm.getIhi())) {
                errors.rejectValue("ihi", "IdentityRecordRemoval.deleteRecordFirst");
            } else {
                if (!(identityRecordRemovalDao.validateIdentityIHI(identityRecordRemovalForm.getIhi()))) {
                    errors.rejectValue("ihi", "IdentityRecordRemoval.noIdentity");
                }
            }
        }


        //validate Child Record before removal
        if (incorrect_Child_Record_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
            if ((identityRecordRemovalDao.validateIdentityIHI(identityRecordRemovalForm.getIhi()))) {
                errors.rejectValue("ihi", "IdentityRecordRemoval.childIdentityExists");
            }
        }
        }
        }
        //for bulk validation
        else{
            LOG.debug("validation for bulk::");
            boolean inoutFileFormatValidation=true;
                     LOG.debug("File Name :: " + identityRecordRemovalForm.getFile().getOriginalFilename());
                     String name = identityRecordRemovalForm.getFile().getOriginalFilename();
                     if(identityRecordRemovalForm.getFile().getOriginalFilename().equals("")){
                         LOG.debug("File not found");
                         errors.rejectValue("file", "ARRestriction.fileNotFound");
                         inoutFileFormatValidation=false;
                     }else if (!name.substring(name.indexOf('.'), name.length()).equalsIgnoreCase(".csv")) {
                         LOG.debug("file name validation failed");
                         errors.rejectValue("file", "ARRestriction.invalidFile");
                         inoutFileFormatValidation=false;
                     }else if(identityRecordRemovalForm.getFile().getSize()>=0 && identityRecordRemovalForm.getFile().getSize()> 1000000){
                         LOG.debug("FIle size validation failed");
                         errors.rejectValue("file", "ARRestriction.invalidFileSize");
                         inoutFileFormatValidation=false;
                     } 
            if(inoutFileFormatValidation){ 
            identityRecordRemovalForm.setListIdentityRemovalBO(fileUtil.getIdentityRemovalInputsFromCSV(identityRecordRemovalForm.getFile()));
            List<IdentityRecordRemovalResponseBO> errorBoList = new ArrayList<IdentityRecordRemovalResponseBO>();
            for(int i=0;i<identityRecordRemovalForm.getListIdentityRemovalBO().size();i++){
              boolean inputValidationFlag=true;
                
                IdentityRemovalBO identityRemovalBO =identityRecordRemovalForm.getListIdentityRemovalBO().get(i);
                if(identityRemovalBO.getFamily_Name()==null || identityRemovalBO.getFamily_Name().length()==0){
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);;
                    
                    errorBo.setDescription("Family name should not be null");
                     errorBoList.add(errorBo);
                    inputValidationFlag=false;
                }
                if(identityRemovalBO.getDob()==null || identityRemovalBO.getDob().length()==0){
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);;
                    
                    errorBo.setDescription("DOB should not be null");
                     errorBoList.add(errorBo);
                    inputValidationFlag=false;
                }
                if(identityRemovalBO.getSex()==null || identityRemovalBO.getSex().length()==0){
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);;
                    
                    errorBo.setDescription("Gender should not be null");
                     errorBoList.add(errorBo);
                    inputValidationFlag=false;
                }
                if(identityRemovalBO.getIhi()==null || identityRemovalBO.getIhi().length()==0){
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);;
                    
                    errorBo.setDescription("IHI should not be null");
                     errorBoList.add(errorBo);
                    inputValidationFlag=false;
                }
               else if(!(identityRemovalBO.getIhi() != null && identityRemovalBO.getIhi().length() > 0 && identityRemovalBO.getIhi().matches("[0-9]{16}"))){
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);;
                    
                    errorBo.setDescription("IHI should be 16 digits");
                     errorBoList.add(errorBo);
                    inputValidationFlag=false;
                }
               
                boolean dateValidate=dateTimeUtil.validatedate(identityRemovalBO.getDob(),"dd/mm/yyyy");
                LOG.debug("Inside bulk Validator- DOB: "+identityRemovalBO.getDob());
                if(!(identityRemovalBO.getDob().equals("")) && !dateValidate) {
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);;
                    
                    errorBo.setDescription("DOB should be in dd/mm/yyyy format");
                     errorBoList.add(errorBo);
                    inputValidationFlag=false;
                }
                LOG.debug("Starting Input validation successfull.");
               if(inputValidationFlag){
                   LOG.debug("Input validation successfull.");
                boolean flag = identityRecordRemovalDao.validateDemographicDetails2(identityRemovalBO);
                
                if(!flag) {
                    LOG.debug("enter into if block....No Demographic Details available for such details.");
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);
                   
                    errorBo.setDescription("No Demographic Details available for such details");
                    errorBoList.add(errorBo);
                  //  identityRecordRemovalForm.get
                    //errors.reject("IdentityRecordRemoval.noDemographicDetails");
                }
                

                 //IHI-Restrict validation
                if(identityRecordRemovalDao.arIHIRestricted(identityRemovalBO.getIhi())){
                    LOG.debug("enter into if block....IHI is currently in AR Restrict");
                    IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);
                    
                    errorBo.setDescription("IHI is currently in AR Restrict");
                    errorBoList.add(errorBo);
                  
                }

                //Validate Records before removal
                
                if (incorrect_Record_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
                    LOG.debug("Input validation successfull.- -- 1");
                    if (!(identityRecordRemovalDao.validateRecordIHI(identityRemovalBO.getIhi()))) {
                      
                        IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);
                       
                        errorBo.setDescription("PCEHR_Record does not exist.");
                        errorBoList.add(errorBo);
                    }
                }

                /**
                 * Validate Identity before removal. If there exists any records for that IHI,
                 * It asks User to remove Records first.
                 */
                LOG.debug( incorrect_Identity_Removal + " - Input validation successfull.- -- 1" + identityRecordRemovalForm.getAction_Type());
                
                if (incorrect_Identity_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
                    if (identityRecordRemovalDao.validateRecordIHI(identityRemovalBO.getIhi())) {
                      
                        IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);
                      
                        errorBo.setDescription("Delete record first");
                        errorBoList.add(errorBo);
                    } else {
                        if (!(identityRecordRemovalDao.validateIdentityIHI(identityRemovalBO.getIhi()))) {
                       
                         IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);
                      
                         errorBo.setDescription("noIdentity");
                            errorBoList.add(errorBo);
                        }
                    }
                }


                //validate Child Record before removal
                if (incorrect_Child_Record_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
                    if ((identityRecordRemovalDao.validateIdentityIHI(identityRecordRemovalForm.getIhi()))) {
                       
                       IdentityRecordRemovalResponseBO errorBo=fileUtil.setErrorBo(identityRemovalBO);
                  
                       errorBo.setDescription("childIdentityExists");
                        errorBoList.add(errorBo);
                    }
                }
                
                
            }
            }   
            LOG.debug("error bo list size:::"+errorBoList.size());
                       if(errorBoList.size()>0){
                           identityRecordRemovalForm.setValidationStatus("invalid");
                           identityRecordRemovalForm.setListIdentityRecordRemovalResponseBO(errorBoList);
                           fileUtil.createCSVForIdentityRemoval(identityRecordRemovalForm);
                           
                       }
                   }
                   }
                   LOG.debug("Leaving  validateIdentityRecordRemoval !!!");
                   return errors;
               }


              
            }
