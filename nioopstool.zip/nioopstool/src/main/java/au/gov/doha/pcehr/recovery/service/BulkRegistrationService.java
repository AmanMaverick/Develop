package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.FileTransferBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.dao.BulkRegistrationDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.BulkRegistrationForm;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

/**
 * Service to perform all Bulk registration for Opt Out relatated task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 18 Nov 2015
 * @version Change-x
 */
@Service
public class BulkRegistrationService {
    public BulkRegistrationService() {
        super();
    }
    private static Logger LOG = Logger.getLogger(BulkRegistrationService.class);
    /*
     * to set the source and destination folder location
     */
    private static final String VALIDATE_EXTRACT = "ValidateExtract";
    /*
     * to set the source and destination folder location
     */
    private static final String DATA_EXTRACTION = "DataExtarction";
    /*
     * to set the source and destination folder location
     */
    private static final String VALIDATE_EXTRACT_OUTPUT = "ValidateExtarctOutput";
    /*
     * to set the source and destination folder location
     */
    private static final String PUSH_TO_DB_OUTPUT = "PushToDbOutput";
    /*
     * File transefr from OSB box success message
     */
    private static final String FILE_TRANSFER_SUCCESSFULL_MESSAGE = "File Transfer is Successful";
    /*
     * OSB Audit user action type as Read
     */
    private static final String AUDIT_ACTION_TYPE_READ = "Read";
    /*
     * OSB Audit user action type as Create
     */
    private static final String AUDIT_ACTION_TYPE_CREATE = "Create";
    /*
     * OSB Audit user action type as Update
     */
    private static final String AUDIT_ACTION_TYPE_UPDATE = "Update";
    /*
     * OSB Audit user acess level type as Limited Access
     */
    private static final String AUDIT_USER_ACCESS_LEVEL = "Limited";

    /*
     * OSB Audit validate extarct business event
     */
    private static final String AUDIT_VALIDATE_EXTRACT_BUSINESS_EVENT = "validateExtract";

    /*
     * OSB Audit validate extarct subject
     */
    private static final String AUDIT_VALIDATE_EXTRACT_SUBJECT = "Validate Extract";

    /*
     * OSB Audit validate extarct business event
     */
    private static final String AUDIT_DATA_EXTRACT_BUSINESS_EVENT = "dataExtraction";

    /*
     * OSB Audit validate extarct subject
     */
    private static final String AUDIT_DATA_EXTRACT_SUBJECT = "Data Extraction";


    /*
     * OSB Audit Validate IHI Info Subject type
     */
    private static final String AUDIT_VALIDATE_IHI_SUBJECT_TYPE = "Validate IHI Info";
    /*
     * OSB Audit Validate IHI Info business Event
     */
    private static final String AUDIT_VALIDATE_IHI_OPERATION_AND_BUSINESS_EVENT = "validation";
    /*
     * OSB Audit Validate IHI Info business Event
     */
    private static final String AUDIT_BULK_RECORD_CREATION_OPERATION_AND_BUSINESS_EVENT = "bulkRecordCreation";
    /*
     * OSB Audit Bulk Record Creation Info Subject type
     */
    private static final String AUDIT_BULK_RECORD_CREATION_SUBJECT_TYPE = "Bulk Record Creation";


    /*
     * OSB Audit Bulk Record Creation Info Subject type
     */
    private static final String AUDIT_VALIDATE_AND_BULK_RECORD_CREATION_SUBJECT = "ValidateAndBulkRecord Creation";

    @Autowired
    BulkRegistrationDAO bulkRegistrationDAO;

    @Autowired
    InsertAuditRecordService insertAuditRecordService;

    @Autowired
    private FileUtil fileUtil;


    /**
     * Used to perform the validate file movement from source folder to proper destination and if successfull will log the audit in osb audit table
     * @param bulkRegistrationForm
     * @throws RecoveryServiceException
     */
    public void pefromValidateExtractFile(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        LOG.debug("entering pefromValidateExtractFile...");
       
        String fileNameFromUI = bulkRegistrationForm.getFileName();
        LOG.debug("file name:::" + fileNameFromUI);
        //calling file name format check to fix the pen test defect to prevent the cheksum command execution after request modification from bruffsuite tool
        if (fileFormatCheck(fileNameFromUI)) {
            LOG.debug("file name validation is succesfull from service");
            bulkRegistrationForm.setValidateDataExtract(VALIDATE_EXTRACT);
            transefrFile(bulkRegistrationForm);


            AuditRecordBO auditRecord = new AuditRecordBO();
            auditRecord.setOperationPerfomed(AUDIT_VALIDATE_EXTRACT_BUSINESS_EVENT);
            auditRecord.setBusinessEvent(AUDIT_VALIDATE_EXTRACT_BUSINESS_EVENT);
            auditRecord.setSubjectType(AUDIT_VALIDATE_EXTRACT_SUBJECT);
            auditRecord.setSubject(bulkRegistrationForm.getFileName());
            auditRecord.setActionType(AUDIT_ACTION_TYPE_READ);
            auditRecord = getAuditRecordBO(auditRecord);
            LOG.debug("calling insertAuditRecordService...");
            if (bulkRegistrationForm.getValidateExtractFileTransferSDescription() != null &&
                bulkRegistrationForm.getValidateExtractFileTransferSDescription().equals(FILE_TRANSFER_SUCCESSFULL_MESSAGE)) {
                LOG.debug("calling audit as file transfer is successfull");
                auditRecord = insertAuditRecordService.insertAudit(auditRecord);
                LOG.debug("insertAuditRecordService response...." + auditRecord.getAuditReponse().getCode());
            } else {
                LOG.debug("Audit is not done as file transfer has failed");
            }

        } else {
            LOG.debug("file name validation is failed from service");
            bulkRegistrationForm.setValidateExtractFileTransferStatus(1);
            bulkRegistrationForm.setValidateExtractFileTransferSDescription("Please input DHS file format.");
        }
        LOG.debug("file transfer status:::" + bulkRegistrationForm.getValidateExtractFileTransferStatus());
        LOG.debug("file transfer description:::" + bulkRegistrationForm.getValidateExtractFileTransferSDescription());
        LOG.debug("leaving pefromValidateExtractFile...");
    }

    /**
     *Used to trigger the data extraction functionlity whcih will invoke util methods to transfer file from  one directory to another
     *
     * @param bulkRegistrationForm
     * @throws RecoveryServiceException
     */
    public void triggerdataExtract(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        LOG.debug("Entering triggerdataExtract...");
      
        String fileNameFromUI = bulkRegistrationForm.getFileName();
        LOG.debug("file name:::" + fileNameFromUI);
        //calling file name format check to fix the pen test defect to prevent the cheksum command execution after request modification from bruffsuite tool
        if (fileFormatCheck(fileNameFromUI)) {
                LOG.debug("file name validation is failed from service");
            bulkRegistrationForm.setValidateDataExtract(DATA_EXTRACTION);
            transefrFile(bulkRegistrationForm);
            LOG.debug("file name:::" + bulkRegistrationForm.getFileName());
            LOG.debug("file name:::" + bulkRegistrationForm.getFileName());
            AuditRecordBO auditRecord = new AuditRecordBO();
            auditRecord.setBusinessEvent(AUDIT_DATA_EXTRACT_BUSINESS_EVENT);
            auditRecord.setOperationPerfomed(AUDIT_DATA_EXTRACT_BUSINESS_EVENT);
            auditRecord.setSubjectType(AUDIT_DATA_EXTRACT_SUBJECT);
            auditRecord.setActionType(AUDIT_ACTION_TYPE_CREATE);
            auditRecord.setSubject(bulkRegistrationForm.getFileName());
            auditRecord = getAuditRecordBO(auditRecord);
            LOG.debug("calling insertAuditRecordService...");
            if (bulkRegistrationForm.getValidateExtractFileTransferSDescription() != null &&
                bulkRegistrationForm.getValidateExtractFileTransferSDescription().equals(FILE_TRANSFER_SUCCESSFULL_MESSAGE)) {
                LOG.debug("calling audit as file transfer is successfull");
                auditRecord = insertAuditRecordService.insertAudit(auditRecord);
                LOG.debug("insertAuditRecordService response...." + auditRecord.getAuditReponse().getCode());
            } else {
                LOG.debug("Audit is not done as file transfer has failed");
            }
            }else{
                LOG.debug("file name validation is failed from service");
                bulkRegistrationForm.setValidateExtractFileTransferStatus(1);
                bulkRegistrationForm.setValidateExtractFileTransferSDescription("Please input DHS file format.");
            }
        LOG.debug("file transfer status:::" + bulkRegistrationForm.getValidateExtractFileTransferStatus());
        LOG.debug("file transfer description:::" + bulkRegistrationForm.getValidateExtractFileTransferSDescription());
        LOG.debug("leaving triggerdataExtract...");
    }


    /**
     *Used to copy the file to local for giving the user to downoad the file
     * @param bulkRegistrationForm
     * @return
     * @throws RecoveryServiceException
     */

    public BulkRegistrationForm copyFiletoLocal(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {

        LOG.debug("copyFiletoLocal1.....");

        //setting the validateExtract value to ValidateExtarctOutput which is used to set the host source folder
        //from where the file will be copied

        FileTransferBO fileTransferBO = setFileTransferBO(bulkRegistrationForm);
        LOG.debug("source folder::" + fileTransferBO.getSourceFolder());
        //Util call to write the file into local
        fileUtil.downloadFileToLocal(fileTransferBO);
        LOG.debug("file copy status in copyFiletoLocal:::" + fileTransferBO.getValidateExtractdownloadStatus());
        //used to set the status and description of file copy status and description
        bulkRegistrationForm.setValidateExtractDownloadStatus(fileTransferBO.getValidateExtractdownloadStatus());
        bulkRegistrationForm.setValidateExtractDownloadDescription(fileTransferBO.getValidateExtractdownloadDescription());
        bulkRegistrationForm.setFileName(fileTransferBO.getFileName());
        return bulkRegistrationForm;

    }


    /**
     *  This method triggers the validate IHI info process in OSB.
     *  update the status to L to V
     * @param
     * @return
     */
    public BulkRegistrationForm validateIHIInfo(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        try {
            if (bulkRegistrationForm.getValidateFilelUpload() != null) {
                List<String> ihiList = readFile(bulkRegistrationForm.getValidateFilelUpload());
                bulkRegistrationForm.setIhiList(ihiList.toArray(new String[ihiList.size()]));
            }
            bulkRegistrationDAO.validateIHIInfo(bulkRegistrationForm);
            //Auditing TODO - Set value as per design
            AuditRecordBO auditRecord = new AuditRecordBO();
            auditRecord.setOperationPerfomed(AUDIT_VALIDATE_IHI_OPERATION_AND_BUSINESS_EVENT);
            auditRecord.setBusinessEvent(AUDIT_VALIDATE_IHI_OPERATION_AND_BUSINESS_EVENT);
            auditRecord.setSubjectType(AUDIT_VALIDATE_IHI_SUBJECT_TYPE);
            auditRecord.setSubject(AUDIT_VALIDATE_IHI_SUBJECT_TYPE);

            auditRecord.setActionType(AUDIT_ACTION_TYPE_UPDATE);
            //auditRecord.setSubject("IHI");
            auditRecord = getAuditRecordBO(auditRecord);
            auditRecord = insertAuditRecordService.insertAudit(auditRecord);
        } catch (RecoveryDAOException recoveryDAOException) {
            throw new RecoveryServiceException(recoveryDAOException.getMessage(), recoveryDAOException);
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        }
        return bulkRegistrationForm;
    }

    /**
     *  This method stop the validate IHI info process in OSB.
     *  update the status to v to null
     * @param
     * @return
     */
    public BulkRegistrationForm validateIHIInfoStop(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        try {

            bulkRegistrationDAO.stopOSBProcess("V", 1, bulkRegistrationForm.getIhiList(), 0);

        } catch (RecoveryDAOException recoveryDAOException) {
            throw new RecoveryServiceException(recoveryDAOException.getMessage(), recoveryDAOException);
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        }
        return bulkRegistrationForm;
    }


    /**
     *  This method triggers the bulk Record Creation process in OSB.
     *  update the status to R to RC
     * @param
     * @return
     */
    public BulkRegistrationForm bulkRecordCreationService(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        try {
            if (bulkRegistrationForm.getRecordCreationFilelUpload() != null) {
                List<String> ihiList = readFile(bulkRegistrationForm.getRecordCreationFilelUpload());
                bulkRegistrationForm.setIhiList(ihiList.toArray(new String[ihiList.size()]));
            }
            bulkRegistrationDAO.bulkRecordCreation(bulkRegistrationForm);
            //Auditing TODO - Set value as per design
            AuditRecordBO auditRecord = new AuditRecordBO();
            auditRecord.setOperationPerfomed(AUDIT_BULK_RECORD_CREATION_OPERATION_AND_BUSINESS_EVENT);
            auditRecord.setBusinessEvent(AUDIT_BULK_RECORD_CREATION_OPERATION_AND_BUSINESS_EVENT);
            auditRecord.setSubjectType(AUDIT_BULK_RECORD_CREATION_SUBJECT_TYPE);
            auditRecord.setSubject(AUDIT_BULK_RECORD_CREATION_SUBJECT_TYPE); //TODO
            auditRecord.setActionType(AUDIT_ACTION_TYPE_UPDATE);
            auditRecord = getAuditRecordBO(auditRecord);
            auditRecord = insertAuditRecordService.insertAudit(auditRecord);
        } catch (RecoveryDAOException recoveryDAOException) {
            throw new RecoveryServiceException(recoveryDAOException.getMessage(), recoveryDAOException);
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        }
        return bulkRegistrationForm;
    }

    /**
     *  This method stop the bulk record creation process in OSB.
     *  update the status to R to null
     * @param
     * @return
     */
    public BulkRegistrationForm bulkRecordCreationStop(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        try {

            bulkRegistrationDAO.stopOSBProcess("R", 1, bulkRegistrationForm.getIhiList(), 0);

        } catch (RecoveryDAOException recoveryDAOException) {
            throw new RecoveryServiceException(recoveryDAOException.getMessage(), recoveryDAOException);
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        }
        return bulkRegistrationForm;
    }

    /**
     *  This method triggers the bulk Record Creation process in OSB.
     *  update the status to VR to RC
     * @param
     * @return
     */
    public BulkRegistrationForm validateAndRecordCreationService(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        try {
            if (bulkRegistrationForm.getValidateAndRecordCreationFile() != null) {
                List<String> ihiList = readFile(bulkRegistrationForm.getValidateAndRecordCreationFile());
                bulkRegistrationForm.setIhiList(ihiList.toArray(new String[ihiList.size()]));
            }
            bulkRegistrationDAO.validateAndBulkRecordCreation(bulkRegistrationForm);
            //Auditing TODO - Set value as per design
            AuditRecordBO auditRecord = new AuditRecordBO();
            auditRecord.setOperationPerfomed(AUDIT_VALIDATE_AND_BULK_RECORD_CREATION_SUBJECT);
            auditRecord.setBusinessEvent(AUDIT_VALIDATE_AND_BULK_RECORD_CREATION_SUBJECT);
            auditRecord.setSubjectType(AUDIT_VALIDATE_AND_BULK_RECORD_CREATION_SUBJECT);
            auditRecord.setSubject(AUDIT_VALIDATE_AND_BULK_RECORD_CREATION_SUBJECT);
            auditRecord.setActionType(AUDIT_ACTION_TYPE_UPDATE);
            auditRecord = getAuditRecordBO(auditRecord);
            auditRecord = insertAuditRecordService.insertAudit(auditRecord);
        } catch (RecoveryDAOException recoveryDAOException) {
            throw new RecoveryServiceException(recoveryDAOException.getMessage(), recoveryDAOException);
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        }
        return bulkRegistrationForm;
    }


    /**
     *  This method stop the bulk record creation process in OSB.
     *  update the status to VR to null
     * @param
     * @return
     */
    public BulkRegistrationForm validateAndRecordCreationStop(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        try {

            bulkRegistrationDAO.stopOSBProcess("VR", 1, bulkRegistrationForm.getIhiList(), 0);

        } catch (RecoveryDAOException recoveryDAOException) {
            throw new RecoveryServiceException(recoveryDAOException.getMessage(), recoveryDAOException);
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        }
        return bulkRegistrationForm;
    }

    /**
     * This methos generates the status report based on the given input
     * @param bulkRegistrationForm
     * @return
     * @throws RecoveryServiceException
     */
    public BulkRegistrationForm bulkRegStatus(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        LOG.info("entered into the bulkRegStatus::" + bulkRegistrationForm.getStatusFilelUpload());
        try {
            if (bulkRegistrationForm.getStatusFilelUpload() != null) {
                LOG.info("entered fileupload is not null");
                List<String> ihiList = readFile(bulkRegistrationForm.getStatusFilelUpload());
                LOG.info("ihi list size" + ihiList.size());
                bulkRegistrationForm.setIhiList(ihiList.toArray(new String[ihiList.size()]));
            }

            bulkRegistrationDAO.bulkRegStatus(bulkRegistrationForm);
        } catch (RecoveryDAOException recoveryDAOException) {
            throw new RecoveryServiceException(recoveryDAOException.getMessage(), recoveryDAOException);
        } catch (Exception ex) {
            LOG.fatal("Exception occured", ex);
            throw new RecoveryServiceException(ex.getMessage(), ex);
        }

        return bulkRegistrationForm;
    }

    /**
     * This method reads the csv file and return the list of ihi.
     * @param file
     * @return
     * @throws RecoveryServiceException
     */
    private List<String> readFile(MultipartFile file) throws RecoveryServiceException {
        LOG.debug("Entered into readFile");
        HashSet<String> uniqIhiSet = new HashSet<String>();
        Set<String> ihiList = new HashSet<String>();
        String csvSplitBy = ",";
        String[] ihi = null;
        InputStreamReader iStreamReader = null;
        BufferedReader bReader = null;
        try {
            iStreamReader = new InputStreamReader(file.getInputStream());
            bReader = new BufferedReader(iStreamReader);
            for (String line = bReader.readLine(); line != null; line = bReader.readLine()) {
                if (line != null && !line.equals(""))
                    ihi = line.split(csvSplitBy);
                uniqIhiSet.addAll(Arrays.asList(ihi));
            }
            ihiList.addAll(uniqIhiSet);
            LOG.debug("DOc id List size ::" + ihiList.size());

        } catch (IOException e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryServiceException(e.getMessage(), e);
        } finally {
            try {
                bReader.close();
                iStreamReader.close();
            } catch (Exception e) {
                LOG.fatal("Exception occured while colosing the resources..", e);

            }
        }
        return new ArrayList<String>(ihiList);
    }


    /**
     *USed to call the file transefer funtionality
     * @param bulkRegistrationForm
     * @throws RecoveryServiceException
     */
    public void transefrFile(BulkRegistrationForm bulkRegistrationForm) throws RecoveryServiceException {
        LOG.debug("inside transefrFile...");
        LOG.debug("file name from UI:::" + bulkRegistrationForm.getFileName());
        LOG.debug("file checsum value from UI:::" + bulkRegistrationForm.getCheckSumValueFromUI());
        FileTransferBO fileTransferBO = new FileTransferBO();

        fileTransferBO = setFileTransferBO(bulkRegistrationForm);
        fileTransferBO.setFileName(bulkRegistrationForm.getFileName());
        fileTransferBO.setChecksumValueFromUI(bulkRegistrationForm.getCheckSumValueFromUI());

        try {
            fileTransferBO = fileUtil.sshServerFileTransfer(fileTransferBO);
        } catch (RecoveryServiceException rse) {

            throw new RecoveryServiceException(rse);
        }
        bulkRegistrationForm.setFileName(fileTransferBO.getFileName());
        //setting the file transefer stastus and description
        bulkRegistrationForm.setValidateExtractFileTransferSDescription(fileTransferBO.getTransferOutputDescription());
        bulkRegistrationForm.setValidateExtractFileTransferStatus(fileTransferBO.getTransferStatus());

        LOG.debug("file transfer status:::" + fileTransferBO.getTransferStatus());
        LOG.debug("file transfer description:::" + fileTransferBO.getTransferOutputDescription());
        LOG.debug("leaving transefrFile...");
    }

    /**
     *Used to set all the file transfer related attributes
     * @param bulkRegistrationForm
     * @return
     */
    public FileTransferBO setFileTransferBO(BulkRegistrationForm bulkRegistrationForm) {
        LOG.debug("inside setFileTransferBO...");
        FileTransferBO fileTransferBO = new FileTransferBO();

        String hostIp = EndPointsConstants.OSB_NFS_HOSTIP;
        String userName = EndPointsConstants.OSB_NFS_USEERNAME;
        String hostPassword = EndPointsConstants.OSB_NFS_PASSWORD;
        String connectionPortString = EndPointsConstants.OSB_NFS_PORT;
        String sourceFolderValidateExtract = EndPointsConstants.OSB_NFS_SOURCEFOLDER_VALIDATE_EXTRACT + "/";
        String destinationFolderValidateExtract = EndPointsConstants.OSB_NFS_DESTINATIONFOLDER_VALIDATE_EXTRACT + "/";
        String sourceFolderDataExtraction = EndPointsConstants.OSB_NFS_SOURCEFOLDER_DATA_EXTRACTION + "/";
        String destinationFolderDataExtraction = EndPointsConstants.OSB_NFS_DESTINATIONFOLDER_DATA_EXTRACTION + "/";
        String sourceFolderValidateExtractOutput = EndPointsConstants.OSB_NFS_VALIDATE_EXTRACT_OUTPUT + "/";
        String sourceFolderPushToDBOutput = EndPointsConstants.OSB_NFS_PUSH_TO_DB_OUTPUT + "/";
        fileTransferBO.setHostIp(hostIp);
        fileTransferBO.setHostUserName(userName);
        fileTransferBO.setHostPassowrd(hostPassword);
        fileTransferBO.setHostPort(Integer.parseInt(connectionPortString));
        if ((VALIDATE_EXTRACT.equals(bulkRegistrationForm.getValidateDataExtract()))) {
            fileTransferBO.setSourceFolder(sourceFolderValidateExtract);
            fileTransferBO.setDestinationFolder(destinationFolderValidateExtract);
        } else if ((DATA_EXTRACTION.equals(bulkRegistrationForm.getValidateDataExtract()))) {
            fileTransferBO.setSourceFolder(sourceFolderDataExtraction);
            fileTransferBO.setDestinationFolder(destinationFolderDataExtraction);
        } else if ((VALIDATE_EXTRACT_OUTPUT.equals(bulkRegistrationForm.getValidateDataExtract()))) {
            fileTransferBO.setSourceFolder(sourceFolderValidateExtractOutput);
            fileTransferBO.setDestinationFolder(destinationFolderDataExtraction);
        } else if ((PUSH_TO_DB_OUTPUT.equals(bulkRegistrationForm.getValidateDataExtract()))) {
            fileTransferBO.setSourceFolder(sourceFolderPushToDBOutput);
            fileTransferBO.setDestinationFolder(destinationFolderDataExtraction);
        }

        LOG.debug("Leaving setFileTransferBO...");
        return fileTransferBO;

    }


    /***Author:Sumanta
     * Method used to create a String with all the content from the copied output file in local
     * @param fileName
     * @return
     */
    public String getFileAsString(String fileName) throws RecoveryServiceException {
        LOG.debug("enterring getFileAsString...");
        String outputFileAsString = fileUtil.convertFileToString(fileName);
        LOG.debug("Leaving getFileAsString...");
        return outputFileAsString;
    }


    /**Author:Sumanta
     * Used to delete the file from current user directory
     * @param fileName
     */
    public void performRemoveFile(String fileName) {
        LOG.debug("Enetring  performRemoveFile ..." + fileName);
        fileUtil.deleteFileFromLocal(fileName);
        LOG.debug("Leaving  performRemoveFile");

    }

    /**Author:Sumanta
     *Sets the audit record common attributes
     * @param bulkRegistrationForm
     * @return
     */
    private AuditRecordBO getAuditRecordBO(AuditRecordBO auditRecord) {

        HttpServletRequest req =
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        //AuditRecordBO auditRecord=new AuditRecordBO ();
        LOG.debug("req.getUserPrincipal().getName().." + req.getUserPrincipal().getName());
        auditRecord.setUserID(req.getUserPrincipal().getName()); //check
        auditRecord.setUsername(req.getUserPrincipal().getName()); //check
        // auditRecord.setIhi("IHI");//check

        auditRecord.setVendor("NIO");
        auditRecord.setComponentSource("NIO");
        auditRecord.setProductName("OPS Tool");
        auditRecord.setEventSource("OPS Tool");
        auditRecord.setProdoctVersion("1.1");
        auditRecord.setPlatForm("Linux");
        auditRecord.setRole("NIO_BULK_REGISTRATION_SYSTEM_OPERATOR");
        auditRecord.setTransactionStatus("COMPLETED"); //check
        auditRecord.setStatus(true); //check
        auditRecord.setMessageLogLevel("AUDIT"); //check
        auditRecord.setAccessLevel(AUDIT_USER_ACCESS_LEVEL);
        auditRecord.setDescription("Success"); //chek
        return auditRecord;


    }


    /**
     * This method call the DAO layer to get the error list.
     * @return
     */
    public List<String> getDistinctErrorCode() {
        return bulkRegistrationDAO.getDistinctErrorCode();
    }

    /**
     *
     * @param bulkRegistrationForm
     * @return
     */
    public BulkRegistrationForm executeReconcileReport(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException {
              if("reconcileRepo".equals(bulkRegistrationForm.getReconReportType())){
                 bulkRegistrationForm= bulkRegistrationDAO.generateReconsileRport(bulkRegistrationForm);
              }else if("discrepancyRepo".equals(bulkRegistrationForm.getReconReportType())){
                  if(bulkRegistrationForm.getReconRegistrationState().equals("FE") || bulkRegistrationForm.getReconRegistrationState().equals("")){
                       LOG.debug("Calling generateDescripencyRportFEAndAll ........ ");
                       bulkRegistrationForm=  bulkRegistrationDAO.generateDescripencyRportFEAndAll(bulkRegistrationForm); 
                  }else{
                      LOG.debug("Calling generateDescripencyRport ........ ");
                      bulkRegistrationForm=  bulkRegistrationDAO.generateDescripencyRport(bulkRegistrationForm);
                  }
              }
                
                return bulkRegistrationForm;
            }

    /**
     *Used to check DHS file format for fixing the pen test defect
     * @param fileName
     * @return
     */
    private boolean fileFormatCheck(String fileName) {
        LOG.debug("inseide fileFormatCheck.."+fileName);
        boolean fileExtensionCheck = false;
        boolean fileFomartCheck = false;
        if (fileName != null && fileName.length() > 0) {
            // String fileNameFromUI = bulkRegistrationForm.getFileName();
            if (fileName.equals("")) {
                LOG.debug("File not found");
                fileFomartCheck = false;
            } else if ((fileName.indexOf(".") < 0)) {
                fileFomartCheck = false;
            } else if (!(fileName.substring(fileName.indexOf('.'), fileName.length())).equalsIgnoreCase(".txt")) {
                fileFomartCheck = false;
            } else {
                fileExtensionCheck = true;
            }


        }
        if (fileExtensionCheck) {
            if (!fileUtil.fileNameFormatValidation(fileName)) {
                fileFomartCheck = false;
                //invalid file format
                LOG.debug("file name validation is failed from service");


            } else {
                fileFomartCheck = true;
            }
        }
        LOG.debug("File format chec status:::"+fileFomartCheck);
        LOG.debug("Leaving fileFormatCheck..");
        
        return fileFomartCheck;

    }
}
