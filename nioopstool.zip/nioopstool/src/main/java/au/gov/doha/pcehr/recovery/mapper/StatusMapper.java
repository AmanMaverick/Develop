package au.gov.doha.pcehr.recovery.mapper;

import au.gov.doha.pcehr.recovery.bo.BulkRegistrationStatusBO;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StatusMapper implements RowMapper<BulkRegistrationStatusBO>{
    @Override
    public BulkRegistrationStatusBO mapRow(ResultSet rs, int i) throws SQLException {
        // TODO Implement this method
        BulkRegistrationStatusBO statusBO = new BulkRegistrationStatusBO();
        statusBO.setError("ERROR");
        statusBO.setIHI(rs.getBigDecimal("IHI"));
        statusBO.setState("STATE");
        return statusBO;
    }
}
