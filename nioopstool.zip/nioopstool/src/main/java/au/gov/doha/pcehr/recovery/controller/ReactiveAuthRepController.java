package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.service.ReactiveAuthRepService;
import au.gov.doha.pcehr.recovery.validation.ReactivateAuthRepValidaor;

import javax.servlet.http.HttpServletRequest;

import javax.validation.Valid;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;


/**
 * @Author Vikash Kumar Singh(10994193)
 * @since 18 Sept 2014
 */
@Controller
public class ReactiveAuthRepController {
    
    private static Logger LOG = Logger.getLogger(ReactiveAuthRepController.class);
    
    @Autowired
    private ReactiveAuthRepService reactiveAuthRepService;
    
    @Autowired
    @Qualifier("reactivateAuthRepValidaor")
    private ReactivateAuthRepValidaor validator;
    
    @InitBinder("ReactivateAuthRepBO")
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
    
    /**
     *
     * @param reActivateAuthRepBO
     * @return
     * @see Reactivate Authorized Representatives Page
     */
    @AuditBefore(AuditMessageConstants.REACTIVE_AUTH_REP_Page)
    @RequestMapping(value="/ReactivateAuthorizedRepresentatives", method=RequestMethod.GET)
    public String ReactivateAuthReCtrl(@ModelAttribute("ReactivateAuthRepBO" )ReactivateAuthRepBO reActivateAuthRepBO){
        return "/NIO/ReactivateAuthorizedRepresentatives";
    }
        
    /**
     *
     * @param reActivateAuthRepBO
     * @param result
     * @param request
     * @param map
     * @return
     */
    @AuditBefore(AuditMessageConstants.REACTIVE_AUTH_REP_OPERATION)
    @RequestMapping(value="/ReactivateAuthorizedRepresentativesScript", method=RequestMethod.POST)
    public String ReactivateAuthRepServiceController(@Valid @ModelAttribute("ReactivateAuthRepBO" )ReactivateAuthRepBO reActivateAuthRepBO, 
                                          BindingResult result, HttpServletRequest request, ModelMap map){
        if (result.hasErrors()) {
            LOG.info("......"+result.hasErrors() + result.toString());
            map.addAttribute("validationError","validationError");
            return "/NIO/ReactivateAuthorizedRepresentatives";
        }
        try{    
            reActivateAuthRepBO.setRecordIHI(reActivateAuthRepBO.getIhi());
           
            HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            String userName = req.getUserPrincipal().getName();
           
            reActivateAuthRepBO = reactiveAuthRepService.reActivateAuthRepScriptService(reActivateAuthRepBO,userName);
            map.addAttribute("reActivateAuthRepBO",reActivateAuthRepBO);
        }catch(Exception e){
            return "/NIO/ReactivateAuthorizedRepresentatives";
        }
        return "/NIO/ReactivateAuthorizedRepresentatives";
    }
    
    /**
     *This message is used to handle exception
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(ServiceException ex) {
        LOG.info("doaexception handler......");
        ModelAndView model = new ModelAndView("/NIO/ReactivateAuthorizedRepresentatives");
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............."+ex.getMessage());
        return model;
    }
    
}
