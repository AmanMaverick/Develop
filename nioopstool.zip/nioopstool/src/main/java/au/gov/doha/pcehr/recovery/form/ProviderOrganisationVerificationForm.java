package au.gov.doha.pcehr.recovery.form;


public class ProviderOrganisationVerificationForm {

    private String hpio;
    
    private int countoim;
    
    private int countoid;
    
    private int oim_provcount;
        
    private int oid_useridcount;

    public void setOim_provcount(int oim_provcount) {
        this.oim_provcount = oim_provcount;
    }

    public int getOim_provcount() {
        return oim_provcount;
    }

    public void setOid_useridcount(int oid_useridcount) {
        this.oid_useridcount = oid_useridcount;
    }

    public int getOid_useridcount() {
        return oid_useridcount;
    }

    public void setHpio(String hpio) {
        this.hpio = hpio;
    }

    public String getHpio() {
        return hpio;
    }

    public void setCountoid(int countoid) {
        this.countoid = countoid;
    }

    public int getCountoid() {
        return countoid;
    }

    public void setCountoim(int countoim) {
        this.countoim = countoim;
    }

    public int getCountoim() {
        return countoim;
    }

}
