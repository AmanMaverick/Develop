package au.gov.doha.pcehr.recovery.bo;


public class DocumentReinstateWSClientBO {
  private String docId;
    private String ihi;
    private String username;
    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocId() {
        return docId;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
