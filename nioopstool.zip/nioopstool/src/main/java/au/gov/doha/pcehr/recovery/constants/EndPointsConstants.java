package au.gov.doha.pcehr.recovery.constants;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.Properties;

import org.apache.log4j.Logger;


public class EndPointsConstants {
    private static Logger LOG = Logger.getLogger(EndPointsConstants.class);
    public static String INITIAL_CONTEXT_FACTORY = "";
    public static String WEBLOGIC_PROVIDER_URL = "";
    public static String WEBLOGIC_JNDI_NAME_PNA = "";
    public static String WEBLOGIC_JNDI_NAME_HTB = "";
    public static String WEBLOGIC_JNDI_NAME_OIM = "";
    public static String WEBLOGIC_JNDI_NAME_OSB = "";
    public static String PNA_OIM_DISABLE_ENDPOINT = "";
    public static String PNA_OIM_DISABLE_USERNAME = "";
    public static String PNA_OIM_DISABLE_PASSWORD = "";
    public static String WEBLOGIC_JNDI_NAME_RLS = "";
    public static String HOST_NAME = "";
    public static String OSB_ENDPOINT = "";
    public static String OSB_USERNAME = "";
    public static String OSB_PASSWORD = "";

    public static String PNA_AR_RESTRICT_ENDPOINT = "";

    public static String PNA_ENDPOINT = "";
    public static String PNA_USERNAME = "";
    public static String PNA_PASSWORD = "";
    public static String PNA_CA_ENDPOINT = "";
    public static String PNA_ARRESTRICT_ENDPOINT = "";
    public static String UPDATE_DOC_ENDPOINT = "";
    public static String UNREMOVE_DOC_ENDPOINT = "";
    public static String PERSITATOMIC_ENDPOINT = "";
    public static String SYNCHRONISE_IHI_ENDPOINT = "";
    public static String DEPRECATE_ATOMIC_DATA_ENDPOINT = "";
    public static String PNA_UPDATE_ENDPOINT = "";
    public static String PNA_UA_ENDPOINT = "";
    public static String PNA_OES_AC_ENDPOINT = "";
    public static String PNA_AUTH_USERNAME = "";
    public static String PNA_AUTH_PWD = "";
    public static String GET_DOC_LIST_ENDPOINT = "";
    public static String OSB_DEVF_PASSWORD = "";
    public static String REMOVE_DOC_ENDPOINT_DEVF = "";
    public static String PNA_CIP_ENDPOINT = "";
    public static String SYNC_IHI_ENDPOINT = "";


    public static String HTB_GETDOC = "";
    public static String HTB_PASSWORD = "";
    public static String HTB_USERNAME = "";
    public static String OAG_GETDOC = "";
    public static String OAG_USERNAME = "";
    public static String OAG_PASSWORD = "";
    public static String PRODUCT_VERSION="";
    //TIP
    public static String OSB_REGISTER_PCEHR = "";
    public static String SEARCH_IHI = "";
    public static String OSB_GET_VIEW = "";
    
    public static String DOCX_GETVIEW_USERNAME;
    public static String DOCX_GETVIEW_PASSWORD;
    public static String DOCXVIEW_HDR_ENDOPINT;
    public static String HDR_USERNAME;
    public static String HDR_PASSWORD;
//OPT-OUT
    public static String OSB_NFS_HOSTIP = "";
    public static String OSB_NFS_USEERNAME = "";
    public static String OSB_NFS_PASSWORD = "";
    public static String OSB_NFS_PORT = "";
    public static String OSB_NFS_SOURCEFOLDER_VALIDATE_EXTRACT = "";
    public static String OSB_NFS_DESTINATIONFOLDER_VALIDATE_EXTRACT = "";
    public static String OSB_NFS_SOURCEFOLDER_DATA_EXTRACTION = "";
    public static String OSB_NFS_DESTINATIONFOLDER_DATA_EXTRACTION = "";
    public static String OSB_NFS_VALIDATE_EXTRACT_OUTPUT = "";
    public static String OSB_NFS_PUSH_TO_DB_OUTPUT = "";
    
 
    public static String SSH_PRIVATE_KEY_LOCATION = "";
    public static String SSH_PRIVATE_KEY_NAME="";
   //MobileVendorApplikcation 
   public static String OSB_MOBILE_VENDOR_APPLICATION_ENDPOINT="";
    public static String OSB_MOBILE_VENDOR_APPLICATION_LIST_ENDPOINT="";
    static {
        try {
            Properties myProp = new Properties();
            String os = System.getProperty("os.name");
            String configFileLocation1 = null;
            if (null != os && os.contains("Linux")) {
                configFileLocation1 = System.getProperty("user.dir") + "/Configuration/EndPoints.properties";
                LOG.debug("configFileLocation1" + configFileLocation1);
            } else {
                configFileLocation1 = System.getProperty("user.dir") + "\\Configuration\\EndPoints.properties";
                LOG.debug("configFileLocation1" + configFileLocation1);
            }
            myProp.load(new FileInputStream(configFileLocation1));
            INITIAL_CONTEXT_FACTORY = myProp.getProperty("Initial_Context_Factory");
            UPDATE_DOC_ENDPOINT = myProp.getProperty("UpdateDocumentStatus_EndPoint");
            UNREMOVE_DOC_ENDPOINT = myProp.getProperty("UnremoveDocument_EndPoint");
            PERSITATOMIC_ENDPOINT = myProp.getProperty("PersistAtomicData_EndPoint");
            SYNCHRONISE_IHI_ENDPOINT = myProp.getProperty("SynchroniseIHI_EndPoint");
            DEPRECATE_ATOMIC_DATA_ENDPOINT = myProp.getProperty("DeprecateAtomicData_EndPoint");
            PNA_UPDATE_ENDPOINT = myProp.getProperty("PNA_UpdateNominated_EndPoint");
            PNA_UA_ENDPOINT = myProp.getProperty("PNA_UpdateAuth_EndPoint");
            WEBLOGIC_PROVIDER_URL = myProp.getProperty("WebLogic_Provider_Url");
            WEBLOGIC_JNDI_NAME_PNA = myProp.getProperty("WebLogic_Jndi_Name_PNA");
            WEBLOGIC_JNDI_NAME_HTB = myProp.getProperty("WebLogic_Jndi_Name_HTB");
            WEBLOGIC_JNDI_NAME_RLS = myProp.getProperty("WebLogic_Jndi_Name_RLS");
            WEBLOGIC_JNDI_NAME_OIM = myProp.getProperty("WebLogic_Jndi_Name_OIM");
            WEBLOGIC_JNDI_NAME_OSB = myProp.getProperty("WebLogic_Jndi_Name_OSB");
            PNA_OIM_DISABLE_ENDPOINT = myProp.getProperty("PNA_OIMDisable");
            PNA_OIM_DISABLE_USERNAME = myProp.getProperty("PNA_OIMDisable_Username");
            PNA_OIM_DISABLE_PASSWORD = myProp.getProperty("PNA_OIMDisable_Password");
            PNA_ENDPOINT = myProp.getProperty("PNA_EndPoint");
            PNA_USERNAME = myProp.getProperty("PNA_Username");
            PNA_PASSWORD = myProp.getProperty("PNA_Password");
            PNA_CA_ENDPOINT = myProp.getProperty("PNA_CreateAuthRep_EndPoint");
            PNA_ARRESTRICT_ENDPOINT = myProp.getProperty("PNA_ARRestrict");
            PNA_OES_AC_ENDPOINT = myProp.getProperty("PNA_AuthoriseRestrict_EndPoint");
            OSB_ENDPOINT = myProp.getProperty("AuditInsert_EndPoint");
            PNA_AUTH_USERNAME = myProp.getProperty("PNA_AUTH_USERNAME");
            PNA_AUTH_PWD = myProp.getProperty("PNA_AUTH_PWD");
            OSB_USERNAME = myProp.getProperty("OSB_Username");
            OSB_PASSWORD = myProp.getProperty("OSB_Password");
            HOST_NAME = myProp.getProperty("HostName");

            PNA_AR_RESTRICT_ENDPOINT = myProp.getProperty("PNA_ARRestrict");

            OSB_DEVF_PASSWORD = myProp.getProperty("OSB_Devf_Password");
            REMOVE_DOC_ENDPOINT_DEVF = myProp.getProperty("RemoveDocument_EndPoint_Devf");
            GET_DOC_LIST_ENDPOINT = myProp.getProperty("GetDocumentList_EndPoint");
            PNA_CIP_ENDPOINT = myProp.getProperty("PNA_CleanIndividualProfile_EndPoint");
            SYNC_IHI_ENDPOINT = myProp.getProperty("SynchroniseIHI_EndPoint");

            HTB_GETDOC = myProp.getProperty("Get_DocumentHTB_Endpoint");
            OAG_GETDOC = myProp.getProperty("Get_DocumentOAG_Endpoint");
            OAG_USERNAME = myProp.getProperty("OAG_Username");
            OAG_PASSWORD = myProp.getProperty("OAG_Password");
            HTB_PASSWORD = myProp.getProperty("HTB_Password");
            HTB_USERNAME = myProp.getProperty("HTB_Username");
            //TIP
            OSB_REGISTER_PCEHR = myProp.getProperty("OSB_Register_PCEHR");
            SEARCH_IHI = myProp.getProperty("SearchIHI_EndPoint");
            
            //product version
            PRODUCT_VERSION=myProp.getProperty("Product_Version");
            OSB_GET_VIEW=myProp.getProperty("OSBGetView_EndPoint");
            HDR_USERNAME=myProp.getProperty("HDR_Username");
            HDR_PASSWORD=myProp.getProperty("HDR_Password");
            DOCXVIEW_HDR_ENDOPINT=myProp.getProperty("DocXView_HDR_Endpoint");
            //OPT-OUT
            OSB_NFS_HOSTIP=myProp.getProperty("OsbNfs_HostIP");
            OSB_NFS_USEERNAME=myProp.getProperty("OsbNfs_Host_UserName");
            OSB_NFS_PASSWORD=myProp.getProperty("OsbNfs_Host_PassWord");
            OSB_NFS_PORT=myProp.getProperty("OsbNfs_Host_Port");
            OSB_NFS_SOURCEFOLDER_VALIDATE_EXTRACT=myProp.getProperty("OsbNfs_Host_SourceFolderValidateExtract");
            OSB_NFS_DESTINATIONFOLDER_VALIDATE_EXTRACT=myProp.getProperty("OsbNfs_Host_DestinationFolderValidateExtract");
            OSB_NFS_SOURCEFOLDER_DATA_EXTRACTION=myProp.getProperty("OsbNfs_Host_SourceFolderDataExtraction");
            OSB_NFS_DESTINATIONFOLDER_DATA_EXTRACTION=myProp.getProperty("OsbNfs_Host_DestinationFolderDataExtraction");
            OSB_NFS_VALIDATE_EXTRACT_OUTPUT=myProp.getProperty("OsbNfs_ValidateExtract_OutPut");
            OSB_NFS_PUSH_TO_DB_OUTPUT = myProp.getProperty("OsbNfs_PushToDB_OutPut");
            //private kety for jsch connection without password
            String fileSeperator=File.separator;
            String homeDirectory = System.getProperty("user.home");
            //changes to only get the location of the file
            SSH_PRIVATE_KEY_LOCATION=homeDirectory+fileSeperator+".ssh"+fileSeperator;
            //changes to get the private key file name as it differs from telstra and NTT
            SSH_PRIVATE_KEY_NAME=myProp.getProperty("SSH_PrivateKey_Name");
            
            OSB_MOBILE_VENDOR_APPLICATION_ENDPOINT=myProp.getProperty("OSB_MobileVendorApplications_EndPoint");
            OSB_MOBILE_VENDOR_APPLICATION_LIST_ENDPOINT=myProp.getProperty("OSB_MobileVendorApplicationsList_EndPoint");
        } catch (IOException ioe) {
            LOG.fatal("Exception occured while instantiating constants..", ioe);
            System.out.println("I/O Exception.");
            ioe.printStackTrace();
        }

    }


}
