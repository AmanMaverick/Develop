package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.ARrestrictionBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Used to interact with oes_pnadb database tables to collect STATUS from PCEHR_RECORD Table
 * @author Vikash Kumar Singh
 * @since 22nd Apr 2016
 * @version Change-x
 */
@Component
public class ARRestrictionDAO {
    
    //LOG variable for logging purpose
    private static final Logger LOG = Logger.getLogger(ARRestrictionDAO.class);
    
    @Autowired
    @Qualifier("pnaJDBCTemplate")
    private JdbcTemplate pnaJdbcTemplate;

    @Value("${AR_RESTRICTION.GET_PCEHR_RECORD}") 
    private String getPCEHRRecordQUery;

    public enum MyHealthRecordStatus{
        ACTIVE("Active"), 
        NOT_ACTIVE("Not Active"),
        SUSPENDED_BUT_ACTIVE("Suspended but active"),
        SUSPENDED_BUT_INACTIVE("Suspended but inactive");
        
        private String value;

        MyHealthRecordStatus(String value){
            this.value = value;
        }
    }
    
    /**
     * Status of PCEHR Record - must be 1 if Record_Deceased = 1
            0 = Active (Default),
            1 = Not Active,
            2 = Suspended but active,
            3 = Suspended but inactive

     * @param arRestrictionBO
     * @return
     */
    public ARrestrictionBO getPCEHRRecord(ARrestrictionBO arRestrictionBO) throws RecoveryDAOException {
        String myHealthRecordStatus = null;
        try{
            myHealthRecordStatus =  pnaJdbcTemplate.queryForObject(
            getPCEHRRecordQUery,
            new Object[]{arRestrictionBO.getIHI()}, String.class);
        }catch(Exception e){
            LOG.fatal("Not Present in PCEHR RECORD : " + arRestrictionBO.getIHI());
        }
        if(myHealthRecordStatus != null && !"".equals(myHealthRecordStatus)){
            arRestrictionBO.setMyHealthRecord(ARrestrictionBO.myHealthecordFound.YES.getOption());
            int statusCode = Integer.parseInt(myHealthRecordStatus);
            switch(statusCode){
                case 0 : arRestrictionBO.setMyHealthRecordStatus(MyHealthRecordStatus.ACTIVE.value); break; 
                case 1 : arRestrictionBO.setMyHealthRecordStatus(MyHealthRecordStatus.NOT_ACTIVE.value); break;
                case 2 : arRestrictionBO.setMyHealthRecordStatus(MyHealthRecordStatus.SUSPENDED_BUT_ACTIVE.value); break;
                case 3 : arRestrictionBO.setMyHealthRecordStatus(MyHealthRecordStatus.SUSPENDED_BUT_INACTIVE.value); break;
            }
        }else{
            arRestrictionBO.setMyHealthRecordStatus("Not Applicable");
            arRestrictionBO.setMyHealthRecord(ARrestrictionBO.myHealthecordFound.NO.getOption());
        }
        return arRestrictionBO;
       
    }
}
