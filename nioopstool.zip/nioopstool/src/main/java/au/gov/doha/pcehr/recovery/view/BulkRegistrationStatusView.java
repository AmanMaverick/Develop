package au.gov.doha.pcehr.recovery.view;

import au.gov.doha.pcehr.recovery.bo.BulkRegistrationStatusBO;
import au.gov.doha.pcehr.recovery.constants.RecoverConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import org.springframework.stereotype.Service;

@Service
public class BulkRegistrationStatusView {
    private static Logger LOG = Logger.getLogger(BulkRegistrationStatusView.class);   
    private static final String FILE_NAME = "BulkRegistration_StatusReport.xls";   
    /**
     *Used to build xls status report
     * @param model
     * @param workbook
     * @param request
     * @param response
     * @throws Exception
     */
    
    public Workbook buildExcelDocument(List<BulkRegistrationStatusBO> bulkGenerationStatusReport,String reportType)
                    throws  RecoveryServiceException {
        LOG.debug("Entered into the excel viiew");
        Workbook wb = new SXSSFWorkbook(100); 
        
        
        if("ALL IHI".equals(reportType)){
            wb = getALLIHI(bulkGenerationStatusReport,wb);
        }else if("List of IHIs".equals(reportType)){
            wb = getforGivenIHI(bulkGenerationStatusReport,wb);
        }else if("File Name".equals(reportType)) {
            wb = getByFile(bulkGenerationStatusReport,wb);
        }
        
        return wb;
        
    }
    
    /**
     *
     * @param bulkGenerationStatusReport
     * @param wb
     * @return
     */
    private Workbook getALLIHI(List<BulkRegistrationStatusBO> bulkGenerationStatusReport,Workbook wb){
        SXSSFSheet sheet = (SXSSFSheet) wb.createSheet("Status Report - All IHI");
        sheet.createRow(0).createCell(0).setCellValue("Count of all IHI");
        sheet.createRow(1).createCell(0);
        
        
        SXSSFRow header = sheet.createRow(2);
        
        
        header.createCell(0).setCellValue("Loaded");
        header.createCell(1).setCellValue("Omitted");
        header.createCell(2).setCellValue("Validation Completed");
        header.createCell(3).setCellValue("Registration Complete");
        header.createCell(4).setCellValue("Functional Errors");
        header.createCell(5).setCellValue("Technical Error");
        header.createCell(6).setCellValue("Null");
        header.createCell(7).setCellValue("Total IHI");
        
        int rowNum = 3;
        int sheetCount = 1;
        LOG.info("size of objects:::"+bulkGenerationStatusReport.size());
        DataFormat format = wb.createDataFormat();
        for(BulkRegistrationStatusBO bulkRegistrationStatusBO :  bulkGenerationStatusReport ){      
            if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                sheet = (SXSSFSheet) wb.createSheet("SatusReport"+sheetCount);
                rowNum=0;
                sheetCount++;
            }
            SXSSFRow row = sheet.createRow(rowNum++);            
            row.createCell(0).setCellValue(bulkRegistrationStatusBO.getLoaded());
            row.createCell(1).setCellValue(bulkRegistrationStatusBO.getOmitted());
            row.createCell(2).setCellValue(bulkRegistrationStatusBO.getValidationCompleted());
            row.createCell(3).setCellValue(bulkRegistrationStatusBO.getRegistrationCompleted());
            row.createCell(4).setCellValue(bulkRegistrationStatusBO.getFunctionalError());
            row.createCell(5).setCellValue(bulkRegistrationStatusBO.getTechnicalError());
            row.createCell(6).setCellValue(bulkRegistrationStatusBO.getNulldata());
            row.createCell(7).setCellValue(bulkRegistrationStatusBO.getTotalIHI());
            bulkRegistrationStatusBO=null;
        }
        
        
        return wb;
    }
    
    private Workbook getforGivenIHI(List<BulkRegistrationStatusBO> bulkGenerationStatusReport,Workbook wb){
        SXSSFSheet sheet = (SXSSFSheet) wb.createSheet("Status Report - IHI List");
        SXSSFRow header = sheet.createRow(0);
        header.createCell(0).setCellValue("IHI");
        header.createCell(1).setCellValue("State");
        header.createCell(2).setCellValue("Error Description");
        
        int rowNum = 1;
        int sheetCount = 1;
        LOG.info("size of objects:::"+bulkGenerationStatusReport.size());
        
        for(BulkRegistrationStatusBO bulkRegistrationStatusBO :  bulkGenerationStatusReport ){      
            if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                sheet = (SXSSFSheet) wb.createSheet("SatusReport"+sheetCount);
                rowNum=0;
                sheetCount++;
            }
            SXSSFRow row = sheet.createRow(rowNum++);            
            row.createCell(0).setCellValue(bulkRegistrationStatusBO.getIHI().toString());
            row.createCell(1).setCellValue(bulkRegistrationStatusBO.getState());
            row.createCell(2).setCellValue(bulkRegistrationStatusBO.getError());
            bulkRegistrationStatusBO=null;
        }
        
        return wb;
        
    }
    
    /**
     *
     * @param bulkGenerationStatusReport
     * @param wb
     * @return
     */
    private Workbook getByFile(List<BulkRegistrationStatusBO> bulkGenerationStatusReport,Workbook wb){
        SXSSFSheet sheet = (SXSSFSheet) wb.createSheet("Status Report-By File");
        SXSSFRow header = sheet.createRow(0);
        header.createCell(0).setCellValue("File Name");
        header.createCell(1).setCellValue("Loaded");
        header.createCell(2).setCellValue("Omitted");
        header.createCell(3).setCellValue("Validation Completed");
        header.createCell(4).setCellValue("Registration Complete");
        header.createCell(5).setCellValue("Functional Errors");
        header.createCell(6).setCellValue("Technical Error");
        header.createCell(7).setCellValue("Null");
        header.createCell(8).setCellValue("Total IHI");
       
        int rowNum = 1;
        int sheetCount = 1;
        LOG.info("size of objects:::"+bulkGenerationStatusReport.size());
        
        for(BulkRegistrationStatusBO bulkRegistrationStatusBO :  bulkGenerationStatusReport ){      
            if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                sheet = (SXSSFSheet) wb.createSheet("SatusReport"+sheetCount);
                rowNum=0;
                sheetCount++;
            }
            SXSSFRow row = sheet.createRow(rowNum++);            
            row.createCell(0).setCellValue(bulkRegistrationStatusBO.getFileName());
            row.createCell(1).setCellValue(bulkRegistrationStatusBO.getLoaded());
            row.createCell(2).setCellValue(bulkRegistrationStatusBO.getOmitted());
            row.createCell(3).setCellValue(bulkRegistrationStatusBO.getValidationCompleted());
            row.createCell(4).setCellValue(bulkRegistrationStatusBO.getRegistrationCompleted());
            row.createCell(5).setCellValue(bulkRegistrationStatusBO.getFunctionalError());
            row.createCell(6).setCellValue(bulkRegistrationStatusBO.getTechnicalError());
            row.createCell(7).setCellValue(bulkRegistrationStatusBO.getNulldata());
            row.createCell(8).setCellValue(bulkRegistrationStatusBO.getTotalIHI());
            bulkRegistrationStatusBO=null;
        }
        
        
        return wb;
    }
}
