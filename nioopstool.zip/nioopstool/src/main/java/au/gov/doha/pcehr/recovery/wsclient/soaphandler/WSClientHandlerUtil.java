package au.gov.doha.pcehr.recovery.wsclient.soaphandler;

//import com.oracle.webservices.impl.internalapi.session.scope.Scope;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;

import java.io.ByteArrayOutputStream;

import java.util.Collections;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.context.annotation.Scope;

/**
 * Class that implements a SOAPHandler in the handler chain, used to access the SOAP
 * request and response message.
 * <p>
 * The class implements the <code>javax.xml.ws.handler.soap.SOAPHandler</code>
 * interface. The class simply prints the SOAP request and response messages
 * to a log file before the messages are processed by the backend component.
 *
 * @author Vikash Kumar Singh      PCEHR       Operations
 * @see au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver
 * @version v0.0.0.1
 * @since 4th Aug 2015
 */
@Service
public class WSClientHandlerUtil implements SOAPHandler<SOAPMessageContext>{
    private static Logger LOG = Logger.getLogger(WSClientHandlerUtil.class);
    @Override
    public Set<QName> getHeaders() {
        // TODO Implement this method
        return Collections.emptySet();
    }
    
    @Autowired
    private SOAPMessageUtil soapMessageUtil;
    
 


    /**
     * Specifies that the SOAP request be logged to a log file before the
     * message is sent to the Java class backend component and
     * SOAP response message be logged to a log file before the
     * message is sent back to the client application that invoked the Web service.
     * If outgoing value is true then it is a an Outbound message(request)
     * If outgoing value is false then it is a an Outbound message(response)
     */
    @Override
    public boolean handleMessage(SOAPMessageContext sOAPMessageContext) {
      LOG.debug("inside handleMessage of WSClientHandlerUtil");
        // TODO Implement this method
        boolean outgoing = (Boolean) sOAPMessageContext.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        SOAPMessage soapMsg = sOAPMessageContext.getMessage();
        String soapMessage = soapMessageUtil.serialiseSoapXml(soapMsg);
        if (outgoing) {
            LOG.debug(" SOAP Request ----- \n" + soapMessage + "\n");
          
            sOAPMessageContext.put("soapRequest", soapMessage); 
            sOAPMessageContext.setScope("soapRequest", MessageContext.Scope.APPLICATION);
        } else {
            LOG.debug(" SOAP Response ----- \n" + soapMessage + "\n");
          
            sOAPMessageContext.put("soapResponse", soapMessage); 
            sOAPMessageContext.setScope("soapResponse", MessageContext.Scope.APPLICATION);
        }
        LOG.debug("Leaving handleMessage of WSClientHandlerUtil");
        return true;
    }
    
   
  /**
   * Specifies that a message be logged to the log file if a SOAP fault is
   * thrown by the Handler instance.
   */
    @Override
    public boolean handleFault(SOAPMessageContext sOAPMessageContext) {
        SOAPMessage soapMsg = sOAPMessageContext.getMessage();
        String soapMessage = soapMessageUtil.serialiseSoapXml(soapMsg);
        LOG.debug(" ** Fault: \n" + soapMessage + "\n");
        sOAPMessageContext.put("soapResponse", soapMessage); 
        sOAPMessageContext.setScope("soapResponse", MessageContext.Scope.APPLICATION);
       return true;
    }


    @Override
    public void close(MessageContext messageContext) {
        // TODO Implement this method
    }
}
