package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.AuditEntryMissingBO;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;


/**
 * This DAO layer fetch data from RLS DB for Audit Entry Missing.
 * @Author Sumanta
 */

@Component
public class AuditEntryMissingDAO {
    private static Logger LOG = Logger.getLogger(AuditEntryMissingDAO.class);
    private static final String CLASS_CODE_60591_5 = "60591-5";
    private static final String CLASS_CODE_57133_1 = "57133-1";
    private static final String CLASS_CODE_51852_2 = "51852-2";
    private static final String CLASS_CODE_18842_5 = "18842-5";
    private static final String CLASS_CODE_34133_9 = "34133-9";
    private static final String CLASS_CODE_100_16764 = "100.16764";
    private static final String CLASS_CODE_100_16765 = "100.16765";
    private static final String CLASS_CODE_100_16681 = "100.16681";
    private static final String CLASS_CODE_100_16685 = "100.16685";
    private static final String CLASS_CODE_100_16696 = "100.16696";
    private static final String CLASS_CODE_100_16812 = "100.16812";
    private static final String CLASS_CODE_100_16870 = "100.16870";
    private static final String CLASS_CODE_100_16919 = "100.16919";
    //new code for Advanced care documents - as per the WP28 - R7 - varsion : Delta v0.0.4
    //Removed CLASS_CODE_52521_2, CLASS_CODE_52687_1 and CLASS_CODE_100_16998 
    //Added Advance Care Planning Document = 100.16998^^NCTIS
    private static final String CLASS_CODE_100_16998 = "100.16998";
    
    //new codes for DI and PATH view
    private static final String CLASS_CODE_100_16957 = "100.16957";
    private static final String CLASS_CODE_100_32001 = "100.32001";
    //AuditeEventID for Advanced care documents
    private static final String AUDIT_EVENT_ID_ACP = "AE015";

    @Autowired
    @Qualifier("rlsJDBCTemplate")
    private JdbcTemplate rlsJDBCTemplate;

    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJDBCTemplate;

    @Autowired
    @Qualifier("rlsNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate rlsNamedParameterJdbcTemplate;

    @Autowired
    @Qualifier("osbNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate osbNamedParameterJdbcTemplate;


    @Autowired
    @Qualifier("pnaNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate pnaNamedParameterJdbcTemplate;


    /**
     *This method is used to retruve the details for audit entry fields from RLS database
     * @param documentListToken
     * @return
     */
    public List<AuditEntryMissingBO> retrieveIHIDetailsFromRLS(String documentDetails) {
        LOG.debug("Entered to DAO - retrieveIHIDetailsFromRLS");
        List<String[]> documentDetailsList = new ArrayList<String[]>();
        String[] docDetails = null;
        String[] documentDetailsArray = null;

        List<AuditEntryMissingBO> auditEntryList = new ArrayList<AuditEntryMissingBO>();
        if (documentDetails.isEmpty() || documentDetails.equals(null)) {
            return auditEntryList;
        }

        int count = 0;
        String documentId = null;
        String[] details = null;
        String ihi = null;
        String integrationID = null;
        String messageID = null;
        String transcationDateTime = null;
        String systemType = null;
        int intAuditCount = 0;

        try {
            StringBuffer queryRLS = new StringBuffer();
            //StringBuffer queryOSB = new StringBuffer();
            queryRLS.append(" SELECT  OP_PERF.CNT AS count,                                                                                                                                                                                                  " +
                            "        IHI_DATA.IHI as IHI, IHI_DATA.IHI_NAME AS IHI_NAME, IHI_DATA.STOP_TIME as STOP_TIME,                                                                                                           " +
                            "        IHI_DATA.HIPI as HIPI, IHI_DATA.ACC_HIPO as ACC_HIPO, IHI_DATA.INH_HIPO as INH_HIPO,                                                                                                           " +
                            "        IHI_DATA.ACCESS_LEVEL as ACCESS_LEVEL,IHI_DATA.TYPE_CODE AS TYPE_CODE,IHI_DATA.REPOSITORY_ID  as REPOSITORY_ID                                                                                                                                                   " +
                            " FROM                                                                                                                                                                                                  " +
                            " (                                                                                                                                                                                                     " +
                            " SELECT PATIENT_ID IHI,TYPE_CD TYPE_CODE, SERVICE_STOP_TIME STOP_TIME,                                                                                                                                                   " +
                            "       EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Slot[@name=\"sourcePatientInfo\"]/ValueList/Value/text()',                                                                                         " +
                            "                                                   'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() IHI_NAME,                                                                   " +
                            "       EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Classification[@classificationScheme=\"urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d\"]/Slot[@name=\"authorPerson\"]/ValueList/Value/text()',      " +
                            "                                                   'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() HIPI,                                                                       " +
                            "       EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Slot[@name=\"repositoryUniqueId\"]/ValueList/Value/text()',      " +
                            "                                                   'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() REPOSITORY_ID,                                                                       " +
                            "       EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Slot[@name=\"urn:nehta:ihe:xds:metadata:accessingOrg\"]/ValueList/Value/text()',                                                                   " +

                            "                                                   'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() ACC_HIPO,                                                                   " +
                            "       EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Classification[@classificationScheme=\"urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d\"]/Slot[@name=\"authorInstitution\"]/ValueList/Value/text()', " +
                            "                                                   'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() INH_HIPO,                                                                   " +
                            "       EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Classification[@classificationScheme=\"urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f\"]/@nodeRepresentation',                                      " +
                            "                                                   'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() ACCESS_LEVEL                                                                " +
                            " FROM hrlcore.DOC_ENTRY where doc_uid = :docID                                                                                                                                                              " +
                            " order by version desc                                                                                                                                                                                 " +
                            " ) IHI_DATA,                                                                                                                                                                                           " +
                            " (                                                                                                                                                                                                     " +
                            " select count(*) CNT from hrlcore.association_oth                                                                                                                                                      " +
                            " where assoc_type = 'RP'                                                                                                                                                                               " +
                            " and sourceobj in (select id as docid from hrlcore.doc_entry                                                                                                                                           " +
                            "                  where doc_uid = :docID)                                                                                                                                                                   " +
                            " ) OP_PERF ");
            documentDetailsArray = documentDetails.split("\n");
            for (int i = 0; i < documentDetailsArray.length; i++) {
                LOG.info("documentDetails after spliting new line :::::" + documentDetailsArray[i]);
                docDetails = documentDetailsArray[i].split(",");
                documentDetailsList.add(docDetails);
            }


            for (String[] docDetailsOnSplit : documentDetailsList) {
                if (docDetailsOnSplit.length >= 1)
                    documentId = docDetailsOnSplit[0];

                if (docDetailsOnSplit.length >= 2)
                    integrationID = docDetailsOnSplit[1];

                if (docDetailsOnSplit.length >= 3)
                    messageID = docDetailsOnSplit[2];

                if (docDetailsOnSplit.length >= 4)
                    systemType = docDetailsOnSplit[3];

                if (docDetailsOnSplit.length == 5)
                    transcationDateTime = docDetailsOnSplit[4];

                LOG.debug("Document ID : " + documentId);
                LOG.debug("messageID : " + messageID);
                LOG.debug("transcationDateTime : " + transcationDateTime);
                LOG.debug("systemType : " + systemType);

                Map namedParameters = new HashMap();
                namedParameters.put("docID", documentId);
                LOG.info("rls query");
                List<Map<String, Object>> listRLS =
                    rlsNamedParameterJdbcTemplate.queryForList(queryRLS.toString(), namedParameters);
                AuditEntryMissingBO auditEntryMissingBO = new AuditEntryMissingBO();
                auditEntryMissingBO.setDocumentID(documentId);
                Map rowRLS = null;
                if (listRLS != null && !listRLS.isEmpty()) {
                    rowRLS = listRLS.get(0);
                    auditEntryMissingBO.setRlsEntryExists(true);
                    ihi = getIHI(rowRLS.get("IHI") != null ? rowRLS.get("IHI").toString() : null);
                    LOG.info("ihi :::" + ihi);
                    List<Map<String, Object>> listOSB = getOSBList(ihi, documentId);
                    Map rowOSB = listOSB != null ? listOSB.get(0) : null;

                    if (rowOSB != null && !rowOSB.isEmpty()) {
                        intAuditCount = Integer.parseInt(rowOSB.get("total").toString());
                        LOG.info("intAuditCount :::" + intAuditCount);
                        if (intAuditCount == 0) {
                            auditEntryMissingBO.setAuditEntryExists(false);
                            if (systemType == null || systemType.length() == 0) {
                                auditEntryMissingBO.setSystemType(getSystemType(rowRLS.get("REPOSITORY_ID").toString(),
                                                                                getClassCode(rowRLS.get("TYPE_CODE").toString()),
                                                                                ihi, rowRLS.get("HIPI")));
                            } else {
                                auditEntryMissingBO.setSystemType(systemType);
                            }
                            if (auditEntryMissingBO.getSystemType() == null ||
                                auditEntryMissingBO.getSystemType().length() == 0) {
                                LOG.debug("class code does not exists.....dao");
                                auditEntryMissingBO.setClassCodeExsits(false);
                            } else {
                                LOG.debug("class code exists.....dao");
                                auditEntryMissingBO.setClassCodeExsits(true);
                                if (auditEntryMissingBO.getSystemType().equalsIgnoreCase("NCP") ||
                                    auditEntryMissingBO.getSystemType().equalsIgnoreCase("CIS")) {
                                    count = ((BigDecimal) rowRLS.get("count")).intValue();
                                    LOG.info("count :::" + count);
                                    if (count == 0) {
                                        auditEntryMissingBO.setOperationPerfomed("uploadDocument");
                                    } else {
                                        auditEntryMissingBO.setOperationPerfomed("uploadDocumentAmendment");
                                    }
                                } else if (auditEntryMissingBO.getSystemType().equalsIgnoreCase("CRP")) {
                                    if (count == 0) {
                                        auditEntryMissingBO.setOperationPerfomed("uploadDocumentMetadata");
                                    } else {
                                        auditEntryMissingBO.setOperationPerfomed("uploadDocumentMetadataAmendment");
                                    }
                                }
                                auditEntryMissingBO.setIhi(ihi);
                                //if(rowRLS.get("IHI_NAME")==null || rowRLS.get("IHI_NAME")!=null){
                                LOG.info("Get ihinameTest.....................::" + rowRLS.get("IHI_NAME"));
                                String ihiName = getIHIName(rowRLS.get("IHI_NAME"), ihi);
                                LOG.info("ihinameTest :::" + ihiName);
                                if (ihiName == null) {
                                    auditEntryList.add(auditEntryMissingBO);
                                    continue;
                                }
                                // }
                                auditEntryMissingBO.setIhiName(ihiName);
                                if (transcationDateTime == null || transcationDateTime.length() == 0) {
                                    auditEntryMissingBO.setServiceStopTime(rowRLS.get("STOP_TIME") != null ?
                                                                           rowRLS.get("STOP_TIME").toString() : null);
                                } else {
                                    auditEntryMissingBO.setServiceStopTime(transcationDateTime);
                                }
                                details = getHPIIDetails(rowRLS.get("HIPI").toString());

                                auditEntryMissingBO.setAuthorPerson(details[1]);
                                auditEntryMissingBO.setAuthorPersonName(details[0]);
                                if (rowRLS.get("ACC_HIPO") != null && !rowRLS.get("ACC_HIPO").toString().isEmpty()) {
                                    details = getHPIODetails(rowRLS.get("ACC_HIPO").toString());
                                } else {
                                    details = getHPIODetails(rowRLS.get("INH_HIPO").toString());
                                }
                                auditEntryMissingBO.setAccessingOrg(details[1]);
                                auditEntryMissingBO.setAccessingOrgName(details[0]);
                                details = getHPIODetails(rowRLS.get("INH_HIPO").toString());
                                auditEntryMissingBO.setInheritingOrg(details[1]);
                                auditEntryMissingBO.setInheritingOrgName(details[0]);
                                auditEntryMissingBO.setAccessLevel(getAccessLevel(rowRLS.get("ACCESS_LEVEL").toString()));
                                auditEntryMissingBO.setIntegrationID(integrationID);
                                auditEntryMissingBO.setMessageID(messageID);
                                //AuditEvetID
                                String currClassCode=getClassCode(rowRLS.get("TYPE_CODE").toString());
                                //if(CLASS_CODE_52521_2.equals(currClassCode) || CLASS_CODE_52687_1.equals(currClassCode) || CLASS_CODE_100_16998.equals(currClassCode)){
                                if(CLASS_CODE_100_16998.equals(currClassCode)){
                                   LOG.debug("setting the audit event ID for ACP docs::"+AUDIT_EVENT_ID_ACP);
                                    auditEntryMissingBO.setAuditEventID(AUDIT_EVENT_ID_ACP);
                                }
                                //
                                LOG.debug("servce stop time:::" + auditEntryMissingBO.getServiceStopTime());

                                LOG.debug("access level VAL::" + rowRLS.get("ACCESS_LEVEL") != null ?
                                          rowRLS.get("ACCESS_LEVEL").toString() : null);
                                LOG.debug("OperationPerfomed" + auditEntryMissingBO.getOperationPerfomed());
                            }
                        } else {
                            LOG.info("audit entry exists....");
                            auditEntryMissingBO.setAuditEntryExists(true);
                        }
                    } else {
                        LOG.info("row osb doesnot exits...");
                    }
                } else {
                    auditEntryMissingBO.setRlsEntryExists(false);
                }
                auditEntryList.add(auditEntryMissingBO);

            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
        }
        LOG.debug("End of method retrieveIHIDetailsFromRLS");
        return auditEntryList;
    }

    /**
     *
     * @param ihi
     * @param documentID
     * @return
     */
    public List<Map<String, Object>> getOSBList(String ihi, String documentID) {
        List<Map<String, Object>> osbList;
        StringBuffer queryOSB = new StringBuffer();
        queryOSB.append(" select (AUDITLOG.audittotal + DLQ.dlqtotal) as total from (                                                                                                       " +
                        " SELECT count(*) as audittotal from pcehr_osb_audit.audit_log where ihi = :IHI and operation_performed in         " +
                        "     ('uploadDocument','uploadDocumentAmendment','uploadDocumentMetadata','uploadDocumentMetadataAmendment') and user_access_permission ='Permit' and subject = :docID) AUDITLOG,                                   " +
                        " (select count(*) as dlqtotal from pcehr_osb_audit.dlq where ihi = :IHI and document_id = :docID and state = 'N') DLQ ");

        Map namedParameters = new HashMap();
        namedParameters.put("IHI", ihi);
        namedParameters.put("docID", documentID);
        osbList = osbNamedParameterJdbcTemplate.queryForList(queryOSB.toString(), namedParameters);
        return osbList;
    }

    /**
     * This method fetches the HIPO details.
     * @param organizationDetails
     * @return
     */
    public String[] getHPIODetails(String organizationDetails) {
        LOG.debug("Start of method getHPIODetails:" + organizationDetails);
        String[] returnDetails = new String[2];
        String hpioNumber = null;
        int position = 0;
        try {
            if (null != organizationDetails) {
                String[] data = organizationDetails.split("\\^");
                returnDetails[0] = data[0];
                hpioNumber = data[data.length - 1];
                position = hpioNumber.lastIndexOf(".") + 1;
                hpioNumber = hpioNumber.substring(position, position + 16);
                returnDetails[1] = hpioNumber;
            }
        } catch (Exception e) {
            LOG.error("Exception occurred in getHPIODetails ::" + e.getMessage());
        }
        LOG.debug("End of method getHPIODetails");
        return returnDetails;
    }

    /**
     * This method fetches the HIIP details.
     * @param organizationDetails
     * @return
     */
    public String[] getHPIIDetails(String organizationDetails) {
        LOG.debug("Start of method getHPIIDetails.... " + organizationDetails);

        String[] returnDetails = new String[2];
        try {
            String hpiiNumber = null;
            int position = 0;
            if (null != organizationDetails) {

                String[] data = organizationDetails.split("\\^");
                if (null == data[5] || data[5].isEmpty()) {
                    returnDetails[0] = data[2] + " " + data[1];
                } else {
                    returnDetails[0] = data[5] + " " + data[2] + " " + data[1];
                }
                hpiiNumber = data[data.length - 1];
                LOG.debug("data length:::" + data.length);

                if (data.length == 9) {
                    if (!hpiiNumber.contains("80036")) {
                        hpiiNumber = data[data.length - 2];
                        LOG.debug("hpii value:::not..80036" + hpiiNumber);
                    }
                    position = hpiiNumber.lastIndexOf(".") + 1;
                    if (hpiiNumber.contains("80036")) {
                        hpiiNumber = hpiiNumber.substring(position, position + 16);
                        LOG.debug("hpii value:::80036" + hpiiNumber);
                    }
                } else if (data.length == 10) {
                    hpiiNumber = hpiiNumber.replaceAll("&amp;", "");
                    hpiiNumber = hpiiNumber.replaceAll("ISO", "");
                    if (hpiiNumber.contains("80036")) {
                        position = hpiiNumber.lastIndexOf(".") + 1;
                        hpiiNumber = hpiiNumber.substring(position, position + 16);
                        LOG.debug("hpii value:::lenght==10" + hpiiNumber);
                    }

                } else {
                    /**
                    * IF legth is not 9 or 10(^^NPDR^^^^&amp;1.2.36.1.2001.1003.0.8003616566666841&amp;ISO)
                    * 1. Array of Strings = Split the last string(&amp;1.2.36.1.2001.1003.0.8003616566666841&amp;ISO) based on &amp;
                    * 2.Get secound last string from the above array(1.2.36.1.2001.1003.0.8003616566666841)
                    * 3.Array of Strings = split the above string based on dot
                    * 4.Retrive last string from the above array(8003616566666841)
                    */


                    String[] hpiitemp = hpiiNumber.split("&amp;");
                    LOG.debug("here.." + hpiitemp[hpiitemp.length - 2]);

                    if (hpiitemp.length > 1) {
                        LOG.debug("hello...");
                        String userids[] = hpiitemp[hpiitemp.length - 2].split("\\.");
                        LOG.debug("value:::" + userids[userids.length - 1]);
                        hpiiNumber = userids[userids.length - 1];
                    }
                }
                returnDetails[1] = hpiiNumber;
                LOG.debug("fibal HPII number value" + hpiiNumber);
            }

        } catch (Exception e) {
            LOG.error("Exception occurred in getHPIIDetails ::" + e.getMessage());
        }
        LOG.debug("End of method getHPIIDetails");
        return returnDetails;
    }

    /**
     *
     * @param ihiname
     * @param ihi
     * @return
     */


    private String getIHIName(Object ihiname, String ihi) {
        LOG.info("Entered into the getIHIName method.");
        String ihiName = "";
        if (ihiname != null) {
            LOG.debug("not calling oes db as IHI name is not null");
            ihiName = ihiname.toString();
        } else {
            //code change for getting IHIname from OES panadb
            LOG.debug("calling oes db as IHI name is null");
            return getIHINameFromOES(ihi);
        }
        LOG.debug("IHI Name in method getIHIName :::" + ihiName);

        try {
            int pos = ihiName.indexOf("PID-5|");
            ihiName = ihiName.substring(pos + 6, ihiName.indexOf("PID-", pos + 6));
            String[] ihiNameArr = ihiName.split("\\^");
            if (null == ihiNameArr) {
                return "";
            }
            LOG.debug("End of method getIHIName" + ihiNameArr[2] + " " + ihiNameArr[1] + " " + ihiNameArr[0]);
            return ihiNameArr[2] + " " + ihiNameArr[1] + " " + ihiNameArr[0];
        } catch (Exception e) {
            LOG.error("Exception occurred in getIHIName ::" + e.getMessage());
            return "";
        }
    }

    /**
     *
     * @param ihi
     * @return
     */
    private String getIHI(String ihi) {
        LOG.debug("Start of method getIHI" + ihi);
        if (null == ihi || ihi.trim().equals("")) {
            return "";
        }
        try {
            ihi = ihi.substring(0, 16);
            LOG.debug("End of method getIHI");
            return ihi;
        } catch (Exception e) {
            LOG.error("Exception occurred in getIHI ::" + e.getMessage());
            return "";
        }
    }

    /**
     * This method fetches the document access levels.
     * @param strAccessLevel
     * @return
     */
    private String getAccessLevel(String strAccessLevel) {
        LOG.debug("Start of method getAccessLevel" + strAccessLevel);
        if (null == strAccessLevel) {
            return "";
        }
        try {
            if ("GENERAL".equals(strAccessLevel)) {
                strAccessLevel = "General";
            } else if ("LIMITED".equals(strAccessLevel)) {
                strAccessLevel = "Limited";
            } else {
                strAccessLevel = "";
            }
            LOG.debug("End of method getAccessLevel.." + strAccessLevel);

            return strAccessLevel;
        } catch (Exception e) {
            LOG.error("Exception occurred in getIHI ::" + e.getMessage());
            return "";
        }
    }

    /**
     *
     * @param repositoryId
     * @param classCode
     * @return
     */
    private String getSystemType(String repositoryId, String classCode, String ihi, Object authorPerson) {
        String pcehrRepositoryID = "1.2.36.1.2001.1007.10.8003640002000050";
        LOG.debug("rep id::::" + repositoryId);
        LOG.debug("Class code:::" + classCode);

        if (!pcehrRepositoryID.equalsIgnoreCase(repositoryId)) {
            LOG.debug("systemType :::CRP");
            return "CRP";
        } else if (CLASS_CODE_60591_5.equals(classCode) || CLASS_CODE_57133_1.equals(classCode) ||
                   CLASS_CODE_51852_2.equals(classCode) || CLASS_CODE_18842_5.equals(classCode) ||
                   CLASS_CODE_34133_9.equals(classCode) || CLASS_CODE_100_16764.equals(classCode) ||
                   CLASS_CODE_100_16765.equals(classCode) || CLASS_CODE_100_16957.equals(classCode) ||
                   CLASS_CODE_100_32001.equals(classCode)) {
            LOG.debug("systemType :::CIS");
            return "CIS";
        } else if (CLASS_CODE_100_16681.equals(classCode) || CLASS_CODE_100_16685.equals(classCode) ||
                   CLASS_CODE_100_16696.equals(classCode) || CLASS_CODE_100_16812.equals(classCode) ||
                   CLASS_CODE_100_16870.equals(classCode) || CLASS_CODE_100_16919.equals(classCode)) {
            LOG.debug("systemType :::NCP");
            return "NCP";
        }
        //for ACP documents
        else if (CLASS_CODE_100_16998.equals(classCode)) {

            if (authorPerson != null) {
                String authorPersonStingVal = authorPerson.toString();
                if (authorPersonStingVal.contains("800360")) {
                    return "NCP";
                } else if (authorPersonStingVal.contains("800361") || authorPersonStingVal.contains("800362")) {
                    return "CIS";
                }

            }


        }

        return null;
    }

    /**
     *
     * @param classCode
     * @return
     */
    private String getClassCode(String classCode) {
        if (null != classCode && classCode.length() > 0) {
            String data[] = classCode.split("\\^");
            LOG.debug("class code value::" + data[0]);
            return data[0];
        }

        return classCode;

    }

    /**
     *
     * @param ihi
     * @return
     */
    //retrieve IHI name from OES_PNADB if IHI_NAME is not found in RLS
    private String getIHINameFromOES(String ihi) {
        LOG.debug("Entering  getIHINameFromOES ihi" + ihi);
        String finalIHIName = "";
        Map namedParameters = new HashMap();
        StringBuffer queryPna = new StringBuffer();
        queryPna.append("select family_name,given_name from OES_PNADB.demographics where ihi=:IHI");
        namedParameters.put("IHI", ihi);
        List<Map<String, Object>> list =
            pnaNamedParameterJdbcTemplate.queryForList(queryPna.toString(), namedParameters);
        LOG.debug("IHI value for " + ihi + " : " + list);
        if (list != null || list.size() > 0) {
            for (Map row : list) {
                String givenName = row.get("given_name") != null ? row.get("given_name").toString() : "";
                if (row.get("family_name") == null) {
                    return null;
                }
                String familyName = row.get("family_name").toString();
                finalIHIName = givenName + " " + familyName;
            }
            LOG.debug("leaving getIHINameFromOES final name::" + finalIHIName);
            return finalIHIName;
        } else {
            LOG.debug("leaving getIHINameFromOES final name::" + finalIHIName);
            return null;
        }


    }
   

}
