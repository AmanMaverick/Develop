package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.ARrestrictionBO;
import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.dao.ARRestrictionDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ARrestrictForm;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.wsclient.PNAARRestricterClient;

import au.pcehr.ws.pna.common.ApplicationResponse;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * This service class performs Auth Representative Restriction Operation by execucuting pnaPCEHRPNA_ARRestricter webservice
 * and updating logs in OSB DB by executing InsertAuditRecordService webservice.
 * @Author Vikash Kumar Singh(10994193), Operations Team,  PCEHR
 * @since 18 Nov 2014
 *
 */
@Service
public class ARRestrictionsService
{
    //LOG variable for logging purpose
    private static final Logger LOG = Logger.getLogger(ARRestrictionsService.class);
    //Failed status constant
    private static final String FAILED_STATUS = "PNA AR Restrict Failed";
    
    @Autowired
    private PNAARRestricterClient pnaARRestrict;
    
    @Autowired
    InsertAuditRecordService insertAuditRecordService;
    
    @Autowired
    private FileUtil fileUtil;
    
    @Autowired
    private ARRestrictionDAO arRestrictionDAO;
    
    public static final String OUTPUT_FILE_NAME = "OutputFile_";
    public static final String INVALID_DATA_FILE_MESSAGE = "Execution interrupted because of one or multiple error. " +
        "Please refer the following file for more information \n" +
        "File path : ";
    public static final String VALID_DATA_FILE_MESSAGE = "Process Completed Successfully. " +
        "Check the following file for more information.\n" +
        "File path : ";
    
    /**
     * This method is used to collect ARrestrictBO object from controller and pass it to executePNAarRestrict method.
     * This will get the ARRestrictionsService operation performed.
     * @param arRestrict
     * @return ARrestrictBO
     */
    public ARrestrictionBO executeSingleARRestriction(ARrestrictForm arRestrict)throws RecoveryServiceException{
        try{
            ARrestrictionBO arRestrictionBO = setARRestrictionBO(arRestrict);
            LOG.debug("Inside ARRestrictionsService");
            arRestrictionBO = executePNAarRestrict(arRestrictionBO, "dd/MM/yyyy");
            insertAudit(arRestrictionBO);            
            return arRestrictionBO;
        }catch(Exception e){
            LOG.fatal("Exception Occured", e);
            throw new RecoveryServiceException(e);    
        }
    }
    //When Valid Data is avalable, PNA ARRestricter Service will be called for AR Restriction of each entry and capture status.
    //Otherwise invalid data will be returned to the controller to generate Error File.
    public String executeBulkARRestriction(ARrestrictForm arRestrict) throws RecoveryServiceException{
        try{
        String message = "";
        List<ARrestrictionBO> arRestrictionOutputList = new ArrayList<ARrestrictionBO>();
        Map<String, List<ARrestrictionBO>> outPutMap= fileUtil.getARRestrictionFormSet(arRestrict.getFile());
        List<ARrestrictionBO> arRestrictionBOList = outPutMap.get("ValidData");
        String actionType = arRestrict.getAction_type();
        String jiraId = arRestrict.getJira_id();
        String operatorName = arRestrict.getOperatorName();
        String userId = arRestrict.getUserID();
        if(arRestrictionBOList != null && arRestrictionBOList.size() > 0){
            LOG.debug("Calling ws for " + arRestrictionBOList.size() + " records.");
            for(int i = 0; i < arRestrictionBOList.size(); i++){
                ARrestrictionBO arRestrictionBO = arRestrictionBOList.get(i);
                arRestrictionBO.setActionType(actionType);
                arRestrictionBO.setJiraId(jiraId);
                arRestrictionBO.setOperatorName(operatorName);
                arRestrictionBO.setUserId(userId);
                // Return arRestrictionBO With WS Response Status.
                arRestrictionBO = executePNAarRestrict(arRestrictionBO, "dd.MM.yyyy");  
                //g.	Record Present in My Health Record
                //h.	My Health Record Status
                arRestrictionBO = arRestrictionDAO.getPCEHRRecord(arRestrictionBO);
                insertAudit(arRestrictionBO);
                arRestrictionOutputList.add(arRestrictionBO);
            }
            
            message = VALID_DATA_FILE_MESSAGE + writeARRestrictionOutputFile(arRestrictionOutputList);
        }else{
            arRestrictionOutputList = outPutMap.get("InValidData");
            message = INVALID_DATA_FILE_MESSAGE + writeARRestrictionOutputFile(arRestrictionOutputList);
        }
            return message;
        }catch(Exception e){
            throw new RecoveryServiceException("Exception Occur while processing input file : ", e);
        }
    }
    /**
     *This method will execute the pnaPCEHRPNA_ARRestricter webservice and returns the response
     * with response status. Using this status, proper message will be set into alertMessage business object.
     * @param arRestrict
     * @return ARrestrictBO
     * @throws RecoveryServiceException
     */
    
    
    


    private ARrestrictionBO executePNAarRestrict(ARrestrictionBO arRestrictionBO, String expiryDateformat) throws ParseException,
                                                                                         DatatypeConfigurationException,
                                                                                         Exception {
        arRestrictionBO.setComments(new StringBuilder(""));
        boolean status = false;
        ApplicationResponse pnaResponse = pnaARRestrict.pnaPCEHRPNA_ARRestricter(arRestrictionBO, expiryDateformat);
        LOG.debug("pnaResponse GetStatusCode ::  " + pnaResponse.getStatusCode().intValue() + ". Status - " + pnaResponse.getStatusDescription());
        switch (pnaResponse.getStatusCode().intValue()) {
                case 60: arRestrictionBO.setComments(arRestrictionBO.getComments().append("Invalid Common Parameter").append(FAILED_STATUS));
                         status = false;
                         break;
                case 358: arRestrictionBO.setComments(arRestrictionBO.getComments().append("IHI restriction to prevent appointment of AR or Record creation successfully created. PNA AR Restrict Creation Success"));
                          status = true;
                          break;
                case 359: arRestrictionBO.setComments(arRestrictionBO.getComments().append("Creation of IHI restriction to prevent appointment of AR or record creation failed. PNA AR Restrict Creation Failed"));
                          status = false;
                          break;
                case 360: arRestrictionBO.setComments(arRestrictionBO.getComments().append("IHI restriction successfully updated. PNA AR Restrict Update Success"));
                          status = true;
                          break;
                case 361: arRestrictionBO.setComments(arRestrictionBO.getComments().append("IHI restriction update failed. PNA AR Restrict Update Failed"));
                          status = false;
                          break;
                case 362: arRestrictionBO.setComments(arRestrictionBO.getComments().append("IHI restriction to prevent appointment of AR or record creation successfully removed. PNA AR Restrict Success"));
                          status = true;
                          break;
                case 363: arRestrictionBO.setComments(arRestrictionBO.getComments().append("Removal of IHI restriction to prevent appointment of AR or record creation failed").append(FAILED_STATUS));
                          status = false;
                          break;
                case 1000: arRestrictionBO.setComments(arRestrictionBO.getComments().append("Description of corresponding technical exception").append(FAILED_STATUS));
                           status = false;
                           break;
                case 61: arRestrictionBO.setComments(arRestrictionBO.getComments().append("Invalid Functional Parameter").append(FAILED_STATUS));
                         status = false;
                         break;
                case 364: arRestrictionBO.setComments(arRestrictionBO.getComments().append("Restricted IHI already exists").append(FAILED_STATUS));
                          status = false;
                          break;
                case 365: arRestrictionBO.setComments(arRestrictionBO.getComments().append("Restricted IHI does not exist").append(FAILED_STATUS));
                          status = false;
                          break;
        }
        if(status){
            arRestrictionBO.setStatus("Successful");       
        }else{
            arRestrictionBO.setStatus("Failed");  
        }
        arRestrictionBO.setWsStatus(status);
        //AuditRecordBO audit = insertAudit(arRestrict, status);
        return arRestrictionBO;
    }

    /**
         * This method will call getAuditRecordBO to set all the reuest values into aRrestrictBO object for updating audit logs.
         * The returned object will be passed to insertAudit method of InsertAuditRecordService and audit details will be updated.
         * @param aRrestrict
         * @param status
         * @return ARrestrictBO
         * @throws RecoveryServiceException
         */
        private AuditRecordBO insertAudit(ARrestrictionBO arRestrictionBO) throws RecoveryServiceException
        {
            try{
                LOG.debug("Inside insertAudit Method .... ");
               // InsertAuditRecordService audit = new InsertAuditRecordService();
                AuditRecordBO auditRecord = getAuditRecordBO(arRestrictionBO);
                auditRecord = insertAuditRecordService.insertAudit(auditRecord);
                LOG.debug("Return insertAudit Method .... ");
                return auditRecord;
            }catch(Exception e){
                LOG.fatal("Exception Occured", e);
                throw new RecoveryServiceException(e);    
            }
        }
    
        /**
         * Collecting data to perform Insert Audit.
         * @param aRrestrict
         * @param status
         * @return ARrestrictBO
         */
        private AuditRecordBO getAuditRecordBO(ARrestrictionBO arRestrictionBO)throws RecoveryServiceException
        {
            try{
                AuditRecordBO auditRecordBO = new AuditRecordBO();
                LOG.debug("getUserID :: " +arRestrictionBO.getUserId());
                auditRecordBO.setUserID(arRestrictionBO.getUserId());
                auditRecordBO.setUsername(arRestrictionBO.getOperatorName());
                auditRecordBO.setIhi(arRestrictionBO.getIHI());
                auditRecordBO.setVendor("NIO - PNA setARRestrictions");
                auditRecordBO.setProductName("setARRestrictions");
                auditRecordBO.setProdoctVersion("1.1");
                auditRecordBO.setPlatForm("Jump Host");
                auditRecordBO.setTransactionStatus("COMPLETED");
                auditRecordBO.setBusinessEvent("setARRestrictions");
                auditRecordBO.setComponentSource("NIO - PNA setARRestrictions");
                auditRecordBO.setIhiName(arRestrictionBO.getIHI());
                auditRecordBO.setSubject(arRestrictionBO.getIHI());
                auditRecordBO.setSubjectType("IHI");
                auditRecordBO.setOperationPerfomed("setARRestrictions");
                auditRecordBO.setReason(null);
                String actionType = arRestrictionBO.getActionType();
                if(actionType.equals("CREATE")||actionType.equals("UPDATE")||actionType.equals("REMOVE") ){
                    auditRecordBO.setActionType("Update");
                }
                auditRecordBO.setOperationPerfomed("setARRestrictions");
                auditRecordBO.setAccessConditions("OpenAccess");
                auditRecordBO.setAccessLevel("Self");
                auditRecordBO.setSystemType("Other");
                auditRecordBO.setStatus(arRestrictionBO.isWsStatus());
                if(arRestrictionBO.isWsStatus())
                {
                    auditRecordBO.setStatusCode("PCEHR_SUCCESS");
                    auditRecordBO.setDescription("Success");
                } else
                {
                    auditRecordBO.setStatusCode("PCEHR_ERROR");
                    auditRecordBO.setDescription("Error");
                }
                auditRecordBO.setMessageLogLevel("AUDIT");
                auditRecordBO.setSoapMesage("");
                return auditRecordBO;
            }catch(Exception e){
                LOG.fatal("Exception Occured", e);
                throw new RecoveryServiceException(e);    
            }
        }

    private ARrestrictionBO setARRestrictionBO(ARrestrictForm arRestrict) {
        ARrestrictionBO arRestrictionBO = new ARrestrictionBO();
        String operationType = arRestrict.getOperationType();
        arRestrictionBO.setActionType(arRestrict.getAction_type());
        if(operationType.equals("single")){
            arRestrictionBO.setIHI(arRestrict.getIHI());
            arRestrictionBO.setExpireDate(arRestrict.getExpire_date());            
        }else if(operationType.equals("bulk")){
            arRestrictionBO.setFile(arRestrict.getFile());  
        }
        arRestrictionBO.setJiraId(arRestrict.getJira_id());
        arRestrictionBO.setOperatorName(arRestrict.getOperatorName());
        arRestrictionBO.setUserId(arRestrict.getUserID());      
        return arRestrictionBO;
    }
    /**
     *To write output csv file
     * @param arRestrictionOutputList
     * @return
     * @throws RecoveryServiceException
     */
    public String writeARRestrictionOutputFile(List<ARrestrictionBO> arRestrictionOutputList) throws RecoveryServiceException{
        PrintWriter pw = null;
        String filePath = null;
        Date date = new Date();
        //ddMMyyyyhhmmss
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd_hh_mm_ss");
        String formatedDate = ft.format(date);
        String fileDir = System.getProperty("user.dir") + File.separator + "ARRestriction";
        Path path = Paths.get(fileDir);
        try {
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
            filePath = fileDir + File.separator + OUTPUT_FILE_NAME + formatedDate +".csv";
            //filePath = "Z:\\Operations\\Output\\Output" + formatedDate +".csv";
            File file = new File(filePath);
            if(!file.exists()){
                file.createNewFile();
            }
            pw = new PrintWriter(file);
            pw.write("IHI,First Name, Last Name,dob, NSW/QLD ID, Expiry Date Set, " +
                "Record Present in My Health Record, My Health Record Status,Status,Comment \n");
            for(int i = 0; i < arRestrictionOutputList.size(); i++){
                ARrestrictionBO a = arRestrictionOutputList.get(i);
                pw.write(a.toString());
            }
        } catch (IOException e) {
            LOG.fatal("Exception Occured", e);
            throw new RecoveryServiceException(e);
        }finally{
            pw.flush();
            pw.close();
        }
        return filePath;
    }
}
