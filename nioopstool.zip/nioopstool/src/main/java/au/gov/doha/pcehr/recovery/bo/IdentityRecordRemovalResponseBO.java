package au.gov.doha.pcehr.recovery.bo;


public class IdentityRecordRemovalResponseBO {
    public IdentityRecordRemovalResponseBO(){
        
    }
    public IdentityRecordRemovalResponseBO(String ihi,String lastName,String dob,String gender,String description) {
     this.ihi=ihi;
     this.lastName=lastName;
     this.gender=gender;
     this.dob=dob;
     this.description=description;
    }
    private String ihi;
  //  private String family_Name;
    private String lastName;
    private String dob;
    private String gender;
    private String description;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getDob() {
        return dob;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGender() {
        return gender;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }


}
