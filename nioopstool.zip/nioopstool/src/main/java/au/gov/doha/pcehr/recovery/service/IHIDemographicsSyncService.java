package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.IHISynchronizationStatusBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.IHISynchronizeForm;
import au.gov.doha.pcehr.recovery.wsclient.SingleIHISynchronizeClient;

import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Form class for IHI Synchronization
 * @Author Rakhi Tholia, Operations, PCEHR
 * @since 9th Apr 2015
 * @version Change-x
 */
@Service
public class IHIDemographicsSyncService {
    private static Logger LOG = Logger.getLogger(IHIDemographicsSyncService.class);
    @Autowired 
    private SingleIHISynchronizeClient singleIHISynchronizeClient;
    
    @Autowired
    private InsertAuditRecordService audit;

    public IHISynchronizeForm processSingleIHI(IHISynchronizeForm ihiSynchronizeForm,HttpServletRequest req) throws RecoveryServiceException {
        LOG.debug("Entered processSingleIHI.." + req.getUserPrincipal().getName());
        StringBuffer statusMessage = new StringBuffer();
        String ihi = (ihiSynchronizeForm.getIhi());
        String username = req.getUserPrincipal().getName();
        ResponseStatusType responseStatusTypeIHI = new ResponseStatusType();
        responseStatusTypeIHI =
                singleIHISynchronizeClient.synchroniseIHIDetails(responseStatusTypeIHI, ihi, username);
        statusMessage.append("<BR><BR> IHI : ").append(ihi).append(" ");
        LOG.debug("Code Returned:"+responseStatusTypeIHI.getCode());
        statusMessage.append(responseStatusTypeIHI.getCode().equals("PCEHR_SUCCESS") ? "SUCCESS" : "FAILED");

        //call for insert audit
        LOG.debug("before insert audit call..");
        AuditRecordBO audit = insertAudit(ihiSynchronizeForm, ihi, responseStatusTypeIHI.getCode());
        statusMessage.append(audit.getResponseStatusMsg());

        LOG.debug("after insert audit call..");
        LOG.debug("leaving processSingleIHI... ");
        ihiSynchronizeForm.setStatus(statusMessage.toString().replaceAll("\n", "<BR>"));
        return ihiSynchronizeForm;
    }



    /**
     * processBulkIHI calls getIHIs for fetching the list of IHIs from input file.
     * Then for each IHI it calls the SingleIHISynchronizeClient to synchronize it.
     * @param ihiSynchronizeForm
     * @return
     * @throws RecoveryServiceException
     */
    public IHISynchronizeForm processBulkIHI(IHISynchronizeForm ihiSynchronizeForm) throws RecoveryServiceException {
        LOG.debug("Entered processBulkIHI..");
        List<IHISynchronizationStatusBO> ihiSyncStatusList = new ArrayList<IHISynchronizationStatusBO>();
        List<String> ihiLst = getIHIs(ihiSynchronizeForm);
        int i=0;
        
        for (String ihi : ihiLst) {
            IHISynchronizationStatusBO ihiSyncStstus = new IHISynchronizationStatusBO();
            
            ResponseStatusType responseStatusTypeIHI = new ResponseStatusType();
            responseStatusTypeIHI = singleIHISynchronizeClient.synchroniseIHIDetails(responseStatusTypeIHI, ihi, ihiSynchronizeForm.getUserName());
            ihiSyncStstus.setIhi(ihi);
            ihiSyncStstus.setCode(responseStatusTypeIHI.getCode().equals("PCEHR_SUCCESS") ? "SUCCESS" : "FAILED");
            //call for insert audit
            LOG.debug("NO............................ LOGGING.........................................................."+i);
            AuditRecordBO audit = insertAudit(ihiSynchronizeForm, ihi, responseStatusTypeIHI.getCode());
            String[] msgArray =  audit.getResponseStatusMsg().split("\n");
            ihiSyncStstus.setStatus(msgArray[3].replaceAll("Description :: ", ""));
            
            ihiSyncStatusList.add(ihiSyncStstus);
            i++;
            ihiSyncStstus=null;
        }
        ihiSynchronizeForm.setIhiSyncStatusList(ihiSyncStatusList);
        LOG.debug("leaving processBulkIHI... ");
        //ihiSynchronizeForm.setStatus(statusMessage.toString().replaceAll("\n", "<BR>"));
        return ihiSynchronizeForm;
    }

    /**
     * getIHIs method fetches the list of IHIs from input file
     * @param ihiSynchronizeForm
     * @return
     * @throws RecoveryServiceException
     */
    public List<String> getIHIs(IHISynchronizeForm ihiSynchronizeForm) throws RecoveryServiceException {
        Set<String> documentIdLst = new HashSet<String>();
        String csvSplitBy = ",";
        String[] ihi = null;
        InputStreamReader inStreamReader = null;
        BufferedReader bReader = null;
        try {
            inStreamReader = new InputStreamReader(ihiSynchronizeForm.getFile().getInputStream());
            bReader = new BufferedReader(inStreamReader);
            for (String line = bReader.readLine(); line != null; line = bReader.readLine()) {
                if (line != null && !line.equals("")) {
                    ihi = line.split(csvSplitBy);
                    documentIdLst.addAll(Arrays.asList(ihi));
                }
            }
        } catch (IOException e) {
            throw new RecoveryServiceException(e);
        } finally {
            try {
                bReader.close();
                inStreamReader.close();
            } catch (Exception e) {
                LOG.debug("Exception occured while colosing the resources..");
            }
        }
        return new ArrayList<String>(documentIdLst);
    }

    /**
     * insertAudit method calls InsertAuditRecordService's insertAudit methos for auditing purpose.
     * @param ihiSynchronizeForm
     * @param ihi
     * @return
     */
    private AuditRecordBO insertAudit(IHISynchronizeForm ihiSynchronizeForm, String ihi, String status) {
        AuditRecordBO auditBO = getAuditRecordBO(ihiSynchronizeForm, ihi, status);
        auditBO = audit.insertAudit(auditBO);
        return auditBO;
    }


    /**
     *getAuditRecordBO method sets an AuditRecordBO for auditing purpose.
     * @param ihiSynchronizeForm
     * @param ihi
     * @param status
     * @return
     */
    private AuditRecordBO getAuditRecordBO(IHISynchronizeForm ihiSynchronizeForm, String ihi, String status) {
        AuditRecordBO auditRecordBO = new AuditRecordBO();
        auditRecordBO.setUsername(ihiSynchronizeForm.getUserName());
        auditRecordBO.setUserID(ihiSynchronizeForm.getUserName());
        if ("PCEHR_SUCCESS".equals(status)) {
            auditRecordBO.setStatus(true);
            auditRecordBO.setTransactionStatus("COMPLETED");
        } else {
            auditRecordBO.setStatus(false);
            auditRecordBO.setTransactionStatus("FAILED");
        }
        auditRecordBO.setVendor("NIO");
        auditRecordBO.setProductName("synchroniseIHIDetails");
        auditRecordBO.setProdoctVersion("1.0");
        auditRecordBO.setPlatForm("Jump Host");
        auditRecordBO.setIhi(ihi);
        auditRecordBO.setActionType("Update");
        auditRecordBO.setBusinessEvent("SynchroniseIHI");
        auditRecordBO.setDescription("Transaction completed");

        auditRecordBO.setComponentSource("NIO");


        auditRecordBO.setIhiName("NA");
        auditRecordBO.setSubject(ihi);
        auditRecordBO.setSubjectType("IHI");

        auditRecordBO.setOperationPerfomed("SynchroniseIHI");

        auditRecordBO.setMessageLogLevel("AUDIT");

        auditRecordBO.setAccessConditions("OpenAccess");
        auditRecordBO.setAccessLevel("Self");
        auditRecordBO.setStatusCode("");
        auditRecordBO.setSoapMesage("");
        return auditRecordBO;
    }


}
