package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.form.MobileApplicationToolForm;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class MobileApplicationToolValidator implements Validator{
    private static Logger LOG = Logger.getLogger(MobileApplicationToolValidator.class);
    private static final String EMAIL_PATTERN="^[a-zA-Z0-9,!#\\$%&amp;'\\*\\+/=\\?\\^_`\\{\\|}~-]+(\\.[a-zA-Z0-9,!#\\$%&amp;'\\*\\+/=\\?\\^_`\\{\\|}~-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]*)*(\\.([a-zA-Z]))*$";
    private static final String MOBILE_NUMBER_PATTERN =  "(^(\\+? *[0+]+)([,0-9 ]*)([0-9 ])*$)|(^ *$)";
    
    private final String INTEGER_FORMAT = "[0-9]+";
    private final String DATE_FORMAT = "dd/MM/yyyy";
    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Inside MobileApplicationToolValidator");
        if(object instanceof MobileApplicationToolForm){
            MobileApplicationToolForm mobApp = (MobileApplicationToolForm)object;
            try{
                LOG.debug("Doing input validation for Mobile Application Tool.");
                //errors = validateMobileApplicationRegTool(mobApp, errors);
                if("CREATE".equals(mobApp.getAction())){
                    LOG.debug("CREATE....");
                        errors = validateMobileApplicationRegTool(mobApp, errors);
                } else if("UPDATE".equals(mobApp.getAction())){
                    LOG.debug("UPDATE....");
                        errors = validateMobileApplicationManTool(mobApp, errors);
                }
                
            }catch(Exception e){
               LOG.error("Exception occured",e);
            }       
        }else {
            LOG.debug("Invalid parameter !!!");
        }
    }

    @Override
    public boolean supports(Class<?> c) {
        return MobileApplicationToolForm.class.equals(c);
    }
    /**
     *
     * @param mobApp
     * @param errors
     * @return
     */
    private Errors validateMobileApplicationRegTool(MobileApplicationToolForm mobApp,Errors errors){
        LOG.debug(" validateMobileApplicationRegTool !!!");
        if(mobApp.getEmail()!=null && mobApp.getEmail().length()>0){
            if(!validateEmail(mobApp.getEmail())){
                        errors.rejectValue("email","MobileApplicationToolForm.emailFormat");
            }
        }
        if(mobApp.getMobile()!=null && mobApp.getMobile().length()>0){
            if(!validateMobileNumber(mobApp.getMobile())){
                        errors.rejectValue("mobile","MobileApplicationToolForm.mobileFormat");
            }
        }
//        if(mobApp.getVersion()!=null && mobApp.getVersion().length()>0){
//            if(!validateNumber(mobApp.getVersion())){
//                        errors.rejectValue("version","MobileApplicationToolForm.versionFormat");
//            }
//            
//            
//        }
        //phone numebr
        if(mobApp.getPhone()!=null && mobApp.getPhone().length()>0){
            if(!validateNumber(mobApp.getPhone())){
                        errors.rejectValue("phone","MobileApplicationToolForm.phoneFormat");
            }
            
            
        }
        
        
        ValidationUtils.rejectIfEmpty(errors, "application", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "vendorName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "appName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "alternateName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "version", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "callbackURL", "MobileApplicationToolForm");
        //ValidationUtils.rejectIfEmpty(errors, "callbackURLNoti", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "intent", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "fullName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "phone", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "submissionDate", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "mobile", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "email", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "businessAddress", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "suburb", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "postcode", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "state", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "applicationStatus", "MobileApplicationToolForm");
        if(null!=mobApp.getSubmissionDate() && mobApp.getSubmissionDate().length()>0){
            if(!dateValidation(mobApp.getSubmissionDate())){
                errors.rejectValue("submissionDate","MobileApplicationToolForm.submissionDateFormat");
            }
        }
        if(!validateApiList(mobApp.getApilist())){
            errors.rejectValue("apilist","MobileApplicationToolForm.apiListSize");
        }
        if(mobApp.getEmailSec()!=null && mobApp.getEmailSec().length()>0){
                 if(!validateEmail(mobApp.getEmailSec())){
                             errors.rejectValue("email","MobileApplicationToolForm.emailFormatManSecondary");
                 }
             }
             if(mobApp.getMobileSec()!=null && mobApp.getMobileSec().length()>0){
                 if(!validateMobileNumber(mobApp.getMobileSec())){
                             errors.rejectValue("mobile","MobileApplicationToolForm.mobileFormatManSecondary");
                 }
             }
        if(mobApp.getPhoneSec()!=null && mobApp.getPhoneSec().length()>0){
            if(!validateNumber(mobApp.getPhoneSec())){
                        errors.rejectValue("phoneSec","MobileApplicationToolForm.phoneFormatSec");
            }
            
            
        }
        LOG.debug("Leaving  Mobile Application Tool validator !!!");
        return errors;
    }
    /**
     *
     * @param mobApp
     * @param errors
     * @return
     */
    private Errors validateMobileApplicationManTool(MobileApplicationToolForm mobApp,Errors errors){
        LOG.debug(" validateMobileApplicationManTool !!!");
        LOG.debug("hidden form value:::"+mobApp.getAppIdMan());
        if(mobApp.getEmail()!=null && mobApp.getEmail().length()>0){
            if(!validateEmail(mobApp.getEmail())){
                        errors.rejectValue("email","MobileApplicationToolForm.emailFormatMan");
            }
        }
        if(mobApp.getMobile()!=null && mobApp.getMobile().length()>0){
            if(!validateMobileNumber(mobApp.getMobile())){
                        errors.rejectValue("mobile","MobileApplicationToolForm.mobileFormatMan");
            }
        }
//        if(mobApp.getVersion()!=null && mobApp.getVersion().length()>0){
//            if(!validateNumber(mobApp.getVersion())){
//                        errors.rejectValue("version","MobileApplicationToolForm.versionFormat");
//            }
//        }
        if(mobApp.getGroupID()!=null && mobApp.getGroupID().length()>0){
            if(!validateNumber(mobApp.getGroupID())){
                        errors.rejectValue("groupID","MobileApplicationToolForm.groupIDFormat");
            }
        }
        if(mobApp.getIntMajor()!=null &&"NO".equals(mobApp.getIntMajor())){
            LOG.debug("hidden form value:::"+mobApp.getAppIdMan());
            if(null!=mobApp.getAppIdMan()){
            if(mobApp.getAppIdMan().equals(mobApp.getApplication())){
                errors.rejectValue("application","MobileApplicationToolForm.sameApplicationFormat");
            }
            }
        }
        if(mobApp.getPhone()!=null && mobApp.getPhone().length()>0){
            if(!validateNumber(mobApp.getPhone())){
                        errors.rejectValue("phone","MobileApplicationToolForm.phoneFormat");
            }
        }
        ValidationUtils.rejectIfEmpty(errors, "applicationIdFromList", "MobileApplicationToolForm");
//        ValidationUtils.rejectIfEmpty(errors, "applicationIdMan", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "groupID", "MobileApplicationToolForm");       
        ValidationUtils.rejectIfEmpty(errors, "application", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "vendorName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "appName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "alternateName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "version", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "callbackURL", "MobileApplicationToolForm");
        //ValidationUtils.rejectIfEmpty(errors, "callbackURLNoti", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "intent", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "fullName", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "phone", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "submissionDate", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "mobile", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "email", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "businessAddress", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "suburb", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "postcode", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "state", "MobileApplicationToolForm");
        ValidationUtils.rejectIfEmpty(errors, "applicationStatus", "MobileApplicationToolForm");
        if(null!=mobApp.getSubmissionDate() && mobApp.getSubmissionDate().length()>0){
            if(!dateValidation(mobApp.getSubmissionDate())){
                errors.rejectValue("submissionDate","MobileApplicationToolForm.submissionDateFormat");
            }
        }
        if(mobApp.getIntMajor()!=null && mobApp.getIntMajor().equals("NO")){
        if(!validateApiList(mobApp.getApilist())){
            errors.rejectValue("apilist","MobileApplicationToolForm.apiListSize");
        }
        }
        if(mobApp.getEmailSec()!=null && mobApp.getEmailSec().length()>0){
                 if(!validateEmail(mobApp.getEmailSec())){
                             errors.rejectValue("email","MobileApplicationToolForm.emailFormatManSecondary");
                 }
             }
             if(mobApp.getMobileSec()!=null && mobApp.getMobileSec().length()>0){
                 if(!validateMobileNumber(mobApp.getMobileSec())){
                             errors.rejectValue("mobile","MobileApplicationToolForm.mobileFormatManSecondary");
                 }
             } 
        if(mobApp.getPhoneSec()!=null && mobApp.getPhoneSec().length()>0){
            if(!validateNumber(mobApp.getPhoneSec())){
                        errors.rejectValue("phoneSec","MobileApplicationToolForm.phoneFormatSec");
            }
            
            
        }
        LOG.debug("Leaving  Mobile Application Tool validator 2 !!!");
        return errors;
    }
    /**
     *
     * @param email
     * @return
     */
    private boolean validateEmail(String email){
        Boolean b = email.matches(EMAIL_PATTERN);
        return b;
    }
    private boolean validateMobileNumber(String number){
        Boolean b = number.matches(MOBILE_NUMBER_PATTERN);
        return b;
    }
    private boolean validateNumber(String num){
        Boolean b = num.matches(INTEGER_FORMAT);
        return b;
    }
    
    private boolean validateApiList(List apiList){
        
        return (apiList!=null && apiList.size()>0)?true:false;
    }
    /**
     *
     * @param submissionDate
     * @return
     */
    private boolean dateValidation(String submissionDate){
      
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        try {
           sdf.parse(submissionDate);
            return true;
        } catch (ParseException e) {
           LOG.fatal("exception e..."+e);
            return false;
        }
      
       
    }

}
