package au.gov.doha.pcehr.recovery.bo;


public class ProviderOrganisationVerificationBO {
    
    private String usr_login;
    
    private String oid_usr_userid;




    public void setUsr_login(String usr_login) {
        this.usr_login = usr_login;
    }

    public String getUsr_login() {
        return usr_login;
    }

    public void setOid_usr_userid(String oid_usr_userid) {
        this.oid_usr_userid = oid_usr_userid;
    }

    public String getOid_usr_userid() {
        return oid_usr_userid;
    }


}
