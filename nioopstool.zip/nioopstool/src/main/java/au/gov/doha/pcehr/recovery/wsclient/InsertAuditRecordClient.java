package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.net.electronichealth.ns.pcehr.svc.intinsertauditrecord._1.InsertAuditRecordPortType;
import au.net.electronichealth.ns.pcehr.svc.intinsertauditrecord._1.InsertAuditRecordService;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecordResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class InsertAuditRecordClient {
    
    @Autowired
    TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    
    @Autowired
    Decrypter decrypter;
    

    private static Logger LOG = Logger.getLogger(InsertAuditRecordClient.class);
    private StringBuffer soapMessage;
    
    
    public final ResponseStatusType insertAudit(final InsertAuditRecord insertAuditRecord, 
                                                final IntPCEHRHeader intPCEHRHeader)
                                                throws WebServiceClientException {
        try{
        InsertAuditRecordService insertAuditRecordService = new InsertAuditRecordService();
        insertAuditRecordService.setHandlerResolver(wSClientHandlerResolver);
        InsertAuditRecordPortType insertAuditRecordPortType = insertAuditRecordService.getInsertAuditRecordSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true,true));

        Map<String, Object> requestContext = ((BindingProvider) insertAuditRecordPortType).getRequestContext();
        
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,EndPointsConstants.OSB_ENDPOINT);
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER,testHostnameVerifier);
        requestContext.put(BindingProvider.USERNAME_PROPERTY,decrypter.decryption(EndPointsConstants.OSB_USERNAME));
        requestContext.put(BindingProvider.PASSWORD_PROPERTY,decrypter.decryption(EndPointsConstants.OSB_PASSWORD));
        Holder<InsertAuditRecordResponse> holder = new Holder<InsertAuditRecordResponse>();
        InsertAuditRecordResponse urdr = new InsertAuditRecordResponse();
        ResponseStatusType rst = new ResponseStatusType();
        urdr.setResponseStatus(rst);
        holder.value = urdr;

        insertAuditRecordPortType.insertAuditRecord(insertAuditRecord,holder,intPCEHRHeader);
        urdr = holder.value;
        rst = urdr.getResponseStatus();
        //getSoapRequestMsg();
        LOG.debug("SOAP messageAudit:");
         return rst;
        }catch(au.net.electronichealth.ns.pcehr.svc.intinsertauditrecord._1.StandardError standError) {
            LOG.fatal("Exception occured",standError);
                                     throw new WebServiceClientException(standError.getMessage(),standError);
                                      
        }catch(Exception e){
           // getSoapRequestMsg();
            LOG.fatal("Exception occured..",e);
        }
        return null;
    }
}
   