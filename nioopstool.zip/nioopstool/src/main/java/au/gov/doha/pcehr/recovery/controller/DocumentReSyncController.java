package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.DocumentReSyncForm;
import au.gov.doha.pcehr.recovery.service.DocumentReSyncService;
import au.gov.doha.pcehr.recovery.validation.DocumentReSyncValidator;

import javax.servlet.http.HttpSession;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * This class will do validation related to DocumentDetailsRe-Synchronisation functionality and perform as a cntroller
 * @Author Vikash Kumar Singh, Operations, PCEHR
 * @since 28 Nov 2014
 * @version Change-x
 */
@Controller
public class DocumentReSyncController {
    
    private static Logger LOG = Logger.getLogger(DocumentReSyncController.class);
    private static final String EXCEPTION_PAGE = "NIO/Exception";
    private static final String DOC_RE_SYNC_LANDING_PAGE = "NIO/DocumentDetailsRe-Synchronisation";
    private static final String DOC_RE_SYNC_RESPONSE = "/NIO/DocAccessLevelRecoveryResponse";
    
    @Autowired
    private DocumentReSyncService documentReSyncService;
    
    @Autowired
    private DocumentReSyncValidator docReSyncValidator;
    
    @InitBinder("DocumentReSync")
    protected void initBinderMetricTypeConfig(WebDataBinder binder) {
        LOG.debug("Initialising the validator");
        binder.setValidator(docReSyncValidator);
    }
    
    @AuditBefore(AuditMessageConstants.DOCUMENT_RE_SYNCHRONISATION_LANDING_PAGE)
    @RequestMapping(value = "/DocumentDetailsReSynchronisationCtlr", method = RequestMethod.GET)
    public String documentReSyncLandingPage(@ModelAttribute("DocumentReSync") DocumentReSyncForm documentReSync) {
        LOG.debug("Entered the DocumentReSyncController controller");
        return DOC_RE_SYNC_LANDING_PAGE;
    }
    
    
    @AuditBefore(AuditMessageConstants.DOCUMENT_RE_SYNCHRONISATION)
    @RequestMapping(value = "/DocumentReSyncUploadFile", method = RequestMethod.POST, params = "DocumentReSyncUploadFile=Submit")
    public String processDocumentReSync(@Valid@ModelAttribute("DocumentReSync") DocumentReSyncForm documentReSyncForm,BindingResult result, HttpSession session,ModelMap map) throws RecoveryServiceException {
        LOG.debug("Entered the FileUploadController controller class");
        if (result.hasErrors()) {
            LOG.debug("Inside has errors");
            LOG.info("......"+result.hasErrors() + result.toString());
            return DOC_RE_SYNC_LANDING_PAGE;
        }
        documentReSyncForm.setUserName((String)session.getAttribute("username"));
        
            documentReSyncForm =  documentReSyncService.processBulkIHI(documentReSyncForm);
           // map.addAttribute("ResponseData", documentReSyncForm.getDocIdList());
       
        return DOC_RE_SYNC_RESPONSE;
    }
    
    /**
     * To handel exceptions
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleAllException(Exception ex) {
        LOG.info("Exception handler......");
        ModelAndView model = new ModelAndView(EXCEPTION_PAGE);
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex.getMessage());
        return model;
    }
}
