package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ConsumerRegistrationOIDForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * Validates Date for Consumer Registration OID by checking for empty date blocks and invalid dates
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Apr 2015
 * @version Change-x
 */
@Component
public class ConsumerRegistrationOIDValidator implements Validator {

    private static Logger LOG = Logger.getLogger(ConsumerRegistrationOIDValidator.class);
    private static final String DATE_FORMAT = "dd/MM/yyyy";

    @Autowired
    @Qualifier("dateTimeUtil")
    private DateTimeUtil dateTimeUtil;

    /**
     * Overriding supports method from Validator Interface
     * @param class1
     * @return
     */
    @Override
    public boolean supports(Class<?> class1) {
        return ConsumerRegistrationOIDForm.class.equals(class1);
    }

    /**
     * Overriding validate method from Validator Interface
     * @param object
     * @param errors
     */
    @Override
    public void validate(Object object, Errors errors) {

        if (object instanceof ConsumerRegistrationOIDForm) {
            ConsumerRegistrationOIDForm form = (ConsumerRegistrationOIDForm) object;
            LOG.debug("Validating the Consumer Registration ");
            try {
                errors = consumerRegistrationValidationOIDMethod(form, errors);
            } catch (Exception e) {
                LOG.error("Exception occured", e);
            }
        }
    }

    /**
     * Calls validatedate method from DateTimeUtil() class and validates dates
     * @param consumerRegistrationOIDForm
     * @param errors
     * @return
     * @throws RecoveryDAOException
     */

    private Errors consumerRegistrationValidationOIDMethod(ConsumerRegistrationOIDForm consumerRegistrationOIDForm,
                                                           Errors errors) throws Exception {
        LOG.debug("Inside validating Date method...");

        ValidationUtils.rejectIfEmpty(errors, "fromDate", "ReconciliationOps.date");
        ValidationUtils.rejectIfEmpty(errors, "toDate", "ReconciliationOps.date");
    
        //Checking both the dates are in specified format  
        if ((!dateTimeUtil.validatedate(consumerRegistrationOIDForm.getFromDate(),DATE_FORMAT)) ||(!dateTimeUtil.validatedate(consumerRegistrationOIDForm.getToDate(), DATE_FORMAT)))
            errors.rejectValue("fromDate", "ReconciliationOps.ValidDate");

        //  Checking if fromDate is before toDate
        if (dateTimeUtil.reconDateOrder(consumerRegistrationOIDForm.getFromDate(),
                                   consumerRegistrationOIDForm.getToDate())) {
                errors.rejectValue("fromDate", "ReconciliationOps.invalidDateOrder");
            
        }
        LOG.debug("Leaving Validator Class");
        return errors;

    }
}
