package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * @author sapna.n.goud
 * This controller handles the request wrt to login page.
 * Looks for the valid user and based on the role directs page.
 * Invalid user are re-directed to Login page. Which will indicate of authentication failure.
 * Version       Issue no.             Description                     Change
 * v1              n/a                 Initial version                  n/a
 */
@Controller
public class NIOLoginController {
    private static Logger LOG = Logger.getLogger(NIOLoginController.class);
    /**
     * Directs to menu page if valid user else directs to login page.
     * @param model
     * @param req
     * @return
     */
     @AuditBefore(AuditMessageConstants.LOGIN)
    @RequestMapping(method = RequestMethod.GET,value="/OperationMenu")
    public String loadLogin(ModelMap model,HttpServletRequest req) {
        if (req.getUserPrincipal() == null) {
            return "/login";
        }else{
            return "NIO/OperationMenu";
        }
    }
    
    /**
     * Invalidates the session and directs to JSP page.
     * @param model
     * @param req
     * @return
     * 
     */
    @AuditBefore(AuditMessageConstants.LOGOUT)
    @RequestMapping(method = RequestMethod.GET,value="/logout")
    public String logout(ModelMap model,HttpServletRequest req, HttpServletResponse response) throws ServletException {
        
        req.getSession().invalidate();
        req.logout();
        return "/login";
    }
    
    /**
     * To handel exceptions
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public String handleAllException(Exception ex) {
        LOG.debug("Exception occured in Login handler...... Redirecting to Login Page..............." + ex.getMessage());
        return "/login";
    }
    
}
