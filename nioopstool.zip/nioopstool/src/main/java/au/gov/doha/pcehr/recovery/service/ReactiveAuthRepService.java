package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepBO;
import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepClientResBO;
import au.gov.doha.pcehr.recovery.dao.ReactiveAuthRepDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.wsclient.ReactivateAuthRep;

import au.pcehr.ws.pna.common.ApplicationResponse;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


/**
 * @Author Vikash Kumar Singh(10994193)
 * @since 18 Sept 2014
 */
@Service
public class ReactiveAuthRepService {
    private static Logger LOG = Logger.getLogger(ReactiveAuthRepService.class);
    
    @Autowired
    @Qualifier("ReactiveAuthRepDAO")
    ReactiveAuthRepDAO reactiveAuthRepDAO;
    
    @Autowired
    InsertAuditRecordService insertAuditRecordService;
    @Autowired
    ReactivateAuthRep reactivateAuthRepClient;
    
    /**
     *
     * @param reactivateAuthRepBO
     * @param username
     * @return
     * @throws RecoveryServiceException
     * @throws RecoveryDAOException
     */
    public ReactivateAuthRepBO reActivateAuthRepScriptService(ReactivateAuthRepBO reactivateAuthRepBO, String username)throws RecoveryServiceException,
                                                                                                                        RecoveryDAOException {
        LOG.debug("Inside reActivateAuthRepScriptService Method .... ");
        reactivateAuthRepBO.setSoapMessage(new StringBuffer());
        reactivateAuthRepBO.setAlertMessage(new StringBuffer());
        reactivateAuthRepBO = perfromReactiveAuth(reactivateAuthRepBO, username);
        LOG.debug("Return reActivateAuthRepScriptService Method .... ");
        return reactivateAuthRepBO;
    }
    
    
    /**
     * This method calls the Reactivate auth client
     * @param reactivateAuthRepBO
     * @param username
     * @return
     * @throws RecoveryServiceException
     * @throws RecoveryDAOException
     */
    private ReactivateAuthRepBO perfromReactiveAuth(ReactivateAuthRepBO reactivateAuthRepBO, String username) throws RecoveryServiceException,RecoveryDAOException {
        LOG.debug("Inside perfromReactiveAuth Method .... ");
        List<ReactivateAuthRepBO> reactivateAuthRepList = new ArrayList<ReactivateAuthRepBO>();
        try{
        
            String ihi = reactivateAuthRepBO.getIhi();
            String rep_ihi = reactivateAuthRepBO.getRep_ihi();
            reactivateAuthRepList = reactiveAuthRepDAO.fetchReactiveAuth_Record(ihi, rep_ihi);
            LOG.debug("reactivateAuthRepList Size .... " + reactivateAuthRepList.size());
            for (int i = 0; i < reactivateAuthRepList.size(); i++) {
                LOG.debug("Doing WebService Call .... " );
                ReactivateAuthRepClientResBO reactivateAuthRepClientResBO =reactivateAuthRepClient.create(getReactivateAuthRepBO(reactivateAuthRepBO,reactivateAuthRepList.get(i)));
                ApplicationResponse responseStatus =  reactivateAuthRepClientResBO.getApplicationResponse();
                reactivateAuthRepBO.setSoapMessage(reactivateAuthRepBO.getSoapMessage().append(reactivateAuthRepClientResBO.getSoapReqRes()));
                reactivateAuthRepBO.setSoapMessage(reactivateAuthRepBO.getSoapMessage().append("\n")); 
                AuditRecordBO audit = insertAudit(reactivateAuthRepBO, username);
                reactivateAuthRepBO.setSoapMessage(reactivateAuthRepBO.getSoapMessage().append(audit.getResponseStatusMsg()));
                if (responseStatus.getStatusCode().intValue() == 161) {
                    reactivateAuthRepBO.setAlertMessage(reactivateAuthRepBO.getAlertMessage().append("Re-Activate Authorized Representative Script for user id " +
                                                                                                           reactivateAuthRepList.get(i).getUserID() +
                                                                                                           " Successfull \n" ));
                } else {
                    reactivateAuthRepBO.setAlertMessage(reactivateAuthRepBO.getAlertMessage().append("Re-Activate Authorized Representative Failed \n" ));
                }
            }
            if(reactivateAuthRepList.size()<=0){
                reactivateAuthRepBO.setAlertMessage(reactivateAuthRepBO.getAlertMessage().append("No record found for the given relationship and IHI. \n"));
            }
        }catch(Exception e){
            LOG.fatal("Exception occured ....  In ReactivateAuthRep Class" ,e);
            throw new RecoveryServiceException(e.getMessage(),e);
        }
        LOG.debug("Return perfromReactiveAuth Method .... ");
        return reactivateAuthRepBO;
    }
    
    /**
     *
     * @param reactivateAuthRepBO
     * @param ihi
     * @return
     */
    private AuditRecordBO getAuditRecordBO(ReactivateAuthRepBO reactivateAuthRepBO, String username) {
        AuditRecordBO auditRecordBO = new AuditRecordBO();
        auditRecordBO.setUserID(reactivateAuthRepBO.getUserID());
        //should be username
        auditRecordBO.setUsername(username);
        auditRecordBO.setIhi(reactivateAuthRepBO.getRecordIHI());


        auditRecordBO.setVendor("NIO");
        auditRecordBO.setProductName("ReinstateRepresentatives");
        auditRecordBO.setProdoctVersion("1.0");
        auditRecordBO.setPlatForm("Jump Host");


        auditRecordBO.setTransactionStatus("COMPLETED");
        auditRecordBO.setBusinessEvent("ReinstateRepresentatives");
        auditRecordBO.setComponentSource("NIO");

        auditRecordBO.setIhiName("");
        auditRecordBO.setSubject("Reinstate Representatives");
        auditRecordBO.setSubjectType("PCEHR");

        auditRecordBO.setOperationPerfomed("Reinstate Representatives");
        auditRecordBO.setReason(null);
        auditRecordBO.setActionType("Update");


        auditRecordBO.setAccessConditions("OpenAccess");
        auditRecordBO.setAccessLevel("Self");

        auditRecordBO.setDescription("Transaction completed");

        auditRecordBO.setMessageLogLevel("AUDIT");


        auditRecordBO.setStatus(true);


        auditRecordBO.setStatusCode("");
        auditRecordBO.setSoapMesage("");
        
        return auditRecordBO;
    }
    
    /**
     *
     * @param reactivateAuthRepBO
     * @param username
     * @return
     */
    private AuditRecordBO insertAudit(ReactivateAuthRepBO reactivateAuthRepBO, String username) {
        LOG.debug("Inside insertAudit Method .... ");
        AuditRecordBO auditBO = getAuditRecordBO(reactivateAuthRepBO, username);
        auditBO = insertAuditRecordService.insertAudit(auditBO);
        LOG.debug("Return insertAudit Method .... ");
       return auditBO;
    }

    /**
     *
     * @param reactivateAuthRepBO
     * @param reactivateAuthRepList1
     * @return
     */
    private ReactivateAuthRepBO getReactivateAuthRepBO(ReactivateAuthRepBO reactivateAuthRepBO,
                                                       ReactivateAuthRepBO reactivateAuthRepList1) {
        reactivateAuthRepBO.setCreated_by(reactivateAuthRepList1.getCreated_by());
        reactivateAuthRepBO.setRecordId(reactivateAuthRepList1.getRecordId());
        reactivateAuthRepBO.setUserID(reactivateAuthRepList1.getUserID());
        reactivateAuthRepBO.setAuth_type(reactivateAuthRepList1.getAuth_type());
        reactivateAuthRepBO.setAuth_issue(reactivateAuthRepList1.getAuth_issue());
        reactivateAuthRepBO.setAuth_startdate(reactivateAuthRepList1.getAuth_startdate());
        reactivateAuthRepBO.setDocType(reactivateAuthRepList1.getDocType());
        return reactivateAuthRepBO;
    }
}
