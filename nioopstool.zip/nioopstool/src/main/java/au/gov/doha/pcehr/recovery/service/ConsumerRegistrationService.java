package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.dao.ConsumerRegistrationDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ConsumerRegistrationForm;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConsumerRegistrationService {
  
    private static Logger LOG = Logger.getLogger(ConsumerRegistrationService.class);

    @Autowired
    private ConsumerRegistrationDAO consumerRegistrationDAO;
    
    /**
     * This method is called from the controller after validation is successful.
     * @param consumerRegistrationForm
     * @return
     * @throws RecoveryDAOException
     */
    
    public ConsumerRegistrationForm consumerRegistrationServicemethod(ConsumerRegistrationForm consumerRegistrationForm) throws RecoveryDAOException {
      LOG.debug("Inside Service Class method");
        consumerRegistrationForm = consumerRegistrationDAO.fetchConsumerRegistrationList(consumerRegistrationForm);                                                                                            
        LOG.debug("Leaving Service Class");  
        return consumerRegistrationForm;
    }
}
