package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.ProviderOrganisationRegistrationBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ProviderOrganisationRegistrationForm;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class ProviderOrganisationRegistrationDAO {

    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJDBCTemplate;

    @Autowired
    @Qualifier("oimJDBCTemplate")
    private JdbcTemplate oimJDBCTemplate;

    @Value("${PROVIDER_ORG_VER_DAO.GET_LIST}")
    private String ORG_COUNT_OIM;

    @Value("${PROVIDER_ORG_VER_DAO.GET_OID_LIST}")
    private String ORG_COUNT_OID;

    @Value("${PROVIDER_ORG_REG.GET_LIST}")
    private String PROVIDER_ORG_REGISTRATION_QUERY;

    private static Logger LOG = Logger.getLogger(ProviderRegistrationDAO.class);

    public ProviderOrganisationRegistrationForm fetchProviderOrganisationRegistrationList(ProviderOrganisationRegistrationForm providerOrganisationRegistrationForm) throws RecoveryDAOException {
        List<ProviderOrganisationRegistrationBO> providerOrgRegistrationList = new ArrayList<ProviderOrganisationRegistrationBO>();
        List<String> orgIdList = new ArrayList<String>();
        boolean existInBoth = true;
        try {
            orgIdList = osbJDBCTemplate.query(PROVIDER_ORG_REGISTRATION_QUERY,
            new Object[] {providerOrganisationRegistrationForm.getFromDate(), providerOrganisationRegistrationForm.getToDate()},
            new RowMapper<String>() {
                public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                    String orgId = rs.getString("ACCESSING_ORG_ID");                   
                    return orgId;
                }
            });
            LOG.debug("orgIdList size :: - " + orgIdList.size());
            if(orgIdList.size() > 0){
                for(int i = 0; i < orgIdList.size(); i++ ){
                    ProviderOrganisationRegistrationBO boObj = new ProviderOrganisationRegistrationBO();
                    String orgId = orgIdList.get(i);
                    boObj.setAccessing_org_id(orgId);
                    int isOrgInOIM = oimJDBCTemplate.queryForObject(ORG_COUNT_OIM, new Object[] {orgId}, Integer.class );
                    
                    if(isOrgInOIM > 0){
                        boObj.setCountoim(1);
                        int isOrgInOID = oimJDBCTemplate.queryForObject(ORG_COUNT_OID, new Object[] {orgId}, Integer.class );
                        if(isOrgInOID > 0){
                            boObj.setCountoid(1);
                        }else{
                            boObj.setCountoid(0);
                        }
                    }else{
                        existInBoth = false;
                        boObj.setCountoim(0);
                        LOG.debug("setting existInBoth :: - " + existInBoth);
                    }
                    
                    providerOrgRegistrationList.add(boObj);
                    providerOrganisationRegistrationForm.setErrorList(providerOrgRegistrationList);
                    providerOrganisationRegistrationForm.setExistInBoth(existInBoth);
                }
            }
            
        }catch(Exception e){
            throw new RecoveryDAOException();
        }
        return providerOrganisationRegistrationForm;
    }
}
