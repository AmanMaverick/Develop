package au.gov.doha.pcehr.recovery.bo;


public class AuditEntryMissingResponseBO {
    private String inheritOrganizationDetails;
    private String accessOrganizationDetails;
    private String unknownDocId;
    private String unknownAuthor;

    public void setInheritOrganizationDetails(String inheritOrganizationDetails) {
        this.inheritOrganizationDetails = inheritOrganizationDetails;
    }

    public String getInheritOrganizationDetails() {
        return inheritOrganizationDetails;
    }

    public void setAccessOrganizationDetails(String accessOrganizationDetails) {
        this.accessOrganizationDetails = accessOrganizationDetails;
    }

    public String getAccessOrganizationDetails() {
        return accessOrganizationDetails;
    }

    public void setUnknownDocId(String unknownDocId) {
        this.unknownDocId = unknownDocId;
    }

    public String getUnknownDocId() {
        return unknownDocId;
    }

    public void setUnknownAuthor(String unknownAuthor) {
        this.unknownAuthor = unknownAuthor;
    }

    public String getUnknownAuthor() {
        return unknownAuthor;
    }
}
