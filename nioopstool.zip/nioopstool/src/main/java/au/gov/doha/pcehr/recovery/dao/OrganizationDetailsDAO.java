package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.OrganisationDtlBO;
import au.gov.doha.pcehr.recovery.util.DBUtility;
import au.gov.doha.pcehr.recovery.util.ExtractCDA;

import au.net.electronichealth.ns.ci.cda.extensions._3.EntityIdentifier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.log4j.Logger;

import org.hl7.v3.II;
import org.hl7.v3.POCDMT000040ClinicalDocument;
import org.hl7.v3.POCDMT000040Organization;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;


/**
 * @Author HTB/RLS(Kiran)
 *
 */
@Component
public class OrganizationDetailsDAO {
    private static Logger LOG = Logger.getLogger(OrganizationDetailsDAO.class);
    private final String HL7_ROOT_ID = "2.16.840.1.113883.1.3";
    private final String HPIO = "HPI-O";

    /**This method fetches the organizationdetails from HTB and RLS based on Document ID
     * @param documentList
     * @return organizationDetailsList
     */
    @Autowired
    @Qualifier("rlsNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate rlsNamedParameterJdbcTemplate;
    
    @Autowired
    @Qualifier("htbNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate htbNamedParameterJdbcTemplate;   
    public List<OrganisationDtlBO> retrieveIHIDetailsFromRLS(String documentList) throws SQLException, JAXBException,
                                                                                         Exception {
        LOG.debug("Entering retrieveIHIDetailsFromRLS");
        OrganisationDtlBO organizsationDtlBo = null;
        List<OrganisationDtlBO> organizationDetailsList = new ArrayList<OrganisationDtlBO>();
        String[] documentIds = documentList.split("\n");
        for (int i = 0; i < documentIds.length; i++) {
            organizsationDtlBo = new OrganisationDtlBO();
            String[] htbOrganizationDetails = getHTBOrganisationDetails(documentIds[i]);
            String[] rlsOrganizationDetails = getRLSOrganisationDetails(documentIds[i]);
            organizsationDtlBo.setInheritingOrgId(htbOrganizationDetails[0]);
            organizsationDtlBo.setUnknownDocumentId(htbOrganizationDetails[1]);
            organizsationDtlBo.setUnknownAuthor(htbOrganizationDetails[2]);
            organizsationDtlBo.setAccessingOrgId(rlsOrganizationDetails[0]);
            organizsationDtlBo.setIhi(rlsOrganizationDetails[1]);
            organizsationDtlBo.setClinicalDocumentId(documentIds[i]);
            organizationDetailsList.add(organizsationDtlBo);
        }
        LOG.debug("Leaving retrieveIHIDetailsFromRLS");
        return organizationDetailsList;
    }

    /**This method fetches the inheriting organization id  from HTB
     * @param documentId
     * @return organizationId
     */
    private String[] getHTBOrganisationDetails(String documentId) throws SQLException, JAXBException, Exception {
        LOG.debug("Entering getHTBORganisationDetails");
        String[] inheritingOrganizationValue = new String[3];
        String[] documentIdWithExt = new String[2];
        String strClinicalDocument = null;
     
        boolean isHPIOFound = false;
        try {
            //connection = DBUtility.getDataBaseConnectionObject("HTB");
            //
            StringBuffer queryHTB=new StringBuffer();
            queryHTB.append( "SELECT EDS.ED_CLOB AS ED_CLOB                                                         " + 
                "FROM CTB.CTB_CORE_ACT_II II, CTB.CTB_CORE_ACTS ACTS, CTB.CTB_CORE_EDS EDS  " +
                "WHERE II.ACT_ID = ACTS.ACT_ID                                              " +
                "AND II.PARTITION_KEY = ACTS.PARTITION_KEY                                  " +
                "AND ACTS.CLASS_CODE = 'DOCCLIN'                                            " +
                "AND ACTS.MOOD_CODE = 'EVN'                                                 " +
                "AND ACTS.CURRENT_VERSION_FLAG = 'Y'                                        " +
                "AND ACTS.TEXT_ED_ID = EDS.ED_ID                                            " +
                "AND II.EXTENSION_TXT NOT LIKE '%-PCEHRDoc'                                 " +
                "AND ACTS.NEGATION_FLAG is null                                             " +
                "AND II.ROOT_ID = :rootID                                                         " + 
                "AND II.EXTENSION_TXT = :extID ");
            Map namedParametersHTB=new HashMap();
            if(null != documentId && ! documentId.contains("^")) {
                namedParametersHTB.put("rootID",HL7_ROOT_ID);
                namedParametersHTB.put("extID",documentId);
                LOG.debug("The Clincical Doc extension : " + documentId);
            } else {
                documentIdWithExt = documentId.split("\\^");
                namedParametersHTB.put("rootID",documentIdWithExt[0]);
                namedParametersHTB.put("extID",documentIdWithExt[1]);  
                LOG.debug("The Clincical Doc root : " + documentIdWithExt[0] + "extension :" + documentIdWithExt[1]);
            }
           
            List<Map<String,Object>> listHTB=htbNamedParameterJdbcTemplate.queryForList(queryHTB.toString(), namedParametersHTB);
            for(Map row:listHTB){
                if(null!=row.get("ED_CLOB")){
                strClinicalDocument = row.get("ED_CLOB").toString();
                LOG.debug("The Clincical Doc CLOB Found");
                }
            }
            //
          
            if (null != strClinicalDocument) {
                char[] docBytes = strClinicalDocument.toCharArray();
                ExtractCDA cdaExtractor = new ExtractCDA();
                JAXBElement<POCDMT000040ClinicalDocument> jaxbElement = cdaExtractor.extract(docBytes);
                POCDMT000040ClinicalDocument clinicalDocument = jaxbElement.getValue();
                JXPathContext context = JXPathContext.newContext(clinicalDocument);

                POCDMT000040Organization organizationDetails =
                    (POCDMT000040Organization)context.getValue("/author/assignedAuthor/assignedPerson/asEmployment/employerOrganization/asOrganizationPartOf/wholeOrganization");
                List<EntityIdentifier> entityIdentifiers = organizationDetails.getAsEntityIdentifier();
                for (EntityIdentifier entityIdenfier : entityIdentifiers) {
                    II id = entityIdenfier.getId();
                    if (null != id && HPIO.equals(id.getAssigningAuthorityName())) {
                        isHPIOFound = true;
                        inheritingOrganizationValue[0] = id.getRoot();
                    }
                }
                if(! isHPIOFound) {
                    inheritingOrganizationValue[2] = documentId;
                    LOG.debug("HPIO doesnt exists for document id" +documentId);
                }
            } else {
                LOG.info("Document " + documentId + " doesnot exists in HTB");
                inheritingOrganizationValue[1] = documentId;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured", e);
            inheritingOrganizationValue[2] = documentId;
            LOG.debug("Author doesnt exists for document id" +documentId);
        } finally {
           
        }
        LOG.debug("Leaving getHTBOrganizationDetails");
        return inheritingOrganizationValue;
    }

    /**This method fetches the accessing organization id,iHI details  from RLS
     * @param documentId
     * @return organizationId,iHI
     */
    private String[] getRLSOrganisationDetails(String documentId) throws SQLException, JAXBException, Exception {
        LOG.debug("Entering getRLSOrganisationDetails");
        String[] clinicalDocumentDetails = new String[2];
       
        try {
           // connection = DBUtility.getDataBaseConnectionObject("RLS");
           // LOG.debug("connection" + connection);
            //
            String id = null;
            StringBuffer queryRLS=new StringBuffer();
            queryRLS.append("select id from HRLCORE.doc_entry where doc_uid = :docID order by version desc");
            Map namedParameters = new HashMap();                
            namedParameters.put("docID", documentId);
            List<Map<String, Object>> listRLS = rlsNamedParameterJdbcTemplate.queryForList(queryRLS.toString(), namedParameters);
            for (Map row : listRLS) {
                if(row.get("id")!=null)
                id=row.get("id").toString();
            }
            //
          
            //
            String authorInstitutionValue = null;
            String patientDetails = null;
            StringBuffer queryGet_AI=new StringBuffer();
            queryGet_AI.append("select PATIENT_ID,extractValue(XMLType(document), '/ExtrinsicObject/Classification/Slot[@name=\"authorInstitution\"]/ValueList/Value', 'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0') val from HRLCORE.doc_entry where id=:ID");
            Map namedParametersGetAI = new HashMap();                
            namedParametersGetAI.put("ID", id);
            List<Map<String, Object>> listRLSGetAI = rlsNamedParameterJdbcTemplate.queryForList(queryGet_AI.toString(), namedParametersGetAI);
            for (Map row : listRLSGetAI) {
                if(row.get("val")!=null)
                authorInstitutionValue = row.get("val").toString();
                if(row.get("PATIENT_ID")!=null)
                patientDetails = row.get("PATIENT_ID").toString();
            }
            //
            
           
            if (null != patientDetails) {
                String[] splitPatientDetails = patientDetails.split("\\^\\^\\^");
                String ihi = splitPatientDetails[0];
                String[] authorInformation = null;
                if (null != authorInstitutionValue) {
                    authorInformation = authorInstitutionValue.split("\\^\\^\\^\\^\\^\\^\\^\\^\\^");

                }
                clinicalDocumentDetails[0] = authorInformation[1];
                clinicalDocumentDetails[1] = ihi;
                LOG.debug("Leaving getRLSOrganisationDetails");
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured", e);
        } finally {
            
        }
        LOG.debug("Leaving getRLSOrganisationDetails");
        return clinicalDocumentDetails;
    }
}
