package au.gov.doha.pcehr.recovery.wsclient.soaphandler;

import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.xml.namespace.QName;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class WSClientHandlerUtilOAG implements  SOAPHandler<SOAPMessageContext> { 
            private static Logger LOG = Logger.getLogger(WSClientHandlerUtilOAG.class);
    public WSClientHandlerUtilOAG() {
        super();
    }
    @Autowired
    private SOAPMessageUtil soapMessageUtil;
    @Override
    public Set<QName> getHeaders() {
        // TODO Implement this method
        return Collections.emptySet();
    }

    @Override
    public boolean handleMessage(SOAPMessageContext sOAPMessageContext) {
        LOG.debug("inside handleMessage of WSClientHandlerUtilOAG");
        // TODO Implement this method
        boolean outgoing=(Boolean)sOAPMessageContext.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        
        if(outgoing){
            try{
        
            String action ="";
            if(sOAPMessageContext.containsKey("ACTIONTAG")){
            action = (String)sOAPMessageContext.get("ACTIONTAG");

            LOG.debug("ACTION in the action....."+action);
            }

            
            
            SOAPHeader header = sOAPMessageContext.getMessage().getSOAPHeader();
            
            Iterator<Node> n1 = header.getChildElements();
            List<Node> nodeToRemove = new ArrayList<Node>();
            while(n1.hasNext()){
              Node node = n1.next();
              LOG.debug("Node"+node.getNodeName());
              if(node.getNodeName().equals("wsa:Action") || node.getNodeName().equals("wsa:To")){
                  nodeToRemove.add(node);
              }
            }
            for(Node node:nodeToRemove){
            node.getParentNode().removeChild(node);
            }
            
            
            header.normalize();
            
            QName headerName1 = new QName("http://www.w3.org/2005/08/addressing",
                             "To", "wsa05");
            SOAPHeaderElement headerElement = header.addHeaderElement(headerName1);
            //frm database with repid
            LOG.debug("was action value:::"+action);
            headerElement.addTextNode(action);
            //  headerElement.addTextNode("http://localhost:8080/DocumentStub/ProxyServices/ConformantRep_getDocumentStub");
            QName headerName2 = new QName("http://www.w3.org/2005/08/addressing",
                             "Action","wsa");
            SOAPHeaderElement headerElement2 = header.addHeaderElement(headerName2);
            
            headerElement2.addTextNode("urn:ihe:iti:2007:RetrieveDocumentSet");
            
            //code chage for addressing feature
            QName messageId1 = new QName("http://www.w3.org/2005/08/addressing",
                             "MessageID", "");
                         SOAPHeaderElement messageIdElement1 = header.addHeaderElement(messageId1);
            messageIdElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                                QName intgressionID = new QName("http://www.w3.org/2005/08/addressing",
                                     "IntegrationID", "");
                                 SOAPHeaderElement headerElementintgressionID2 = header.addHeaderElement(intgressionID);
                                headerElementintgressionID2.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
            
            //
           
               
            }
        catch (SOAPException soap) {
            LOG.fatal("ERRRORRRRR:"+soap);
            }
            SOAPMessage soapMsg = sOAPMessageContext.getMessage();
            String soapMessage = soapMessageUtil.serialiseSoapXml(soapMsg);
            LOG.debug(" SOAP Request ----- \n" + soapMessage + "\n");
            
            sOAPMessageContext.put("soapRequest", soapMessage); 
            sOAPMessageContext.setScope("soapRequest", MessageContext.Scope.APPLICATION);
            LOG.debug("End.......");
       
        }else{
            SOAPMessage soapMsg = sOAPMessageContext.getMessage();
            String soapMessage = soapMessageUtil.serialiseSoapXml(soapMsg);
            LOG.debug(" SOAP Response ----- \n" + soapMessage + "\n");
            
            sOAPMessageContext.put("soapResponse", soapMessage); 
            sOAPMessageContext.setScope("soapResponse", MessageContext.Scope.APPLICATION);
        }
        LOG.debug("Leaving handleMessage of WSClientHandlerUtilOAG");
        return true;
    }

    @Override
    public boolean handleFault(SOAPMessageContext sOAPMessageContext) {
        SOAPMessage soapMsg = sOAPMessageContext.getMessage();
        LOG.debug(" ** Fault: \n" + soapMessageUtil.serialiseSoapXml(soapMsg) + "\n");
        return true;
    }

    @Override
    public void close(MessageContext messageContext) {
        // TODO Implement this method
    }
}
