package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.wsclient.InsertAuditRecordClient;

import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.AccessConditionsType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.AccessedEntityType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ParticipantActionType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ParticipantDetailsType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord.EventRecord;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord.EventRecord.AuditEvent;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord.EventRecord.LogEvent;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InsertAuditRecordService {
    @Autowired
    InsertAuditRecordClient insertAuditRecordClient;
    
    
    private static Logger LOG = Logger.getLogger(InsertAuditRecordService.class);
    


     
    
    public AuditRecordBO insertAudit(AuditRecordBO bo){
                                LOG.debug("Entering Insert Audit method.");
                                XMLGregorianCalendar xgcal = null;
                                  IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
                                  IntPCEHRHeader.User user = new IntPCEHRHeader.User();
                                  
                                  user.setIDType("LocalSystemIdentifier");
                                  user.setID(bo.getUserID());
                                  if(bo.getRole()!= null && bo.getRole().equals("NIO_BULK_REGISTRATION_SYSTEM_OPERATOR")){
                                      user.setRole("NIO_BULK_REGISTRATION_SYSTEM_OPERATOR");
                                  }else{
                                      user.setRole("PCEHR_SYSTEM_OPERATOR");
                                  }
                                  user.setUserName(bo.getUsername());
                                  user.setUseRoleForAudit(false);
                                  intPCEHRHeader.setUser(user);
                                  
                                  IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
                                  productType.setVendor(bo.getVendor());
                                  productType.setProductName(bo.getProductName());
                                  productType.setProductVersion(EndPointsConstants.PRODUCT_VERSION);
                                  productType.setPlatform(bo.getPlatForm());
                                  
                                  intPCEHRHeader.setProductType(productType);
                          
                                  IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
                                  //clientSystem.setSystemID(EndPointsConstants.HOST_NAME);
                                  clientSystem.setSystemID("NIOOpsTool");
                                  if(null == bo.getSystemType()){
                                    clientSystem.setSystemType("Admin");
                                  }else{
                                      clientSystem.setSystemType(bo.getSystemType());
                                  }
                                  intPCEHRHeader.setClientSystem(clientSystem);
                          
                                  IntPCEHRHeader.AccessingOrganisation accessingOrg = new IntPCEHRHeader.AccessingOrganisation();
                                  accessingOrg.setOrganisationID("");
                                  accessingOrg.setOrganisationName("");
                                  intPCEHRHeader.setAccessingOrganisation(accessingOrg);
                          
                                  intPCEHRHeader.setOverrideLogLevel(false);
                                  LOG.debug("bo.getIhi()"+bo.getIhi());
                                  intPCEHRHeader.setIhiNumber(bo.getIhi());
                                  
                                 
                                  LogEvent logEvent = new LogEvent();
                                  ResponseStatusType responseStatusType = new ResponseStatusType();
                                  ResponseStatusType responseStatusError = new ResponseStatusType();
                                  if (bo.isStatus()){
                                      LOG.debug("is staus true....");
                                      
                                      responseStatusType.setCode("PCEHR_SUCCESS");
                                      responseStatusType.setDescription(bo.getDescription());
                                      logEvent.setStatusDetails(responseStatusType);
                                  } else{
                                      
                                      LOG.debug("is staus false....");
                                      responseStatusType.setCode("N/A");
                                      responseStatusType.setDescription("N/A");
                                      logEvent.setStatusDetails(responseStatusType);
                                      responseStatusError.setCode(bo.getStatusCode());
                                      responseStatusError.setDescription(bo.getDescription());
                                      responseStatusError.setDetails(bo.getSoapMesage().replaceAll("&lt;", "<").replaceAll("&gt;", ">"));
                                      logEvent.setErrorDetails(responseStatusError); 
                                     
                                  }
                                  
                                  
                               
                                  logEvent.setMessageLogLevel(bo.getMessageLogLevel());
                                 
                                  logEvent.setOverrideLogLevelFlag(true);
                                  
                                  ParticipantDetailsType participantDetailsType = new ParticipantDetailsType();
                                  participantDetailsType.setUserID(bo.getUserID());
                                  participantDetailsType.setUserName(bo.getUsername());
                                  participantDetailsType.setDisplayRole("PCEHR_SYSTEM_OPERATOR");
                                  
                                  AccessedEntityType accessedEntityType = new AccessedEntityType();
                                  LOG.debug("bo.getIhiName()......."+bo.getIhiName());
                                  accessedEntityType.setIhiName(bo.getIhiName());
                                  LOG.debug("bo.getIhi()......."+bo.getIhi());
                                  accessedEntityType.setIhiNumber(bo.getIhi());
                                  LOG.debug("bo.getSubjectType()"+bo.getSubjectType());
                                  accessedEntityType.setSubject(bo.getSubject());
                                  accessedEntityType.setSubjectType(bo.getSubjectType());  
                          
                                  ParticipantActionType participantActionType = new ParticipantActionType();
                                  participantActionType.setActionType(bo.getActionType());
//                                  if (action_type.equals("CREATE")) {
//                                      participantActionType.setActionType("Create");
//                                  }
//                                 else if (action_type.equals("UPDATE")) {
//                                      participantActionType.setActionType("Update"); 
//                                  }
//                                  else if (action_type.equals("REMOVE")) {
//                                      participantActionType.setActionType("Delete");
//                                  }
                                  participantActionType.setOperationPerformed(bo.getOperationPerfomed());
                                  participantActionType.setReason(bo.getReason());                            
                                  participantActionType.setStatusPriorDeactivation(bo.getStatusPriorDeactivation());
                                  AccessConditionsType accessConditionsType = new AccessConditionsType();
                                  accessConditionsType.setAccessPermission("Permit");
                                  //use bo to get these two values
                                  accessConditionsType.setAccessConditions(bo.getAccessConditions());
                                 accessConditionsType.setAccessLevel(bo.getAccessLevel());
                          
                                  AuditEvent auditEvent = new AuditEvent();
                                  auditEvent.setParticipantDetails(participantDetailsType);
                                  auditEvent.setAccessedEntity(accessedEntityType);
                                  auditEvent.setParticipantAction(participantActionType);
                                  auditEvent.setAccessConditions(accessConditionsType);
                                  
                                  try {
                                      GregorianCalendar gcal = new GregorianCalendar();
                                      xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
                                  } catch (Exception e) {
                                      System.out.println("Exception");
                                  }
                          
                                  EventRecord eventRecord = new EventRecord();
                                  eventRecord.setTransactionStatus(bo.getTransactionStatus());
                                  eventRecord.setComponentSource(bo.getComponentSource());
                                  eventRecord.setBusinessEvent(bo.getBusinessEvent());  
                                  eventRecord.setLogEvent(logEvent);
                                  eventRecord.setAuditEvent(auditEvent);
                                  eventRecord.setEventTimeStamp(xgcal);
                          
                                  InsertAuditRecord insertAuditRecord = new InsertAuditRecord();
                                  insertAuditRecord.setEventRecord(eventRecord);
                                  StringBuffer respStatus = new StringBuffer();
                                  try {
                                     // InsertAuditRecordClient insertAuditRecordProxy = new InsertAuditRecordClient();
                                      LOG.debug("Calling Audit ...");
                                      ResponseStatusType response = insertAuditRecordClient.insertAudit(insertAuditRecord, intPCEHRHeader);
                                      
                                      bo.setAuditReponse(response);  
                                      LOG.debug("responseStatusType status"+(null != response));
                                      if(null != responseStatusType) {
                                          LOG.debug("here....");
                                              respStatus.append("\nInsert Audit Response");
                                              respStatus.append("\n");
                                              respStatus.append("\nCode :: " + response.getCode());
                                              respStatus.append("\nDescription :: " + response.getDescription());
                                              respStatus.append("\nDetails :: " + response.getDetails());
                                              respStatus.append("\n");
                                             LOG.debug("Get response status message.."+respStatus.toString());
                                              bo.setResponseStatusMsg(respStatus.toString());
                                      }
                                  } catch(WebServiceClientException standError) {
                                      LOG.fatal("here....exception"+standError);
                                      //LOG.fatal("here....exception"+standError.getMessage());
                                      respStatus.append("\nInsert Audit Response");
                                      respStatus.append("\nException Occurred<b>");
                                      respStatus.append("\nError Message : " );
                                      respStatus.append("\n");
                                      
                                      bo.setAlertMsg("Insert Audit Failed");
                                      
                                  } catch(Exception e) {
                                      LOG.fatal("here....exception",e);
                                      
                                  }

                                  return bo;
      
    }
}
