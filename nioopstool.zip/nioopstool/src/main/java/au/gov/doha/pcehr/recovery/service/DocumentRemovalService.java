package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalWSClientBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.wsclient.DocumentRemovalClient;

import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;

import java.util.Locale;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;


/**
 * @author Sumanta Kumar Saha
 * This is a service layer for Document remvoal.
 */
@Service
public class DocumentRemovalService {
    private static Logger LOG = Logger.getLogger(DocumentRemovalService.class);
    
    private static final String PCEHR_SUCCESS = "PCEHR_SUCCESS";
   
    @Autowired
    MessageSource messageSource;
    @Autowired
    DocumentRemovalClient documentRemovalClient;
    
    
  
    
    /**
     * This method is called from the controller.
     * @param documentRemovalBO
     * @return DocumentRemovalBO
     * @throws RecoveryServiceException
     */
    public DocumentRemovalBO processDocumentRemoval(DocumentRemovalBO documentRemovalBO) throws RecoveryServiceException {
        LOG.debug("entering processDocumentRemoval");
        LOG.debug("ihi value:::" + documentRemovalBO.getIhi());    
        documentRemovalBO.setSoapMessage(new StringBuffer());
        documentRemovalBO.setAlertMessage(new StringBuffer());
        documentRemovalBO = performRemoval(documentRemovalBO);
        LOG.debug("leaving processDocumentRemoval");
        return documentRemovalBO;

    }

    /**
     * This method calls the webservice client for Document remvoal.
     * @param documentRemovalBO
     * @return DocumentRemovalBO
     */
    private DocumentRemovalBO performRemoval(DocumentRemovalBO documentRemovalBO) throws RecoveryServiceException {

        LOG.debug("entering performRemoval");
     
        try {
           
          //  documentRemovalClient.setDocumentRemovalWSClientBO(getDocumentRemovalClientBO(documentRemovalBO));
            //can return one consolidated message
            try {
                ResponseStatusType response = documentRemovalClient.remove(getDocumentRemovalClientBO(documentRemovalBO));

                if (PCEHR_SUCCESS.equals(response.getCode())) {
                    documentRemovalBO.getAlertMessage().append(response.getDescription());
                    documentRemovalBO.getSoapMessage().append(response.getDescription());
                } else {
                    documentRemovalBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                        new Object[] { response.getDescription() },
                                                                                        Locale.US));
                    
                    documentRemovalBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                        new Object[] { response.getDescription() },
                                                                                        Locale.US));
                }
            } catch (WebServiceClientException exception) {
                documentRemovalBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                    new Object[] { exception.getMessage() },
                                                                                    Locale.US));
                documentRemovalBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                   new Object[] { exception.getMessage() },
                                                                                   Locale.US));
            }
      
            documentRemovalBO.setSoapMessage(documentRemovalBO.getSoapMessage().append(documentRemovalClient.getSoapMessage()));



        } catch (Exception e) {
      
            throw new RecoveryServiceException(e);
        }

        LOG.debug("leaving performRemoval");
        return documentRemovalBO;
    }

    /**
     * This method sets the business objects for Document removal.
     * @param DocumentRemovalBO
     * @return DocumentRemovalWSClientBO
     */
    private DocumentRemovalWSClientBO getDocumentRemovalClientBO(DocumentRemovalBO bo) {
        LOG.debug("entering getDocumentRemovalClientBO");
        DocumentRemovalWSClientBO clientBo = new DocumentRemovalWSClientBO();
        LOG.debug("valeus:::ihi" + bo.getIhi());
        LOG.debug("valeus:::Doc id" + bo.getDocumentId());
        LOG.debug("valeus::reson" + bo.getResonForRemoval());
        clientBo.setIhi(bo.getIhi());
        clientBo.setDocumentId(bo.getDocumentId());
        clientBo.setResonForRemoval(bo.getResonForRemoval());
        LOG.debug("leaving getDocumentRemovalClientBO");
        return clientBo;
    }


}
