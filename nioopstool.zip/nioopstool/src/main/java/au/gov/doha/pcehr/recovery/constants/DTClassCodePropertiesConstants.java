package au.gov.doha.pcehr.recovery.constants;

import java.io.FileInputStream;
import java.io.IOException;

import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;


public class DTClassCodePropertiesConstants {
    private static Logger LOG = Logger.getLogger(DTClassCodePropertiesConstants.class);
    public DTClassCodePropertiesConstants() {
        super();
    }
    public static HashMap<String,String> classCodeMap = new HashMap();
    static {
        try {
            Properties myProp = new Properties();
    String os = System.getProperty("os.name");
    String configFileLocation1 = null;
    if (null != os && os.contains("Linux")) {
        configFileLocation1 = System.getProperty("user.dir") + "/Configuration/DTClassCode.properties";
        
      LOG.debug("configFileLocation1" + configFileLocation1);
    } else {
        configFileLocation1 = System.getProperty("user.dir") + "\\Configuration\\DTClassCode.properties";
          
       
        LOG.debug("configFileLocation1" + configFileLocation1);
    }
    myProp.load(new FileInputStream(configFileLocation1));
    for (String key : myProp.stringPropertyNames()) {
        String value = myProp.getProperty(key);
        classCodeMap.put(key, value);
    }

            } catch (IOException ioe) {
                LOG.fatal("Exception occured while instantiating constants..", ioe);
               
            }
}
}
