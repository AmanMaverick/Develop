package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.bo.MobileVendorApplicationsClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.net.electronichealth.ns.pcehr.svc.intgetvendorapplicationlist._1.GetVendorApplicationListPortType;
import au.net.electronichealth.ns.pcehr.svc.intgetvendorapplicationlist._1.GetVendorApplicationListService;
import au.net.electronichealth.ns.pcehr.svc.intmanagevendorapplicationdetails._1.ManageVendorApplicationDetailsPortType;
import au.net.electronichealth.ns.pcehr.svc.intmanagevendorapplicationdetails._1.ManageVendorApplicationDetailsService;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.getvendorapplicationlist._1.ApplicationList;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.getvendorapplicationlist._1.GetVendorApplicationListResponse;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.managevendorapplicationdetails._1.Action;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.managevendorapplicationdetails._1.ManageVendorApplicationDetails;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.managevendorapplicationdetails._1.ManageVendorApplicationDetailsResponse;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.managevendorapplicationdetails._1.MobileAPIList;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.math.BigInteger;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Service
public class MobileVendorApplicationDetailsWsClient {
    public MobileVendorApplicationDetailsWsClient() {
        super();
    }

    @Autowired
    private TestHostnameVerifier testHostnameVerifier;
    @Autowired
    Decrypter decrypter;
    @Autowired
    DateTimeUtil dateTimeUtil;

    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    private static Logger LOG = Logger.getLogger(MobileVendorApplicationDetailsWsClient.class);
    public final String ACTION_APPLICATION = "applciation";
    public final String ACTION_REGISTER = "register";
    public final String ACTION_UPDATE = "update";

    /**
     *This method is used to get the applications list
     * @param mobileVendorApplicationsClientBO
     * @return
     */
    public Map<String, String> getApplicationList() {
        LOG.debug("inside getApplicationList");

        Map<String, String> appListDtlsMap = new HashMap<String, String>();
        URL url = null;
        try {
            url =
                new URL("http://localhost:8011/#%7Bhttp%3A%2F%2Fns.electronichealth.net.au%2Fpcehr%2Fsvc%2FintGetVendorApplicationList%2F1.0%7DgetVendorApplicationListService?wsdl");

        } catch (MalformedURLException e) {
            LOG.fatal("Exception...", e);
        }
        QName qname =
            new QName("http://ns.electronichealth.net.au/pcehr/svc/intGetVendorApplicationList/1.0",
                      "getVendorApplicationListService");
        GetVendorApplicationListService getVendorApplicationListService =
            new GetVendorApplicationListService(url, qname);
        getVendorApplicationListService.setHandlerResolver(wSClientHandlerResolver);
        GetVendorApplicationListPortType getVendorApplicationListPortType =
            getVendorApplicationListService.getGetVendorApplicationListSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true,
                                                                                                                          true));
        Map<String, Object> requestContext = ((BindingProvider) getVendorApplicationListPortType).getRequestContext();
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                           EndPointsConstants.OSB_MOBILE_VENDOR_APPLICATION_LIST_ENDPOINT);
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
        requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD));

        //getVendorApplicationListRequest

        Holder<GetVendorApplicationListResponse> response = new Holder<GetVendorApplicationListResponse>();
        Object ob1 = new Object();
        IntPCEHRHeader header = createHeader();
        Holder<IntPCEHRHeader> intHeaderHolder = new Holder<IntPCEHRHeader>();
        intHeaderHolder.value = header;
        try {
            getVendorApplicationListPortType.getVendorApplicationList(ob1, response, intHeaderHolder);
        } catch (Exception e) {
            LOG.fatal("exception occured:::" + e);
            
        }
        LOG.debug("Leaving getApplicationList");
        if(null!=response ){
                
            if(null!=response.value.getResponseStatus() && response.value.getResponseStatus().getCode().equals("PCEHR_SUCCESS")){
                List<ApplicationList> appList = response.value.getApplicationList();
                for (ApplicationList app :
                     appList) {
                 
                    appListDtlsMap.put(app.getApplicationID(),
                                       app.getApplicationName() + "~" + app.getApplicationVersion() + "~" +
                                       app.getVendorName());
                    

                }
            }
            else{
                LOG.debug("RESPONSE STATUS:::"+response.value.getResponseStatus().getCode());
            }
        }
        
        LOG.debug("appListDtlsMap sixze.." + appListDtlsMap.size());
        return appListDtlsMap;
    }

    /**
     *This method is used to creat or update the application details
     * @param mobileVendorApplicationsClientBO
     */
    @SuppressWarnings("oracle.jdeveloper.java.insufficient-catch-block")

    public ManageVendorApplicationDetailsResponse manageVendorApplicationDetails(MobileVendorApplicationsClientBO mobileVendorApplicationsClientBO) throws au.net.electronichealth.ns.pcehr.svc.intmanagevendorapplicationdetails._1.StandardErrorMsg {
        LOG.debug("inside createOrUpdateApplication");
        URL url = null;
        try {
            url =
                new URL("http://localhost:8011/#%7Bhttp%3A%2F%2Fns.electronichealth.net.au%2Fpcehr%2Fsvc%2FintManageVendorApplicationDetails%2F1.0%7DmanageVendorApplicationDetailsService?wsdl");

        } catch (MalformedURLException e) {
            LOG.fatal("Exception...", e);
        }
        QName qname =
            new QName("http://ns.electronichealth.net.au/pcehr/svc/intManageVendorApplicationDetails/1.0",
                      "manageVendorApplicationDetailsService");
        ManageVendorApplicationDetailsService manageVendorApplicationDetailsService =
            new ManageVendorApplicationDetailsService(url, qname);
        manageVendorApplicationDetailsService.setHandlerResolver(wSClientHandlerResolver);

        ManageVendorApplicationDetailsPortType manageVendorApplicationDetailsPortType =
            manageVendorApplicationDetailsService.getManageVendorApplicationDetailsSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true,
                                                                                                                                      true));
        Map<String, Object> requestContext =
            ((BindingProvider) manageVendorApplicationDetailsPortType).getRequestContext();
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                           EndPointsConstants.OSB_MOBILE_VENDOR_APPLICATION_ENDPOINT);
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
        requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD));

        //getVendorApplicationListRequest
        ManageVendorApplicationDetails manageVendorApplicationDetails =
            getManageVendorApplicationDetailsRequestParam(mobileVendorApplicationsClientBO);

        Holder<ManageVendorApplicationDetailsResponse> response = new Holder<ManageVendorApplicationDetailsResponse>();
        Object ob1 = new Object();
        IntPCEHRHeader header = createHeader();
        Holder<IntPCEHRHeader> intHeaderHolder = new Holder<IntPCEHRHeader>();
        intHeaderHolder.value = header;
        // try {
        try {
            manageVendorApplicationDetailsPortType.manageVendorApplicationDetails(manageVendorApplicationDetails,
                                                                                  response, intHeaderHolder);
        } catch (au.net.electronichealth.ns.pcehr.svc.intmanagevendorapplicationdetails._1.StandardErrorMsg e) {
            LOG.fatal("exception occured:::" + e);
            throw e;
        }
        LOG.debug("ws response app ID:::" + response.value.getApplicationID());
        LOG.debug("ws response OS name::" + response.value.getOS());
        LOG.debug("ws response OS name::" + response.value.getSecondaryState());
        LOG.debug("ws response OS name::" + response.value.getPrimaryState());
        LOG.debug("Leaving createOrUpdateApplication");
        //return mobileVendorApplicationsClientBO;
        return response.value;

    }

    /**
     *
     * @return
     */
    private static IntPCEHRHeader createHeader() {

        LOG.debug("Entering setHeader ");
        HttpServletRequest req =
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
        IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
        clientSystem.setSystemID("Other001");
        clientSystem.setSystemType("Other");
        // intPCEHRHeader.setIhiNumber(ihi);
        IntPCEHRHeader.ProductType producType = new IntPCEHRHeader.ProductType();
        producType.setPlatform("Linux");
        producType.setProductName("Ops Tool");
        producType.setProductVersion(EndPointsConstants.PRODUCT_VERSION);
        producType.setVendor("NIO");
        IntPCEHRHeader.User user = new IntPCEHRHeader.User();
        user.setID(req.getUserPrincipal().getName());
        user.setIDType("LocalSystemIdentifier");
        user.setRole("PCEHR_SYSTEM_OPERATOR");

        user.setUseRoleForAudit(false);
        user.setUserName(req.getUserPrincipal().getName());
        intPCEHRHeader.setOverrideLogLevel(false);
        intPCEHRHeader.setClientSystem(clientSystem);
        intPCEHRHeader.setUser(user);
        intPCEHRHeader.setProductType(producType);
        LOG.debug("Leaving setHeader ");
        return intPCEHRHeader;
    }

    /**
     *
     * @param mobileVendorApplicationsClientBO
     * @return
     */
    private ManageVendorApplicationDetails getManageVendorApplicationDetailsRequestParam(MobileVendorApplicationsClientBO mobileVendorApplicationsClientBO) {
        LOG.debug("entering getManageVendorApplicationDetailsRequestParam");

        ManageVendorApplicationDetails manageVendorApplicationDetails = new ManageVendorApplicationDetails();
        try {
            if (ACTION_APPLICATION.equals(mobileVendorApplicationsClientBO.getAction()))
                manageVendorApplicationDetails.setAction(Action.RETRIEVE_APPLICATION);
            else if (ACTION_REGISTER.equals(mobileVendorApplicationsClientBO.getAction()) ){
                if(null!=mobileVendorApplicationsClientBO.getGroupID()&&mobileVendorApplicationsClientBO.getGroupID().length()>0)
                manageVendorApplicationDetails.setGroupID(new BigInteger(mobileVendorApplicationsClientBO.getGroupID()));
                manageVendorApplicationDetails.setAction(Action.REGISTER_APPLICATION);
                MobileAPIList mobileAPIList = new MobileAPIList();
                LOG.debug("apililist::;" + mobileAPIList.getAPIID());
                if (null != mobileVendorApplicationsClientBO.getAPIList() &&
                    mobileVendorApplicationsClientBO.getAPIList().size() > 0)
                    mobileAPIList.getAPIID().addAll(mobileVendorApplicationsClientBO.getAPIList());
                manageVendorApplicationDetails.setMobileAPIList(mobileAPIList);

                manageVendorApplicationDetails.setStatus(mobileVendorApplicationsClientBO.getApplicationStatus());
                manageVendorApplicationDetails.setInteractionModel(new BigInteger(mobileVendorApplicationsClientBO.getIntModel()));

            } else if (ACTION_UPDATE.equals(mobileVendorApplicationsClientBO.getAction())) {
                LOG.debug("grp id:::" + mobileVendorApplicationsClientBO.getGroupID());
                manageVendorApplicationDetails.setGroupID(new BigInteger(mobileVendorApplicationsClientBO.getGroupID()));
              
                manageVendorApplicationDetails.setAction(Action.UPDATE_APPLICATION);
                MobileAPIList mobileAPIList = new MobileAPIList();
                
                if (null != mobileVendorApplicationsClientBO.getAPIList() &&
                    mobileVendorApplicationsClientBO.getAPIList().size() > 0){
                    mobileAPIList.getAPIID().addAll(mobileVendorApplicationsClientBO.getAPIList());
                manageVendorApplicationDetails.setMobileAPIList(mobileAPIList);
                    }
                manageVendorApplicationDetails.setStatus(mobileVendorApplicationsClientBO.getApplicationStatus());
                if(mobileVendorApplicationsClientBO.getIntModel()!=null){
                manageVendorApplicationDetails.setInteractionModel(new BigInteger(mobileVendorApplicationsClientBO.getIntModel()));
                }
               
            }

            manageVendorApplicationDetails.setIPRange(mobileVendorApplicationsClientBO.getIpRange());
            manageVendorApplicationDetails.setApplicationID(mobileVendorApplicationsClientBO.getApplicationId());
            manageVendorApplicationDetails.setApplicationName(mobileVendorApplicationsClientBO.getAppName());
            manageVendorApplicationDetails.setVendorName(mobileVendorApplicationsClientBO.getVendorName());
            manageVendorApplicationDetails.setVersion(mobileVendorApplicationsClientBO.getVersion());
            //if getAppDetails flag is false then set rest all the values


            //        for( Field fld : ManageVendorApplicationDetails.class.getDeclaredFields() ) {
            //
            //        }
            //        for(Method method : ManageVendorApplicationDetails.class.getMethods()){
            //            if(!method.getName().startsWith("set")){
            //                method.invoke(arg0, arg1){
            //
            //                }
            //            }
            //        }
            manageVendorApplicationDetails.setAlternateName(mobileVendorApplicationsClientBO.getAlternateName());
            manageVendorApplicationDetails.setAuthCodeCallbackURL(mobileVendorApplicationsClientBO.getCallbackURL());
            manageVendorApplicationDetails.setEventNotificationCallbackURL(mobileVendorApplicationsClientBO.getEventNotificationCallbackURL());

            //manageVendorApplicationDetails.setIPRange(mobileVendorApplicationsClientBO.getIP);
            manageVendorApplicationDetails.setIntent(mobileVendorApplicationsClientBO.getIntent());

            //cehck


            manageVendorApplicationDetails.setOS(mobileVendorApplicationsClientBO.getOs());
            manageVendorApplicationDetails.setPrimaryBusinessAddress(mobileVendorApplicationsClientBO.getBusinessAddress());
            manageVendorApplicationDetails.setPrimaryEmail(mobileVendorApplicationsClientBO.getEmail());
            manageVendorApplicationDetails.setPrimaryFullName(mobileVendorApplicationsClientBO.getFullName());
            manageVendorApplicationDetails.setPrimaryMobile(mobileVendorApplicationsClientBO.getMobile());
            manageVendorApplicationDetails.setPrimaryPhone(mobileVendorApplicationsClientBO.getPhone());
            manageVendorApplicationDetails.setPrimaryPostcode(mobileVendorApplicationsClientBO.getPostcode());
            manageVendorApplicationDetails.setPrimaryState(mobileVendorApplicationsClientBO.getState());
            manageVendorApplicationDetails.setPrimarySuburb(mobileVendorApplicationsClientBO.getSuburb());
            manageVendorApplicationDetails.setSecondaryBusinessAddress(mobileVendorApplicationsClientBO.getBusinessAddressSec());
            manageVendorApplicationDetails.setSecondaryEmail(mobileVendorApplicationsClientBO.getEmailSec());
            manageVendorApplicationDetails.setSecondaryFullName(mobileVendorApplicationsClientBO.getFullNameSec());
            manageVendorApplicationDetails.setSecondaryMobile(mobileVendorApplicationsClientBO.getMobileSec());
            manageVendorApplicationDetails.setSecondaryPhone(mobileVendorApplicationsClientBO.getPhoneSec());
            manageVendorApplicationDetails.setSecondaryPostcode(mobileVendorApplicationsClientBO.getPostcodeSec());
            manageVendorApplicationDetails.setSecondaryState(mobileVendorApplicationsClientBO.getStateSec());
            manageVendorApplicationDetails.setSecondarySuburb(mobileVendorApplicationsClientBO.getSuburbSec());

            // manageVendorApplicationDetails.setA
            //manageVendorApplicationDetails.setStatus(mobileVendorApplicationsClientBO.getSt);

            manageVendorApplicationDetails.setSubmissionDate(mobileVendorApplicationsClientBO.getSubmissionDate());

            LOG.debug("Leaving getManageVendorApplicationDetailsRequestParam");
        } catch (Exception e) {
            LOG.fatal("exception:::" + e.getStackTrace());
            e.printStackTrace();
            throw e;
        }
        return manageVendorApplicationDetails;
    }
}
