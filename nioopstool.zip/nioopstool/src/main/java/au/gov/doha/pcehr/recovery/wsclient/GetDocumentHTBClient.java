package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.bo.DocTransformationErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.bo.GetDocumentHTBWSClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import com.sun.xml.ws.developer.JAXWSProperties;

import ihe.iti.xds_b._2007.DocumentRepositoryPortType;
import ihe.iti.xds_b._2007.DocumentRepositoryService;
import ihe.iti.xds_b._2007.RetrieveDocumentSetRequestType;
import ihe.iti.xds_b._2007.RetrieveDocumentSetRequestType.DocumentRequest;
import ihe.iti.xds_b._2007.RetrieveDocumentSetResponseType;

import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.soap.SOAPBinding;

import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryError;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryErrorList;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryResponseType;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * Client to perform all Get Document from HTB  related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since  5 JAN 2015
 * @version Change-x
 */
@Service
public class GetDocumentHTBClient {
    @Autowired
    TestHostnameVerifier testHostnameVerifier;
    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;

   
    private static Logger LOG = Logger.getLogger(GetDocumentHTBClient.class);
    private static final String HTB_FALIURE = "HTB Failure";

    /**
     *
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     * @throws Exception
     */
    public DocumentTransformationForm getDocument(DocumentTransformationForm form,GetDocumentHTBWSClientBO getDocumentHTBWSClientBO) throws FileNotFoundException,
                                                                                          IOException, Exception {
        LOG.debug("Entering get Doc service ");
        FileUtil fileUtility = new FileUtil();
        LOG.debug("DOC ID IN CLIENT ::" + getDocumentHTBWSClientBO.getDocumentID());
        LOG.debug("rep ID IN CLIENT ::" + getDocumentHTBWSClientBO.getRepositoryID());
        byte[] bytes = null;
        try {
            DocumentRepositoryService documentRepositoryService = new DocumentRepositoryService();
            documentRepositoryService.setHandlerResolver(wSClientHandlerResolver);
            DocumentRepositoryPortType documentRepositoryPortType =
                documentRepositoryService.getDocumentRepositoryPortSoap12(new javax.xml.ws.soap.AddressingFeature(true,
                                                                                                                  true));
            // Add your code to call the desired methods.

            Map<String, Object> ctxt = ((BindingProvider) documentRepositoryPortType).getRequestContext();
            ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.HTB_GETDOC);

            //needed to enable MTOM Feature to support the HDR upgradation from HTB. HDR response does not returns the Binary data with the response as the attachment.
            BindingProvider bp = (BindingProvider) documentRepositoryPortType;
            SOAPBinding binding = (SOAPBinding) bp.getBinding();
            binding.setMTOMEnabled(true);
            ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            RetrieveDocumentSetRequestType s = new RetrieveDocumentSetRequestType();
            DocumentRequest docRequest = new DocumentRequest();
            docRequest.setDocumentUniqueId(getDocumentHTBWSClientBO.getDocumentID());
            docRequest.setRepositoryUniqueId(getDocumentHTBWSClientBO.getRepositoryID());


            s.getDocumentRequest().add(docRequest);
            LOG.debug("rebefore calling:::");
            RetrieveDocumentSetResponseType response =
                documentRepositoryPortType.documentRepositoryRetrieveDocumentSet(s);


            LOG.debug("RESPONSE..." + response);
            if (response != null) {
                RegistryResponseType registryResponse = response.getRegistryResponse();
                if (null != registryResponse) {
                    LOG.debug("registryResponse status...." + registryResponse.getStatus());
                }
                if (null != registryResponse && registryResponse.getStatus().contains("Success")) {
                    List<RetrieveDocumentSetResponseType.DocumentResponse> listResponse =
                        response.getDocumentResponse();

                    LOG.debug("response getDocument SIZES:::" + listResponse.size());
                    if (listResponse != null && listResponse.size() > 0) {
                        LOG.debug("HTB response getDocument:::" + listResponse.get(0).getDocument());
                        LOG.debug("HTB response getMimeType:::" + listResponse.get(0).getMimeType());

                        bytes = listResponse.get(0).getDocument();
                        form.setWsResposeDoc(bytes);
                        //WRITE status as pass IN CSV FILE AS NEW REQUIREMENT CHANGED
                        String sysDate = fileUtility.getDateFormat();
                        DocTransformationErrorBO errorBo =
                            fileUtility.createErrorBo(getDocumentHTBWSClientBO.getIhi(),
                                                      getDocumentHTBWSClientBO.getDocumentID(), "N/A",
                                                      getDocumentHTBWSClientBO.getDocumnetType(), "PASS", sysDate);


                        if (form.getErrorBoList() != null) {
                            form.getErrorBoList().add(errorBo);
                        } else {
                            List<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
                            listErrorBo.add(errorBo);
                            form.setErrorBoList(listErrorBo);
                        }


                    }
                } else if (null != registryResponse && registryResponse.getStatus().contains("Failure")) {
                    LOG.debug("no document found in HTB..");
                    RegistryErrorList rgistryError = registryResponse.getRegistryErrorList();
                    List<RegistryError> registryErrorList = rgistryError.getRegistryError();
                    if (null != registryErrorList && registryErrorList.size() > 0) {
                        LOG.debug("error value for no doc in HTB.." + registryErrorList.get(0).getValue());

                        String sysDate = fileUtility.getDateFormat();
                        DocTransformationErrorBO errorBo =
                            fileUtility.createErrorBo(getDocumentHTBWSClientBO.getIhi(),
                                                      getDocumentHTBWSClientBO.getDocumentID(), HTB_FALIURE,
                                                      getDocumentHTBWSClientBO.getDocumnetType(), "FAIL", sysDate);
                        form.setWsResposeDoc(null);
                        if (form.getErrorBoList() != null) {
                            form.getErrorBoList().add(errorBo);
                        } else {
                            List<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
                            listErrorBo.add(errorBo);
                            form.setErrorBoList(listErrorBo);
                        }
                    }
                }
            }
        } catch (Exception e) {
            //getSoapRequestMsg();
            LOG.fatal("Exception occuredin messagebuilding", e);
            LOG.fatal("Exception", e);
            String sysDate = fileUtility.getDateFormat();
            DocTransformationErrorBO errorBo =
                fileUtility.createErrorBo(getDocumentHTBWSClientBO.getIhi(), getDocumentHTBWSClientBO.getDocumentID(),
                                          HTB_FALIURE, getDocumentHTBWSClientBO.getDocumnetType(), "FAIL", sysDate);
            form.setWsResposeDoc(null);
            if (form.getErrorBoList() != null) {
                form.getErrorBoList().add(errorBo);
            } else {
                List<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
                listErrorBo.add(errorBo);
                form.setErrorBoList(listErrorBo);
            }

        }

        LOG.debug("leaving get Doc service ");

        return form;

    }

    


}
