package au.gov.doha.pcehr.recovery.bo;

import java.util.HashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;


public class DocumentTransformationForm {
    
   private String ihi;
   private HashMap<String,List<DocumentTransformationRLSBO>> ihiRlsMap;
    private List<String> ihiList;
   private MultipartFile file;
    private String fileFormat;
    private String de_Identification;
    private String userID;
    private String systemOperator;
    private List<String> documentType;
    private String documentTypeAvailable;
    private StringBuffer errorCsv;
    private List<DocTransformationErrorBO> errorBoList;
    private byte[] wsResposeDoc;
    private List<String> zippedFileList;
    private int zipFileCount;
    private int errorCSVIhiCount;
    private int errorCSVFailCount;
    //for making audit
    private boolean auditRequired;
    private String errorCsvName;
    
    //new changes for malicious content
      private String inputType;
     private String creationTime;
    private String endTime;
    private List<String> cdaZippedCreatedIHIList;
    private List<String> docStatus;
    
    
    //getDocIdDateRange no doc found error message
    private String docNotFoundDateRange;
    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }


    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public void setDe_Identification(String de_Identification) {
        this.de_Identification = de_Identification;
    }

    public String getDe_Identification() {
        return de_Identification;
    }

    public void setDocumentType(List<String> documentType) {
        this.documentType = documentType;
    }

    public List<String> getDocumentType() {
        return documentType;
    }

    public void setDocumentTypeAvailable(String documentTypeAvailable) {
        this.documentTypeAvailable = documentTypeAvailable;
    }

    public String getDocumentTypeAvailable() {
        return documentTypeAvailable;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setIhiList(List<String> ihiList) {
        this.ihiList = ihiList;
    }

    public List<String> getIhiList() {
        return ihiList;
    }

    public void setIhiRlsMap(HashMap ihiRlsMap) {
        this.ihiRlsMap = ihiRlsMap;
    }

    public HashMap getIhiRlsMap() {
        return ihiRlsMap;
    }

    public void setErrorCsv(StringBuffer errorCsv) {
        this.errorCsv = errorCsv;
    }

    public StringBuffer getErrorCsv() {
        return errorCsv;
    }

    public void setErrorBoList(List<DocTransformationErrorBO> errorBoList) {
        this.errorBoList = errorBoList;
    }

    public List<DocTransformationErrorBO> getErrorBoList() {
        return errorBoList;
    }

    public void setWsResposeDoc(byte[] wsResposeDoc) {
        this.wsResposeDoc = wsResposeDoc;
    }

    public byte[] getWsResposeDoc() {
        return wsResposeDoc;
    }

    public void setZippedFileList(List<String> zippedFileList) {
        this.zippedFileList = zippedFileList;
    }

    public List<String> getZippedFileList() {
        return zippedFileList;
    }



    public void setZipFileCount(int zipFileCount) {
        this.zipFileCount = zipFileCount;
    }

    public int getZipFileCount() {
        return zipFileCount;
    }

    public void setErrorCSVIhiCount(int errorCSVIhiCount) {
        this.errorCSVIhiCount = errorCSVIhiCount;
    }

    public int getErrorCSVIhiCount() {
        return errorCSVIhiCount;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setSystemOperator(String systemOperator) {
        this.systemOperator = systemOperator;
    }

    public String getSystemOperator() {
        return systemOperator;
    }

    public void setAuditRequired(boolean isAuditRequired) {
        this.auditRequired = isAuditRequired;
    }

    public boolean isAuditRequired() {
        return auditRequired;
    }

    public void setErrorCsvName(String errorCsvName) {
        this.errorCsvName = errorCsvName;
    }

    public String getErrorCsvName() {
        return errorCsvName;
    }

    public void setErrorCSVFailCount(int errorCSVFailCount) {
        this.errorCSVFailCount = errorCSVFailCount;
    }

    public int getErrorCSVFailCount() {
        return errorCSVFailCount;
    }

    public void setInputType(String inputType) {
        this.inputType = inputType;
    }

    public String getInputType() {
        return inputType;
    }

    public void setCreationTime(String creationTime) {
        this.creationTime = creationTime;
    }

    public String getCreationTime() {
        return creationTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setCdaZippedCreatedIHIList(List<String> cdaZippedCreatedIHIList) {
        this.cdaZippedCreatedIHIList = cdaZippedCreatedIHIList;
    }

    public List<String> getCdaZippedCreatedIHIList() {
        return cdaZippedCreatedIHIList;
    }

    public void setDocStatus(List<String> docStatus) {
        this.docStatus = docStatus;
    }

    public List<String> getDocStatus() {
        return docStatus;
    }

    public void setDocNotFoundDateRange(String docNotFoundDateRange) {
        this.docNotFoundDateRange = docNotFoundDateRange;
    }

    public String getDocNotFoundDateRange() {
        return docNotFoundDateRange;
    }
}
