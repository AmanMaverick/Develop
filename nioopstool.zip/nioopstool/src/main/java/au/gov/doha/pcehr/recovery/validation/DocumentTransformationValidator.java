package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.bo.DocTransformationErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.dao.DocumentTransformationDAO;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.MultipartFile;


public class DocumentTransformationValidator implements Validator {
    private static Logger LOG = Logger.getLogger(DocumentTransformationValidator.class);
    private static final String FILE_OUTPUT_FORMAT_CDA = "CDA";
    @Autowired
    private FileUtil fileUtil;
    
    @Autowired
    @Qualifier("dateTimeUtil")
    private DateTimeUtil dateTimeUtil;
    
    @Autowired
    DocumentTransformationDAO documentTransformationDAO;

    @Override
    public boolean supports(Class<?> class1) {
        return DocumentTransformationForm.class.equals(class1);
    }

    @Override
    public void validate(Object object, Errors errors) {

        LOG.debug("entering validate ...");
        DocumentTransformationForm form = (DocumentTransformationForm) object;
        validateDocTrasnformation(form, errors);
        LOG.debug("leaving validate ...");
    }

    private Errors validateDocTrasnformation(DocumentTransformationForm documentTransformationForm, Errors errors) {
        LOG.debug("entering validateDocTrasnformation ...");
        MultipartFile file = documentTransformationForm.getFile();
        
         if((documentTransformationForm.getInputType()!=null && documentTransformationForm.getInputType().length()>0)){
            try {
                List<String> fileList = fileUtil.createList(file);
                int size = fileList.size();
                if (file != null && !"csv".equalsIgnoreCase(FilenameUtils.getExtension(file.getOriginalFilename()))) {
                    errors.rejectValue("file", "DocumentTransformationAttribute.inputFileFormat");
                }else{
                    if (size < 1) {
                        LOG.debug("file conains more than 500 IHI..");
                        errors.rejectValue("file", "DocumentTransformationAttribute.fileSizeMinSize");
                    } else if (size > 500) {
                        LOG.debug("file conains more than 500 IHI..");
                        errors.rejectValue("file", "DocumentTransformationAttribute.fileSizeMaxSize");
                    } else { //checking for invalid IHI in the CSV file
                        List<DocTransformationErrorBO> errorBoList = new ArrayList<DocTransformationErrorBO>();
                        String sysDate = fileUtil.getDateFormat();
                        
                        String pattern =     "IHI".equals(documentTransformationForm.getInputType())?"[0-9]{16}":"\\d+.\\d+(?:.\\d+.\\d+)*";
                       for (String ihi : fileList) {
                            if (!ihi.matches(pattern)) {
                                LOG.debug("invalid ihi : " + ihi);
                                DocTransformationErrorBO docTransErrorBO = new DocTransformationErrorBO();
                                if( "IHI".equals(documentTransformationForm.getInputType())){
                                    docTransErrorBO.setIHI(ihi);
                                    docTransErrorBO.setDocType("N/A");
                                    docTransErrorBO.setErrorDescription("IHI should be 16 digit.");
                                }else{
                                    docTransErrorBO.setIHI("N/A");
                                    docTransErrorBO.setDocType(ihi);
                                    docTransErrorBO.setErrorDescription("Invalid Document id.");
                                }
                              
                                docTransErrorBO.setStatus("FAIL");
                                docTransErrorBO.setDocId("N/A");
                                docTransErrorBO.setTranscationDateAndTime(sysDate);
                               
                                errorBoList.add(docTransErrorBO);
                            }
                        }
                        if (errorBoList.size() > 0) {
                            errors.rejectValue("file", "DocumentTransformationAttribute.invalidIHI", new String[] {
                                               errorBoList.size() + "", sysDate
                            }, null);
                            documentTransformationForm.setErrorBoList(errorBoList);
                            fileUtil.createCSV(documentTransformationForm);
                            documentTransformationForm.setErrorBoList(null); //passing null, impact is on JSP. show two error block if it the list have data
                        }
                    }
                }
            } catch (Exception e) {
                LOG.debug("Exception occured ..", e);
            }
        }else{
            if(documentTransformationForm.getCreationTime()==null || documentTransformationForm.getCreationTime().length()==0 ||  documentTransformationForm.getEndTime()==null || documentTransformationForm.getEndTime().length()==0){
                errors.reject("DocumentTransformationAttribute.mandatoryDateCondition");
            }
            if(documentTransformationForm.getDocumentType()==null ||documentTransformationForm.getDocumentType().size()==0){
                errors.reject("DocumentTransformationAttribute.mandatoryDateConditionClassCode");
            }
             //validation of date range part has been taken care from service layer

        }

      
        if ((documentTransformationForm.getFileFormat() == null)) {
            ValidationUtils.rejectIfEmpty(errors, "de_Identification",
                                          "DocumentTransformationAttribute.de_Identification");
        }
        if ((documentTransformationForm.getDocStatus()==null || documentTransformationForm.getDocStatus().size()==0 )) {
            ValidationUtils.rejectIfEmpty(errors, "docStatus",
                                          "DocumentTransformationAttribute.docStatus");
        }
        if (documentTransformationForm.getFileFormat() != null &&
            !documentTransformationForm.getFileFormat().equals(FILE_OUTPUT_FORMAT_CDA)) {
            ValidationUtils.rejectIfEmpty(errors, "de_Identification",
                                          "DocumentTransformationAttribute.de_Identification");
        }
       // ValidationUtils.rejectIfEmpty(errors, "inputType", "DocumentTransformationAttribute.inputType");
        ValidationUtils.rejectIfEmpty(errors, "fileFormat", "DocumentTransformationAttribute.outputFileFormat");
        ValidationUtils.rejectIfEmpty(errors, "userID", "DocumentTransformationAttribute.userID");
        ValidationUtils.rejectIfEmpty(errors, "systemOperator", "DocumentTransformationAttribute.systemOperator");
       // ValidationUtils.rejectIfEmpty(errors, "creationTime", "DocumentTransformationAttribute.creationTime");
        //ValidationUtils.rejectIfEmpty(errors, "endTime", "DocumentTransformationAttribute.endTime");
//        if (documentTransformationForm.getDocumentType() == null ||
//            documentTransformationForm.getDocumentType().size() == 0) {
//            //
//            errors.rejectValue("file", "DocumentTransformationAttribute.docType");
//        }
        if(documentTransformationForm.getCreationTime()!=null && documentTransformationForm.getCreationTime().length()>0){
            boolean validateDate = dateTimeUtil.validatedate(documentTransformationForm.getCreationTime(), "dd/MM/yyyy");
            if(!validateDate){
                errors.rejectValue("creationTime", "DocumentTransformationAttribute.creationTime.format");
            }else if(documentTransformationForm.getCreationTime().length()!=10){
                errors.rejectValue("creationTime", "DocumentTransformationAttribute.creationTime.format");
            }
        }
        if(documentTransformationForm.getEndTime()!=null && documentTransformationForm.getEndTime().length()>0){
            boolean validateDate = dateTimeUtil.validatedate(documentTransformationForm.getEndTime(), "dd/MM/yyyy");
            if(!validateDate){
                errors.rejectValue("creationTime", "DocumentTransformationAttribute.creationTime.format");
            }else if(documentTransformationForm.getEndTime().length()!=10){
                errors.rejectValue("creationTime", "DocumentTransformationAttribute.endTime.format");
            }else if(!dateTimeUtil.reconDateOrder(documentTransformationForm.getEndTime(),documentTransformationForm.getCreationTime())){
                errors.rejectValue("creationTime", "DocumentTransformationAttribute.endTime.dateRange");
            }
        }
        LOG.debug("Leaving validateDocTrasnformation ...");

        return errors;
    }


   
}
