package au.gov.doha.pcehr.recovery.form;


public class TestingInProdForm{
    
    private String individualType;
    
    private String ihi;
    private String lastName;
    private String sex;
    private String dateOfBirth;
    private String userId;
    
    private String pbsRPBS;
    private String pastPBSrpbs;
    private String mbsDVS;
    private String pastMBSdvs;
    private String acir;
    private String aodr;
    
    private String arIHI;
    private String arLastName;
    private String arSex;
    private String arDateOfBirth;

    private String medicareCardCheck;
    private String relationshipType;
    private String documentSighted;
    private String docDetail;
    private String authrityStartDate;
    private String authrityEndDate;
    private String authrityReviewtDate;
    //notifaction changes
    private String notificationChannel;
    private String notificationDetails;
    private String healthcareProviderAssertion;
    public void setNotificationChannel(String notificationChannel) {
        this.notificationChannel = notificationChannel;
    }

    public String getNotificationChannel() {
        return notificationChannel;
    }

    public void setNotificationDetails(String notificationDetails) {
        this.notificationDetails = notificationDetails;
    }

    public String getNotificationDetails() {
        return notificationDetails;
    }

    public void setHealthcareProviderAssertion(String healthcareProviderAssertion) {
        this.healthcareProviderAssertion = healthcareProviderAssertion;
    }

    public String getHealthcareProviderAssertion() {
        return healthcareProviderAssertion;
    }
    private String registerPCEHRRepsonse;


 
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setRegisterPCEHRRepsonse(String registerPCEHRRepsonse) {
        this.registerPCEHRRepsonse = registerPCEHRRepsonse;
    }

    public String getRegisterPCEHRRepsonse() {
        return registerPCEHRRepsonse;
    }

    public void setIndividualType(String individualType) {
        this.individualType = individualType;
    }

    public String getIndividualType() {
        return individualType;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSex() {
        return sex;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setPbsRPBS(String pbsRPBS) {
        this.pbsRPBS = pbsRPBS;
    }

    public String getPbsRPBS() {
        return pbsRPBS;
    }

    public void setPastPBSrpbs(String pastPBSrpbs) {
        this.pastPBSrpbs = pastPBSrpbs;
    }

    public String getPastPBSrpbs() {
        return pastPBSrpbs;
    }

    public void setMbsDVS(String mbsDVS) {
        this.mbsDVS = mbsDVS;
    }

    public String getMbsDVS() {
        return mbsDVS;
    }

    public void setPastMBSdvs(String pastMBSdvs) {
        this.pastMBSdvs = pastMBSdvs;
    }

    public String getPastMBSdvs() {
        return pastMBSdvs;
    }

    public void setAcir(String acir) {
        this.acir = acir;
    }

    public String getAcir() {
        return acir;
    }

    public void setAodr(String aodr) {
        this.aodr = aodr;
    }

    public String getAodr() {
        return aodr;
    }

    public void setArIHI(String arIHI) {
        this.arIHI = arIHI;
    }

    public String getArIHI() {
        return arIHI;
    }

    public void setArLastName(String arLastName) {
        this.arLastName = arLastName;
    }

    public String getArLastName() {
        return arLastName;
    }

    public void setArSex(String arSex) {
        this.arSex = arSex;
    }

    public String getArSex() {
        return arSex;
    }

    public void setArDateOfBirth(String arDateOfBirth) {
        this.arDateOfBirth = arDateOfBirth;
    }

    public String getArDateOfBirth() {
        return arDateOfBirth;
    }


    public void setMedicareCardCheck(String medicareCardCheck) {
        this.medicareCardCheck = medicareCardCheck;
    }

    public String getMedicareCardCheck() {
        return medicareCardCheck;
    }

    public void setRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
    }

    public String getRelationshipType() {
        return relationshipType;
    }

    public void setDocumentSighted(String documentSighted) {
        this.documentSighted = documentSighted;
    }

    public String getDocumentSighted() {
        return documentSighted;
    }

    public void setDocDetail(String docDetail) {
        this.docDetail = docDetail;
    }

    public String getDocDetail() {
        return docDetail;
    }

    public void setAuthrityStartDate(String authrityStartDate) {
        this.authrityStartDate = authrityStartDate;
    }

    public String getAuthrityStartDate() {
        return authrityStartDate;
    }

    public void setAuthrityEndDate(String authrityEndDate) {
        this.authrityEndDate = authrityEndDate;
    }

    public String getAuthrityEndDate() {
        return authrityEndDate;
    }

    public void setAuthrityReviewtDate(String authrityReviewtDate) {
        this.authrityReviewtDate = authrityReviewtDate;
    }

    public String getAuthrityReviewtDate() {
        return authrityReviewtDate;
    }
}
