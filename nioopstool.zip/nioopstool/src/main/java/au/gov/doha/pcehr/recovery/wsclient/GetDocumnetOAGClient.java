package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.bo.DocTransformationErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.bo.GetDocumnetOAGWSClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolverOAG;

import au.net.electronichealth.ns.pcehr.b2b.xsd.common.commoncoreelements._0.B2BResponseStatusHeader;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.TimestampType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;

import com.sun.xml.ws.developer.JAXWSProperties;

import ihe.iti.xds_b._2007.DocumentRepositoryBindingQSService;
import ihe.iti.xds_b._2007.DocumentRepositoryPortType;
import ihe.iti.xds_b._2007.RetrieveDocumentSetRequestType;
import ihe.iti.xds_b._2007.RetrieveDocumentSetResponseType;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryError;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryErrorList;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryResponseType;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


//import ihe.iti.xds_b._2007.DocumentRepositoryBindingQSService;


//import ihe.iti.xds_b._2007.DocumentReposit


/**
 * Client to perform all Get Document from OAG  related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since  13 JAN 2015
 * @version Change-x
 */
@Service
public class GetDocumnetOAGClient {
    @Autowired
    private TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    private WSClientHandlerResolverOAG wsClientHandlerResolverOag;
    
    @Autowired
    Decrypter decrypter;
    
    private static Logger LOG = Logger.getLogger(GetDocumnetOAGClient.class);
    
   
    private static final String OAG_FALIURE = "OAG Failure";


    /**
     *
     * @return
     */

    public DocumentTransformationForm getExtDocument(DocumentTransformationForm form,GetDocumnetOAGWSClientBO getDocumnetOAGWSClientBO) {
        LOG.debug("Enetring getExtDocument ");
        LOG.debug("DOC ID IN CLIENT oag::" + getDocumnetOAGWSClientBO.getDocumentID());
        LOG.debug("rep ID IN CLIENT oag::" + getDocumnetOAGWSClientBO.getRepositoryID());
        LOG.debug("ihi IN CLIENT oag::" + getDocumnetOAGWSClientBO.getIhi());
        LOG.debug("action in CLIENT oag::" + getDocumnetOAGWSClientBO.getAction());
        byte[] bytes = null;
        FileUtil fileUtility = new FileUtil();
        try {

            URL url = null;
            try {
                url = new URL("file:/Resources/WSDL/B2BExternalDoc/B2B_Outbound_XDS.b_DocumentRepository_v01.wsdl");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }

            
            QName qname = new QName("urn:ihe:iti:xds-b:2007", "DocumentRepositoryBindingQSService");

            DocumentRepositoryBindingQSService documentRepositoryService =
                new DocumentRepositoryBindingQSService(url, qname);
            documentRepositoryService.setHandlerResolver(wsClientHandlerResolverOag);
            
            DocumentRepositoryPortType port =
                documentRepositoryService.getDocumentRepository_BindingQSPort();

            //LOG.debug("Hello2.....");
            Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
            //LOG.debug("Hello3.....");
            requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            // LOG.debug("Hello.....");

            LOG.debug("oag endpoint..." + EndPointsConstants.OAG_GETDOC);
            requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.OAG_GETDOC);
            requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OAG_USERNAME));
            requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OAG_PASSWORD));
            requestContext.put("ACTIONTAG", getDocumnetOAGWSClientBO.getAction());
          
            //   LOG.debug("Hello4.....");
            TimestampType timeStampType = new TimestampType();
           


            //PCEHR Header
            IntPCEHRHeader header = getHeader(getDocumnetOAGWSClientBO.getIhi());


            RetrieveDocumentSetRequestType retrieveDocumentSetRequestType = new RetrieveDocumentSetRequestType();
            RetrieveDocumentSetRequestType.DocumentRequest DocumentRequest =
                new RetrieveDocumentSetRequestType.DocumentRequest();
            DocumentRequest.setDocumentUniqueId(getDocumnetOAGWSClientBO.getDocumentID());
            DocumentRequest.setRepositoryUniqueId(getDocumnetOAGWSClientBO.getRepositoryID());

            retrieveDocumentSetRequestType.getDocumentRequest().add(DocumentRequest);
            Holder<au.net.electronichealth.ns.pcehr.b2b.xsd.common.commoncoreelements._0.B2BResponseStatusHeader> holder =
                new Holder<au.net.electronichealth.ns.pcehr.b2b.xsd.common.commoncoreelements._0.B2BResponseStatusHeader>();
            B2BResponseStatusHeader b2bResponseStatusHeader = new B2BResponseStatusHeader();
            LOG.debug("Hello.....");

           

            RetrieveDocumentSetResponseType response =
                port.documentRepositoryRetrieveDocumentSet(retrieveDocumentSetRequestType, header, holder);
            LOG.debug("RESPONSE OAG..." + response);
            if (response != null) {
                RegistryResponseType registryResponse = response.getRegistryResponse();
                if (null != registryResponse && registryResponse.getStatus().contains("Success")) {
                    List<RetrieveDocumentSetResponseType.DocumentResponse> listResponse =
                        response.getDocumentResponse();

                    LOG.debug("oag response getDocument SIZES:::" + listResponse.size());
                    if (listResponse != null && listResponse.size() > 0) {
                        LOG.debug("OAG response getDocument:::" + listResponse.get(0).getDocument());
                        LOG.debug("OAG response getMimeType:::" + listResponse.get(0).getMimeType());

                        bytes = listResponse.get(0).getDocument();
                        form.setWsResposeDoc(bytes);
                        //WRITE status as pass IN CSV FILE AS NEW REQUIREMENT CHANGED
                        String sysDate=fileUtility.getDateFormat();
                        DocTransformationErrorBO errorBo =
                            fileUtility.createErrorBo(getDocumnetOAGWSClientBO.getIhi(), getDocumnetOAGWSClientBO.getDocumentID(),
                                                      "N/A", getDocumnetOAGWSClientBO.getDocumnetType(), "PASS",sysDate);


                        if (form.getErrorBoList() != null) {
                            form.getErrorBoList().add(errorBo);
                        } else {
                            List<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
                            listErrorBo.add(errorBo);
                            form.setErrorBoList(listErrorBo);
                        }

                        //
                    }   
                } else if (null != registryResponse && registryResponse.getRegistryErrorList() != null &&
                           registryResponse.getRegistryErrorList().getRegistryError() != null &&
                           registryResponse.getRegistryErrorList().getRegistryError().size() > 0) {
                    LOG.debug("Failure from OAG..");
                    RegistryErrorList rgistryError = registryResponse.getRegistryErrorList();
                    List<RegistryError> registryErrorList = rgistryError.getRegistryError();
                    if (null != registryErrorList && registryErrorList.size() > 0) {
                        if (null != registryErrorList.get(0)) {
                            LOG.debug("error value for no doc in OAG getCodeContext.." +
                                      registryErrorList.get(0).getCodeContext());
                        }


                        LOG.debug("error value for no doc in OAG value object not found..");
                        String sysDate=fileUtility.getDateFormat();
                        DocTransformationErrorBO errorBo =
                            fileUtility.createErrorBo(getDocumnetOAGWSClientBO.getIhi(), getDocumnetOAGWSClientBO.getDocumentID(),
                                                      OAG_FALIURE,
                                                      getDocumnetOAGWSClientBO.getDocumnetType(), "FAIL",sysDate);

                        form.setWsResposeDoc(null);
                        if (form.getErrorBoList() != null) {
                            form.getErrorBoList().add(errorBo);
                        } else {
                            List<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
                            listErrorBo.add(errorBo);
                            form.setErrorBoList(listErrorBo);
                        }

                    }
                }
            }

            LOG.debug("Hello.....SOAP Message....");
            //getSoapRequestMsg();
        } catch (Exception e) {
            //getSoapRequestMsg();
            LOG.fatal("Exception occuredin messagebuilding", e);
            String sysDate=fileUtility.getDateFormat();
            DocTransformationErrorBO errorBo =
                fileUtility.createErrorBo(getDocumnetOAGWSClientBO.getIhi(), getDocumnetOAGWSClientBO.getDocumentID(),
                                          OAG_FALIURE, getDocumnetOAGWSClientBO.getDocumnetType(), "FAIL",sysDate);
            form.setWsResposeDoc(null);
            if (form.getErrorBoList() != null) {
                form.getErrorBoList().add(errorBo);
            } else {
                List<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
                listErrorBo.add(errorBo);
                form.setErrorBoList(listErrorBo);
            }
        }
        return form;
    }


  

    
    /**
     *
     * @param ihi
     * @return
     */
    private IntPCEHRHeader getHeader(String ihi) {
        IntPCEHRHeader header = new IntPCEHRHeader();
        IntPCEHRHeader.User user = new IntPCEHRHeader.User();
        user.setIDType("LocalSystemIdentifier");
        user.setID("8003640003000029");
        user.setUserName("DHS Medicare Repository Services");
        user.setUseRoleForAudit(true);
        header.setUser(user);

        header.setIhiNumber(ihi);

        IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
        productType.setVendor("DHS");
        productType.setProductName("DHS Medicare Repository Service");
        productType.setProductVersion("1");
        productType.setPlatform("ESB");
        header.setProductType(productType);

        IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
        clientSystem.setSystemID("general.8003640001000010.electonichealth.net.au");
        clientSystem.setSystemType("CRP");
        header.setClientSystem(clientSystem);


        IntPCEHRHeader.AccessingOrganisation accessingOrganisation = new IntPCEHRHeader.AccessingOrganisation();
        accessingOrganisation.setOrganisationID("8003624900018984");
        // accessingOrganisation.setOrganisationID("8003640001000036");
        accessingOrganisation.setOrganisationName("DHS Medicare");
        header.setAccessingOrganisation(accessingOrganisation);
        return header;
    }

    /**
     *
     * @return
     */
//    private void getSoapRequestMsg() {
//        StringBuffer soapMessagesg = new StringBuffer();
//        soapMessagesg.setLength(0);
//        if (null != LoggingHandler.lastSoapRequest) {
//            soapMessagesg.append("\n getExtDocument SOAP Request");
//            soapMessagesg.append("\n" +
//                    LoggingHandler.lastSoapRequest);
//        }
//        if (null != LoggingHandler.lastSoapResponse) {
//            soapMessagesg.append("---------------------------------------------------------");
//            soapMessagesg.append("\n");
//            soapMessagesg.append("\n getExtDocument SOAP Response");
//            soapMessagesg.append("\n" +
//                    LoggingHandler.lastSoapResponse);
//        }
//        LOG.debug("soap request:::" + soapMessagesg.toString().replaceAll("&lt;", "<").replaceAll("&gt;", ">"));
//    }
}
