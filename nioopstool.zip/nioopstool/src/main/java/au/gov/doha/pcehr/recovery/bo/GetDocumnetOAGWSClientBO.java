package au.gov.doha.pcehr.recovery.bo;


public class GetDocumnetOAGWSClientBO {
    private String documentID;
    private String repositoryID;
    private String ihi;
    private String documnetType;
    private String action;
    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    public String getDocumentID() {
        return documentID;
    }

    public void setRepositoryID(String repositoryID) {
        this.repositoryID = repositoryID;
    }

    public String getRepositoryID() {
        return repositoryID;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocumnetType(String documnetType) {
        this.documnetType = documnetType;
    }

    public String getDocumnetType() {
        return documnetType;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }
}
