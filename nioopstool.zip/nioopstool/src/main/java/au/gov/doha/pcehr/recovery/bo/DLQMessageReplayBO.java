package au.gov.doha.pcehr.recovery.bo;


/**
 * Object class to collect DB details for DLQ
 * @author Vikash Kumar Singh
 * Since 10th March 2015
 */
public class DLQMessageReplayBO {
   
    //DBDetails
    private String dbIntgrationID;
    private String meessageId;
    private String userType;
    private String userId;
    private String ihi;
    private String systemType;
    private String systemId;
    private String accessingOrgId;
    private String documnetId;
    private String documnetCode;
    private String conceptCode;
    private String codeSystem;
    private String businessEvenetName;
    private String businessEvenetTrigger;
    private String errorEndpointId;
    private String dbErrorCode;
    private String errorAdditionalDescription;
    private String dbErrorDetails;
    private String createdDate;
    private String lastUpdatedDate;
    private String dbState;
    private String delliveryCount;
    private String  purge;
    private String payload;
    private String destType;
    private String destUri;
    private String ticketNumber;
    private String remarks;
    private int dbCount;
    
    public void setDbIntgrationID(String dbIntgrationID) {
        this.dbIntgrationID = dbIntgrationID;
    }

    public String getDbIntgrationID() {
        return dbIntgrationID;
    }

    public void setMeessageId(String meessageId) {
        this.meessageId = meessageId;
    }

    public String getMeessageId() {
        return meessageId;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setSystemType(String systemType) {
        this.systemType = systemType;
    }

    public String getSystemType() {
        return systemType;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setAccessingOrgId(String accessingOrgId) {
        this.accessingOrgId = accessingOrgId;
    }

    public String getAccessingOrgId() {
        return accessingOrgId;
    }

    public void setDocumnetId(String documnetId) {
        this.documnetId = documnetId;
    }

    public String getDocumnetId() {
        return documnetId;
    }

    public void setDocumnetCode(String documnetCode) {
        this.documnetCode = documnetCode;
    }

    public String getDocumnetCode() {
        return documnetCode;
    }

    public void setConceptCode(String conceptCode) {
        this.conceptCode = conceptCode;
    }

    public String getConceptCode() {
        return conceptCode;
    }

    public void setCodeSystem(String codeSystem) {
        this.codeSystem = codeSystem;
    }

    public String getCodeSystem() {
        return codeSystem;
    }

    public void setBusinessEvenetName(String businessEvenetName) {
        this.businessEvenetName = businessEvenetName;
    }

    public String getBusinessEvenetName() {
        return businessEvenetName;
    }

    public void setBusinessEvenetTrigger(String businessEvenetTrigger) {
        this.businessEvenetTrigger = businessEvenetTrigger;
    }

    public String getBusinessEvenetTrigger() {
        return businessEvenetTrigger;
    }

    public void setErrorEndpointId(String errorEndpointId) {
        this.errorEndpointId = errorEndpointId;
    }

    public String getErrorEndpointId() {
        return errorEndpointId;
    }

    public void setDbErrorCode(String dbErrorCode) {
        this.dbErrorCode = dbErrorCode;
    }

    public String getDbErrorCode() {
        return dbErrorCode;
    }

    public void setErrorAdditionalDescription(String errorAdditionalDescription) {
        this.errorAdditionalDescription = errorAdditionalDescription;
    }

    public String getErrorAdditionalDescription() {
        return errorAdditionalDescription;
    }

    public void setDbErrorDetails(String dbErrorDetails) {
        this.dbErrorDetails = dbErrorDetails;
    }

    public String getDbErrorDetails() {
        return dbErrorDetails;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setDbState(String dbState) {
        this.dbState = dbState;
    }

    public String getDbState() {
        return dbState;
    }

    public void setDelliveryCount(String delliveryCount) {
        this.delliveryCount = delliveryCount;
    }

    public String getDelliveryCount() {
        return delliveryCount;
    }

    public void setPurge(String purge) {
        this.purge = purge;
    }

    public String getPurge() {
        return purge;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public String getPayload() {
        return payload;
    }

    public void setDestType(String destType) {
        this.destType = destType;
    }

    public String getDestType() {
        return destType;
    }

    public void setDestUri(String destUri) {
        this.destUri = destUri;
    }

    public String getDestUri() {
        return destUri;
    }

    public void setTicketNumber(String ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setDbCount(int dbCount) {
        this.dbCount = dbCount;
    }

    public int getDbCount() {
        return dbCount;
    }
}
