package au.gov.doha.pcehr.recovery.form;


import au.gov.doha.pcehr.recovery.bo.IdentityRecordRemovalResponseBO;
import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

/**
 * IdentityRemovalForm contains getters and setters for private variables.
 * @author Rakhi Tholia, AO,  PCEHR
 * @since 10th March 2014
 * @version - x
 */

public class IdentityRecordRemovalForm {
    private String ihi;
    private String lastName;
    private String sex;
    private String dob;
    private String action_Type;
    private String operatorName;
    private String userID;
    private IdentityRemovalBO identityRemovalBO;
    private String userName;
    private String deleteStatus;
    private String changeBy;

    private String operationTypeRemoval;
    private MultipartFile file;
    private List<IdentityRemovalBO> listIdentityRemovalBO;
    private List<IdentityRecordRemovalResponseBO> listIdentityRecordRemovalResponseBO;
    private String outPutFilename;
    private List<String> listIHI;
    
    private String validationStatus;
    
    private String jsonString;
    /**
     * @return
     */
    public String getIhi() {
        return ihi;
    }

    /**
     * @param ihi
     */
    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public void setListIHI(List<String> listIHI) {
        this.listIHI = listIHI;
    }

    public List<String> getListIHI() {
        return listIHI;
    }

    public void setOutPutFilename(String outPutFilename) {
        this.outPutFilename = outPutFilename;
    }

    public String getOutPutFilename() {
        return outPutFilename;
    }

    public void setListIdentityRecordRemovalResponseBO(List<IdentityRecordRemovalResponseBO> listIdentityRecordRemovalResponseBO) {
        this.listIdentityRecordRemovalResponseBO = listIdentityRecordRemovalResponseBO;
    }

    public List<IdentityRecordRemovalResponseBO> getListIdentityRecordRemovalResponseBO() {
        return listIdentityRecordRemovalResponseBO;
    }

    public void setListIdentityRemovalBO(List<IdentityRemovalBO> listIdentityRemovalBO) {
        this.listIdentityRemovalBO = listIdentityRemovalBO;
    }

    public List<IdentityRemovalBO> getListIdentityRemovalBO() {
        return listIdentityRemovalBO;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setOperationTypeRemoval(String operationTypeRemoval) {
        this.operationTypeRemoval = operationTypeRemoval;
    }

    public String getOperationTypeRemoval() {
        return operationTypeRemoval;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSex() {
        return sex;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getDob() {
        return dob;
    }

    /**
     * @param userID
     */
    public void setUserID(String userID) {
        this.userID = userID;
    }

    /**
     * @return
     */
    public String getUserID() {
        return userID;
    }


    /**
     * @param action_Type
     */
    public void setAction_Type(String action_Type) {
        this.action_Type = action_Type;
    }

    /**
     * @return
     */
    public String getAction_Type() {
        return action_Type;
    }


    /**
     * @param operatorName
     */
    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    /**
     * @return
     */
    public String getOperatorName() {
        return operatorName;
    }


    /**
     * @param changeBy
     */
    public void setChangeBy(String changeBy) {
        this.changeBy = changeBy;
    }

    /**
     * @return
     */
    public String getChangeBy() {
        return changeBy;
    }

    /**
     * @param userName
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return
     */
    public String getUserName() {
        return userName;
    }


    public void setIdentityRemovalBO(IdentityRemovalBO identityRemovalBO) {
        this.identityRemovalBO = identityRemovalBO;
    }

    public IdentityRemovalBO getIdentityRemovalBO() {
        return identityRemovalBO;
    }

    /**
     * @return
     */
    public String getDeleteStatus() {
        return deleteStatus;
    }

    /**
     * @param deleteStatus
     */
    public void setDeleteStatus(String deleteStatus) {
        this.deleteStatus = deleteStatus;
    }


    public void setJsonString(String jsonString) {
        this.jsonString = jsonString;
    }

    public String getJsonString() {
        return jsonString;
    }

    public void setValidationStatus(String validationStatus) {
        this.validationStatus = validationStatus;
    }

    public String getValidationStatus() {
        return validationStatus;
    }
}
