package au.gov.doha.pcehr.recovery.bo;

import java.sql.Date;

public class ConsumerRegistrationBO {
    
    private String userId;
    
    private Date uDate;

    private String mBun;

    public void setMBun(String mBun) {
        this.mBun = mBun;
    }

    public String getMBun() {
        return mBun;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUDate(Date UDate) {
        this.uDate = UDate;
    }

    public Date getUDate() {
        return uDate;
    }

}
