package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.ConsumerRegistrationOIDBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ConsumerRegistrationOIDForm;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

/**
 * DAO class that interacts with the DataBase to fetch Data
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Apr 2015
 * @version Change-x
 */

@Component
public class ConsumerRegistrationOIDDAO {

    private static Logger LOG = Logger.getLogger(ConsumerRegistrationOIDDAO.class);

    @Autowired
    @Qualifier("oimJDBCTemplate")
    private JdbcTemplate oimJDBCTemplate;

    @Value("${CONSUMER_REG_OID_DAO.GET_CONSUMER_OID_LIST}")
    private String CONSUMER_REGISTRATION_OID_QUERY;

    /**
     * This method is called from the service class to perform Database related task for Consumer Registration OID.
     * Accesses Data from Database and inserts into List
     * @param consumerRegistrationOIDForm
     * @return
     * @throws RecoveryDAOException
     */
    public ConsumerRegistrationOIDForm fetchConsumerRegistrationOIDList(ConsumerRegistrationOIDForm consumerRegistrationOIDForm) throws RecoveryDAOException {
        List<ConsumerRegistrationOIDBO> consumerRegistrationOIDList = new ArrayList<ConsumerRegistrationOIDBO>();
        LOG.debug("Entered consumerRegistrationOIDList Method in DAO.... ");

        try {
            consumerRegistrationOIDList = oimJDBCTemplate.query(CONSUMER_REGISTRATION_OID_QUERY, new Object[] {
                                                                consumerRegistrationOIDForm.getFromDate(),
                                                                consumerRegistrationOIDForm.getToDate()
            },

                new RowMapper<ConsumerRegistrationOIDBO>() {

                    public ConsumerRegistrationOIDBO mapRow(ResultSet rs, int rowNum) throws SQLException {
                        ConsumerRegistrationOIDBO consumerRegsitrationOIDRpt = new ConsumerRegistrationOIDBO();
                        consumerRegsitrationOIDRpt.setUser_login(rs.getString("USR_LOGIN"));
                        consumerRegsitrationOIDRpt.setIdentity_token(rs.getString("USR_UDF_PCEHR_IDENTITY_TOKEN"));
                        consumerRegsitrationOIDRpt.setUser_create_date(rs.getDate("usr_create"));
                        return consumerRegsitrationOIDRpt;
                        
                    }
                });
            
            consumerRegistrationOIDForm.setErrorList(consumerRegistrationOIDList);
            LOG.debug(" List is" +consumerRegistrationOIDList);
        } catch (Exception e) {
            LOG.fatal("Exception occured in DAO try block", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("Leaving DAO Class");
        return consumerRegistrationOIDForm;
    }
}
