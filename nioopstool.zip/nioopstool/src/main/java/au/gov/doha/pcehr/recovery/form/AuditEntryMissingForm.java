package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.AuditEntryMissingResponseBO;

import org.springframework.web.multipart.MultipartFile;

public class AuditEntryMissingForm extends AuditEntryMissingResponseBO{
    private MultipartFile file;
    private String dataFix;
    
    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setDataFix(String dataFix) {
        this.dataFix = dataFix;
    }

    public String getDataFix() {
        return dataFix;
    }
}
