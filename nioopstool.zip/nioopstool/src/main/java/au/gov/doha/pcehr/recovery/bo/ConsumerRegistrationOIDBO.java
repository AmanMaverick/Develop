package au.gov.doha.pcehr.recovery.bo;

import java.util.Date;

public class ConsumerRegistrationOIDBO {
    
    private String user_login;
    private String identity_token;
    private Date user_create_date;

    public void setUser_login(String user_login) {
        this.user_login = user_login;
    }

    public String getUser_login() {
        return user_login;
    }

    public void setIdentity_token(String identity_token) {
        this.identity_token = identity_token;
    }

    public String getIdentity_token() {
        return identity_token;
    }

    public void setUser_create_date(Date user_create_date) {
        this.user_create_date = user_create_date;
    }

    public Date getUser_create_date() {
        return user_create_date;
    }
}
