package au.gov.doha.pcehr.recovery.bo;

public class BulkRegistrationBO {
    public BulkRegistrationBO() {
        super();
    }
    private String validateDataExtract;
    private String fileName;

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setValidateDataExtract(String validateDataExtract) {
        this.validateDataExtract = validateDataExtract;
    }

    public String getValidateDataExtract() {
        return validateDataExtract;
    }
}
