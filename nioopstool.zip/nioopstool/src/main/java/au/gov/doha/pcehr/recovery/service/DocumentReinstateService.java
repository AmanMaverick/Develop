package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.DocumentReinstateWSClientBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.wsclient.DocumentReinstateClient;

import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;

import java.util.Locale;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;


/**
 * @author Sumanta Kumar Saha
 *This is a service layer for Document reinstate.
 */
@Service
public class DocumentReinstateService {
  
    private static Logger LOG = Logger.getLogger(DocumentReinstateService.class);
    private static final String PCEHR_SUCCESS = "PCEHR_SUCCESS";
    
    @Autowired
    MessageSource messageSource ;
    
    @Autowired
    DocumentReinstateClient documentReinstateClient;
    
    /**
     *
     * @param documentReinstateBO
     * @return DocumentRemovalBO
       * @throws RecoveryServiceException
     */
    public  DocumentRemovalBO processDocumentReinstate(DocumentRemovalBO documentReinstateBO) throws RecoveryServiceException {
        LOG.debug("entering processDocumentReinstate");
        documentReinstateBO.setSoapMessage(new StringBuffer());
        documentReinstateBO.setAlertMessage(new StringBuffer());
        documentReinstateBO=performReinstate(documentReinstateBO);
        LOG.debug("leaving processDocumentReinstate::::::"+documentReinstateBO.getSoapMessage());
        return documentReinstateBO;
        
    }
    /**
     *
     * @param documentReinstateBO
     * @return DocumentRemovalBO
     * @throws RecoveryServiceException
     */
    private DocumentRemovalBO performReinstate(DocumentRemovalBO documentReinstateBO) throws RecoveryServiceException {
        LOG.debug("entering performReinstate");
       
      //  documentReinstateClient.setDocumentReinstateWSClientBO(getDocumentReinstateWSClientBO(documentReinstateBO));
        try{
            try{
            ResponseStatusType response=documentReinstateClient.reinstate(getDocumentReinstateWSClientBO(documentReinstateBO));
                LOG.debug("response code:::"+response.getCode());
                if(PCEHR_SUCCESS.equals(response.getCode())){
                    documentReinstateBO.getAlertMessage().append(response.getDescription());
                    documentReinstateBO.getSoapMessage().append(response.getDescription());
                }else{
                    documentReinstateBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{response.getDescription()},Locale.US));
                    documentReinstateBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{response.getDescription()},Locale.US));
                }
            
            
            }catch(WebServiceClientException e){
                documentReinstateBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{e.getMessage()},Locale.US));
                documentReinstateBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{e.getMessage()},Locale.US));
            }
            
            
            documentReinstateBO.setSoapMessage(documentReinstateBO.getSoapMessage().append(documentReinstateClient.getSoapMessage()));

            
            

        }catch(Exception e){
            throw new RecoveryServiceException(e);
        }
        
     
        LOG.debug("leaving performReinstate");
        return documentReinstateBO;
    }
    
    /**
     *
     * @param documentReinstateBO
     * @return DocumentReinstateWSClientBO
     */
    private DocumentReinstateWSClientBO getDocumentReinstateWSClientBO(DocumentRemovalBO documentReinstateBO){
        LOG.debug("entering getDocumentReinstateWSClientBO");
        DocumentReinstateWSClientBO documentReinstateWSClientBO=new DocumentReinstateWSClientBO();
        documentReinstateWSClientBO.setDocId(documentReinstateBO.getDocumentId());
        documentReinstateWSClientBO.setIhi(documentReinstateBO.getIhi());
        documentReinstateWSClientBO.setUsername(documentReinstateBO.getUsername());
        LOG.debug("leaving getDocumentReinstateWSClientBO");
        return documentReinstateWSClientBO;
    }
}
