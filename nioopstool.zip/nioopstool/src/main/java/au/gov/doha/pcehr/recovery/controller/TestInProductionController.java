package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.form.TestingInProdForm;
import au.gov.doha.pcehr.recovery.service.TestInProductionService;
import au.gov.doha.pcehr.recovery.validation.TestInProductionValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestInProductionController {
    private static Logger LOG = Logger.getLogger(ARRestrictionsController.class);
    private static final String EXCEPTION_PAGE = "NIO/Exception";
    private static final String TEST_IN_PRODUCTION_PAGE = "NIO/TestingInProdLanding";
    private static final String TEST_IN_PRODUCTION_ATTRIBUTE="testingInProdAttribute";
    
    @Autowired
    TestInProductionService testInProductionService;
        
    @Autowired
    private TestInProductionValidator testInProductionValidator;
    
    @InitBinder(TEST_IN_PRODUCTION_ATTRIBUTE)
    protected void initBinderTestInProd(WebDataBinder binder) {
            binder.setValidator(testInProductionValidator);         
                 }
    @AuditBefore(AuditMessageConstants.TESTING_IN_PROD_LANDINGPAGE)
    @RequestMapping(method = {RequestMethod.GET}, value="/TestingInProdCntrl" )
    public String arRestrictionsMenuHandler(@ModelAttribute(TEST_IN_PRODUCTION_ATTRIBUTE)TestingInProdForm testingInProdform) {
        return TEST_IN_PRODUCTION_PAGE;
    }
    
    @AuditBefore(AuditMessageConstants.TESTING_IN_PROD_OPERATION)
    @RequestMapping(method={RequestMethod.POST}, value="/TestingInProdOpertion")
    public String performRegisterPceher(@Valid @ModelAttribute(TEST_IN_PRODUCTION_ATTRIBUTE) TestingInProdForm testingInProdform,BindingResult tipBinnindingResult){
        LOG.debug("Inside performRegisterPceher...");
        if (tipBinnindingResult.hasErrors()) {
          
            LOG.debug("validation error for performRegisterPceher ...");
            return TEST_IN_PRODUCTION_PAGE;
        }
        testInProductionService.processRegisterPcher(testingInProdform);
        LOG.debug("leaving performRegisterPceher...");
        return TEST_IN_PRODUCTION_PAGE;
    }
    
    @ExceptionHandler(Exception.class)
    public ModelAndView handleAllException(Exception ex) {
        LOG.info("Exception handler......");
        ModelAndView model = new ModelAndView(EXCEPTION_PAGE);
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex.getMessage());
        return model;
    }
    
    
}
