package au.gov.doha.pcehr.recovery.bo;


public class DocumentReinstateBO {
    private String ihi;
    private String documentId;
    private String action;
    private String username;
    private String responseDescription;
    private StringBuffer soapMessage;
    private StringBuffer alertMessage;
    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setResponseDescription(String responseDescription) {
        this.responseDescription = responseDescription;
    }

    public String getResponseDescription() {
        return responseDescription;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setAlertMessage(StringBuffer alertMessage) {
        this.alertMessage = alertMessage;
    }

    public StringBuffer getAlertMessage() {
        return alertMessage;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
