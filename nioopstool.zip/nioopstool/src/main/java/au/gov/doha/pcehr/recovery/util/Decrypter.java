package au.gov.doha.pcehr.recovery.util;


import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;

import weblogic.security.internal.SerializedSystemIni;
import weblogic.security.internal.encryption.ClearOrEncryptedService;
import weblogic.security.internal.encryption.EncryptionService;

/**
 * @author Sapna
 * This class used for Decrypting the passwords.
 */
@Component
public class Decrypter {
    
    private static Logger LOG = Logger.getLogger(Decrypter.class);
    
    public  String decryption(String encryptedText) {
            String decryptedText="";
            try {
                    EncryptionService encryptionService =
                        SerializedSystemIni.getEncryptionService();
                    ClearOrEncryptedService clearOrEncryptedService =
                        new ClearOrEncryptedService(encryptionService);
                    decryptedText = clearOrEncryptedService.decrypt(encryptedText);   
                } catch (Exception e) {                            
                 e.printStackTrace();
            }
            return decryptedText;
        }
    
   /* public static String wlsencryption(String decryptedText) {
        String encryptedText="";
        try {
                EncryptionService encryptionService =
                    SerializedSystemIni.getEncryptionService();
                ClearOrEncryptedService clearOrEncryptedService =
                    new ClearOrEncryptedService(encryptionService);
                encryptedText = clearOrEncryptedService.encrypt(decryptedText);                           
            } catch (Exception e) {                            
             e.printStackTrace();
        }
        return encryptedText;
    }*/

}
