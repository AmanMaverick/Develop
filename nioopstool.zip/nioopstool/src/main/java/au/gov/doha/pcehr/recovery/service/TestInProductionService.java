package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.bo.RegisterPCEHRClientBO;
import au.gov.doha.pcehr.recovery.form.TestingInProdForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.wsclient.RegisterPCEHRClient;

import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.registerpcehr._2.RegisterPCEHRResponse;

import java.text.ParseException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestInProductionService {
    
    private static Logger LOG = Logger.getLogger(TestInProductionService.class);

    @Autowired
    DateTimeUtil dateTimeUtil;
    
    @Autowired
    RegisterPCEHRClient registerPCEHRClient;
    public TestingInProdForm processRegisterPcher(TestingInProdForm form) {
        LOG.debug("entring processRegisterPcher");
        StringBuffer regPcherResposne = new StringBuffer();
        
        try {
            RegisterPCEHRResponse response = registerPCEHRClient.register(createTIPWsClientBO(form));
            RegisterPCEHRResponse.IvcDetails ivcDetails = new RegisterPCEHRResponse.IvcDetails();
            if (null != response) {
                ResponseStatusType responseStatus = response.getResponseStatus();
                regPcherResposne.append("Register PCEHR Response");
                regPcherResposne.append("<br />");
                if (null != responseStatus){
                LOG.debug("Register PCEHR Response code:"+ responseStatus.getCode());
                }
                if (null != responseStatus && responseStatus.getCode().equalsIgnoreCase("PCEHR_SUCCESS")) {
                    LOG.debug("REGISTER PCEHR SUCCESS");
                    regPcherResposne.append("<br />Code :: " + responseStatus.getCode());
                    regPcherResposne.append("<br />Description :: " + responseStatus.getDescription());

                    regPcherResposne.append("<br />");
                }
                else{
                    LOG.debug("REGISTER PCEHR FALIURE");
                    regPcherResposne.append("PCEHR Registration Failed");
                    regPcherResposne.append("<br />Code :: " + responseStatus.getCode());
                    regPcherResposne.append("<br />Description :: " + responseStatus.getDescription());
                }
                ivcDetails = response.getIvcDetails();
                if (null != ivcDetails && ivcDetails.getCode() != null) {
                    LOG.debug("IVC code::"+ivcDetails.getCode());
                    regPcherResposne.append("<br />IVC CODE:: " + ivcDetails.getCode());
                    
                    regPcherResposne.append("<br />Expiry Date :: " + dateTimeUtil.getXMLGregorianDateToCustomDateString(ivcDetails.getExpiryDate()));

                    regPcherResposne.append("<br />");
                }
            }
        } catch (au.net.electronichealth.ns.pcehr.svc.intregisterpcehr._2.StandardErrorMsg error) {
            LOG.fatal("PCEHR error occured ..", error);
            LOG.fatal("here....exception" + error.getFaultInfo().getErrorCode().toString());
            LOG.fatal("here....exception" + error.getFaultInfo().getMessage());
            regPcherResposne.append("PCEHR Registration Failed");
            regPcherResposne.append("<br />Register PCEHR Error Response");
        
            regPcherResposne.append("<br />Error Code : " + error.getFaultInfo().getErrorCode());
            regPcherResposne.append("<br />Error Message : " + error.getFaultInfo().getMessage());
            regPcherResposne.append("<br />");
            LOG.fatal("Register PCEHR Failed..." + regPcherResposne);

        } catch (Exception e) {
            LOG.fatal("Register PCEHR Exception ..", e);
            regPcherResposne.append("Register PCEHR Failed");
            regPcherResposne.append("<br />");
        }
        form.setRegisterPCEHRRepsonse(regPcherResposne.toString());
        LOG.debug("Leaving processRegisterPcher");
        return form;
    }

    private RegisterPCEHRClientBO createTIPWsClientBO(TestingInProdForm form) throws ParseException,
                                                                                     DatatypeConfigurationException,
                                                                                     Exception {

        LOG.debug("Entering createTIPWsClientBO");

        RegisterPCEHRClientBO bo = new RegisterPCEHRClientBO();
        bo.setIndividualType(form.getIndividualType());
        bo.setIhi(form.getIhi());
        bo.setLastName(form.getLastName());
        bo.setSex(form.getSex());
        bo.setUserId(form.getUserId());
        bo.setDateOfBirth(dateTimeUtil.getXMLGregorianCalendar(form.getDateOfBirth()));
        bo.setPbsRPBS(form.getPbsRPBS());
        bo.setMbsDVS(form.getMbsDVS());
        bo.setPastPBSrpbs(form.getPastPBSrpbs());
        bo.setPastMBSdvs(form.getPastMBSdvs());
        bo.setAcir(form.getAcir());
        bo.setAodr(form.getAodr());
        String notificationChannel = form.getNotificationChannel();
        bo.setNotificationChannel(notificationChannel);
        if(notificationChannel.equalsIgnoreCase("email") || notificationChannel.equalsIgnoreCase("sms")){
            bo.setNotificationDetails(form.getNotificationDetails());
        }
        if (form.getIndividualType().equals("Dependent")) {
            //bo.setMedicareCardCheck(form.getMedicareCardCheck());
            bo.setArIHI(form.getArIHI());
            bo.setArLastName(form.getArLastName());
            bo.setArDateOfBirth(dateTimeUtil.getXMLGregorianCalendar(form.getArDateOfBirth()));
            bo.setArSex(form.getArSex());
            String relationshipType = form.getRelationshipType();
            bo.setRelationshipType(relationshipType);
            if(relationshipType.equalsIgnoreCase("Under 18 - Parental Responsibility")){
                bo.setHealthcareProviderAssertion(form.getHealthcareProviderAssertion());
            }
                bo.setDocumentSighted(form.getDocumentSighted());
                bo.setDocDetail(form.getDocDetail());
                
                bo.setAuthrityStartDate(form.getAuthrityStartDate().equals("")? null : dateTimeUtil.getXMLGregorianCalendar(form.getAuthrityStartDate()));
                bo.setAuthrityEndDate(form.getAuthrityEndDate().equals("")? null : dateTimeUtil.getXMLGregorianCalendar(form.getAuthrityEndDate()));
                bo.setAuthrityReviewtDate(form.getAuthrityReviewtDate().equals("")? null : dateTimeUtil.getXMLGregorianCalendar(form.getAuthrityReviewtDate()));
            
        }
        LOG.debug("Leaving createTIPWsClientBO");
        return bo;
    }


  
}
