package au.gov.doha.pcehr.recovery.bo;


/**
 * IdentityRemovalBO contains getters and setters for private variables
 * relating to demographic details of given IHI.
 * @author Rakhi Tholia, AO,  PCEHR
 * @since 10th March 2014
 * @version - x
 */

public class IdentityRemovalBO {


    private String ihi;
    private String family_Name;
    private String given_Name;
    private String dob;
    private String sex;


    /**
     * @return
     */
    public String getIhi() {
        return ihi;
    }

    /**
     * @param ihi
     */
    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    /**
     * @return
     */
    public String getFamily_Name() {
        return family_Name;
    }

    public void setFamily_Name(String family_Name) {
        this.family_Name = family_Name;
    }

    public String getGiven_Name() {
        return given_Name;
    }

    public void setGiven_Name(String given_Name) {
        this.given_Name = given_Name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }
}
