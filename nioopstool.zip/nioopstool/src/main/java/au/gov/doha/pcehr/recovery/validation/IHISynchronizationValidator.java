package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.dao.CommonValidationDAO;
import au.gov.doha.pcehr.recovery.dao.PNAStatusActiveInactiveDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.IHISynchronizeForm;
import au.gov.doha.pcehr.recovery.service.IHIDemographicsSyncService;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


/**
 * Validator class for IHI Synchronization
 * @Author Rakhi Tholia, Operations, PCEHR
 * @since 9th Apr 2015
 * @version Change-x
 */
@Component
public class IHISynchronizationValidator implements Validator {
    private static Logger LOG = Logger.getLogger(IHISynchronizationValidator.class);
    @Autowired
    private FileUtil fileUtil;
        
//    @Autowired
//    PNAStatusActiveInactiveDAO pnaStatusActiveInactiveDAO;

//    public PNAStatusActiveInactiveDAO getPNAStatusActiveInactiveDAOObject() throws RecoveryServiceException {
//        return new PNAStatusActiveInactiveDAO();
//    }
    @Autowired
    IHIDemographicsSyncService ihiDemographicsSyncService;

    @Autowired
    CommonValidationDAO commonValidationDAO;
    
    @Override
    public boolean supports(Class<?> class1) {
        return IHISynchronizeForm.class.equals(class1);
    }

    /**
     * Overriden method validates the input data and returns errors.
     * It calls different internal methods of validation depending upon Synchronization type- Bulk/Single.
     * @param object, errors
     */
    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Inside IHISynchronizationValidator");
        if (object instanceof IHISynchronizeForm) {
            IHISynchronizeForm ihiSynchronizeForm = (IHISynchronizeForm)object;
            LOG.debug("Inside IHISynchronizationValidator Synctype: " + ihiSynchronizeForm.getSyncType());
            try {
                if (ihiSynchronizeForm.getSyncType().equals("SingleIHI"))
                    errors = validateSynchronizeIHI(ihiSynchronizeForm, errors);
                else if (ihiSynchronizeForm.getSyncType().equals("BulkIHI"))
                    errors = validateBulkSynchronizeIHI(ihiSynchronizeForm, errors);
                else
                    LOG.debug("ERROR-- VALIDATION");
            } catch (Exception e) {
                LOG.error("Exception occured", e);
            }
        } else {
            LOG.debug("Invalid parameter !!!");
        }
    }

    /**
     * validateSynchronizeIHI method validates the input IHI and returns errors
     * in case of Single IHI synchronization.
     * @param ihiSynchronizeForm, errors
     * @return Errors
     */
    private Errors validateSynchronizeIHI(IHISynchronizeForm ihiSynchronizeForm,
                                          Errors errors) throws RecoveryDAOException, RecoveryServiceException {
        LOG.debug("Inside validateSynchronizeIHI...");

        //Null Validation
        ValidationUtils.rejectIfEmpty(errors, "ihi", "SynchronizeIHIFormAttribute");
        
        //IHI - 16 digit validation
        if (ihiSynchronizeForm.getIhi() != null && ihiSynchronizeForm.getIhi().length() > 0 &&
            (!ihiSynchronizeForm.getIhi().matches("[0-9]{16}"))) {
            LOG.debug("IHI......Match.....");
            errors.rejectValue("ihi", "SynchronizeIHIFormAttribute.ihiLength");
        }

        //IHI Validation call
        else if(ihiSynchronizeForm.getIhi() != null && ihiSynchronizeForm.getIhi().length() > 0){
        boolean flag = commonValidationDAO.validateIHIDemographics(ihiSynchronizeForm.getIhi());
        if (flag == false)
            errors.rejectValue("ihi", "SynchronizeIHIFormAttribute.invalidIHI");
        }

        LOG.debug("Leaving validateSynchronizeIHI !!!");
        return errors;
    }


    /**
     * validateBulkSynchronizeIHI method validates the input file and returns errors
     * in case of Bulk IHI synchronization.
     * @param ihiSynchronizeForm, errors
     * @return Errors
     */
    private Errors validateBulkSynchronizeIHI(IHISynchronizeForm ihiSynchronizeForm,
                                              Errors errors) throws RecoveryServiceException, RecoveryDAOException {
        LOG.debug("File Name :: " + ihiSynchronizeForm.getFile().getOriginalFilename());
        String name = ihiSynchronizeForm.getFile().getOriginalFilename();
        try{
            
            
            
        //File not found validation
        if (ihiSynchronizeForm.getFile().getOriginalFilename().equals("")) {
            LOG.debug("File not found");
            errors.rejectValue("file", "BulkIHISyncFile.fileNotFound");
            return errors;
        }
        if(ihiSynchronizeForm.getFile() != null && fileUtil.createList(ihiSynchronizeForm.getFile()).size() == 0){
            errors.rejectValue("file","BulkIHISyncFile.emptyFile");
            return errors;
        }

        //File format (csv only) validation
        if (!name.substring(name.indexOf('.'), name.length()).equalsIgnoreCase(".csv")) {
            LOG.debug("file name validation failed");
            errors.rejectValue("file", "BulkIHISyncFile.invalidFile");
            return errors;
        }

        //File Size Validation
        if (ihiSynchronizeForm.getFile().getSize() >= 0 && ihiSynchronizeForm.getFile().getSize() > 1000000) {
            LOG.debug("FIle size validation failed");
            errors.rejectValue("file", "BulkIHISyncFile.invalidFileSize");
            return errors;
        } else {
            LOG.debug("Checking for invalid IHI");
            List<String> ihiList = new ArrayList<String>();
            ihiList = ihiDemographicsSyncService.getIHIs(ihiSynchronizeForm);
            int count = 0;
            for (String ihi : ihiList) {
                boolean flag = commonValidationDAO.validateIHIDemographics(ihi);
                LOG.debug("IHI INVALID --- "+ihi + " :: flag : " + flag);
                if (flag == false) {
                    LOG.debug("IHI INVALID --- "+ihi);
                    count++;
                }
            }
            if (count > 0) {
                LOG.debug("Count of invalid IHIs in file:"+count);
                errors.rejectValue("file","BulkIHISyncFile.invalidIHI",new String[] {count+""}, null);
            }

        }
        }catch(Exception e){
            LOG.fatal("IHISync Validator Exception Occur ..  ", e);
        }
        LOG.info("File Size is :: " + ihiSynchronizeForm.getFile().getSize());
        LOG.debug(" Leaving validateBulkSynchronizeIHI !!!");
        return errors;
    }

}
