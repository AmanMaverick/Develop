package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.form.HealthRecordExtForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.MultipartFile;

/**
 * Validator for Health record Extraction JSP.
 * @author  Aman Sharma
 * @since R 6.0.4
 */

@Component
public class HealthRecordExtValidator implements Validator{
    
    private static Logger LOG = Logger.getLogger(HealthRecordExtValidator.class);
    @Autowired
    @Qualifier("dateTimeUtil")
    private DateTimeUtil dateTimeUtil;
    
    @Autowired
    private FileUtil fileUtil;
    
    @Override
    public boolean supports(Class<?> c) {
        return HealthRecordExtForm.class.equals(c);
    }
    /**
     * This method is used for validation
     * @param object
     * @param errors
     */
    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("entering validate method ...");
        HealthRecordExtForm form = (HealthRecordExtForm) object;
        try{
            if(form.getViewType().equals("")){
                errors.rejectValue("viewType","HealthRecordExtFormAttribute.viewTypeValidation");
            }
            if(form.getConfidentiality()==null || form.getConfidentiality().isEmpty()){
                errors.rejectValue("confidentiality","HealthRecordExtFormAttribute.dataFix");
            }else if(form.getConfidentiality().size()>2){
                errors.rejectValue("confidentiality","HealthRecordExtFormAttribute.dataFix");
            }
            
            String fileName = form.getIhiExtractionLst().getOriginalFilename();
            if(form.getIhiExtractionLst().getSize()!=0){
                LOG.info("Validate the csv file");
                errors = validateHealthRecordExtFile(form,errors);
                validateHealthExt(form,errors);
            }else if(fileName.equals("")){
                errors.rejectValue("ihiExtractionLst","HealthRecordExtFormAttribute.file");
            }else if(form.getIhiExtractionLst() != null){
                List<String> docIdList = fileUtil.createList(form.getIhiExtractionLst());
                if(docIdList.size() == 0){
                    errors.rejectValue("ihiExtractionLst","HealthRecordExtFormAttribute.emptyFile");
                }
            }
          
            // ValidationUtils.rejectIfEmpty(errors, "fromDate", "HealthRecordExtAttribute.fromDate");
            if(("".equals(form.getFromDate()) && !"".equals(form.getToDate()))||(!"".equals(form.getFromDate()) && "".equals(form.getToDate()))){
               errors.rejectValue("fromDate", "HealthRecordExtAttribute.InvalidEntry");
            } else if(!"".equals(form.getFromDate()) && !"".equals(form.getToDate())){
                        
                //Validating date Format for FromDate
                boolean validIndD = dateTimeUtil.validatedate(form.getFromDate(), "dd/MM/yyyy");
                if(!validIndD){
                    errors.rejectValue("fromDate", "HealthRecordExtAttribute.InvalidDate");
                }
                else if(form.getFromDate().length()!=10){
                    errors.rejectValue("fromDate", "HealthRecordExtAttribute.InvalidDate");
                }
                                
                //Validating date Format for toDate.
                boolean validateToDate = dateTimeUtil.validatedate(form.getToDate(), "dd/MM/yyyy");
                if(!validateToDate){
                    errors.rejectValue("toDate", "HealthRecordExtAttribute.InvalidDate");
                }
                else if(form.getFromDate().length()!=10){
                    errors.rejectValue("toDate", "HealthRecordExtAttribute.InvalidDate");
                }
                
                //validate to check if toDate is greater than fromDate
                boolean flag = dateTimeUtil.reconDateOrder(form.getToDate(), form.getFromDate());
                if(!flag){
                    errors.rejectValue("toDate", "HealthRecordExtAttribute.InvalidDateOccurance");
                }
            }
            
            
        }catch(Exception e){
            LOG.error("Exception occured",e);
        }
        
    }
    /**
     * This method validates the uploaded file.
     * File size, File Type(.csv)
     * @param form
     * @param errors
     * @return
     */
    private Errors validateHealthRecordExtFile(HealthRecordExtForm form, Errors errors) throws Exception{
        String fileName = form.getIhiExtractionLst().getOriginalFilename();
        if(fileName.equals("")){
            LOG.info("File not found");
        }else if(!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv")){
            LOG.info("File format is not CSV");
            errors.rejectValue("ihiExtractionLst","HealthRecordExtFormAttribute.InvalidFile");
        }else if(form.getIhiExtractionLst().getSize()>1000000){
            LOG.info("File size validation failed.");
            errors.rejectValue("ihiExtractionLst","HealthRecordExtFormAttribute.InvalidFileSize");
        }else{
            LOG.info("file size :: "+form.getIhiExtractionLst().getSize());
        }
        
        return errors;        
    }
    
    /**
     * This method validates the uploaded IHIs in the file.
     * @param form
     * @param errors
     * @return
     */
    private Errors validateHealthExt(HealthRecordExtForm form, Errors errors){
            LOG.debug("entering validateDocTrasnformation ...");
            MultipartFile file = form.getIhiExtractionLst();
            FileUtil fileUtil=new FileUtil();
           if(file!=null &&  !"csv".equalsIgnoreCase(FilenameUtils.getExtension(file.getOriginalFilename()))) {
                errors.rejectValue( "file", "HealthRecordExtAttribute.inputFileFormat");
            }else{
                try{
                        List<String> fileList = fileUtil.createList(file);
                        int size= fileList.size();
                   
                    if(size<1){
                        LOG.debug("file conains less than 1 IHI..");
                        errors.rejectValue( "ihiExtractionLst", "HealthRecordExtAttribute.fileSizeMinSize");  
                    }
                }
                catch(Exception e){
                        LOG.debug("Exception occured ..",e);
                    }
            }
            LOG.debug("Leaving validateDocTrasnformation ...");
            
            return errors;
        }


}
