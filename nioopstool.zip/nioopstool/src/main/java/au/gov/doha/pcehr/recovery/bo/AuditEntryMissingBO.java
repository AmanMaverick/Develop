package au.gov.doha.pcehr.recovery.bo;


public class AuditEntryMissingBO {
    private String ihi;
    private String ihiName;
    private String operationPerfomed;
    private String subject;
    private String accessingOrg;
    private String accessingOrgName;
    private String inheritingOrg;
    private String inheritingOrgName;
    private String serviceStopTime;
    private String authorPerson;
    private String authorPersonName;
    private String accessLevel;
    private String documentID;
    private String integrationID;
    private String messageID;
    private boolean auditEntryExists;
    private boolean rlsEntryExists;
    private String systemType;
    private boolean classCodeExsits;
    //auditEventID
    private String auditEventID;

    public void setAuditEventID(String auditEventID) {
        this.auditEventID = auditEventID;
    }

    public String getAuditEventID() {
        return auditEventID;
    }
   

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setIhiName(String ihiName) {
        this.ihiName = ihiName;
    }

    public String getIhiName() {
        return ihiName;
    }

    public void setOperationPerfomed(String operationPerfomed) {
        this.operationPerfomed = operationPerfomed;
    }

    public String getOperationPerfomed() {
        return operationPerfomed;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setAccessingOrg(String accessingOrg) {
        this.accessingOrg = accessingOrg;
    }

    public String getAccessingOrg() {
        return accessingOrg;
    }

    public void setInheritingOrg(String inheritingOrg) {
        this.inheritingOrg = inheritingOrg;
    }

    public String getInheritingOrg() {
        return inheritingOrg;
    }

    public void setServiceStopTime(String serviceStopTime) {
        this.serviceStopTime = serviceStopTime;
    }

    public String getServiceStopTime() {
        return serviceStopTime;
    }

    public void setAuthorPerson(String authorPerson) {
        this.authorPerson = authorPerson;
    }

    public String getAuthorPerson() {
        return authorPerson;
    }

    public void setAccessLevel(String accessLevel) {
        this.accessLevel = accessLevel;
    }

    public String getAccessLevel() {
        return accessLevel;
    }

    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    public String getDocumentID() {
        return documentID;
    }

    public void setAccessingOrgName(String accessingOrgName) {
        this.accessingOrgName = accessingOrgName;
    }

    public String getAccessingOrgName() {
        return accessingOrgName;
    }

    public void setInheritingOrgName(String inheritingOrgName) {
        this.inheritingOrgName = inheritingOrgName;
    }

    public String getInheritingOrgName() {
        return inheritingOrgName;
    }

    public void setAuthorPersonName(String authorPersonName) {
        this.authorPersonName = authorPersonName;
    }

    public String getAuthorPersonName() {
        return authorPersonName;
    }

    public void setAuditEntryExists(boolean auditEntryExists) {
        this.auditEntryExists = auditEntryExists;
    }

    public boolean isAuditEntryExists() {
        return auditEntryExists;
    }

    public void setRlsEntryExists(boolean rlsEntryExists) {
        this.rlsEntryExists = rlsEntryExists;
    }

    public boolean isRlsEntryExists() {
        return rlsEntryExists;
    }

    public void setIntegrationID(String integrationID) {
        this.integrationID = integrationID;
    }

    public String getIntegrationID() {
        return integrationID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public String getMessageID() {
        return messageID;
    }

    public void setSystemType(String systemType) {
        this.systemType = systemType;
    }

    public String getSystemType() {
        return systemType;
    }

    public void setClassCodeExsits(boolean classCodeExsits) {
        this.classCodeExsits = classCodeExsits;
    }

    public boolean isClassCodeExsits() {
        return classCodeExsits;
    }
}
