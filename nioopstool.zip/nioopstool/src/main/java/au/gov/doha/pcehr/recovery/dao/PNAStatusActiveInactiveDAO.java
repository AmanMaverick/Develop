package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.PNAStatusActiveInactiveBO;
import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepBO;
import au.gov.doha.pcehr.recovery.constants.RecoverConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.util.DBUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;


/**
 * This DAO layer fetch data from PNA DB for PCEHR status update.
 * @Author Vikash/Sumanta
 */

@Component
public class PNAStatusActiveInactiveDAO {
    
    private static Logger LOG = Logger.getLogger(PNAStatusActiveInactiveDAO.class);
    
    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     * @throws RecoveryDAOException
     */
    public PNAStatusActiveInactiveBO fetchPcehr_Record(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) throws RecoveryDAOException{
        LOG.debug("entering fetchPcehr_Record");
        Connection  conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        boolean isRecordExist = false;
        try{
            LOG.debug("entering into try block");
            StringBuffer query = new StringBuffer();
            query.append("SELECT RECORD_ID,RECORD_STATUS,RECORD_DEACTIVATION_REASON FROM oes_pnadb.PCEHR_RECORD WHERE IHI = ? ");
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, pNAStatusActiveInactiveBO.getIhi());
            rst = pStmt.executeQuery();
            while(rst.next()){
                pNAStatusActiveInactiveBO.setRecordId(rst.getString(1));
                pNAStatusActiveInactiveBO.setRecordStatus(rst.getString(2));
                pNAStatusActiveInactiveBO.setRecordDeactivationReason(rst.getString(3));
                isRecordExist = true;
            }  
            pNAStatusActiveInactiveBO.setValidationStatus(isRecordExist);
            if(!isRecordExist){
                pNAStatusActiveInactiveBO.setAlertMessage("Invalid IHI.");
                return pNAStatusActiveInactiveBO;
            }
            LOG.debug("staus is....."+pNAStatusActiveInactiveBO.getStatus());
            if("ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus())){
                if(pNAStatusActiveInactiveBO.getRecordDeactivationReason()!=null && pNAStatusActiveInactiveBO.getRecordDeactivationReason().equals("1")){
                    pNAStatusActiveInactiveBO.setReason("Death");
                }else if(pNAStatusActiveInactiveBO.getRecordDeactivationReason()!=null && pNAStatusActiveInactiveBO.getRecordDeactivationReason().equals("8")){
                    pNAStatusActiveInactiveBO.setReason(RecoverConstants.PNA_STATUS_6);
                }
            }
            
        }catch(Exception e){
            LOG.fatal("Exception Occured..",e);
            throw new RecoveryDAOException(e);
        }finally{
            DBUtility.close(rst); 
            DBUtility.close(pStmt); 
            DBUtility.close(conn);   
        }
        LOG.debug("pNAStatusActiveInactiveBO.setReason...."+pNAStatusActiveInactiveBO.getReason());
        LOG.debug("Leaving fetchPcehr_Record"+pNAStatusActiveInactiveBO.getRecordStatus()+"id:::::"+pNAStatusActiveInactiveBO.getRecordId());
        return pNAStatusActiveInactiveBO;
    }
    
    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     * @throws RecoveryDAOException
     */
    public boolean validateIHI(String IHI) throws RecoveryDAOException{
        LOG.debug("entering fetchPcehr_Record");
        Connection  conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        boolean flag=false;
        try{
            StringBuffer query = new StringBuffer();
            query.append("SELECT * FROM oes_pnadb.PCEHR_RECORD WHERE IHI = ? ");
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, IHI);
            rst = pStmt.executeQuery();
            while(rst.next()){
               flag=true;
            }  
        }catch(Exception e){
            LOG.fatal("Exception Occured..",e);
            throw new RecoveryDAOException(e);
        }finally{
            DBUtility.close(rst); 
            DBUtility.close(pStmt); 
            DBUtility.close(conn);   
        }
    
        return flag;
    }
    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     * @throws RecoveryDAOException
     */
    public boolean validateRepresentativeIHI(String IHI) throws RecoveryDAOException{
        LOG.debug("entering fetchPcehr_Record");
        Connection  conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        boolean flag=false;
        try{
            StringBuffer query = new StringBuffer();
            query.append("SELECT * FROM oes_pnadb.pcehr_identity WHERE IHI = ? ");
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, IHI);
            rst = pStmt.executeQuery();
            while(rst.next()){
               flag=true;
            }  
        }catch(Exception e){
            LOG.fatal("Exception Occured..",e);
            throw new RecoveryDAOException(e);
        }finally{
            DBUtility.close(rst); 
            DBUtility.close(pStmt); 
            DBUtility.close(conn);   
        }
    
        return flag;
    }
    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     * @throws RecoveryDAOException
     */
    public PNAStatusActiveInactiveBO  fetchReactivateAuthRepData(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) throws RecoveryDAOException{
        StringBuffer query = new StringBuffer();
        query.append("  SELECT iden.record_id,   ");
        query.append("    iden.RELATIONSHIP_CREATED_BY,   ");
        query.append("    iden.user_id,   ");
        query.append("    auth.AUTHORITY_TYPE,   ");
        query.append("    auth.issuing_authority,   ");
        query.append("    TO_CHAR(auth.authority_start_date,'ddMMyyyy'),   ");
        query.append("    auth.authority_doc_type,iden.RELATIONSHIP_TYPE_ID    ");
        query.append("  FROM oes_pnadb.identity_record_relationship iden,   ");
        query.append("    oes_pnadb.authority_relationship auth,   ");
        query.append("    oes_pnadb.pcehr_identity piden,   ");
        query.append("    oes_pnadb.pcehr_record a   ");
        query.append("  WHERE iden.user_id IN   ");
        query.append("    (SELECT user_id   ");
        query.append("    FROM oes_pnadb.identity_record_relationship   ");
        query.append("    WHERE record_id IN   ");
        query.append("      (SELECT record_id FROM oes_pnadb.pcehr_record WHERE ihi= ?   ");
        query.append("      )   ");
        query.append("    )   ");
        query.append("  AND iden.record_id IN   ");
        query.append("    (SELECT record_id FROM oes_pnadb.pcehr_record WHERE ihi= ?   ");
        query.append("    )   ");
        query.append("  AND iden.RELATIONSHIP_TYPE_ID  IN (5,16,17,18,19,20)   ");
        query.append("  AND iden.relationship_status_id = 1   ");
        query.append("  AND auth.user_id               IN   ");
        query.append("    (SELECT user_id   ");
        query.append("    FROM oes_pnadb.identity_record_relationship   ");
        query.append("    WHERE record_id IN   ");
        query.append("      (SELECT record_id FROM oes_pnadb.pcehr_record WHERE ihi= ?   ");
        query.append("      )   ");
        query.append("    )   ");
        query.append("  AND auth.record_id IN   ");
        query.append("    (SELECT record_id FROM oes_pnadb.pcehr_record WHERE ihi= ?   ");
        query.append("    )   ");
        query.append("  AND piden.ihi             = a.ihi   ");
        query.append("  AND auth.AUTHORITY_STATUS = 0   ");
        query.append("  AND auth.user_id          = iden.user_id   ");
        query.append("  AND iden.user_id          = piden.user_id   ");
        query.append("  AND auth.record_id        = iden.record_id    ");
        

        Connection  conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        try{
            LOG.debug("query Representative "+query.toString());
            LOG.debug("getIhi()"+pNAStatusActiveInactiveBO.getIhi());
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            
            pStmt.setString(1, pNAStatusActiveInactiveBO.getIhi());
            pStmt.setString(2, pNAStatusActiveInactiveBO.getIhi());
            pStmt.setString(3, pNAStatusActiveInactiveBO.getIhi());
            pStmt.setString(4, pNAStatusActiveInactiveBO.getIhi());
            
            
            rst = pStmt.executeQuery();
            List<ReactivateAuthRepBO> list = new ArrayList<ReactivateAuthRepBO>();
            while(rst.next()){
                LOG.debug("query Representative Got the record");
                ReactivateAuthRepBO reactivateAuthRepBO = new ReactivateAuthRepBO();
               
                reactivateAuthRepBO.setRecordIHI(pNAStatusActiveInactiveBO.getIhi());
                reactivateAuthRepBO.setCreated_by(rst.getString(2));
                reactivateAuthRepBO.setUserID(rst.getNString(3));
                reactivateAuthRepBO.setAuth_type(rst.getInt(4));
                reactivateAuthRepBO.setAuth_issue(rst.getString(5));
                reactivateAuthRepBO.setAuth_startdate(rst.getString(6));
                reactivateAuthRepBO.setDocType(rst.getInt(7));
                reactivateAuthRepBO.setRel_type(rst.getString(8));
                LOG.debug("reactivateAuthRepBO - User id"+reactivateAuthRepBO.getUserID());
                list.add(reactivateAuthRepBO);
            }  
            pNAStatusActiveInactiveBO.setReactivateAuthRepBO(list);
        }catch(Exception e){
            LOG.fatal("Exception Occured..",e);
            throw new RecoveryDAOException(e);
        }finally{
            DBUtility.close(rst); 
            DBUtility.close(pStmt); 
            DBUtility.close(conn);   
        }
     return pNAStatusActiveInactiveBO;   
    }
    
    
    
}
