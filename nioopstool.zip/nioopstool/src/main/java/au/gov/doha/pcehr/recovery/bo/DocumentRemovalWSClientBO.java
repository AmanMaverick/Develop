package au.gov.doha.pcehr.recovery.bo;


public class DocumentRemovalWSClientBO {
    private String ihi;
    private String documentId;
    private String resonForRemoval;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setResonForRemoval(String resonForRemoval) {
        this.resonForRemoval = resonForRemoval;
    }

    public String getResonForRemoval() {
        return resonForRemoval;
    }
}
