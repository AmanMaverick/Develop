package au.gov.doha.pcehr.recovery.bo;


public class DocumentRemovalBO {
    public DocumentRemovalBO() {
        super();
    }
    
    private String ihi;
    private String documentId;
    private String resonForRemoval;
    private String action;
    private String responseCode;
    private String responseDetails;
    private String username;
    private String responseDescription;
    private StringBuffer soapMessage;
    private StringBuffer alertMessage;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setResonForRemoval(String resonForRemoval) {
        this.resonForRemoval = resonForRemoval;
    }

    public String getResonForRemoval() {
        return resonForRemoval;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseDetails(String responseDetails) {
        this.responseDetails = responseDetails;
    }

    public String getResponseDetails() {
        return responseDetails;
    }

    public void setResponseDescription(String responseDescription) {
        this.responseDescription = responseDescription;
    }

    public String getResponseDescription() {
        return responseDescription;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }

    public void setAlertMessage(StringBuffer alertMessage) {
        this.alertMessage = alertMessage;
    }

    public StringBuffer getAlertMessage() {
        return alertMessage;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
