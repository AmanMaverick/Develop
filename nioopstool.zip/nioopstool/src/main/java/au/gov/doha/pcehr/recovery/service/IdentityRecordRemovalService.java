package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.IdentityRecordRemovalResponseBO;
import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;
import au.gov.doha.pcehr.recovery.constants.AuditConstants;
import au.gov.doha.pcehr.recovery.dao.IdentityRecordRemovalDao;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.IdentityRecordRemovalForm;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.util.JSONUtil;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


/**
 * Service class for Identity and Record Removal page.
 * @author Rakhi Tholia, AO,  PCEHR
 * @since 10th March 2014
 * @version - x
 */
@Service
public class IdentityRecordRemovalService {
    private static Logger LOG = Logger.getLogger(IdentityRecordRemovalService.class);


    // Fetching value from Property File and assigning it to a variable.
    @Value("${IdentityRecordRemoval.DropDown.action_Type1}")
    private String incorrect_Record_Removal;

    @Value("${IdentityRecordRemoval.DropDown.action_Type2}")
    private String incorrect_Identity_Removal;

    @Value("${IdentityRecordRemoval.DropDown.action_Type3}")
    private String incorrect_Record_Identity_Removal;

    @Value("${IdentityRecordRemoval.DropDown.action_Type4}")
    private String incorrect_Child_Record_Removal;


    @Autowired
    private IdentityRecordRemovalDao identityRecordRemovalDao;

    @Autowired
    private InsertAuditRecordService audit;
    @Autowired
    FileUtil fileUtil;

    /**
     * This Method fetch demographic details from Database by calling DAO class methods.
     * @param identityRecordRemovalForm
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    public IdentityRecordRemovalForm getDetails(IdentityRecordRemovalForm identityRecordRemovalForm) throws RecoveryServiceException,
                                                                                                            RecoveryDAOException {
        LOG.debug("Inside Service - getDetails Method");
        identityRecordRemovalForm = identityRecordRemovalDao.fetchDemographicsDtls(identityRecordRemovalForm);
        return identityRecordRemovalForm;
    }


    /**
     * deleteRecord Method deletes records for the given IHI.
     * It calls DAO Class methods for deleting from database.
     * @param identityRecordRemovalForm
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    public IdentityRecordRemovalForm deleteRecord(IdentityRecordRemovalForm identityRecordRemovalForm) throws IOException,
                                                                                                              JsonParseException,
                                                                                                              JsonMappingException {

        LOG.debug("Inside Service - delete Record Method" + identityRecordRemovalForm.getAction_Type());
        identityRecordRemovalForm= processDeleteingIdentityAndRecords(identityRecordRemovalForm,"Records Successfully Deleted.");
        if("bulkInput".equals(identityRecordRemovalForm.getOperationTypeRemoval())){
            fileUtil.createCSVForIdentityRemoval(identityRecordRemovalForm);
        }
        return identityRecordRemovalForm;
    }

    /**
     * deleteIdentity Method deletes Identity for the given IHI.
     * It calls DAO Class methods for deleting from database.
     * @param identityRecordRemovalForm
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    public IdentityRecordRemovalForm deleteIdentity(IdentityRecordRemovalForm identityRecordRemovalForm) throws RecoveryServiceException,
                                                                                                                RecoveryDAOException,
                                                                                                                IOException,
                                                                                                                JsonParseException,
                                                                                                                JsonMappingException {


        LOG.debug("Inside Service - deleteIdentity Method");
        
        identityRecordRemovalForm= processDeleteingIdentityAndRecords(identityRecordRemovalForm,"Identity Successfully Deleted.");
        if("bulkInput".equals(identityRecordRemovalForm.getOperationTypeRemoval())){
            fileUtil.createCSVForIdentityRemoval(identityRecordRemovalForm);
        }
        return identityRecordRemovalForm;
    }


    /**
     * deleteIdentityAndRecord Method deletes records as well as identity for a given IHI.
     * It calls DAO Class methods for deleting from database.
     * @param identityRecordRemovalForm
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    public IdentityRecordRemovalForm deleteIdentityAndRecord(IdentityRecordRemovalForm identityRecordRemovalForm) throws RecoveryServiceException,
                                                                                                                         RecoveryDAOException,
                                                                                                                         IOException,
                                                                                                                         JsonParseException,
                                                                                                                         JsonMappingException {

        LOG.debug("Inside Service - deleteIdentityAndRecord Method - " + identityRecordRemovalForm.getAction_Type());
        identityRecordRemovalForm= processDeleteingIdentityAndRecords(identityRecordRemovalForm,"Records and Identity Successfully Deleted");
        if("bulkInput".equals(identityRecordRemovalForm.getOperationTypeRemoval())){
            fileUtil.createCSVForIdentityRemoval(identityRecordRemovalForm);
        }
        return identityRecordRemovalForm;
       
    }


    /**
     * deleteChildRecord Method deletes Child's record having no Identity.
     * It calls DAO Class methods for deleting from database.
     * @param identityRecordRemovalForm
     * @throws RecoveryDAOException, RecoveryServiceException
     */
    public IdentityRecordRemovalForm deleteChildRecord(IdentityRecordRemovalForm identityRecordRemovalForm) throws RecoveryServiceException,
                                                                                                                   RecoveryDAOException,
                                                                                                                   IOException,
                                                                                                                   JsonParseException,
                                                                                                                   JsonMappingException {

        LOG.debug("Inside Service - delete Method" + identityRecordRemovalForm.getAction_Type());

        
        identityRecordRemovalForm= processDeleteingIdentityAndRecords(identityRecordRemovalForm,"Child Record Successfully Deleted..");
        if("bulkInput".equals(identityRecordRemovalForm.getOperationTypeRemoval())){
            fileUtil.createCSVForIdentityRemoval(identityRecordRemovalForm);
        }
        return identityRecordRemovalForm;
    }

    /**
     *
     * @param identityRecordRemovalForm
     * @return
     */
    private IdentityRecordRemovalForm processDeleteingIdentityAndRecords(IdentityRecordRemovalForm identityRecordRemovalForm,
                                                                         String reposneDEscription) throws IOException,
                                                                                                           JsonParseException,
                                                                                                           JsonMappingException {
        List<IdentityRemovalBO> identityRemovalBOList = new ArrayList<>();
        String action_Type = identityRecordRemovalForm.getAction_Type();
        if (identityRecordRemovalForm.getOperationTypeRemoval().equals("singleInput")) {
            identityRemovalBOList = setIdentityBoListForSingleInput(identityRecordRemovalForm);
        }else{
            JSONUtil<IdentityRemovalBO> jsonUtil = new JSONUtil<IdentityRemovalBO>();
            identityRemovalBOList = jsonUtil.getJsonToIdentityRemovalBOList(identityRecordRemovalForm.getJsonString());
        }
       identityRecordRemovalForm.setListIdentityRemovalBO(identityRemovalBOList);
        for (int i = 0; i < identityRemovalBOList.size(); i++) {
           // identityRemovalBO = inputRecordsList.get(i);
            String ihi = identityRemovalBOList.get(i).getIhi();
            LOG.debug("Action Type:" + identityRecordRemovalForm.getAction_Type());
            LOG.debug("IHI Used:" + ihi);
            try {
                if (action_Type.equals("Incorrect Record Removal")){
                    identityRecordRemovalDao.deleteRecord(ihi);
                }else if (action_Type.equals("Incorrect Identity Removal")){
                    identityRecordRemovalDao.deleteIdentity(ihi);
                }else if (action_Type.equals("Incorrect Identity & Record Removal")){
                    identityRecordRemovalDao.deleteIdentityRecord(ihi);
                }else if (action_Type.equals("Incorrect Child Record Removal_with No Identity")){
                    identityRecordRemovalDao.deleteChildRecord(ihi);
                }
                    
                identityRecordRemovalForm =
                    callInsertAudit(ihi, identityRecordRemovalForm);
                
                if(identityRecordRemovalForm.getOperationTypeRemoval().equals("bulkInput")) {
                    processBulkInputResponse(identityRecordRemovalForm,identityRemovalBOList.get(i), reposneDEscription);
                }else{
                    identityRecordRemovalForm.setDeleteStatus(reposneDEscription);
                    return identityRecordRemovalForm;
                }


                LOG.debug("Status:" + identityRecordRemovalForm.getDeleteStatus());
            }


            catch (Exception e) {
                LOG.fatal("Exception Occured..", e);
                if (identityRecordRemovalForm.getOperationTypeRemoval().equals("bulkInput")) {
                    processBulkInputResponse(identityRecordRemovalForm, identityRemovalBOList.get(i), "Delete Unsuccessful");
                } else {
                    identityRecordRemovalForm.setDeleteStatus("Delete Unsuccessful.");
                    return identityRecordRemovalForm;
                }


            }
        }
        return identityRecordRemovalForm;

    }


    /**
     * This method handles auditing request for OSB through webservice and request for the audit insertion for the identity/record removal operation.
     * @param identityRecordRemovalForm
     * @return
     */
    private IdentityRecordRemovalForm callInsertAudit(String ihi, IdentityRecordRemovalForm identityRecordRemovalForm) {
        AuditRecordBO auditBO = getAuditRecordBO(ihi, identityRecordRemovalForm);
        auditBO = audit.insertAudit(auditBO);
        LOG.debug("user id " + auditBO.getUserID() + " audit inserted");
        auditBO.setSubject(identityRecordRemovalForm.getIhi());
        return identityRecordRemovalForm;
    }


    /**
     * This method forms an object AuditRecordBO based on IdentityRemovalBO.
     * @param identityRecordRemovalForm
     * @return
     */
    private AuditRecordBO getAuditRecordBO(String ihi, IdentityRecordRemovalForm identityRecordRemovalForm) {

        AuditRecordBO auditBO = new AuditRecordBO();
        auditBO.setIhi(ihi);
        auditBO.setUserID(identityRecordRemovalForm.getUserID());
        LOG.debug("Used Id set to:" + identityRecordRemovalForm.getUserID());
        auditBO.setUsername(identityRecordRemovalForm.getOperatorName());
        LOG.debug("User Name set to:" + identityRecordRemovalForm.getOperatorName());
        auditBO.setActionType("Delete");
        auditBO.setSubjectType("IHI");
        auditBO.setVendor(AuditConstants.VENDOR);
        auditBO.setComponentSource(AuditConstants.COMPONENT_SOURCE);
        auditBO.setProductName(AuditConstants.PRODUCT_NAME);
        auditBO.setProdoctVersion(AuditConstants.PRODUCT_VERSION);
        auditBO.setPlatForm(AuditConstants.PLATFORM);
        auditBO.setSoapMesage(AuditConstants.SOAP_MESSAGE);
        auditBO.setReason(null);
        auditBO.setStatus(AuditConstants.STATUS);
        auditBO.setTransactionStatus("COMPLETED");
        auditBO.setLogEvent("true");
        auditBO.setEventSource("OPS Tool");
        if (incorrect_Record_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
            auditBO.setBusinessEvent("deleteRecordBySystemOperator");
            auditBO.setOperationPerfomed("deleteRecordBySystemOperator");
        } else if (incorrect_Identity_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
            auditBO.setBusinessEvent("deleteIdentityBySystemOperator");
            auditBO.setOperationPerfomed("deleteIdentityBySystemOperator");
        } else if (incorrect_Record_Identity_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
            auditBO.setBusinessEvent("deleteIdentityRecordBySystemOperator");
            auditBO.setOperationPerfomed("deleteIdentityRecordBySystemOperator");
        } else if (incorrect_Child_Record_Removal.equals(identityRecordRemovalForm.getAction_Type())) {
            auditBO.setBusinessEvent("deleteChildRecordBySystemOperator");
            auditBO.setOperationPerfomed("deleteChildRecordBySystemOperator");
        }
        auditBO.setMessageLogLevel(AuditConstants.MESSAGE_LOG_LEVEL);
        auditBO.setStatusCode(AuditConstants.STATUS_CODE);
        auditBO.setProductType("");
        auditBO.setDescription("Record Deleted");
        auditBO.setDetails("Record Deleted");

        return auditBO;
    }

    /**
     *
     * @param identityRecordRemovalForm
     * @return
     */
    private List<IdentityRemovalBO> setIdentityBoListForSingleInput(IdentityRecordRemovalForm identityRecordRemovalForm) {
       
        
        List<IdentityRemovalBO> identityRemovalBOList = new ArrayList<>();
        IdentityRemovalBO bo = new IdentityRemovalBO();
        bo.setIhi(identityRecordRemovalForm.getIhi());
        identityRemovalBOList.add(bo);
        return identityRemovalBOList;
    }

    /**
     *
     * @param identityRecordRemovalForm
     * @param identityRemovalBO
     * @return
     */
    private IdentityRecordRemovalForm processBulkInputResponse(IdentityRecordRemovalForm identityRecordRemovalForm,
                                                               IdentityRemovalBO identityRemovalBO,                                                              
                                                               String responseDescription) {
        LOG.debug("Entering processBulkInputResponse");
        IdentityRecordRemovalResponseBO responseBo = fileUtil.setErrorBo(identityRemovalBO);
        responseBo.setDescription(responseDescription);
        if (identityRecordRemovalForm.getListIdentityRecordRemovalResponseBO() != null) {
            identityRecordRemovalForm.getListIdentityRecordRemovalResponseBO().add(responseBo);
        } else {
            List<IdentityRecordRemovalResponseBO> listResponseBo = new ArrayList<IdentityRecordRemovalResponseBO>();
            listResponseBo.add(responseBo);
            identityRecordRemovalForm.setListIdentityRecordRemovalResponseBO(listResponseBo);
        }
        LOG.debug("Leaving processBulkInputResponse");
        return identityRecordRemovalForm;
    }
}
