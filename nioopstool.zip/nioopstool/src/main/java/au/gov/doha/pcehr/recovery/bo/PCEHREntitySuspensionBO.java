package au.gov.doha.pcehr.recovery.bo;

import au.pcehr.ws.pna.pd.OIMDisableEntitiesResponse;

import java.util.List;
import java.util.Map;

public class PCEHREntitySuspensionBO {
    
    private String entityType;

    private String enableOrDisable;
    private String sysOperatorName;
    private String userId;
    
    private List<String> entities;
    
    private Map<String, OIMDisableEntitiesResponse>  suspensionClientResp;
    private StringBuffer soapMessage;
    private StringBuffer alertMsg;
    
    private String fileName;
    
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityType() {
        return entityType;
    }
   
    public void setEnableOrDisable(String enableOrDisable) {
        this.enableOrDisable = enableOrDisable;
    }

    public String getEnableOrDisable() {
        return enableOrDisable;
    }

    public void setSysOperatorName(String sysOperatorName) {
        this.sysOperatorName = sysOperatorName;
    }

    public String getSysOperatorName() {
        return sysOperatorName;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setEntities(List<String> entities) {
        this.entities = entities;
    }

    public List<String> getEntities() {
        return entities;
    }


    public void setSuspensionClientResp(Map<String, OIMDisableEntitiesResponse> suspensionClientResp) {
        this.suspensionClientResp = suspensionClientResp;
    }

    public Map<String, OIMDisableEntitiesResponse> getSuspensionClientResp() {
        return suspensionClientResp;
    }

    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }

    public void setAlertMsg(StringBuffer alertMsg) {
        this.alertMsg = alertMsg;
    }

    public StringBuffer getAlertMsg() {
        return alertMsg;
    }


    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }
}
