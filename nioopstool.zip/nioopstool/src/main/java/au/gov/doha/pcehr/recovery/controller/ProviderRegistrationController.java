package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ProviderRegistrationForm;
import au.gov.doha.pcehr.recovery.service.ProviderRegistrationService;
import au.gov.doha.pcehr.recovery.validation.ProviderRegistrationValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Controller class to perform all ProviderRegistration related task.
 * Redirects to Provider Registration operations and later on submit to Provider Registration List.
 * @Since Apr 2015
 * @Author Dinesh Kaki, Operations, PCEHR
 * @version Change-x
 */

@Controller
@RequestMapping("/ProviderRegistration**")
public class ProviderRegistrationController {

    private static Logger LOG = Logger.getLogger(ProviderRegistrationController.class);
    private static final String MAIN_PAGE_LINK = "/NIO/ProviderRegistration";
    private static final String MODEL_ATTRIBUTE = "ProviderRegistrationForm";
    private static final String FINAL_PAGE_LINK = "/NIO/ProviderRegistrationList";
    private static final String PAGE_EXCEPTION = "NIO/Exception";
    

    @Autowired
    private ProviderRegistrationService providerRegistrationService;

    @Autowired
    private ProviderRegistrationValidator providerRegistrationValidator;

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(providerRegistrationValidator);
    }

    /**
     * This method is called when user clicks on Provider Registration in Work around menu section.
     * @param providerRegistrationForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.PROVIDER_REGISTRATION_LANDINGPAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/ProviderRegistration")
    public String ProviderRegistrationMenu(@ModelAttribute(MODEL_ATTRIBUTE)
        ProviderRegistrationForm providerRegistrationForm) {
        LOG.debug("Inside Provider Registration page");
        return MAIN_PAGE_LINK;
    }
 
    /**
     * This method is called when user clicks submit in the Workaround Operations section.
     * @param providerRegistrationForm
     * @param result
     * @return
     * @throws RecoveryDAOException
     */
    @AuditBefore(AuditMessageConstants.GET_PROVIDER_REGISTRATION_LIST)
    @RequestMapping(method = RequestMethod.POST, params ="ProviderRegistrationSubmit=Submit")
    public String getProviderRegistrationList(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        ProviderRegistrationForm providerRegistrationForm, BindingResult result) throws RecoveryDAOException,
                                                                           RecoveryServiceException {
        if (result.hasErrors()) {
            LOG.debug("Returning page to enter Date and errors -->" + result.hasErrors());
            return MAIN_PAGE_LINK;
        }
        LOG.debug("No Errors");
        providerRegistrationForm = providerRegistrationService.providerRegistrationServiceMethod(providerRegistrationForm);
        LOG.debug("Leaving Controller Class ");
        return FINAL_PAGE_LINK;
    }

    /**
     * This method is called when ServiceException occurs.
     * @param ex
     * @return model
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(Exception e) {
        LOG.info("DAO_Exception handler......");
        ModelAndView model = new ModelAndView(PAGE_EXCEPTION);
        model.addObject("errorMsg", e.getMessage());
        LOG.debug("e.getMessage().............." + e.getMessage());
        return model;
    }

}
