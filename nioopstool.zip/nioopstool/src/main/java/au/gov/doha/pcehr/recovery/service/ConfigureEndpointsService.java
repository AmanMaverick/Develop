package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.ConfigureEndpointsBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.dao.ConfigureEndpointsDAO;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service to perform all Configure Endpoints related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 10 April 2015
 * @version Change-x
 */

@Service
public class ConfigureEndpointsService {
    public ConfigureEndpointsService() {
        super();
    }
    private static Logger LOG = Logger.getLogger(ConfigureEndpointsService.class);
    @Autowired
    ConfigureEndpointsDAO configureEndpointsDAO;
    /**
     *
     * @param bo
     * @return
     */
    public ConfigureEndpointsBO getPropertiesValues(ConfigureEndpointsBO bo){
        LOG.debug("entering getPropertiesValues..");
        bo.setAuditInsert(EndPointsConstants.OSB_ENDPOINT);  
        bo.setDeprecateAtomicData(EndPointsConstants.DEPRECATE_ATOMIC_DATA_ENDPOINT);
        bo.setGetDocumentHTB(EndPointsConstants.HTB_GETDOC);
        bo.setGetDocumentList(EndPointsConstants.GET_DOC_LIST_ENDPOINT);
        bo.setGetDocumentOAG(EndPointsConstants.OAG_GETDOC);
        bo.setHostName(EndPointsConstants.HOST_NAME);
        bo.setHtbPassword(EndPointsConstants.HTB_PASSWORD);
        bo.setHtbUsername(EndPointsConstants.HTB_USERNAME);
        bo.setInitialContextFactory(EndPointsConstants.INITIAL_CONTEXT_FACTORY);
        bo.setOagPassword(EndPointsConstants.OAG_PASSWORD);
        bo.setOagUsername(EndPointsConstants.OAG_USERNAME);
        bo.setOsbDevfPassword(EndPointsConstants.OSB_DEVF_PASSWORD);
        bo.setOsbPassword(EndPointsConstants.OSB_PASSWORD);
        bo.setOsbUsername(EndPointsConstants.OSB_USERNAME);
        bo.setPersistAtomicData(EndPointsConstants.PERSITATOMIC_ENDPOINT);
        bo.setPnaARRestrict(EndPointsConstants.PNA_AR_RESTRICT_ENDPOINT);
        bo.setPnaAuthPassword(EndPointsConstants.PNA_AUTH_PWD);
        bo.setPnaAuthUsername(EndPointsConstants.PNA_AUTH_USERNAME);
        bo.setPnaAuthoriseRestrict(EndPointsConstants.PNA_OES_AC_ENDPOINT);
        bo.setPnaCleanIndividualProfile(EndPointsConstants.PNA_CIP_ENDPOINT);
        bo.setPnaCreateAuthRep(EndPointsConstants.PNA_CA_ENDPOINT);
        bo.setPnaEndPoint(EndPointsConstants.PNA_ENDPOINT);
        bo.setPnaOIMDisable(EndPointsConstants.PNA_OIM_DISABLE_ENDPOINT);
        bo.setPnaOIMDisablePassword(EndPointsConstants.PNA_OIM_DISABLE_PASSWORD);
        bo.setPnaOIMDisableUsername(EndPointsConstants.PNA_OIM_DISABLE_USERNAME);
        bo.setPnaPassword(EndPointsConstants.PNA_PASSWORD);
        bo.setPnaUpdateAuth(EndPointsConstants.PNA_UA_ENDPOINT);
        bo.setPnaUpdateNominated(EndPointsConstants.PNA_UPDATE_ENDPOINT);
        bo.setPnaUsername(EndPointsConstants.PNA_USERNAME);
        bo.setRemoveDocument(EndPointsConstants.REMOVE_DOC_ENDPOINT_DEVF);
        bo.setRemoveDocumentDevf(EndPointsConstants.REMOVE_DOC_ENDPOINT_DEVF);
        bo.setSynchroniseIHI(EndPointsConstants.SYNCHRONISE_IHI_ENDPOINT);
        bo.setUnremoveDocument(EndPointsConstants.UNREMOVE_DOC_ENDPOINT);
        bo.setUpdateDocumentStatus(EndPointsConstants.UPDATE_DOC_ENDPOINT);
        bo.setWebLogicJndiNameHTB(EndPointsConstants.WEBLOGIC_JNDI_NAME_HTB);
        bo.setWebLogicJndiNameOIM(EndPointsConstants.WEBLOGIC_JNDI_NAME_OIM);
        bo.setWebLogicJndiNameOSB(EndPointsConstants.WEBLOGIC_JNDI_NAME_OSB);
        bo.setWebLogicJndiNamePNA(EndPointsConstants.WEBLOGIC_JNDI_NAME_PNA);
        bo.setWebLogicJndiNameRLS(EndPointsConstants.WEBLOGIC_JNDI_NAME_RLS);
        bo.setWebLogicProviderUrl(EndPointsConstants.WEBLOGIC_PROVIDER_URL);
        
        //TIP
             bo.setOsbRegisterPcehr(EndPointsConstants.OSB_REGISTER_PCEHR);
             bo.setSearchIHI(EndPointsConstants.SEARCH_IHI);
             //product version
             bo.setProductVersion(EndPointsConstants.PRODUCT_VERSION);
        LOG.debug("entering getPropertiesValues..");
    return bo;
    }
    /**
     *
     * @param bo
     * @return
     */
    public ConfigureEndpointsBO updateEndpoints(ConfigureEndpointsBO bo){
        LOG.debug("entering updateEndpoints..");
       bo=configureEndpointsDAO.update(bo);
        LOG.debug("Leaving updateEndpoints..");
        
        return bo;
    }
}
