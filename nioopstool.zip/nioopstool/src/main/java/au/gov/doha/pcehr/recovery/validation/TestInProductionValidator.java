package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.bo.SearchIHIBO;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.form.TestingInProdForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.wsclient.SearchIHIClient;

import au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHIResponse;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class TestInProductionValidator implements Validator {
    private static final String EMAIL_PATTERN="^[a-zA-Z0-9,!#\\$%&amp;'\\*\\+/=\\?\\^_`\\{\\|}~-]+(\\.[a-zA-Z0-9,!#\\$%&amp;'\\*\\+/=\\?\\^_`\\{\\|}~-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]*)*(\\.([a-zA-Z]))*$";
    private static final String MOBILE_NUMBER_PATTERN =  "(^(\\+? *[0+]+)([,0-9 ]*)([0-9 ])*$)|(^ *$)";
    public TestInProductionValidator() {
        super();
    }
    @Autowired
    @Qualifier("dateTimeUtil")
    private DateTimeUtil dateTimeUtil;

    @Autowired
    private SearchIHIClient searchIHIClient;
    
    private static Logger LOG = Logger.getLogger(TestInProductionValidator.class);
    private static final String DATE_FORMAT = "dd/MM/yyyy";
    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

    @Override
    public boolean supports(Class<?> c) {
        // TODO Implement this method
        return TestingInProdForm.class.equals(c);
    }

    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("entering validate method ...");
        // TODO Implement this method
        TestingInProdForm form = (TestingInProdForm) object;
        if (form != null) {
            ValidationUtils.rejectIfEmpty(errors, "individualType", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "ihi", "TestingInProdAttribute");
            if ((form.getIhi() != null) && !form.getIhi().equals("") && !form.getIhi().matches("[0-9]{16}")) {
                LOG.debug("IHI......Match.....");
                errors.rejectValue("ihi", "TestingInProdAttribute.ihiLength");
            }

            ValidationUtils.rejectIfEmpty(errors, "lastName", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "sex", "TestingInProdAttribute");
           
            
            ValidationUtils.rejectIfEmpty(errors, "dateOfBirth", "TestingInProdAttribute");
            if(!"".equals(form.getDateOfBirth())){
                boolean validIndDOB = dateTimeUtil.validatedate(form.getDateOfBirth(), "dd/MM/yyyy");
                if(!validIndDOB){
                    errors.rejectValue("dateOfBirth", "TestingInProdAttribute.IndDOBInvalidFormat");
                }
                else if(form.getDateOfBirth().length()!=10){
                    errors.rejectValue("dateOfBirth", "TestingInProdAttribute.IndDOBInvalidFormat");
                }
            }
            ValidationUtils.rejectIfEmpty(errors, "userId", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "pbsRPBS", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "pastPBSrpbs", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "mbsDVS", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "pastMBSdvs", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "acir", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "aodr", "TestingInProdAttribute");
            ValidationUtils.rejectIfEmpty(errors, "notificationChannel", "TestingInProdAttribute");
            
            LOG.debug("Looking for Validation for Dependent");
            if (null != form.getIndividualType() && form.getIndividualType().equalsIgnoreCase("Dependent")) {
                LOG.debug("Validation for Dependent");
                ValidationUtils.rejectIfEmpty(errors, "arIHI", "TestingInProdAttribute");
                if ((form.getArIHI() != null) && !form.getArIHI().equals("") && !form.getArIHI().matches("[0-9]{16}")) {
                    LOG.debug("IHI......Match.....");
                    errors.rejectValue("arIHI", "TestingInProdAttribute.arIhiLength");
                }
                ValidationUtils.rejectIfEmpty(errors, "arLastName", "TestingInProdAttribute");
                ValidationUtils.rejectIfEmpty(errors, "arSex", "TestingInProdAttribute");
                ValidationUtils.rejectIfEmpty(errors, "arDateOfBirth", "TestingInProdAttribute");
                if(!"".equals(form.getArDateOfBirth())){
                    boolean validArDOB = dateTimeUtil.validatedate(form.getArDateOfBirth(), "dd/MM/yyyy");
                    if(!validArDOB){
                        errors.rejectValue("arDateOfBirth", "TestingInProdAttribute.ArDOBInvalidFormat");
                    }
                    else if(form.getArDateOfBirth().length()!=10){
                        errors.rejectValue("arDateOfBirth", "TestingInProdAttribute.ArDOBInvalidFormat");
                    }
                }    
                //ValidationUtils.rejectIfEmpty(errors, "medicareCardCheck", "TestingInProdAttribute");
                ValidationUtils.rejectIfEmpty(errors, "relationshipType", "TestingInProdAttribute");
                
                if (null != form.getRelationshipType() && !form.getRelationshipType().equalsIgnoreCase("Under 18 - Parental Responsibility")) {
                    ValidationUtils.rejectIfEmpty(errors, "documentSighted", "TestingInProdAttribute");
                    ValidationUtils.rejectIfEmpty(errors, "docDetail", "TestingInProdAttribute");
                    ValidationUtils.rejectIfEmpty(errors, "authrityStartDate", "TestingInProdAttribute");

                    ValidationUtils.rejectIfEmpty(errors, "authrityEndDate", "TestingInProdAttribute");

                    ValidationUtils.rejectIfEmpty(errors, "authrityReviewtDate", "TestingInProdAttribute");
                    

                }else{
                    ValidationUtils.rejectIfEmpty(errors, "healthcareProviderAssertion", "TestingInProdAttribute");
                }
                if(!"".equals(form.getAuthrityStartDate())){
                    boolean validStartDate = dateTimeUtil.validatedate(form.getAuthrityStartDate(), "dd/MM/yyyy");
                    if(!validStartDate){
                        errors.rejectValue("authrityStartDate", "TestingInProdAttribute.startDateInvalidFormat");
                    }
                    else if(form.getAuthrityStartDate().length()!=10){
                        errors.rejectValue("authrityStartDate", "TestingInProdAttribute.startDateInvalidFormat");
                    }
                    if(!"".equals(form.getAuthrityEndDate())){
                        boolean endDateGreaterFlag = dateTimeUtil.reconDateOrder(form.getAuthrityEndDate(),form.getAuthrityStartDate());
                        boolean validEndDate = dateTimeUtil.validatedate(form.getAuthrityEndDate(), "dd/MM/yyyy");
                        if(!validEndDate){
                            errors.rejectValue("authrityEndDate", "TestingInProdAttribute.endDateInvalidFormat");
                        }
                        else if(form.getAuthrityEndDate().length()!=10){
                            errors.rejectValue("authrityEndDate", "TestingInProdAttribute.endDateInvalidFormat");
                        }
                        else if(!endDateGreaterFlag){
                            errors.rejectValue("authrityEndDate", "TestingInProdAttribute.endDateIsGreater");
                        }
                    }
                    if(!"".equals(form.getAuthrityReviewtDate())){
                        boolean authReviewDateGreaterFlag = dateTimeUtil.reconDateOrder(form.getAuthrityReviewtDate(),form.getAuthrityStartDate());
                        boolean validReviewDate = dateTimeUtil.validatedate(form.getAuthrityReviewtDate(), "dd/MM/yyyy");
                            if(!validReviewDate){
                                errors.rejectValue("authrityReviewtDate", "TestingInProdAttribute.reviewDateInvalidFormat");
                            }
                        else if(form.getAuthrityReviewtDate().length()!=10){
                            errors.rejectValue("authrityReviewtDate", "TestingInProdAttribute.reviewDateInvalidFormat");
                        }
                            else if(!authReviewDateGreaterFlag){
                            errors.rejectValue("authrityReviewtDate", "TestingInProdAttribute.authReviewDateIsGreater");
                        }
                    }
                }
                
            }
            if(form.getNotificationChannel().equalsIgnoreCase("sms") || form.getNotificationChannel().equalsIgnoreCase("email")){
                ValidationUtils.rejectIfEmpty(errors, "notificationDetails", "TestingInProdAttribute");
            }
            //Validation for phone number in 'Notification Details' for sms
        
            if(form.getNotificationDetails()!=null && form.getNotificationDetails().length()>0){
            if(form.getNotificationChannel().equalsIgnoreCase("sms") && !validateMobileNumber(form.getNotificationDetails()) ){
                errors.rejectValue("notificationDetails", "TestingInProdAttribute.InvalidMobileNumber");
            }else if(form.getNotificationChannel().equalsIgnoreCase("email") &&
                     !validateEmail(form.getNotificationDetails())){
                errors.rejectValue("notificationDetails", "TestingInProdAttribute.InvalidEmailPattern");
            }
            }
            //Validation for 18 and Over
            try{
                if(form.getIndividualType().equals("Dependent")&&!form.getDateOfBirth().equals("") &&
                   !form.getRelationshipType().equalsIgnoreCase("")
                ){
                    String relationShipTypeUnder18 = form.getRelationshipType().substring(0,8);
                    String relationShipTypeOver18 = form.getRelationshipType().substring(0,11);
                    LOG.debug("Relationship Type = :: " + relationShipTypeUnder18);
                    Date individualDOB = sdf.parse(form.getDateOfBirth());
                    int age = dateTimeUtil.getAge(individualDOB);
                    LOG.debug("age = :: " + age);
                    if(relationShipTypeUnder18.equals("Under 18") && age >= 18){
                        errors.rejectValue("dateOfBirth", "TestingInProdAttribute.under18DateOfBirth");
                    }else if(relationShipTypeOver18.equals("18 and Over") && age < 18){
                        errors.rejectValue("dateOfBirth", "TestingInProdAttribute.under18DateOfBirth");
                    }
                }
            } catch (ParseException e) {
                LOG.fatal("Parsing Exception Occured... " , e);
                }catch(IllegalArgumentException ex){
                    errors.rejectValue("dateOfBirth", "TestingInProdAttribute.FutureDate");
                }
            
            if(!errors.hasErrors()){
                SearchIHIBO searchIHIBO = new SearchIHIBO();
                searchIHIBO.setDateOfBirth(form.getDateOfBirth());
                searchIHIBO.setLastName(form.getLastName());
                searchIHIBO.setSex(form.getSex());
                searchIHIBO.setUserID(form.getUserId());
                searchIHIBO.setIhi(form.getIhi());
                boolean searchIndividualIHI = validateIHI(searchIHIBO);
                boolean searchDependentIHI = true;
                if(form.getIndividualType().equals("Dependent")){
                    SearchIHIBO searchARIHIBO = new SearchIHIBO();
                    searchARIHIBO.setDateOfBirth(form.getArDateOfBirth());
                    searchARIHIBO.setLastName(form.getArLastName());
                    searchARIHIBO.setSex(form.getArSex());
                    searchARIHIBO.setUserID(form.getUserId());
                    searchARIHIBO.setIhi(form.getArIHI());
                    searchDependentIHI = validateIHI(searchARIHIBO);
                }
                if(!searchIndividualIHI){
                    errors.rejectValue("ihi", "TestingInProdAttribute.IndividualDemographicsNotFound");
                }
                if(!searchDependentIHI){
                    errors.rejectValue("arIHI", "TestingInProdAttribute.DependentDemographicsNotFound");
                }
            }
            
        }
        LOG.debug("Leaving validate method ...");

    }

    /**
     * Validates Demographics details for the given IHI
     * @param testingInProdForm
     */
    private boolean validateIHI(SearchIHIBO searchIHIBO){
        try{
            LOG.debug("entering validateIHI.");
            
            SearchIHIResponse res = searchIHIClient.searchIHI(searchIHIBO);
            if(null!=res){
                LOG.debug("!\"PCEHR_SUCCESS\".equals(res.getResponseStatus().getCode())"+(!"PCEHR_SUCCESS".equals(res.getResponseStatus().getCode())));
                if(res==null || !"PCEHR_SUCCESS".equals(res.getResponseStatus().getCode()) ||!("PCEHR_SUCCESS".equals(res.getResponseStatus().getCode())&& searchIHIBO.getIhi().equals(res.getIndividual().getIhiNumber()))){
                    LOG.debug("Invalid demographics.");
                    return false;
                }
            }       
        }catch(WebServiceClientException e){
            return false;
        }
        
        LOG.debug("Leaving validateIHI.");
        return  true;
    }
    /**
     *
     * @param email
     * @return
     */
    private boolean validateEmail(String email){
        Boolean b = email.matches(EMAIL_PATTERN);
        return b;
    }
    private boolean validateMobileNumber(String number){
        Boolean b = number.matches(MOBILE_NUMBER_PATTERN);
        return b;
    }

}
