package au.gov.doha.pcehr.recovery.constants;

import java.io.File;

public class HealthRecordExtractionConstants {
    public HealthRecordExtractionConstants() {
        super();
    }
    /*stylesheet location for HRO  */
    
    public static String STYLE_SHEET_LOCATION_HRO ="";
    /*stylesheet location for NPDR  */
    public static String STYLE_SHEET_LOCATION_NPDR ="";
    /*stylesheet location for MIV  */
    public static String STYLE_SHEET_LOCATION_MIV ="";
    /*INPUT response location for HRO  */
    public static String INPUT_FILE_LOCATION_HEALTH_RECORD_EXTRACTION ="";
 
  
    
    /*INPUT response location for HRO  */
    public static String OUTPUT_FILE_LOCATION_HEALTH_RECORD_EXTRACTION ="";
    //error file location
    public static String ERROR_FILE_LOCATION = "";
    
    static{
        
        try{
   
    String fileSeperator=File.separator;
    String fileLocation = null;
   
        fileLocation = System.getProperty("user.dir") + fileSeperator+"HealthRecordOverview"+fileSeperator;
        
        STYLE_SHEET_LOCATION_HRO=fileLocation+"stylesheets"+fileSeperator+"HROstylesheet.xsl";
        STYLE_SHEET_LOCATION_MIV=fileLocation+"stylesheets"+fileSeperator+"MO.xsl";
        STYLE_SHEET_LOCATION_NPDR=fileLocation+"stylesheets"+fileSeperator+"NPDR.xsl";
        
        INPUT_FILE_LOCATION_HEALTH_RECORD_EXTRACTION=fileLocation+"HealthRecordExtraction"+fileSeperator+"input"+fileSeperator;
        
        
        
        OUTPUT_FILE_LOCATION_HEALTH_RECORD_EXTRACTION=fileLocation+"HealthRecordExtraction"+fileSeperator+"output"+fileSeperator;
        ERROR_FILE_LOCATION=fileLocation+"HealthRecordExtraction"+fileSeperator+"Error"+fileSeperator;
   
    }catch(Exception e){
       // System.out.println("Exception occured while instantiating constants..",e);
    }
    }
}
