package au.gov.doha.pcehr.recovery.bo;

import au.pcehr.ws.pna.common.ApplicationResponse;

public class ReactivateAuthRepClientResBO {
   
    ApplicationResponse applicationResponse;
    String soapReqRes;


    public void setApplicationResponse(ApplicationResponse applicationResponse) {
        this.applicationResponse = applicationResponse;
    }

    public ApplicationResponse getApplicationResponse() {
        return applicationResponse;
    }

    public void setSoapReqRes(String soapReqRes) {
        this.soapReqRes = soapReqRes;
    }

    public String getSoapReqRes() {
        return soapReqRes;
    }
}
