package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.dao.ConsumerRegistrationOIDDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ConsumerRegistrationOIDForm;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service class for Consumer Registration OID
 * Obtains list from DAO class.
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Apr 2015
 * @version Change-x
 */


@Service
public class ConsumerRegistrationOIDService {
    
    private static Logger LOG = Logger.getLogger(ConsumerRegistrationOIDService.class);

    @Autowired
    private ConsumerRegistrationOIDDAO consumerRegistrationOIDDAO;
    
    /**
     * This method is called from the controller after validation is successful.
     * @param consumerRegistrationOIDForm
     * @return
     * @throws RecoveryDAOException
     */
    public ConsumerRegistrationOIDForm consumerRegistrationServiceMethod(ConsumerRegistrationOIDForm consumerRegistrationOIDForm) throws RecoveryDAOException,
                                                                                                                                         RecoveryServiceException {
      LOG.debug("Inside Service Class method");
      try{
        consumerRegistrationOIDForm = consumerRegistrationOIDDAO.fetchConsumerRegistrationOIDList(consumerRegistrationOIDForm);                                                                                            
      }catch (RecoveryDAOException ex) {
            throw ex;   
        }catch(Exception e){
                LOG.fatal("Exception Occured", e);
                throw new RecoveryServiceException(e);    
        }
        LOG.debug("Leaving Service Class");  
        return consumerRegistrationOIDForm;
        
    }
    
}
