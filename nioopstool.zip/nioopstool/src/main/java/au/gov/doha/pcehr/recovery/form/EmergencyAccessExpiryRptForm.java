package au.gov.doha.pcehr.recovery.form;

import java.util.List;
import java.util.Map;

public class EmergencyAccessExpiryRptForm {
   private String date;
   private List<Map<String, Object>> displaylist;
    private String relationshipParty;
    private String ihi;
    private String givenName;
    private String familyName;
    private String dob;
    private String relationShipStartDate;
   

    public void setDate(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void getRequestType() {
    }

    public void setDisplaylist(List<Map<String, Object>> displaylist) {
        this.displaylist = displaylist;
    }

    public List<Map<String, Object>> getDisplaylist() {
        return displaylist;
    }


    public void setRelationshipParty(String relationshipParty) {
        this.relationshipParty = relationshipParty;
    }

    public String getRelationshipParty() {
        return relationshipParty;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getDob() {
        return dob;
    }

    public void setRelationShipStartDate(String relationShipStartDate) {
        this.relationShipStartDate = relationShipStartDate;
    }

    public String getRelationShipStartDate() {
        return relationShipStartDate;
    }

   
}
