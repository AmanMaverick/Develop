package au.gov.doha.pcehr.recovery.constants;


public class RecoverConstants {
    
   public static String[] SUSPENSION_ERROR_CODE ={"9","649","651","652","653","654","648","655","656","657","658","659","87","81","660","661","662","663","664"};
   public static String[] PNA_STATUS_ERROR_CODE = {"1","0","60","322","61","339","1000","301"};
  //public static String PNA_STATUS_8 = "Tier 3 staff only - Cancelled as no authorised representatives and consent not renewed";
   public static String PNA_STATUS_6 = "Tier 3 staff only - Cancelled as no authorised representatives and consent not renewed";
    public static String PNA_STATUS_1 = "Record under Investigation";
    public static int FILE_SIZE=1000000;
    public static final int EXCEL_FILE_LIMIT_SXSS=1048576;
}