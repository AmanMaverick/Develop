package au.gov.doha.pcehr.recovery.bo;


public class UpdateDocuementStatusClientBO {
    private String ihi;
    private String docID;


    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocID(String docID) {
        this.docID = docID;
    }

    public String getDocID() {
        return docID;
    }
}
