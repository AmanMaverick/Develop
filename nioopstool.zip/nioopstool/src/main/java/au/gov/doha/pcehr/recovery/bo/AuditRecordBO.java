package au.gov.doha.pcehr.recovery.bo;

import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;

public class AuditRecordBO {
    private String userID;
    private String username;
    private String ihi;
    private String ihiName;
    private String systemOperatorName;
    private boolean status;
    private String actionType;
    private ResponseStatusType auditReponse;
    private String responseStatusMsg;
    private String alertMsg;
    private String operationPerfomed;
    private String businessEvent;
    private String subject;
    private String subjectType;
    private String vendor;
    private String componentSource;
    private String productName;
    private String eventSource;
    private String messageLogLevel;
    private String transactionStatus;
    private String statusCode;
    private String description;
    private String soapMesage;
    private String logEvent;
    private String prodoctVersion;
    private String platForm;
    private String productType;
    private String reason;    
    private String statusPriorDeactivation;
   private String statusDetails;
    private String details;
    private String accessConditions;
    private String accessLevel;    
    private String role;
    private String systemType;

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setSystemOperatorName(String systemOperatorName) {
        this.systemOperatorName = systemOperatorName;
    }

    public String getSystemOperatorName() {
        return systemOperatorName;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean isStatus() {
        return status;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getActionType() {
        return actionType;
    }

    public void setAuditReponse(ResponseStatusType auditReponse) {
        this.auditReponse = auditReponse;
    }

    public ResponseStatusType getAuditReponse() {
        return auditReponse;
    }

    public void setResponseStatusMsg(String responseStatusMsg) {
        this.responseStatusMsg = responseStatusMsg;
    }

    public String getResponseStatusMsg() {
        return responseStatusMsg;
    }

    public void setAlertMsg(String alertMsg) {
        this.alertMsg = alertMsg;
    }

    public String getAlertMsg() {
        return alertMsg;
    }

    public void setOperationPerfomed(String operationPerfomed) {
        this.operationPerfomed = operationPerfomed;
    }

    public String getOperationPerfomed() {
        return operationPerfomed;
    }

    public void setBusinessEvent(String businessEvent) {
        this.businessEvent = businessEvent;
    }

    public String getBusinessEvent() {
        return businessEvent;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubjectType(String subjectType) {
        this.subjectType = subjectType;
    }

    public String getSubjectType() {
        return subjectType;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getVendor() {
        return vendor;
    }

    public void setComponentSource(String componentSource) {
        this.componentSource = componentSource;
    }

    public String getComponentSource() {
        return componentSource;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setEventSource(String eventSource) {
        this.eventSource = eventSource;
    }

    public String getEventSource() {
        return eventSource;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setMessageLogLevel(String messageLogLevel) {
        this.messageLogLevel = messageLogLevel;
    }

    public String getMessageLogLevel() {
        return messageLogLevel;
    }

  

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setSoapMesage(String soapMesage) {
        this.soapMesage = soapMesage;
    }

    public String getSoapMesage() {
        return soapMesage;
    }



    public void setPlatForm(String platForm) {
        this.platForm = platForm;
    }

    public String getPlatForm() {
        return platForm;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getProductType() {
        return productType;
    }

    public void setProdoctVersion(String prodoctVersion) {  
        this.prodoctVersion = prodoctVersion;
    }

    public String getProdoctVersion() {
        return prodoctVersion;
    }

    public void setIhiName(String ihiName) {
        this.ihiName = ihiName;
    }

    public String getIhiName() {
        return ihiName;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return reason;
    }

    public void setStatusPriorDeactivation(String statusPriorDeactivation) {
        this.statusPriorDeactivation = statusPriorDeactivation;
    }

    public String getStatusPriorDeactivation() {
        return statusPriorDeactivation;
    }

    public void setLogEvent(String logEvent) {
        this.logEvent = logEvent;
    }

    public String getLogEvent() {
        return logEvent;
    }

    public void setStatusDetails(String statusDetails) {
        this.statusDetails = statusDetails;
    }

    public String getStatusDetails() {
        return statusDetails;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getDetails() {
        return details;
    }

    public void setAccessConditions(String accessConditions) {
        this.accessConditions = accessConditions;
    }

    public String getAccessConditions() {
        return accessConditions;
    }

    public void setAccessLevel(String accessLevel) {
        this.accessLevel = accessLevel;
    }

    public String getAccessLevel() {
        return accessLevel;
    }


    public void setRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public void setSystemType(String systemType) {
        this.systemType = systemType;
    }

    public String getSystemType() {
        return systemType;
    }
}
