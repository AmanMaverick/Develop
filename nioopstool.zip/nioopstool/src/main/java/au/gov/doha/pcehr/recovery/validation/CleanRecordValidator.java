package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.bo.CleanRecordBO;

import org.apache.log4j.Logger;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


public class CleanRecordValidator implements Validator {
    private static Logger LOG = Logger.getLogger(CleanRecordValidator.class);
    private static final String OPERATION_RESET="Reset the Individual Profile";
    private static final String OPERATION_CLEANUP="Clean-up Pending Verification Details";
    private static final String OPERATION_REMOVE_DOCUMENTS="Remove Documents associated with the Record";
    
    @Override
    public boolean supports(Class<?> class1) {
        return CleanRecordBO.class.equals(class1);
    }
    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Validating the CleanRecordBO");
        CleanRecordBO form = (CleanRecordBO) object;
        if(form!=null){
            LOG.debug("Validating the CleanRecordBO:::"+form.getOperationOnRecord());
            if(form.getOperationOnRecord()==null || form.getOperationOnRecord().length()<0){
                ValidationUtils.rejectIfEmpty(errors, "action", "DocumentRemovalAttribute");
            }else if(OPERATION_RESET.equals(form.getOperationOnRecord())){
                errors = validateResetIndividualAandRemove(form,errors);
            }else if(OPERATION_CLEANUP.equals(form.getOperationOnRecord())){
                errors = validateCleanupPendingVerification(form,errors);
            }
            else if(OPERATION_REMOVE_DOCUMENTS.equals(form.getOperationOnRecord())){
                            errors = validateResetIndividualAandRemove(form,errors);
                        }
        }
        LOG.debug("leaving Validating the CleanRecordBO");
    }
      /**
     *
     * @param documentRemovalBO
     * @param errors
     * @return
     */
    private Errors validateResetIndividualAandRemove(CleanRecordBO cleanRecordBO, Errors errors){
        ValidationUtils.rejectIfEmpty(errors, "ihi", "DocumentRemovalAttribute");
       //ValidationUtils.rejectIfEmpty(errors, "resonForRemoval", "DocumentRemovalAttribute");
        //ValidationUtils.rejectIfEmpty(errors, "documentId", "DocumentRemovalAttribute");
        LOG.debug("Entering the validateResetIndividualAandRemove");
        if((cleanRecordBO.getIhi()!=null) && !cleanRecordBO.getIhi().matches("[0-9]{16}")){
            LOG.debug("IHI......Match.....");
            errors.rejectValue( "ihi", "CleanRecordAttribute.ihiLength");
        }
        LOG.debug("leaving the validateResetIndividualAandRemove");
        
    return errors;
    }
        
        /**
     *
     * @param documentRemovalBO
     * @param errors
     * @return
     */
    private Errors validateCleanupPendingVerification(CleanRecordBO cleanRecordBO, Errors errors){
        LOG.debug("Entering  the validateCleanupPendingVerification");
        ValidationUtils.rejectIfEmpty(errors, "ihi", "CleanRecordAttribute");
       // ValidationUtils.rejectIfEmpty(errors, "operationOnRecord", "CleanRecordAttribute");
        ValidationUtils.rejectIfEmpty(errors, "systemOperator", "CleanRecordAttribute");
        ValidationUtils.rejectIfEmpty(errors, "userID", "CleanRecordAttribute");
        if((cleanRecordBO.getIhi()!=null) && !cleanRecordBO.getIhi().matches("[0-9]{16}")){
            LOG.debug("IHI......Match.....");
            errors.rejectValue( "ihi", "CleanRecordAttribute.ihiLength");
        }
        LOG.debug("leaving the validateCleanupPendingVerification");
        
    return errors;
    }
    
}
