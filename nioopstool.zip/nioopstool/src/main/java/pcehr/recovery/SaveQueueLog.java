package pcehr.recovery;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import java.util.List;

/**
 * This class is to Save JMS logs (Message ID) into file.
 */
public class SaveQueueLog {
    
    Writer output = null;
    /**
     *
     * @param filename
     * @param messageID
     * @throws IOException
     */
    public final void fileGeneartion(final String filename, final List messageID)throws IOException {
        File file = new File(filename);
        output = new BufferedWriter(new FileWriter(file));
        for (int i = 0; i < messageID.size(); i++) {
            output.write(messageID.get(i).toString());
            output.write("\n");
        }
        output.close();
    }
}
