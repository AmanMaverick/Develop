package pcehr.recovery;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.xml.namespace.QName;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.log4j.Logger;


/**
 * This SOAP handler logs incoming and outgoing SOAP messages. If a SOAP handler
 * is specified in the handler chain of a JAX-WS client or service, JAX-WS will
 * call the SOAP handler before a SOAP message is sent (request) and after a
 * SOAP message has been received (response).<br>
 */
public final class LoggingHandler implements SOAPHandler<SOAPMessageContext> {
    private static Logger LOG = Logger.getLogger(LoggingHandler.class);
    /**
     * Constant for empty string.
     */
    public static final String EMPTY = "";

    /**
     * Character set encoding to use when serialising the SOAP XML.
     */
    public static final String ENCODING = "utf-8";



    public static String lastSoapRequest;
    public static String lastSoapResponse;
    public static boolean isAuditEntryMissing = false;
    public static String integrationID;
    public static String messageID;
     
    /**
     * The SOAP response message corresponding to the most recent web service invocation.
     */
    private static String lastAuditSoapResponse;
    /**
     * To identify the Source Service
     */
    private String source;

    /**
     * Default constructor.
     *
     * @param source whether or not logging is required.
     */
    public LoggingHandler(final String source) {
        this.source = source;
    }
   
    /**
     * Getter for lastSoapResponse.
     *
     * @return lastSoapResponse the lastSoapResponse instance variable
     */
    public String getLastSoapResponse() {
        return lastSoapResponse;
    }

    /**
     * Getter for lastSoapRequest.
     *
     * @return lastSoapRequest the lastSoapRequest instance variable (Mandatory)
     */
    public String getLastSoapRequest() {
        return lastSoapRequest;
    }


    /**
     * Logs outgoing and incoming messages.
     *
     * @param context The SOAP Message context.
     * @return {@link Boolean}.TRUE handle message is successful else return
     *         FALSE
     * @see javax.xml.ws.handler.Handler#handleMessage(javax.xml.ws.handler.MessageContext)
     */
    public boolean handleMessage(final SOAPMessageContext context) {
        // log to SOAP message to console
            logSOAPMessage(context);
        return true; // Continue processing
    }

    /**
     * Logs outgoing and incoming faults.
     *
     * @param context the SOAP message context object to provide access to the SOAP message for either RPC request or
     *                response
     * @return {@link Boolean}.TRUE if handleFault is successful, else returns
     *         {@link Boolean}.FALSE
     * @see javax.xml.ws.handler.Handler#handleFault(javax.xml.ws.handler.MessageContext)
     */
    public boolean handleFault(final SOAPMessageContext context) {
        // log to SOAP message to console
        logSOAPMessage(context);
        return true; // Continue processing
    }

    /**
     * Logs outgoing and incoming faults.
     *
     * @param context the SOAP Message context
     */
        private void logSOAPMessage(final SOAPMessageContext context) {
        boolean outgoing = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
        //
        
        
        if (outgoing) {
            if (source.equals("UpdateDocumentStatus")) {
                try {
                    SOAPHeader header = context.getMessage().getSOAPHeader();
                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
                        "Action", "");
                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
                    headerElement.addTextNode("urn:ihe:iti:2010:UpdateDocumentSet");
                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
                        "MessageID", "");
                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                } catch (SOAPException soap) {
                    System.out.println(soap);
                }
            } else if (source.equals("RemoveDocument")) {
                try {
                    SOAPHeader header = context.getMessage().getSOAPHeader();
                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
                        "Action", "");
                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
                    headerElement.addTextNode("http://ns.electronichealth.net.au/pcehr/svc/intRemoveDocument/1.0/RemoveDocumentPortType/removeDocumentRequest");
                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
                        "MessageID", "");
                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                } catch (SOAPException soap) {
                    System.out.println(soap);
                }
            } else if (source.equals("UnremoveDocument")) {
                try {
                    SOAPHeader header = context.getMessage().getSOAPHeader();
                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
                        "Action", "");
                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
                    headerElement.addTextNode("http://ns.electronichealth.net.au/pcehr/svc/intUnremoveDocument/1.0/UnremoveDocumentPortType/unremoveDocumentRequest");
                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
                        "MessageID", "");
                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                } catch (SOAPException soap) {
                    System.out.println(soap);
                }
            } else if (source.equals("updateConfCode")) {
                try {
                    System.out.println("Inside Logging Handler");
                    SOAPHeader header = context.getMessage().getSOAPHeader();
                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
                        "Action", "");
                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
                    headerElement.addTextNode("updateConfidentialityCode");
                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
                        "MessageID", "");
                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                } catch (SOAPException soap) {
                    System.out.println("Inside Exception");
                    System.out.println(soap);
                }
//            } else if (source.equals("deleteDocument")) {
//                try {
//                    System.out.println("Inside Logging Handler");
//                    SOAPHeader header = context.getMessage().getSOAPHeader();
//                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
//                        "Action", "");
//                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
//                    headerElement.addTextNode("urn:ihe:iti:2010:DeleteDocumentSet");
//                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
//                        "MessageID", "");
//                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
//                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
//                } catch (SOAPException soap) {
//                    System.out.println("Inside Exception");
//                    System.out.println(soap);
//                }
//            
                            } else if (source.equals("cleanRecordDeleteDocuments")) {
                try {
                    System.out.println("Inside Logging Handler");
                    SOAPHeader header = context.getMessage().getSOAPHeader();
                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
                        "Action", "");
                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
                    headerElement.addTextNode("urn:ihe:iti:2010:DeleteDocumentSet");
                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
                        "MessageID", "");
                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                } catch (SOAPException soap) {
                    System.out.println("Inside Exception");
                    System.out.println(soap);
                }
            
            }else if (source.equals("insertAuditRecord")) 
            {
//                try {
//                    SOAPHeader header = context.getMessage().getSOAPHeader();
//                    
//                    QName toQName = new QName("http://www.w3.org/2005/08/addressing", 
//                        "To", "");
//                    SOAPHeaderElement toHeaderElement = header.addHeaderElement(toQName);
//                    toHeaderElement.addTextNode("NIO_INSERT_AUDIT_RECORD");
//                    
//                    QName replytoQName = new QName("http://www.w3.org/2005/08/addressing", 
//                        "ReplyTo", "");
//                    SOAPHeaderElement replytoHeaderElement = header.addHeaderElement(replytoQName);
//                    QName addressQName = new QName("http://www.w3.org/2005/08/addressing", 
//                        "Address", "");
//                    SOAPElement addressHeaderElement = replytoHeaderElement.addChildElement(addressQName);
//                    addressHeaderElement.addTextNode("http://www.w3.org/2002/ws/addr/ns/ws-addr");
//                    
//                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
//                        "Action", "");
//                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
//                    headerElement.addTextNode("http://ns.electronichealth.net.au/pcehr/svc/intInsertAuditRecord/1.0/InsertAuditRecordPortType/insertAuditRecordRequest");
//                    
//                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
//                        "MessageID", "");
//                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
//                    if(isAuditEntryMissing) {
//                        headerElement1.addTextNode(messageID);
//                        QName headerName2 = new QName("http://www.w3.org/2005/08/addressing", 
//                            "IntegrationID", "");
//                        SOAPHeaderElement headerElement2 = header.addHeaderElement(headerName2);
//                        headerElement2.addTextNode(integrationID);
//                    } else {
//                        headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
//                    }
//                } catch (SOAPException soap) {
//                    System.out.println(soap);
//                }
//            } else if (source.equals("SynchroniseIHI")) {
//                try {
//                    SOAPHeader header = context.getMessage().getSOAPHeader();
//                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
//                        "MessageID", "");
//                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
//                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
//                } catch (SOAPException soap) {
//                    System.out.println(soap);
//                }
            }
            else if (source.equals("ARRestricted")) {
                try {
                    SOAPHeader header = context.getMessage().getSOAPHeader();
                    QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
                        "MessageID", "");
                    SOAPHeaderElement headerElement1 = header.addHeaderElement(headerName1);
                    headerElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                    
                    QName headerName = new QName("http://www.w3.org/2005/08/addressing", 
                        "Action", "");
                    SOAPHeaderElement headerElement = header.addHeaderElement(headerName);
                    headerElement.addTextNode("http://pd.pna.ws.pcehr.au/PNA_PCEHR_setARRestriction/PDsetARRestrictionRequest");
                } catch (SOAPException soap) {
                    System.out.println(soap);
                }
            }
            //oag
            else if (source.equals("GetDocOAG")) {
                try {
                                                  String action ="";
                                               if(context.containsKey("ACTIONTAG")){
                                               action = (String)context.get("ACTIONTAG");

                                               LOG.debug("ACTION in the action....."+action);
                                               } 

                    
                    
                                            SOAPHeader header = context.getMessage().getSOAPHeader();
                                            
                                            Iterator<Node> n1 = header.getChildElements(); 
                                            List<Node> nodeToRemove = new ArrayList<Node>(); 
                                                while(n1.hasNext()){
                                                    Node node = n1.next();
                                                    LOG.debug("Node"+node.getNodeName());
                                                    if(node.getNodeName().equals("wsa:Action") || node.getNodeName().equals("wsa:To")){
                                                        nodeToRemove.add(node);
                                                    }
                                                }
                                            for(Node node:nodeToRemove){
                                                node.getParentNode().removeChild(node);
                                            }
                                            
                                            
                                            header.normalize();
                                            
                                            QName headerName1 = new QName("http://www.w3.org/2005/08/addressing", 
                                                                   "To", "wsa05");
                                            SOAPHeaderElement headerElement = header.addHeaderElement(headerName1);
                                            //frm database with repid
                                          LOG.debug("was action value:::"+action);
                                               headerElement.addTextNode(action);
                                            //  headerElement.addTextNode("http://localhost:8080/DocumentStub/ProxyServices/ConformantRep_getDocumentStub");
                                            QName headerName2 = new QName("http://www.w3.org/2005/08/addressing",
                                                                   "Action","wsa");
                                            SOAPHeaderElement headerElement2 = header.addHeaderElement(headerName2);
                                      
                                            headerElement2.addTextNode("urn:ihe:iti:2007:RetrieveDocumentSet");
                                           
  //code chage for addressing feature
                                           QName messageId1 = new QName("http://www.w3.org/2005/08/addressing", 
                                                                   "MessageID", "");
                                                               SOAPHeaderElement messageIdElement1 = header.addHeaderElement(messageId1);
                                               messageIdElement1.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                                                                      QName intgressionID = new QName("http://www.w3.org/2005/08/addressing",
                                                                           "IntegrationID", "");
                                                                       SOAPHeaderElement headerElementintgressionID2 = header.addHeaderElement(intgressionID);
                                                                      headerElementintgressionID2.addTextNode("urn:uuid:" + UUID.randomUUID().toString());
                                           
                                           //
                                             LOG.debug("End.......");
                                           } catch (SOAPException soap) {
                                            System.out.println("ERRRORRRRR:"+soap);
                                        }
            }
            lastSoapRequest = XmlUtil.serialiseSoapXml(context.getMessage());
            if (source.equals("UpdateDocumentStatus")) {
                lastSoapRequest = lastSoapRequest.replace("<Action", "<Action soap:mustUnderstand='1'");
                lastSoapRequest = lastSoapRequest.replace("<MessageID", "<MessageID soap:mustUnderstand='1'");
            } 
            System.out.println("SOAP Request ::" + lastSoapRequest);
        } else {
            lastSoapResponse = XmlUtil.serialiseSoapXml(context.getMessage());
            System.out.println("SOAP Response ::" + lastSoapResponse);
            if (source.equals("insertAuditRecord")) {
                lastAuditSoapResponse = lastSoapResponse;
            }
        }
    }

    /**
     * Ignore processing of SOAP header as the primary intention is just to
     * 'Dump' the SOAP message.
     *
     * @see javax.xml.ws.handler.soap.SOAPHandler#getHeaders()
     *
     * @return QName
     */
    public Set<QName> getHeaders() {
        return Collections.<QName>emptySet();
    }


    /**
     * Does nothing <br>
     * Not utilised for dumping SOAP message.
     *
     * @param context the SOAP Message context
     *
     * @see javax.xml.ws.handler.Handler#close(javax.xml.ws.handler.MessageContext)
     */
    public void close(final MessageContext context) {
    }

   
}
