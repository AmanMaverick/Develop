package pcehr.recovery;


import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;

import au.net.electronichealth.ns.pcehr.svc.intsynchroniseihidetails._1.StandardError;
import au.net.electronichealth.ns.pcehr.svc.intsynchroniseihidetails._1.SynchroniseIHIDetails;
import au.net.electronichealth.ns.pcehr.svc.intsynchroniseihidetails._1.SynchroniseIHIDetailsPortType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.IDType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.synchroniseihidetails._1.SynchroniseIHIDetailsResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * This class is proxy for Synchronise IHI web service.
 */
public class SynchroniseIHIProxy {
    
    @Autowired
    Decrypter decrypter;
    /**
     *
     * @param myProp
     * @param responseStatus
     * @param strIHI
     * @param strUsername
     * @return ResponseStatusType
     */
    public final ResponseStatusType synchroniseIHIDetails(final Properties myProp, 
                                                          ResponseStatusType responseStatus, 
                                                          final String strIHI, final String strUsername) {
        try {
            SynchroniseIHIDetails synchroniseIHIDetails = new SynchroniseIHIDetails();
            synchroniseIHIDetails.setHandlerResolver(new ClientHandlerResolver());
            SynchroniseIHIDetailsPortType synchroniseIHIDetailsPortType = synchroniseIHIDetails.getSynchroniseIHIDetailsSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true,true));
            Map<String, Object> ctxt = ((BindingProvider) synchroniseIHIDetailsPortType).getRequestContext();
            Decrypter decrypt = new Decrypter();
            ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.SYNC_IHI_ENDPOINT);
            ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, new TestHostnameVerifier());
            ctxt.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
            ctxt.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD)); 
            au.net.electronichealth.ns.pcehr.xsd.interfaces.synchroniseihidetails._1.SynchroniseIHIDetails syncIHIDetails = 
                new au.net.electronichealth.ns.pcehr.xsd.interfaces.synchroniseihidetails._1.SynchroniseIHIDetails();
            syncIHIDetails.setIDType(IDType.IHI);
            syncIHIDetails.setIDNumber(strIHI);
            
            IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
            
            IntPCEHRHeader.User user = new IntPCEHRHeader.User();
            user.setIDType("LocalSystemIdentifier");
            user.setID(strUsername);
            user.setRole("PCEHR_SYSTEM_OPERATOR");
            user.setUserName(strUsername);
            user.setUseRoleForAudit(false);
            intPCEHRHeader.setUser(user);
    
            IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
            productType.setVendor("NIO");
            productType.setProductName("synchroniseIHIDetails");
            productType.setProductVersion(EndPointsConstants.PRODUCT_VERSION);
            productType.setPlatform("Jump Host");
            intPCEHRHeader.setProductType(productType);
    
            IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
            clientSystem.setSystemID(EndPointsConstants.HOST_NAME);
            clientSystem.setSystemType("Admin");
            intPCEHRHeader.setClientSystem(clientSystem);
    
            IntPCEHRHeader.AccessingOrganisation accessingOrg = new IntPCEHRHeader.AccessingOrganisation();
            accessingOrg.setOrganisationID("");
            accessingOrg.setOrganisationName("");
            intPCEHRHeader.setAccessingOrganisation(accessingOrg);
            intPCEHRHeader.setOverrideLogLevel(false);
            intPCEHRHeader.setIhiNumber(strIHI);
            
            Holder<SynchroniseIHIDetailsResponse> holder = new Holder<SynchroniseIHIDetailsResponse>();
            SynchroniseIHIDetailsResponse syncIHIRes = new SynchroniseIHIDetailsResponse();
            syncIHIRes.setResponseStatus(responseStatus);
            holder.value = syncIHIRes;
            try {
                synchroniseIHIDetailsPortType.synchroniseIHIDetails(syncIHIDetails, holder, intPCEHRHeader);
                syncIHIRes = holder.value;
                responseStatus = syncIHIRes.getResponseStatus();
            } catch (StandardError error) {
                error.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return responseStatus;
    }
    /**
     * This class is to verify host name.
     */
    public class TestHostnameVerifier implements HostnameVerifier {
        /**
         *
         * @param arg0
         * @param arg1
         * @return
         */
        public final boolean verify(final String arg0, final SSLSession arg1) {
            System.out.println("Inside TestHost");
            return true;
        }
    }
    /**
     * This class is to handle the SOAP Request and Response.
     */
    public class ClientHandlerResolver implements HandlerResolver {
        /**
         *
         * @param port_info
         * @return Handler
         */
        public final List<Handler> getHandlerChain(final PortInfo port_info) {
            List<Handler> handlerChain = new ArrayList<Handler>();
            LoggingHandler loggingHandler = new LoggingHandler("SynchroniseIHI");
            handlerChain.add(loggingHandler);
            return handlerChain;
        }
    }

}
