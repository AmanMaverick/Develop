package pcehr.recovery;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

/**
 * This class is to authenticate Username and Password.
 */
public class MyAuthenticator extends Authenticator {  
      
    private String user;  
    private String password;  
    /**
     *
     * @param user
     * @param password
     */
    public MyAuthenticator(final String user, final String password) {  
      this.user = user;  
      this.password = password;  
    }  
    /**
     *
     * @return PasswordAuthentication
     */
    @Override  
    protected final PasswordAuthentication getPasswordAuthentication() {  
        PasswordAuthentication auth = new PasswordAuthentication(user, password.toCharArray());  
        return auth;  
    }  
}  

