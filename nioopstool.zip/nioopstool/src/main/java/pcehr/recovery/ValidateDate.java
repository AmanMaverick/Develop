package pcehr.recovery;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Validate date againt user input string for the format (ddMMyyyy)
 */
public class ValidateDate {
    /**
     *
     * @param inDate
     * @return boolean
     */
    public static boolean isValidDate(final String inDate) {

        if (inDate == null) {
            return false;
        }

        //set the format to use as a constructor argument
        SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");

        if (inDate.trim().length() != dateFormat.toPattern().length()) {
            return false;
        }

        dateFormat.setLenient(false);

        try {
            //parse the inDate parameter
            dateFormat.parse(inDate.trim());
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }
    /**
     *
     * @param date1
     * @param date2
     * @return long
     */
    public static long compareTo(final java.util.Date date1, final java.util.Date date2 )   
    {   
        //returns negative value if date1 is before date2   
        //returns 0 if dates are even   
        //returns positive value if date1 is after date2 
        return date1.getTime() - date2.getTime();   
    }
}
