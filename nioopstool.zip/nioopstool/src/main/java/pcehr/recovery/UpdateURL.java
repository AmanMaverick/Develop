package pcehr.recovery;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.Properties;

/**
 * This class is to Update the properties of URL for JMS in properties file.
 */
public class UpdateURL {
    private String propertyFileLocation;
    private String webLogicProviderURL;
    private String domainName;
    /**
     *
     * @param webLogicProviderURL
     * @param domainName
     * @param propertyFileLocation
     */
    public UpdateURL(final String webLogicProviderURL, final String domainName, final String propertyFileLocation) {
        super();
        this.webLogicProviderURL = webLogicProviderURL;
        this.propertyFileLocation = propertyFileLocation;
        this.domainName = domainName;
    }
    /**
     *
     * @param myProp2
     * @return
     */
    public final String savePropertyEntries(final Properties myProp2) {
        Properties myNewProp2 = alterProperties2(myProp2);
        return saveProperties(myNewProp2);
    }
    /**
     *
     * @param myProp
     * @return
     */
    public final String removePropertyEntries(final Properties myProp) {
        Properties newProp = alterProperties(myProp);
        return removeProperties(newProp);
    }
    /**
     *
     * @param p
     * @return
     */
    private Properties alterProperties(final Properties p) {
        p.remove(domainName);
        return p;
    }
    /**
     *
     * @param p
     * @return
     */
    private Properties alterProperties2(final Properties p) {
        Properties newProps = new Properties();
        String value = webLogicProviderURL;
        newProps.setProperty(domainName, value);
        return newProps;
    }
    /**
     *
     * @param p2
     * @return
     */
    private String saveProperties(final Properties p2) {
        OutputStream outPropFile2;
        try {
            File file2 = new File(propertyFileLocation);
            outPropFile2 = new FileOutputStream(file2, true);
            p2.store(outPropFile2, "");
            outPropFile2.close();
            return "SUCCESS";
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return "FAILED";
        }
    }
    /**
     *
     * @param p2
     * @return
     */
    private String removeProperties(final Properties p2) {
        OutputStream outPropFile2;
        try {
            File file2 = new File(propertyFileLocation);
            outPropFile2 = new FileOutputStream(file2);
            p2.store(outPropFile2, "");
            outPropFile2.close();
            return "SUCCESS";
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return "FAILED";
        }
    }
}
