package pcehr.recovery;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.Enumeration;
import java.util.Properties;

/**
 * This class is to save JMS configuration to Properties file.
 */
public class SaveJmsConfig {
    
    private String propertyFileLocation;
    private String propertyFileLocation2;
    private String sourceQueue;
    private String detinationQueue;
    private String connectionFactory;
    private String sourceQueueList;
    
   /**
     *
     * @param propertyFileLocation
     * @param propertyFileLocation2
     * @param sourceQueue
     * @param detinationQueue
     * @param connectionFactory
     * @param sourceQueueList
     */
    public final void setValues(final String propertyFileLocation, 
                                final String propertyFileLocation2,
                                final String sourceQueue, 
                                final String detinationQueue, 
                                final String connectionFactory, 
                                final String sourceQueueList) {
        this.propertyFileLocation = propertyFileLocation;
        this.propertyFileLocation2 = propertyFileLocation2;
        this.sourceQueue = sourceQueue;
        this.detinationQueue = detinationQueue;
        this.connectionFactory = connectionFactory;
        this.sourceQueueList = sourceQueueList;
    }
   /**
     *
     * @param myProp
     * @param myProp2
     * @return String
     */
    public final String savePropertyEntries(final Properties myProp, final Properties myProp2) {
        Properties myNewProp = alterProperties(myProp);
        Properties myNewProp2 = alterProperties2(myProp2);
        return saveProperties(myNewProp, myNewProp2);
    }
    public final boolean validateSourceQueue() {
        boolean flag = false;
        int index1 = sourceQueueList.indexOf(sourceQueue);
        if (index1 == -1) {
            flag = true;
        }
        return flag;
    }
    /**
     *
     * @param p 
     * @return Properties
     */
    private Properties alterProperties(final Properties p) {
        Properties newProps = new Properties();
                String value = detinationQueue + "," + connectionFactory;
                newProps.setProperty(sourceQueue, value);
        return newProps;
    }
    /**
     *
     * @param p
     * @return Properties
     */
    private Properties alterProperties2(final Properties p) {
        Properties newProps = new Properties();
        Enumeration enumProps = p.propertyNames();
        String key = "";
        while (enumProps.hasMoreElements()) {
            key = (String) enumProps.nextElement();
            if (key.equals("Source_Queue")) {
                newProps.setProperty(key, sourceQueueList);
            }
        }
        return newProps;
    }
    /**
     *
     * @param p
     * @param p2
     * @return String
     */
    private String saveProperties(final Properties p, final Properties p2) {
        OutputStream outPropFile;
        OutputStream outPropFile2;
        try {
            File file = new File(propertyFileLocation);
            File file2 = new File(propertyFileLocation2);
            outPropFile = new FileOutputStream(file, true);
            outPropFile2 = new FileOutputStream(file2);
            p.store(outPropFile, "");
            p2.store(outPropFile2, "");
            outPropFile.close();
            outPropFile2.close();
            return "SUCCESS";
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return "FAILED";
        }
    }
    /**
     *
     * @param sourceQueue
     */
    public final void setSourceQueue(final String sourceQueue) {
        this.sourceQueue = sourceQueue;
    }
    /**
     *
     * @param sourceQueueList
     */
    public final void setSourceQueueList(final String sourceQueueList) {
        this.sourceQueueList = sourceQueueList;
    }
}
