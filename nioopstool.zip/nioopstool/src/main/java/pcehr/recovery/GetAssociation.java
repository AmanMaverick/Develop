package pcehr.recovery;


import com.sun.xml.ws.developer.JAXWSProperties;

import ihe.iti.xds_b._2007.DocumentRegistryPortType;
import ihe.iti.xds_b._2007.DocumentRegistryService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryRequest;
import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryResponse;
import oasis.names.tc.ebxml_regrep.xsd.query._3.ResponseOptionType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.AdhocQueryType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.SlotType1;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ValueListType;


/**
 * This class is proxy for Get Association Web service.
 */
public class GetAssociation {
    /**
     * This method is to get Association for Single ID
     * @param myProp
     * @param id
     * @return AdhocQueryResponse
     */
    public static AdhocQueryResponse getAsso(final Properties myProp, 
                                             final String id) {        
        DocumentRegistryService documentRegistryService = new DocumentRegistryService();
        documentRegistryService.setHandlerResolver(new ClientHandlerResolver());
        DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12(new javax.xml.ws.soap.AddressingFeature(true,true));
       // DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12();
        Map<String, Object> ctxt = ((BindingProvider) documentRegistryPortType).getRequestContext();
        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, 
                 myProp.getProperty(UtilConstants.GET_DOC_LIST_ENDPOINT));
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, 
                 new TestHostnameVerifier());
        ResponseOptionType responseOptionType = new ResponseOptionType();
        responseOptionType.setReturnType("LeafClass");
        responseOptionType.setReturnComposedObjects(true);       
        AdhocQueryType adhocQueryType = new AdhocQueryType();
        List<SlotType1> newslots = new ArrayList<SlotType1>();
        newslots.add(createSlot("$uuid", "('" + id + "')"));
        adhocQueryType.getSlot().addAll(newslots);
        adhocQueryType.setId("urn:uuid:a7ae438b-4bc2-4642-93e9-be891f7bb155");        
        AdhocQueryRequest adhocQueryRequest = new AdhocQueryRequest();
        adhocQueryRequest.setAdhocQuery(adhocQueryType);
        adhocQueryRequest.setResponseOption(responseOptionType);        
        AdhocQueryResponse adhocQueryResponse = documentRegistryPortType.documentRegistryRegistryStoredQuery(adhocQueryRequest);
        return adhocQueryResponse;
    }
    /**
     * this method is to include slots into the request.
     * @param name
     * @param value
     * @return SlotType1
     */
    private static SlotType1 createSlot(final String name, final String value) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        slot.setValueList(new ValueListType());
        slot.getValueList().getValue().add(value);
        return slot;
    }
    /**
     * This class is to handle the SOAP Request and Response.
     */
    public static class ClientHandlerResolver implements HandlerResolver {
        /**
         *
         * @param port_info
         * @return Handler
         */
        public final List<Handler> getHandlerChain(final PortInfo port_info) {
            List<Handler> handlerChain = new ArrayList<Handler>();
            LoggingHandler loggingHandler = new LoggingHandler(UtilConstants.GET_ASSOCIATION);
            handlerChain.add(loggingHandler);
            return handlerChain;
        }
    }
    /**
     * This class is to verify host name.
     */
    public static class TestHostnameVerifier implements HostnameVerifier {
        /**
         *
         * @param arg0
         * @param arg1
         * @return boolean
         */
        public final boolean verify(final String arg0, final SSLSession arg1) {
            System.out.println("Inside TestHost");
            return true;
        }
    }
    /**
     *
     * @param myProp
     * @param idList
     * @return AdhocQueryResponse
     */
    public static AdhocQueryResponse getAssoList(final Properties myProp, final List idList) {
        DocumentRegistryService documentRegistryService = new DocumentRegistryService();
        documentRegistryService.setHandlerResolver(new ClientHandlerResolver());
        DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12(new javax.xml.ws.soap.AddressingFeature(true,true));
       // DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12();
        Map<String, Object> ctxt = ((BindingProvider) documentRegistryPortType).getRequestContext();
        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, 
                 myProp.getProperty(UtilConstants.GET_DOC_LIST_ENDPOINT));
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, 
                 new TestHostnameVerifier());
        ResponseOptionType responseOptionType = new ResponseOptionType();
        responseOptionType.setReturnType("LeafClass");
        responseOptionType.setReturnComposedObjects(true);       
        AdhocQueryType adhocQueryType = new AdhocQueryType();
        List<SlotType1> newslots1 = new ArrayList<SlotType1>();
        SlotType1 slot = new SlotType1();
        slot.setName("$uuid");
        slot.setValueList(new ValueListType());
        for (int i = 0; i < idList.size(); i++) {
            slot.getValueList().getValue().add("('" + idList.get(i) + "')");
        }
        newslots1.add(slot);                
        adhocQueryType.getSlot().addAll(newslots1);
        adhocQueryType.setId("urn:uuid:a7ae438b-4bc2-4642-93e9-be891f7bb155");            
        AdhocQueryRequest adhocQueryRequest = new AdhocQueryRequest();
        adhocQueryRequest.setAdhocQuery(adhocQueryType);
        adhocQueryRequest.setResponseOption(responseOptionType);        
        AdhocQueryResponse adhocQueryResponse = documentRegistryPortType.documentRegistryRegistryStoredQuery(adhocQueryRequest);     
        return adhocQueryResponse;
    }
}
