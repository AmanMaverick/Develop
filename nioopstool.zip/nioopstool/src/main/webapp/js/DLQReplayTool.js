$(document).ready(function() {
     $('#selectAll').click(function(event) {  //on click

        if(this.checked) { // check select status
            $('.errorCodeId').each(function() { //loop through each checkbox
                this.checked = true;  //select all checkboxes with class "docId"              
            });
        }else{
            $('.errorCodeId').each(function() { //loop through each checkbox
                this.checked = false; //deselect all checkboxes with class "docId"                      
            });        
        }
    });
    
   
    

  //xss cahnges
  //to view a particular error codes message details
  
  $("#dlqMessageViewDivId a").click(function() {

  
  
       $('#myform').method="post";
   
           $("#myform").attr("action",ctx+"/NIO/DLQReplayMessageView");
        $("#errorCode").val(this.id);

       $('#myform').submit();

  });
  //click the back button to return DLQ Message Replay Search Result page
 $('#dlqMessageReplayBackHrefId').click(function(event){
     
       $('#myform').method="post";
          $('#myform').attr("target","_self");
      $("#myform").attr("action",ctx+"/NIO/DLQReplayToolMessageViewBack");
      $('#myform').submit();

  });   
//get the dbDetails of a particular message
$("#dlqMessageDBDetailsDivId a").click(function() {

    //alert(this.id);

 $('#myform').method="post";
  
          $("#myform").attr("action",ctx+"/NIO/DLQMessageDBDetails");
            $('#myform').attr("target","_blank");
          
            $("#intgrationID").val(this.id);
            $('#myform').submit();
        //Do stuff when clicked
    });
    //play a particular message in DLQ Replay Tool - Message Detail
    //check if submit button is selected then call
    $('#IntegrationIdMessageReplySubmit').click(function(){
       $('#myform').attr("target","_self");
         $("#myform").attr("action",ctx+"/NIO/DLQReplayIntegrationId");
         if($('.errorCodeId:checkbox:checked').length != 0){
            //alert('Checkbox is checked!!');
        }else{
            alert("Please select atleast one item.");
            return false;
        }
         $('#myform').submit();
        
    });
     //play a particular ErrorCode DLQ Replay Tool - Message Detail
    //check if submit button is selected then call
    $('#ErrorCodeMessageReplySubmit').click(function(){
       $('#myform').attr("target","_self");
         $("#myform").attr("action",ctx+"/NIO/DLQReplayToolPlay");
         if($('.errorCodeId:checkbox:checked').length != 0){
            //alert('Checkbox is checked!!');
        }else{
            alert("Please select atleast one item.");
            return false;
        }
         $('#myform').submit();
        
    });
      //click the back button to return DLQ Message Replay Message Detail page
 $('#dlqMessageVerificationToMsgViewBackHrefId').click(function(event){
        $('#DlqVerifactionForm').method="post";
          $('#DlqVerifactionForm').attr("target","_self");
      $("#DlqVerifactionForm").attr("action",ctx+"/NIO/DLQReplayMessageView");
      $('#DlqVerifactionForm').submit();

  }); 
  
      //click the back button to return DLQ Message Replay Search Result
 $('#dlqMessageVerificationToMsgSeacrhViewBackHrefId').click(function(event){
       $('#DlqVerifactionForm').method="post";
          $('#DlqVerifactionForm').attr("target","_self");
      $("#DlqVerifactionForm").attr("action",ctx+"/NIO/DLQReplayToolMessageViewBack");
      $('#DlqVerifactionForm').submit();

  }); 
});
