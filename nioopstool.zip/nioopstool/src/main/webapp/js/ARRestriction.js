$(document).ready(function() {
    
    $('#ihiShow').show();
    $('#dateShow').show();
    $('#fileShow').hide();
    $('#flSizeSpan').hide();
     
    if($('input:radio[name=operationType]:checked').val() == "bulk"){
        $('#ihiShow').hide();
        $('#dateShow').hide();
        $('#fileShow').show();
        
    }else if($('input:radio[name=operationType]:checked').val() == "single"){
        $('#ihiShow').show();
        $('#dateShow').show();
        $('#fileShow').hide();
    }
    $('#reset').click(function() {
        $('#ihi').val('');
        $('#expire_date').val('');
        $('#jira_id').val('');
        $('#operatorname').val('');
        $('#userID').val('');
        $('#soapResponse').val('');
        $('#errormessageId').hide('');
        $('#messageID').hide('');
        $('#fileShow').val(''); 
    });


 //to toggle between two tables for ART search operation
        $("input[name='operationType']").click(function(){
            if($('input:radio[name=operationType]:checked').val() == "bulk"){
                $('#ihiShow').hide();
                $('#dateShow').hide();
                $('#fileShow').show();
                
            }else if($('input:radio[name=operationType]:checked').val() == "single"){
                $('#ihiShow').show();
                $('#dateShow').show();
                $('#fileShow').hide();
            }
        });
 
         //This method is used to show the span and file size in bytes
    $("#flUpload").change(function (){
     var iSize = ($("#flUpload")[0].files[0].size / 1024);
     var f=this.files[0];
     $('#flSizeSpan').show();
     var val = f.size||f.fileSize ;
      $("#lblSize").html(val + " bytes");
  }); 

});