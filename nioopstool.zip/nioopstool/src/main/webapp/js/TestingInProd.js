//@Author Vikash Kumar Singh    Operations    PCEHR
//@version - 1.0.0.0
$(document).ready(function() {
        
        ////For Disable or renable Notification Details depending on Notification Channel select option
        // Notification Channel(sms/email) - Notification Details(Enable)
        //Notification Channel(rest) - Notification Details(Disable)
        
        //Onload logic
        if($("#notificationMethodId option:selected").index() == 1 || $("#notificationMethodId option:selected").index() == 2){
            $('#notificationDetailsId').removeAttr("disabled");
        }else{
            $('#notificationDetailsId').val('');
            $('#notificationDetailsId').attr("disabled", true);
        }
        
        //OnChange Logic
        $( "#notificationMethodId" ).change(function() {
            if($("#notificationMethodId option:selected").index() == 1 || $("#notificationMethodId option:selected").index() == 2){
                $('#notificationDetailsId').removeAttr("disabled");
            }else{
                $('#notificationDetailsId').val('');
                $('#notificationDetailsId').attr("disabled", true);
                //$( "td:contains('Notification Details:')" ).removeClass( "required" );
            }
        });
        
        
        //For removing asterisk(*) symbol on load for medicare detail under 'Authority Details' heading
        if($("#relationshipType option:selected").index() == 1){
            $( "td:contains('Document Sighted :')" ).removeClass( "required" );
            $( "td:contains('Document Details :')" ).removeClass( "required" );
            $( "td:contains('Start date of Authority :')" ).removeClass( "required" );
            $( "td:contains('End date of Authority :')" ).removeClass( "required" );
            $( "td:contains('Review date of Authority :')" ).removeClass( "required" );
            $('#HealthcareProviderAssertionTableId').show();
        }else{
            if(!$( "td:contains('Document Sighted :')" ).hasClass( "required" )){
                $( "td:contains('Document Sighted :')" ).addClass( "required" );
                $( "td:contains('Document Details :')" ).addClass( "required" );
                $( "td:contains('Start date of Authority :')" ).addClass( "required" );
                $( "td:contains('End date of Authority :')" ).addClass( "required" );
                $( "td:contains('Review date of Authority :')" ).addClass( "required" );
            }
        }
        
        if($('input:radio[name=individualType]:checked').val() == "Individual"){
         $('#individualOrDependent').text("Individual Demographic Details");
            $('.AR-demographics-container').hide();
            $('.AR-Detail-container').hide();
         
        }else if($('input:radio[name=individualType]:checked').val() == "Dependent"){
            $('#individualOrDependent').text("Dependant Demographic Details"); 
            $('.AR-demographics-container').show();
            $('.AR-Detail-container').show();
            if($("#relationshipType option:selected").index() == 1){
                $('#HealthcareProviderAssertionTableId').show();
            }else{
                $('#HealthcareProviderAssertionTableId').hide();
            }
        }
//        if($('input:radio[name=medicareCardCheck]:checked').val() == "Yes"){
//            $('#relationshipDetail').hide();
//            //$('select[name=relationshipType] option:eq(2)').attr('selected', 'selected');
//            //$("#relationshipType").attr('readonly', 'readonly');
//        }else{
//            $('#relationshipDetail').show();
//        }
        
        $("input[name='individualType']").click(function(){
            $('#errormessageDiv').hide();  
            if($('input:radio[name=individualType]:checked').val() == "Individual"){
                $('#individualOrDependent').text("Individual Demographic Details");
                $('.AR-demographics-container').hide(1000);
                $('.AR-Detail-container').hide(1000);
            }else if($('input:radio[name=individualType]:checked').val() == "Dependent"){
              $('#individualOrDependent').text("Dependant Demographic Details");
                $('.AR-demographics-container').show(1000);
                $('.AR-Detail-container').show(1000);
                if($("#relationshipType option:selected").index() == 1){
                    $('#HealthcareProviderAssertionTableId').show();
                }else{
                    $('#HealthcareProviderAssertionTableId').hide();
                }
//                if($('input:radio[name=medicareCardCheck]:checked').val() == "Yes"){
//                    $('#relationshipDetail').hide(800);
//                   // $('select[name=relationshipType] option:eq(1)').attr('selected', 'selected');
//                    //$("#relationshipType").attr('readonly', 'readonly');
//                }else{
//                    $('#relationshipDetail').show(800);
//                }
            }
        });
        
//        $("input[name='medicareCardCheck']").click(function(){
//            if($('input:radio[name=medicareCardCheck]:checked').val() == "Yes"){
//                $('#relationshipDetail').hide(800);
//            }else{
//                $('#relationshipDetail').show(800);
//                //$('select[name=relationshipType] option:eq(0)').attr('selected', 'selected');
//                 //   $("#relationshipType").attr('readonly', false);
//            }
//        });
        
        $( "#relationshipType" ).change(function() {
           if($("#relationshipType option:selected").index() == 1){
                $('#HealthcareProviderAssertionTableId').show();
                $( "td:contains('Document Sighted :')" ).removeClass( "required" );
                $( "td:contains('Document Details :')" ).removeClass( "required" );
                $( "td:contains('Start date of Authority :')" ).removeClass( "required" );
                $( "td:contains('End date of Authority :')" ).removeClass( "required" );
                $( "td:contains('Review date of Authority :')" ).removeClass( "required" );
            }else{
                $('#HealthcareProviderAssertionTableId').hide();
                if(!$( "td:contains('Document Sighted :')" ).hasClass( "required" )){
                    $( "td:contains('Document Sighted :')" ).addClass( "required" );
                    $( "td:contains('Document Details :')" ).addClass( "required" );
                    $( "td:contains('Start date of Authority :')" ).addClass( "required" );
                    $( "td:contains('End date of Authority :')" ).addClass( "required" );
                    $( "td:contains('Review date of Authority :')" ).addClass( "required" );
                }
            }
        });
        
// For 'Reset' button
        
       $("#reset").click(function(){
           $('#errormessageDiv').hide();
           $('#messageId').hide();
           var individualFlag = false;
           if($('input:radio[name=individualType]:checked').val() == "Individual"){
                 individualFlag = true;
           }
            resetForm($('#tipForm'));
            
            $('#notificationDetailsId').val('');
            $('#notificationDetailsId').attr("disabled", true);
            $('#HealthcareProviderAssertionTableId').hide();
            if(!$( "td:contains('Document Sighted :')" ).hasClass( "required" )){
                $( "td:contains('Document Sighted :')" ).addClass( "required" );
                $( "td:contains('Document Details :')" ).addClass( "required" );
                $( "td:contains('Start date of Authority :')" ).addClass( "required" );
                $( "td:contains('End date of Authority :')" ).addClass( "required" );
                $( "td:contains('Review date of Authority :')" ).addClass( "required" );
            }
            if(individualFlag){
                $("input:radio[name=individualType][value='Individual']").prop("checked", true);
                
            }else{
                $("input:radio[name=individualType][value='Dependent']").prop("checked", true);
            }
        });
        
        function resetForm($form) {
            $form.find('input:text, input:password, input:file, select, textarea').val('');
            $form.find('input:radio, input:checkbox').removeAttr('checked').removeAttr('selected');
        }
        
});