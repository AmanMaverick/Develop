$(document).ready(function () {
    
    $("#validateAllIHI,#validateFileIHI,#validateForRow,#validateIHIInfoDiv,#validateButtonDiv").hide();
    $("#BulkRecordCreationAllIHI,#BulkRecordCreationFileIHI,#BulkRecordCreationForRow,#BulkRecordCreationButtonDiv").hide();
     $("#ValidateAndBulkRecordCreationAllIHI,#validateAndCreateFileIHI,#validateAndCreateRecordForRow,#validateAndCreateButtonDiv").hide();
    $("#statusAllIHI,#statusFileIHI,#statusForDHSFile,#validateIHIInfoDiv,#statusButtonDiv").hide();
    $("#reconcileDescrepancyDiv,#reconcileReconcileationDiv").hide();
    var tabFlag = false;
    $("ul#tabs li.active").removeClass("active");
    $("ul#tab li.active").removeClass("active");
    if ($('#validateAndDataExtractionAction').val() == 'ValidateAndDataExtarctAction') {
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 1 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 1 + ")").addClass("active");
        tabFlag = true;
        $("#validateIHIDiv,#reconsileDataErrorDiv,#recordCreationDiv,#statusErrorDiv,#validateAndCreateRecordErrorDiv").hide();
    }

    if ($('#bulkRegvalidateAction').val() == 'ValidateIHIInfo') {
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 2 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 2 + ")").addClass("active");
         tabFlag = true;
        $("#validateAndExtractErrorDiv,#reconsileDataErrorDiv,#recordCreationDiv,#statusErrorDiv,#validateAndCreateRecordErrorDiv").hide();
        validateIHIInfoActionFunc();
    }
    if ($('#bulkrecordCreationAction').val() == 'RecordCreation') {
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 3 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 3 + ")").addClass("active");
        tabFlag = true;
        $("#validateAndExtractErrorDiv,#reconsileDataErrorDiv,#validateIHIDiv,#statusErrorDiv,#validateAndCreateRecordErrorDiv").hide();
         bulkRecordCreationActionFunc();
    }
    if ($('#validateAndCreateRecordAction').val() == 'validateAndCreateRecordAction') {
      
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 4 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 4 + ")").addClass("active");
        tabFlag = true;
        $("#validateAndExtractErrorDiv,#reconsileDataErrorDiv,#validateIHIDiv,#statusErrorDiv,#recordCreationDiv").hide();
          validateAndCreateRecordActionFunc();
    }
    if ($('#reconsileDataAction').val() == 'ReconsileData') {
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 5 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 5 + ")").addClass("active");
        tabFlag = true;
        $("#validateAndExtractErrorDiv,#reconsileDataErrorDiv,#validateIHIDiv,#recordCreationDiv,#validateAndCreateRecordErrorDiv").hide();
        reconcileActionFunc();
    }
    if ($('#bulkStatusAction').val() == 'Status') {
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 6 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 6 + ")").addClass("active");
        tabFlag = true;
        $("#validateAndExtractErrorDiv,#reconsileDataErrorDiv,#validateIHIDiv,#recordCreationDiv,#validateAndCreateRecordErrorDiv").hide();
         satusActionFunc();
    }

     if(!tabFlag){
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 1 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 1 + ")").addClass("active");
        $("#validateIHIDiv,#reconsileDataErrorDiv,#recordCreationDiv,#statusErrorDiv,#validateAndCreateRecordErrorDiv").hide();
    }

    //      Sumanta Code
    $('#ValidateSubmitID').click(function (e) {
        // $("#validateExtractForm").attr("action", "#");
        $('#validateAndDataExtractionAction').val('ValidateAndDataExtarctAction');

    });
    $('#PushToDatabaseSubmitID').click(function (e) {
        //  $("#validateExtractForm").attr("action", "#");

        $('#validateAndDataExtractionAction').val('ValidateAndDataExtarctAction');
    });
    //clear the message output div while clicking the link
    $('#outputLinkValidateExtarction').click(function () {
        $('#messageId').hide();
    });
    $('#outputLinkDataExtarction').click(function () {
        $('#messageId').hide();
    });
    //to open in a new window on output link--validate Extract
    $("#outputLinkValidateExtarction").click(function () {
        $('#OutputLinkSubmitValidateExtarctionID').click();

    });
    //to open in a new window on output link--push to DB
    $("#outputLinkDataExtarction").click(function () {
        $('#OutputLinkSubmitDataExtractID').click();

    });
    //    Sumanta Code Ends here
    $("ul#tabs li").click(function (e) {
        if (!$(this).hasClass("active")) {
            var tabNum = $(this).index();
            var nthChild = tabNum + 1;
            $("ul#tabs li.active").removeClass("active");
            $(this).addClass("active");
            $("ul#tab li.active").removeClass("active");
            $("ul#tab li:nth-child(" + nthChild + ")").addClass("active");
        }
    });
    $.fn.diplayCurrentTab = function (tabNum) {
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + tabNum + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + tabNum + ")").addClass("active");
    }

    function validateIHIInfoActionFunc() {
    //alert("here 2nd time");
        $('#bulkRegvalidateAction').val('ValidateIHIInfo');
        var selectedVal = $('#validateAction').val();
      //  alert("here validateIHI action.."+selectedVal);
        $("#validateAllIHI,#validateFileIHI,#validateForRow,#validateIHIInfoDiv").hide();
        if (selectedVal == "Validate ALL IHIs") {
            $("#validateFileIHI,#validateForRow").hide();
            $("#validateAllIHI,#validateButtonDiv").show();

            $("#ValidateIHIInfoBut").val("Validate ALL IHIs");

        }
        if (selectedVal == "Select IHI List for Validation") {
            $("#validateAllIHI,#validateForRow").hide();
            $("#validateFileIHI,#validateButtonDiv").show();
            $("#ValidateIHIInfoBut").val("Validate IHI List");
        }
        if (selectedVal == "Select Number of Rows for Validation") {
            $("#validateFileIHI,#validateAllIHI").hide();
            $("#validateForRow,#validateButtonDiv").show();
            $('#validateNoOfRows').val('');
            $("#ValidateIHIInfoBut").val("Validate IHIs");
        }
        if (selectedVal == "") {
            $("#validateFileIHI,#validateForRow,#validateAllIHI,#validateButtonDiv").hide();
        }
}


    //Validate and Bulk Record Creation Tabs On change function for Action Dropdown
    
   function validateAndCreateRecordActionFunc() {
        $('#validateAndCreateRecordAction').val('validateAndCreateRecordAction');
        var selectedVal = $('#validateAndRecordCreationId').val();
        $("#validateAndCreateButtonDiv").show();
        //$("#validateAllIHI,#validateFileIHI,#validateForRow,#validateIHIInfoDiv").hide();
        if (selectedVal == "Validate and Register for ALL IHIs") {
            $("#ValidateAndBulkRecordCreationAllIHI").show();
            $("#validateAndCreateFileIHI,#validateAndCreateRecordForRow").hide();
            $("#validateAndCreateButton").val("Validate and Create Records for ALL IHIs ");
        }
        if (selectedVal == "Validate and Register for a List of IHIs") {
            $("#validateAndCreateRecordForRow,#ValidateAndBulkRecordCreationAllIHI").hide();
            $("#validateAndCreateFileIHI").show();
            $("#validateAndCreateButton").val("Validate and Create Records ");
        }
        if (selectedVal == "Validate and Register for Specified Number of Rows") {
            $("#ValidateAndBulkRecordCreationAllIHI,#validateAndCreateFileIHI").hide();
            $("#validateAndCreateRecordForRow").show();
            $('#validateAndCreateNoOfRows').val('');
            $("#validateAndCreateButton").val("Validate and Create Records ");
        }
        if (selectedVal == "") {
            $("#ValidateAndBulkRecordCreationAllIHI,#validateAndCreateFileIHI,#validateAndCreateRecordForRow,#validateAndCreateButtonDiv").hide();
        }
    }

    function bulkRecordCreationActionFunc() {
        $('#bulkrecordCreationAction').val('RecordCreation');
        var selectedVal = $('#recordCreationAction').val();
        $("#BulkRecordCreationAllIHI,#BulkRecordCreationFileIHI,#BulkRecordCreationForRow,#BulkRecordCreationDiv").hide();
        if (selectedVal == "Create Records for ALL IHIs") {
            $("#BulkRecordCreationFileIHI,#BulkRecordCreationForRow").hide();
            $("#BulkRecordCreationAllIHI,#BulkRecordCreationButtonDiv").show();
            $("#bulkRecordCreationBut").val("Create Record for ALL IHIs");
        }
        if (selectedVal == "Create Record for List of IHIs") {
            $("#BulkRecordCreationAllIHI,#BulkRecordCreationForRow").hide();
            $("#BulkRecordCreationFileIHI,#BulkRecordCreationButtonDiv").show();
            $("#bulkRecordCreationBut").val("Create Record");
        }
        if (selectedVal == "Create Records for a Specified Number of Rows") {
            $("#BulkRecordCreationFileIHI,#BulkRecordCreationAllIHI").hide();
            $("#BulkRecordCreationForRow,#BulkRecordCreationButtonDiv").show();
            $("#bulkRecordCreationBut").val("Create Records");
            $('#recordCreationNoOfRows').val('');
        }
        if (selectedVal == "") {
            $("#BulkRecordCreationFileIHI,#BulkRecordCreationForRow,#BulkRecordCreationAllIHI,#BulkRecordCreationButtonDiv").hide();
        }
    }

    function satusActionFunc(){
  
        $('#bulkStatusAction').val('Status');
        var selectedVal = $('#statusAction').val();
        $("#statusAllIHI,#statusFileIHI,#statusForDHSFile,#validateIHIInfoDiv").hide();
        if (selectedVal == "ALL IHI") {
            $("#statusFileIHI,#statusForDHSFile").hide();
            $("#statusAllIHI,#statusButtonDiv").show();
        }
        if (selectedVal == "List of IHIs") {
            $("#statusAllIHI,#statusForDHSFile").hide();
            $("#statusFileIHI,#statusButtonDiv").show();
        }
        if (selectedVal == "File Name") {
            $("#statusFileIHI,#statusAllIHI").hide();
            $("#statusForDHSFile,#statusButtonDiv").show();
            $('#inputDHSFileName').val('');
        }
        if (selectedVal == "") {
            $("#statusFileIHI,#statusForDHSFile,#statusAllIHI,#statusButtonDiv").hide();
        }
    }
    function reconcileActionFunc() {
        $('#reconsileDataAction').val('ReconsileData');

        var selectedVal = $('#reportTypeId').val();
        $("#reconcileDescrepancyDiv,#reconcileReconcileationDiv").hide();
        if (selectedVal == "reconcileRepo") {
            $("#reconcileDescrepancyDiv").hide();
            $("#reconcileReconcileationDiv").show();
        }
        if (selectedVal == "discrepancyRepo") {
            $("#reconcileDescrepancyDiv").show();
            $("#reconcileReconcileationDiv").hide();
        }
        if (selectedVal == "") {
            $("#reconcileDescrepancyDiv,#reconcileReconcileationDiv").hide();
        }
    }

    $("#validateAction").change(function () {
        $('#filename1').val('');
        
        validateIHIInfoActionFunc();
    });
    $("#recordCreationAction").change(function () {
        $('#filename2').val('');
       bulkRecordCreationActionFunc();
    });
    $("#validateAndRecordCreationId").change(function () {
        $('#filename3').val('');
       validateAndCreateRecordActionFunc();
    });
    $("#statusAction").change(function () {
        $('#filename4').val('');
          //added for error div hidding --Sumanta
          $('#statusErrorDiv').hide();
        satusActionFunc();
    });
    //added for statusErrorDiv hidding --Sumanta
     $("#statusButId").click(function(){
             $('#statusErrorDiv').hide();
     });
     //end--statusErrorDiv
    $("#reportTypeId").change(function () {
       reconcileActionFunc();
    });
    $('#validateIHIInfoReset').click(function () {
        $("#validateFileIHI,#validateIHIDiv").hide();
        $("#validateForRow,#validateButtonDiv").hide();
        $("#validateAllIHI").hide();
        $('#filename1').val('');
        $('#validateNoOfRows').val('');
        $("#validateAction").val($("#validateAction option:first").val());
    });
    $('#bulkRecordCreationReset').click(function () {
        $('#filename2').val('');
        $("#BulkRecordCreationFileIHI,#recordCreationDiv").hide();
        $("#BulkRecordCreationForRow").hide();
        $("#BulkRecordCreationAllIHI").hide();
        $("#BulkRecordCreationButtonDiv").hide();
        $('#recordCreationNoOfRows').val('');
        $("#recordCreationAction").val($("#recordCreationAction option:first").val());
    });

    //validateAndCreateReset
    $('#validateAndCreateReset').click(function () {
        $('#filename3').val('');
        $("#ValidateAndBulkRecordCreationAllIHI,#validateAndCreateFileIHI,#validateAndCreateRecordForRow,#validateAndCreateButtonDiv,#validateAndCreateRecordErrorDiv").hide();
        $('#validateAndCreateNoOfRows').val('');
        $("#validateAndRecordCreationId").val($("#validateAndRecordCreationId option:first").val());
    });

    //reconsileDataReset
    $('#reconsileDataReset').click(function () {
        $("#reportTypeId").val($("#reportTypeId option:first").val());
        $("#registrationStateId").val($("#registrationStateId option:first").val());
        $("#registrationActionId").val($("#registrationActionId option:first").val());
        $("#registrationErrorId").val($("#registrationErrorId option:first").val());
        $("#reconsileDataErrorDiv").hide();
    });

    //Code for Browse button Start
    
    $('#uploadBtn1').change(function () {
        var filename = $('#uploadBtn1').val().split('\\').pop();
        $('#uploadFile1').val(filename);
    });

    $('#uploadBtn2').change(function () {
        var filename = $('#uploadBtn2').val().split('\\').pop();
        $('#uploadFile2').val(filename);
    });
    $('#uploadBtn3').change(function () {
        var filename = $('#uploadBtn3').val().split('\\').pop();
        $('#uploadFile3').val(filename);
    });
    $('#uploadBtn4').change(function () {
        var filename = $('#uploadBtn4').val().split('\\').pop();
        $('#uploadFile4').val(filename);
    });
    //Code for Browse button End
    
//    document.getElementById("uploadBtn").onchange = function () {
//        document.getElementById("uploadFile").value = this.value.split('\\').pop();
//    };

    
    $("#registrationStateId").change(function () {
        var select = $('#registrationStateId').val();
        if(select == 'FE' || select == ''){
            $("tr#errorTr").show();
        }else{
            $("tr#errorTr").hide();
        }
    });
});

