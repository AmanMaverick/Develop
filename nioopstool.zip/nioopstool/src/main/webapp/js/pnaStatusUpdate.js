$(document).ready(function() {
    $('#reset').click(function() {
        $('#ihi').val('');
        $('input[path="status"]').prop('checked', false);
        $("#relationshipType").val($("#relationshipType option:first").val());
        $('input[path="isCleanRecord"]').prop('checked', false);
        $('#representativeIHI').val('');
        $('#changeBy').val('');
        $('#userID').val('');
        $('#soapMessage').val('');
    });

});