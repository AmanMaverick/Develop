package pcehr.recovery;


import com.sun.xml.ws.developer.JAXWSProperties;

import ihe.iti.xds_b._2007.DocumentRegistryPortType;
import ihe.iti.xds_b._2007.DocumentRegistryService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import javax.xml.bind.JAXBElement;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryRequest;
import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryResponse;
import oasis.names.tc.ebxml_regrep.xsd.query._3.ResponseOptionType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.AdhocQueryType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ExtrinsicObjectType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.IdentifiableType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.SlotType1;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ValueListType;


/**
 * This class is proxy for Get Document List Web service.
 */
public class GetDocumentList {
    /**
     *
     * @param myProp
     * @param ihi
     * @return HashMap
     */
    public static HashMap getDocList(final Properties myProp, final String ihi) {
        HashMap iDListHashMap = new HashMap();
        DocumentRegistryService documentRegistryService = new DocumentRegistryService();
        
        documentRegistryService.setHandlerResolver(new ClientHandlerResolver());
        DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12(new javax.xml.ws.soap.AddressingFeature(true,true));
        //DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12();
        Map<String, Object> ctxt = ((BindingProvider) documentRegistryPortType).getRequestContext();
        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, 
                 myProp.getProperty(UtilConstants.GET_DOC_LIST_ENDPOINT));
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, 
                 new TestHostnameVerifier());
        ResponseOptionType responseOptionType = new ResponseOptionType();
        responseOptionType.setReturnType("LeafClass");
        responseOptionType.setReturnComposedObjects(true);        
        AdhocQueryType adhocQueryType = new AdhocQueryType();        
        List<SlotType1> newslots = new ArrayList<SlotType1>();
        String patID = "'" + ihi + "^^^&1.2.36.1.2001.1003.0&ISO'";
        newslots.add(createSlot("$XDSDocumentEntryPatientId", patID));
        newslots.add(createStatusSlot("$XDSDocumentEntryStatus", "('urn:oasis:names:tc:ebxml-regrep:StatusType:Approved')","('urn:oasis:names:tc:ebxml-regrep:StatusType:Deprecated')"));
        adhocQueryType.getSlot().addAll(newslots);
        adhocQueryType.setId("urn:uuid:14d4debf-8f97-4251-9a74-a90016b0af0d");        
        AdhocQueryRequest adhocQueryRequest = new AdhocQueryRequest();
        adhocQueryRequest.setAdhocQuery(adhocQueryType);
        adhocQueryRequest.setResponseOption(responseOptionType);
        AdhocQueryResponse adhocQueryResponse = documentRegistryPortType.documentRegistryRegistryStoredQuery(adhocQueryRequest);
        List<JAXBElement<? extends IdentifiableType>> identifiable = adhocQueryResponse.getRegistryObjectList().getIdentifiable();
        for (int j = 0; j < identifiable.size(); j++) {
            for (int i = 0; i < ((ExtrinsicObjectType) identifiable.get(j).getValue()).getExternalIdentifier().size(); i++) {            
                String temp = ((ExtrinsicObjectType) identifiable.get(j).getValue()).getExternalIdentifier().get(i).getValue().toString();
                if (!temp.contains("ISO")) {
                    iDListHashMap.put( identifiable.get(j).getValue().getId(), temp);
                }
            }
        }
        return iDListHashMap;
    }
    
    public static AdhocQueryResponse getAccessLevel(final Properties myProp, final String ihi, final String docID) {
        String accessLevel = null;
        int noOfExtrinsicObjects = 0;
        int rlsVersionNumber = 0;
        DocumentRegistryService documentRegistryService = new DocumentRegistryService();
        documentRegistryService.setHandlerResolver(new ClientHandlerResolver());
        DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12(new javax.xml.ws.soap.AddressingFeature(true,true));
        //DocumentRegistryPortType documentRegistryPortType = documentRegistryService.getDocumentRegistryPortSoap12();
        Map<String, Object> ctxt = ((BindingProvider) documentRegistryPortType).getRequestContext();
        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, 
                 myProp.getProperty(UtilConstants.GET_DOC_LIST_ENDPOINT));
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, 
                 new TestHostnameVerifier());
        ResponseOptionType responseOptionType = new ResponseOptionType();
        responseOptionType.setReturnType("LeafClass");
        responseOptionType.setReturnComposedObjects(true);        
        AdhocQueryType adhocQueryType = new AdhocQueryType();
        List<SlotType1> newslots = new ArrayList<SlotType1>();
        newslots.add(createSlot("$XDSDocumentEntryUniqueId","('"+docID+"')"));
        newslots.add(createStatusSlot("$XDSDocumentEntryStatus", "('urn:oasis:names:tc:ebxml-regrep:StatusType:Approved')","('urn:oasis:names:tc:ebxml-regrep:StatusType:Deprecated')"));
        adhocQueryType.getSlot().addAll(newslots);
        adhocQueryType.setId("urn:uuid:5c4f972b-d56b-40ac-a5fc-c8ca9b40b9d4");        
        AdhocQueryRequest adhocQueryRequest = new AdhocQueryRequest();
        adhocQueryRequest.setAdhocQuery(adhocQueryType);
        adhocQueryRequest.setResponseOption(responseOptionType);
        AdhocQueryResponse adhocQueryResponse = documentRegistryPortType.documentRegistryRegistryStoredQuery(adhocQueryRequest);
//        List<JAXBElement<? extends IdentifiableType>> identifiable = adhocQueryResponse.getRegistryObjectList().getIdentifiable();
//        for (int j = 0; j < identifiable.size(); j++) {
//            for (int i = 0; i < ((ExtrinsicObjectType) identifiable.get(j).getValue()).getClassification().size(); i++) {            
//                String temp = ((ExtrinsicObjectType) identifiable.get(j).getValue()).getClassification().get(i).getClassificationScheme().toString();    
//                if (temp.contains("urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f")) {
//                    accessLevel = ((ExtrinsicObjectType) identifiable.get(j).getValue()).getClassification().get(i).getNodeRepresentation().toString();
//                }
//            }
//        }

        return adhocQueryResponse;
    }
    /**
     * This method is to include slot into the Request.
     * @param name
     * @param value
     * @return SlotType1
     */
    private static SlotType1 createSlot(final String name, final String value) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        slot.setValueList(new ValueListType());
        slot.getValueList().getValue().add(value);
        return slot;
    }
    /**
     * This method is to include slot into the Request.
     * @param name
     * @param value
     * @return SlotType1
     */
    private static SlotType1 createStatusSlot(final String name, final String value1, final String value2) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        slot.setValueList(new ValueListType());
        slot.getValueList().getValue().add(value1);
        slot.getValueList().getValue().add(value2);
        return slot;
    }
    /**
     * This class is to handle the SOAP Request and Response.
     */
    public static class ClientHandlerResolver implements HandlerResolver {
        /**
         *
         * @param port_info
         * @return Handler
         */
        public final List<Handler> getHandlerChain(final PortInfo port_info) {
            List<Handler> handlerChain = new ArrayList<Handler>();
            LoggingHandler loggingHandler = new LoggingHandler(UtilConstants.GET_DOC_LIST);
            handlerChain.add(loggingHandler);
            return handlerChain;
        }
    }
    /**
     * This class is to verify host name.
     */
    public static class TestHostnameVerifier implements HostnameVerifier {
        public final boolean verify(final String arg0, final SSLSession arg1) {
            System.out.println("Inside TestHost");
            return true;
        }
    }   
}
