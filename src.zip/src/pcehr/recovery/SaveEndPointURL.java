package pcehr.recovery;

import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.Enumeration;
import java.util.Properties;

/**
 * This class is to save Endpoint URL's to Properties file.
 */
public class SaveEndPointURL {

    private String persistAtomicData;
    private String deprecateAtomicData;
    private String updateDocumentStatus;
    private String getDocumentList;
    private String unremoveDocument;
    private String removeDocument;
    private String pna;
    private String createAuthpna;
    private String updateAuthpna;
    private String updateNompna;
    private String cleanIndProfile;
    private String arRestrict;
   private String authoriseRestrict;
    private String oimDisable;
    private String insertAudit;
    private String syncIHI;
    private String htbUsername;
    private String htbPassword;
    private String pnaUsername;
    private String pnaPassword;
    private String osbUsername;
    private String osbPassword;
    private String pnaAuthUsername;
    private String pnaAuthPassword;
    private String propertyFileLocation;
    private String webLogicInitialContext;
    private String webLogicProviderURL;
    private String webLogicJndiNameOSB;
    private String webLogicJndiNameHTB;
    private String webLogicJndiNamePNA;
    private String webLogicJndiNameOIM;
    private String webLogicJndiNameRLS;
    private String hostName;
    /**
     *
     * @param persistAtomicData
     * @param deprecateAtomicData
     * @param updateDocumentStatus
     * @param getDocumentList
     * @param unremoveDocument
     * @param removeDocument
     * @param pna
     * @param createAuthpna
     * @param updateAuthpna
     * @param updateNompna
     * @param insertAudit
     * @param syncIHI
     * @param htbUsername
     * @param htbPassword
     * @param pnaUsername
     * @param pnaPassword
     * @param osbUsername
     * @param osbPassword
     * @param webLogicInitialContext
     * @param webLogicProviderURL
     * @param webLogicJndiNameOSB
     * @param webLogicJndiNameHTB
     * @param webLogicJndiNamePNA
     * @param webLogicJndiNameOIM
     * @param webLogicJndiNameRLS
     * @param hostName
     * @param propertyFileLocation
     */
    public SaveEndPointURL(final String persistAtomicData, final String deprecateAtomicData,
                           final String updateDocumentStatus, final String getDocumentList , final String unremoveDocument, final String removeDocument, final String pna, 
                           final String createAuthpna, final String updateAuthpna, final String updateNompna,final String cleanIndProfile,final String authoriseRestrict,final String arRestrict,final String oimDisable,
                           final String insertAudit, final String syncIHI, final String htbUsername, final String htbPassword,
                           final String pnaUsername, final String pnaPassword, final String osbUsername, final String osbPassword,final String pnaAuthUsername,final String pnaAuthPassword,
                           final String webLogicInitialContext, final String webLogicProviderURL, 
                           final String webLogicJndiNameOSB, final String webLogicJndiNameHTB, 
                           final String webLogicJndiNamePNA, final String webLogicJndiNameOIM,final String webLogicJndiNameRLS,
                           final String hostName, final String propertyFileLocation) {
        super();
        this.persistAtomicData = persistAtomicData;
        this.deprecateAtomicData = deprecateAtomicData;
        this.updateDocumentStatus = updateDocumentStatus;
        this.getDocumentList = getDocumentList;
        this.unremoveDocument = unremoveDocument;
        this.removeDocument = removeDocument;
        this.pna = pna;
        this.createAuthpna = createAuthpna;
        this.updateAuthpna = updateAuthpna;
        this.updateNompna = updateNompna;
        this.arRestrict = arRestrict;
        this.oimDisable = oimDisable;
        this.authoriseRestrict = authoriseRestrict;
        this.insertAudit = insertAudit;
        this.syncIHI = syncIHI;
        this.htbUsername = htbUsername;
        this.htbPassword = htbPassword;
        this.pnaUsername = pnaUsername;
        this.pnaPassword = pnaPassword;
        this.osbUsername = osbUsername;
        this.osbPassword = osbPassword;
        this.pnaAuthUsername = pnaAuthUsername;
        this.pnaAuthPassword = pnaAuthPassword;
        this.webLogicInitialContext = webLogicInitialContext;
        this.webLogicProviderURL = webLogicProviderURL;
        this.webLogicJndiNameOSB = webLogicJndiNameOSB;
        this.webLogicJndiNameHTB = webLogicJndiNameHTB;
        this.webLogicJndiNamePNA = webLogicJndiNamePNA;
        this.webLogicJndiNameOIM = webLogicJndiNameOIM;
        this.webLogicJndiNameRLS = webLogicJndiNameRLS;
        EndPointsConstants.WEBLOGIC_JNDI_NAME_RLS=webLogicJndiNameRLS;
        this.hostName = hostName;
        this.propertyFileLocation = propertyFileLocation;
        this.cleanIndProfile = cleanIndProfile;
    }
    /**
     *
     * @param myProp
     * @return String
     */
    public String savePropertyEntries(final Properties myProp) {

        String fileName = "EndPoints.properties";
        Properties myNewProp = alterProperties(myProp);
        
        return saveProperties(myNewProp, fileName);
    }
    /**
     *
     * @param p
     * @return Properties
     */
    private Properties alterProperties(final Properties p) {
        Properties newProps = new Properties();
        Enumeration enumProps = p.propertyNames();
        String key = "";
        while (enumProps.hasMoreElements()) {
            key = (String) enumProps.nextElement();
            if (key.equals("PersistAtomicData_EndPoint")) {
                newProps.setProperty(key, persistAtomicData);
            } else if (key.equals("AuditInsert_EndPoint")) {
                newProps.setProperty(key, insertAudit);
            } else if (key.equals("DeprecateAtomicData_EndPoint")) {
                newProps.setProperty(key, deprecateAtomicData);
            } else if (key.equals("PNA_EndPoint")) {
                newProps.setProperty(key, pna);
            } else if (key.equals("PNA_CreateAuthRep_EndPoint")) {
                newProps.setProperty(key, createAuthpna);
            } else if (key.equals("PNA_UpdateAuth_EndPoint")) {
                newProps.setProperty(key, updateAuthpna);
            } else if (key.equals("PNA_UpdateNominated_EndPoint")) {
                newProps.setProperty(key, updateNompna);
            } else if (key.equals("PNA_CleanIndividualProfile_EndPoint")) {
                newProps.setProperty(key, cleanIndProfile);
            }
            else if (key.equals("PNA_ARRestrict")) {
                newProps.setProperty(key, arRestrict);
            } else if (key.equals("PNA_AuthoriseRestrict_EndPoint")) {
                    newProps.setProperty(key, authoriseRestrict);
                }else if (key.equals("PNA_OIMDisable")) {
                newProps.setProperty(key, oimDisable);
            }else if (key.equals("UpdateDocumentStatus_EndPoint")) {
                newProps.setProperty(key, updateDocumentStatus);
            } else if (key.equals("GetDocumentList_EndPoint")) {
                newProps.setProperty(key, getDocumentList);
            } else if (key.equals("UnremoveDocument_EndPoint")) {
                newProps.setProperty(key, unremoveDocument);
            } else if (key.equals("RemoveDocument_EndPoint")) {
                newProps.setProperty(key, removeDocument);
            } else if (key.equals("SynchroniseIHI_EndPoint")) {
                newProps.setProperty(key, syncIHI);
            } else if (key.equals("HTB_Username")) {
                newProps.setProperty(key, htbUsername);
            } else if (key.equals("HTB_Password")) {
                newProps.setProperty(key, htbPassword);
            } else if (key.equals("PNA_Username")) {
                newProps.setProperty(key, pnaUsername);
            } else if (key.equals("PNA_Password")) {
                newProps.setProperty(key, pnaPassword);
            } else if (key.equals("OSB_Username")) {
                newProps.setProperty(key, osbUsername);
            } else if (key.equals("OSB_Password")) {
                newProps.setProperty(key, osbPassword);
            }else if (key.equals("PNA_AUTH_USERNAME")) {
                newProps.setProperty(key, pnaAuthUsername);
            }  else if (key.equals("PNA_AUTH_PWD")) {
                 newProps.setProperty(key, pnaAuthPassword);
            } else if (key.equals("Initial_Context_Factory")) {
                newProps.setProperty(key, webLogicInitialContext);
            } else if (key.equals("WebLogic_Provider_Url")) {
                newProps.setProperty(key, webLogicProviderURL);
            } else if (key.equals("WebLogic_Jndi_Name_OSB")) {
                newProps.setProperty(key, webLogicJndiNameOSB);
            } else if (key.equals("WebLogic_Jndi_Name_HTB")) {
                newProps.setProperty(key, webLogicJndiNameHTB);
            } else if (key.equals("WebLogic_Jndi_Name_PNA")) {
                newProps.setProperty(key, webLogicJndiNamePNA);
            } else if (key.equals("WebLogic_Jndi_Name_OIM")) {
                newProps.setProperty(key, webLogicJndiNameOIM);
            } else if (key.equals("WebLogic_Jndi_Name_RLS")) {
                 newProps.setProperty(key, webLogicJndiNameRLS);
            } else if (key.equals("HostName")) {
                newProps.setProperty(key, hostName);
            } else {
                newProps.setProperty(key, p.getProperty(key));
            }
        }
        return newProps;
    }
    /**
     *
     * @param p
     * @param fileName
     * @return String
     */
    private String saveProperties(final Properties p, final String fileName) {
        OutputStream outPropFile;
        try {
            File file = new File(propertyFileLocation);
            outPropFile = new FileOutputStream(file);
            p.store(outPropFile, "");
            outPropFile.close();
            return "SUCCESS";
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return "FAILED";
        }
    }

}
