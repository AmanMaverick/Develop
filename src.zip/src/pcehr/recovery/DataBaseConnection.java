package pcehr.recovery;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Hashtable;
import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

/**
 * This class is to connect to the DB.
 */
public class DataBaseConnection {
    private static Logger LOG = Logger.getLogger(DataBaseConnection.class);
    /**
     * Connection variable.
     */
    private Connection connection = null;

    /**
     *
     */
    private String dbPropsFile = "pcehr.recovery.DatabaseConnection";

    /**
     *
     */
    private ResourceBundle myBundle;

    /**
     *
     */
    private String webLogicInitialContext;

    /**
     *
     */
    private String webLogicProviderURL;

    /**
     *
     */
    private String webLogicJndiName;
    
    static javax.sql.DataSource osbds = null; 
    static javax.sql.DataSource pnads = null; 
    static javax.sql.DataSource oimds = null; 
    static javax.sql.DataSource htbds = null; 
    static javax.sql.DataSource rlsds = null; 

    Logger log = Logger.getLogger("DataBaseConnection.class.getName()");  
    /**
     *
     * @param webLogicInitialContext
     * @param webLogicProviderURL
     * @param webLogicJndiName
     */
    public DataBaseConnection(final String webLogicInitialContext, final String webLogicProviderURL,
                              final String webLogicJndiName) {
        
        this.webLogicInitialContext = webLogicInitialContext;
        this.webLogicProviderURL = webLogicProviderURL;
        this.webLogicJndiName = webLogicJndiName;
    }

    /**
     * This method is to return the Result Set from OSB DB.
     * @param sqlQuery
     * @return ResultSet
     * @throws SQLException
     */
     public final ResultSet getResultSet(final String sqlQuery) throws SQLException {
        
         Statement stmt = null;
         ResultSet rs = null;
         try {
             connection = getConnection();
             stmt = connection.createStatement();
             rs = stmt.executeQuery(sqlQuery);
         } catch (SQLException e) {
             throw(e);
         }
         return rs;
     }

    /**
     * This methos is to return Prepared statement.
     * @param sqlQuery
     * @return PreparedStatement
     * @throws SQLException
     */
    public final PreparedStatement getPreparedStatment(final String sqlQuery) throws SQLException {
        PreparedStatement preStmt = null;
        try {
            if (null == connection) {
                log.debug("Establishing OSB Connection ");
                connection = getConnection();
                log.debug("OSB Connection Established");
            }
            preStmt = connection.prepareStatement(sqlQuery);
        } catch (SQLException e) {
            throw (e);
        }
        return preStmt;
    }

    /**
     *This method is to return the Connection to OSB DB.
     * @return Connection
     * @throws SQLException
     */
     public final Connection getConnection() throws SQLException {
         try {
             myBundle = ResourceBundle.getBundle(dbPropsFile);
             String isTestingLocal = myBundle.getString("testingLocal");
             if (null != isTestingLocal && isTestingLocal.equalsIgnoreCase("yes")) {
                 try {
                 Class.forName("oracle.jdbc.OracleDriver");
                 } catch (ClassNotFoundException classNot) {
                     classNot.printStackTrace();
                 }
                 connection =
                         DriverManager.getConnection(myBundle.getString("OSB_Connection_Url"), 
                                                     myBundle.getString("OSB_Username"),
                                                     myBundle.getString("OSB_Password"));
             } else if (isTestingLocal.equalsIgnoreCase("no")) {
                 Context ctx = null;  
                 Hashtable ht = new Hashtable();  
                 ht.put(Context.INITIAL_CONTEXT_FACTORY, webLogicInitialContext);  
                 ht.put(Context.PROVIDER_URL, webLogicProviderURL);
                 ctx = new InitialContext(ht);    
                 javax.sql.DataSource ds = (javax.sql.DataSource) ctx.lookup(webLogicJndiName);    
                 connection = ds.getConnection();
             }
         } catch (NamingException naming) {
             naming.printStackTrace();
         }
         return connection;
     }

    /**
     * This method is to return the Connection to HTB DB.
     * @return Connection
     * @throws SQLException
     */
    public final Connection getHTBConnection() throws SQLException {
        try {
            myBundle = ResourceBundle.getBundle(dbPropsFile);
            String isTestingLocal = myBundle.getString("testingLocal");
        if (isTestingLocal.equalsIgnoreCase("no")) {
                log.debug("Establishing HTB Connection ");
                Context ctx = null;
                Hashtable ht = new Hashtable();
                ht.put(Context.INITIAL_CONTEXT_FACTORY, webLogicInitialContext);
                ht.put(Context.PROVIDER_URL, webLogicProviderURL);
                ctx = new InitialContext(ht);
                if(htbds == null){
                    htbds = (javax.sql.DataSource)ctx.lookup(webLogicJndiName);
                } 
                connection = htbds.getConnection();
                log.debug("HTB Connection Established");
            }
        } catch (NamingException naming) {
            naming.printStackTrace();
        }
        return connection;
    }
    
    /**
       * This method is to return the Connection to HIMRLS DB.
       * @return Connection
       * @throws Exception
       */
     public final Connection getConnectionfromRLS() throws Exception {
         try {
             myBundle = ResourceBundle.getBundle(dbPropsFile);
             String isTestingLocal = myBundle.getString("testingLocal");
         if (isTestingLocal.equalsIgnoreCase("no")) {
                 log.debug("Establishing RLS Connection ");
                 Context ctx = null;
                 Hashtable ht = new Hashtable();
                 ht.put(Context.INITIAL_CONTEXT_FACTORY, webLogicInitialContext);
                 ht.put(Context.PROVIDER_URL, webLogicProviderURL);
                 ctx = new InitialContext(ht);
                 if(rlsds == null){
                     rlsds = (javax.sql.DataSource)ctx.lookup(webLogicJndiName);
                 } 
                 connection = rlsds.getConnection();
                 log.debug("RLS Connection Established");
             }
         } catch (Exception e) {
            LOG.fatal("Exception occured",e);
         }
         return connection;
     }


    /**
     * This method is to return the Connection to OIM DB.
     * @return Connection
     * @throws Exception
     */
    public final Connection getConnectionfromOIM() throws Exception {
        try {
            myBundle = ResourceBundle.getBundle(dbPropsFile);
            String isTestingLocal = myBundle.getString("testingLocal");
        if (isTestingLocal.equalsIgnoreCase("no")) {
                log.debug("Establishing OIM Connection ");
                Context ctx = null;
                Hashtable ht = new Hashtable();
                ht.put(Context.INITIAL_CONTEXT_FACTORY, webLogicInitialContext);
                ht.put(Context.PROVIDER_URL, webLogicProviderURL);
                ctx = new InitialContext(ht);
                if(oimds == null){
                    oimds = (javax.sql.DataSource)ctx.lookup(webLogicJndiName);
                } 
                connection = oimds.getConnection();
                log.debug("OIM Connection Established");
            }
        } catch (NamingException naming) {
            naming.printStackTrace();
        }
        return connection;
    }

    /**
     * This method is to return the Connection to OES_PNA DB.
     * @return Connection
     * @throws Exception
     */
    public final Connection getConnectionfromOESPNA() throws Exception {
        try {
            myBundle = ResourceBundle.getBundle(dbPropsFile);
            String isTestingLocal = myBundle.getString("testingLocal");
        if (isTestingLocal.equalsIgnoreCase("no")) {
                log.debug("Establishing PNA Connection ");
                Context ctx = null;
                Hashtable ht = new Hashtable();
                ht.put(Context.INITIAL_CONTEXT_FACTORY, webLogicInitialContext);
                ht.put(Context.PROVIDER_URL, webLogicProviderURL);
                ctx = new InitialContext(ht);
                if(pnads == null){
                    pnads = (javax.sql.DataSource)ctx.lookup(webLogicJndiName);
                } 
                connection = pnads.getConnection();
                log.debug("PNA Connection Established");
            }
        } catch (NamingException naming) {
            naming.printStackTrace();
        }
        return connection;
    }

    /**
     * This methos is to return Prepared statement.
     * @param sqlQuery
     * @return PreparedStatement
     * @throws SQLException
     */
    public final PreparedStatement getPNAPreparedStatment(final String sqlQuery) throws SQLException {
        PreparedStatement preStmt = null;
        try {
            if (null == connection) {
                connection = getConnectionfromOESPNA();
                log.debug("PNA Connection Established");
            }
            preStmt = connection.prepareStatement(sqlQuery);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return preStmt;
    }
    
    /**
     * This method is to return the Result Set from PNA DB.
     * @param sqlQuery
     * @return ResultSet
     * @throws SQLException
     * @throws Exception
     */
    public final ResultSet getResultSetPNA(final String sqlQuery) throws Exception {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = getPNAPreparedStatment(sqlQuery);
            rs = pstmt.executeQuery();
        } catch (Exception e) {
            throw (e);
        }
        return rs;
    }

    /**
     * This method is to release the DB Connection
     * @throws SQLException
     */
    public final void releaseConnection() throws SQLException {
        try{
            if (connection != null) {
                connection.close();
                log.debug("Connection Closed");
            }
        }catch(Exception e){
            
        }
        
    }

}
