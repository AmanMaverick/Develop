package pcehr.recovery;

import java.math.BigInteger;

/**
 * This Class is to convert UUID to OID
 */
public class ConvertUUIDToOID {
    /**
     *
     * @param uuid
     * @return String
     */
    public static String convertUUIDtoOID(final String uuid) {
        String strippedUUID = uuid.replaceAll("-", "");
        strippedUUID = strippedUUID.toLowerCase();
        String oid = "2.25." + getWeightedSum(strippedUUID);
        return oid;
    }
    /**
     *
     * @param str
     * @return BigInteger
     */
    private static BigInteger getWeightedSum(final String str) {

            BigInteger sum = new BigInteger(str, 16);

            return sum;
        }
}
