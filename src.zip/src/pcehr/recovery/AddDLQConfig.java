package pcehr.recovery;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Properties;

public class AddDLQConfig {
    
    private String propertyFileLocation;
    private String propertyFileLocation2;
    private String queueTypeList;
    private String queueSizeList;
    private String deliveryCount;
    private String webLogicInitialContext = null;
    private String webLogicProviderURL = null;
    private String webLogicJndiNameOSB = null;
    private String hostName = null;    
        
    public final void setvalues(final String propertyFileLocation,  
                                final String propertyFileLocation2, 
                                final String queueTypeList,
                                final String queueSizeList,
                                final String deliveryCount,
                                final String webLogicInitialContext,
                                final String webLogicProviderURL,
                                final String webLogicJndiNameOSB,
                                final String hostName){
        this.propertyFileLocation = propertyFileLocation;
        this.propertyFileLocation2 = propertyFileLocation2;
        this.webLogicInitialContext = webLogicInitialContext;
        this.webLogicProviderURL = webLogicProviderURL;
        this.webLogicJndiNameOSB = webLogicJndiNameOSB;
        this.hostName =hostName;
        this.queueTypeList = queueTypeList;
        this.queueSizeList = queueSizeList;
        this.deliveryCount = deliveryCount;
    }
    
    public final void savePropertyEntries(final Properties myProp, final Properties myProp2) {
        Properties myNewProp = alterProperties1(myProp);
        Properties myNewProp2 = alterProperties2(myProp2);
        saveProperties(myNewProp,myNewProp2);
    }
    
    private Properties alterProperties1(final Properties p) {
        Properties newProps = new Properties();
        Enumeration enumProps = p.propertyNames();
        String key = "";
        while (enumProps.hasMoreElements()) {
            key = (String) enumProps.nextElement();
            if (key.equals("QueueType")) {
                newProps.setProperty(key, queueTypeList);
            } else if (key.equals("QueueSize")) {
                newProps.setProperty(key, queueSizeList);
            } else if (key.equals("DeliveryCount")) {
                newProps.setProperty(key, deliveryCount);
            } 
        }
        return newProps;
    }

    private Properties alterProperties2(final Properties p) {
        Properties newProps = new Properties();
        Enumeration enumProps = p.propertyNames();
        String key = "";
        while (enumProps.hasMoreElements()) {
            key = (String) enumProps.nextElement();
            if (key.equals("Initial_Context_Factory")) {
                newProps.setProperty(key, webLogicInitialContext);
            } else if (key.equals("WebLogic_Provider_Url")) {
                newProps.setProperty(key, webLogicProviderURL);
            } else if (key.equals("WebLogic_Jndi_Name_OSB")) {
                newProps.setProperty(key, webLogicJndiNameOSB);
            } else if (key.equals("HostName")) {
                newProps.setProperty(key, hostName);
            }
        }
        return newProps;
    }
    
    private void saveProperties(final Properties p, final Properties p2) {
        OutputStream outPropFile;
        OutputStream outPropFile2;
        try {
            File file1 = new File(propertyFileLocation);
            File file2 = new File(propertyFileLocation2);
            outPropFile = new FileOutputStream(file1);
            outPropFile2 = new FileOutputStream(file2);
            p.store(outPropFile, "");
            p2.store(outPropFile2, "");
            outPropFile.close();
            outPropFile2.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
