/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package com.accenture.pcehr.artconsentfileextraction.util;
package pcehr.recovery;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


/**
 * Handling java and HTTP error
 * @author subhrajyoti.majumder
 */
public class ErrorHandlerServlet extends HttpServlet {
    
    private static Logger log = Logger.getLogger(ErrorHandlerServlet.class);
    
    private String url = "/";
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        log.debug("We got Exception ..... ");
        try{
            Throwable throwable = (Throwable) request.getAttribute("javax.servlet.error.exception");
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        String servletName = (String) request.getAttribute("javax.servlet.error.servlet_name");
        if (servletName == null) {
            servletName = "Unknown";
        }
        String requestUri = (String) request.getAttribute("javax.servlet.error.request_uri");
        if (requestUri == null) {
            requestUri = "Unknown";
        }
        request.setAttribute("statusCode", statusCode);
        request.setAttribute("servletName", servletName);
        request.setAttribute("exceptionType", throwable);
        request.setAttribute("requestUri", requestUri);
        }catch(Exception ex){
            log.error(ex.getLocalizedMessage(), ex);
        }
        log.debug("Forward to ..... RequestDispatcher");
        RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
        rd.forward(request, response);
    }
}
