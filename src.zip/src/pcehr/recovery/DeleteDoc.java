package pcehr.recovery;

import com.sun.xml.ws.developer.JAXWSProperties;

import ihe.iti.xds_b._2007.DocumentRegistryMUPortType;
import ihe.iti.xds_b._2007.DocumentRegistryMUService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import oasis.names.tc.ebxml_regrep.xsd.lcm._3.RemoveObjectsRequest;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ObjectRefListType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ObjectRefType;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryResponseType;

/**
 * This class is proxy for Update Document Status Web service.
 */
public class DeleteDoc {
    /**
     *
     * @param myProp
     * @param idLHashMap
     * @return RegistryResponseType
     */
    public static RegistryResponseType deteteDocument(final Properties myProp, 
                                                      final LinkedHashMap idLHashMap) {
        DocumentRegistryMUService documentRegistryMUService = new DocumentRegistryMUService();
        documentRegistryMUService.setHandlerResolver(new ClientHandlerResolver());
        DocumentRegistryMUPortType documentRegistryMUPortType = documentRegistryMUService.getDocumentRegistryMUPortSoap12(new javax.xml.ws.soap.AddressingFeature(true,true));
        Map<String, Object> ctxt = ((BindingProvider) documentRegistryMUPortType).getRequestContext();
        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, 
                 myProp.getProperty(UtilConstants.UPDATE_DOC_STAT_ENDPOINT));
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, 
                 new TestHostnameVerifier());        
        RemoveObjectsRequest removeObjectsRequest = new RemoveObjectsRequest();
        ObjectRefListType objectRefListType = new ObjectRefListType();
        ObjectRefType objectRefType = new ObjectRefType();        
        Collection c = idLHashMap.values();
        Iterator itr = c.iterator();
        while (itr.hasNext()) {
            String temp = itr.next().toString();
            objectRefType.setId(temp);
            objectRefListType.getObjectRef().add(objectRefType);
            objectRefType = new ObjectRefType();
        }
        removeObjectsRequest.setObjectRefList(objectRefListType);    
        RegistryResponseType registryResponseType = documentRegistryMUPortType.documentRegistryDeleteDocumentSet(removeObjectsRequest);
        return registryResponseType;
    }
    /**
     * This class is to handle the SOAP Request and Response.
     */
    public static class ClientHandlerResolver implements HandlerResolver {
        /**
         * @param port_info
         * @return Handler
         */ 
        public final List<Handler> getHandlerChain(final PortInfo port_info) {
            List<Handler> handlerChain = new ArrayList<Handler>();
            LoggingHandler loggingHandler = new LoggingHandler(UtilConstants.DELETE_DOCUMENT);
            handlerChain.add(loggingHandler);
            return handlerChain;
        }
    }
    /**
     * This class is to verify host name.
     */
    public static class TestHostnameVerifier implements HostnameVerifier {
        /**
         * @param arg0
         * @param arg1
         * @return boolean
         */
        public final boolean verify(final String arg0, 
                                    final SSLSession arg1) {
            System.out.println("Inside TestHost");
            return true;
        }
    }
}
