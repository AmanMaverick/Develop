package pcehr.recovery;

import com.sun.xml.ws.developer.JAXWSProperties;

import ihe.iti.xds_b._2007.DocumentRegistryMUPortType;
import ihe.iti.xds_b._2007.DocumentRegistryMUService;

import java.io.StringReader;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import oasis.names.tc.ebxml_regrep.xsd.lcm._3.ObjectFactory;
import oasis.names.tc.ebxml_regrep.xsd.lcm._3.SubmitObjectsRequest;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.AssociationType1;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.IdentifiableType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.RegistryObjectListType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.SlotType1;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ValueListType;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryError;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryErrorList;
import oasis.names.tc.ebxml_regrep.xsd.rs._3.RegistryResponseType;

/**
 * This class is proxy for Update document status webservice.
 */
public class UpdateDocumentStatus {
    RegistryResponseType registryResponseType = null;
    /**
     *
     * @param myProp
     * @param fileData
     */
    public final void executeUpdateDocumentStatus(final Properties myProp, final String fileData) {
        System.out.println(fileData);
        DocumentRegistryMUService documentRegistryMUService = new DocumentRegistryMUService();
        documentRegistryMUService.setHandlerResolver(new ClientHandlerResolver());
        DocumentRegistryMUPortType documentRegistryMUPortType = documentRegistryMUService.getDocumentRegistryMUPortSoap12();
        Map<String, Object> ctxt = ((BindingProvider) documentRegistryMUPortType).getRequestContext();
        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, myProp.getProperty("UpdateDocumentStatus_EndPoint"));
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, new TestHostnameVerifier());
        ObjectFactory obj = new ObjectFactory();
        SubmitObjectsRequest submitObjectRequest = obj.createSubmitObjectsRequest();
        try {
          JAXBContext jaxbContext = JAXBContext.newInstance("oasis.names.tc.ebxml_regrep.xsd.lcm._3");
          Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
          StringBuffer xmlStr = new StringBuffer(fileData);
          submitObjectRequest =  (SubmitObjectsRequest) jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(xmlStr.toString())));
        } catch (JAXBException jax) {
          jax.printStackTrace();
        }

        registryResponseType = documentRegistryMUPortType.documentRegistryUpdateDocumentSet(submitObjectRequest);
    }
    /**
     *
     * @param myProp
     * @param fileData
     */
    public final void deprecateDocumentStatus(final Properties myProp, final String fileData) {
        DocumentRegistryMUService documentRegistryMUService = new DocumentRegistryMUService();
        documentRegistryMUService.setHandlerResolver(new ClientHandlerResolver());
        DocumentRegistryMUPortType documentRegistryMUPortType = documentRegistryMUService.getDocumentRegistryMUPortSoap12();
        Map<String, Object> ctxt = ((BindingProvider) documentRegistryMUPortType).getRequestContext();
        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, myProp.getProperty(UtilConstants.UPDATE_DOC_STAT_ENDPOINT));
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, new TestHostnameVerifier());
        ObjectFactory obj = new ObjectFactory();
        SubmitObjectsRequest submitObjectRequest = obj.createSubmitObjectsRequest();
        try {
          JAXBContext jaxbContext = JAXBContext.newInstance("oasis.names.tc.ebxml_regrep.xsd.lcm._3");
          Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
          StringBuffer xmlStr = new StringBuffer(fileData);
          submitObjectRequest =  (SubmitObjectsRequest) jaxbUnmarshaller.unmarshal(new StreamSource(new StringReader(xmlStr.toString())));
        } catch (JAXBException jax) {
          jax.printStackTrace();
        }
        int objTypeIndex = fileData.indexOf("objectType=\"") + UtilConstants.VALUE_12; 
        int objTypeIndexEnd = fileData.indexOf(("\""), objTypeIndex);
        String targetObject = fileData.substring(objTypeIndex, objTypeIndexEnd);
        submitObjectRequest = returnNewSubmitObjectRequest(submitObjectRequest, targetObject);
        registryResponseType = documentRegistryMUPortType.documentRegistryUpdateDocumentSet(submitObjectRequest);
    }
    
    /**
     *
     * @return String
     */
    public final String getResponseStatus() {
        if (null != registryResponseType) {
            return registryResponseType.getStatus();
        } else {
            return null;
        }
    }
    /**
     *
     * @return String
     */
    public final String getResponseError() {
        String codeContext = null;
        if (null != registryResponseType) {
            RegistryErrorList errorList = registryResponseType.getRegistryErrorList();
            List<RegistryError> list = errorList.getRegistryError();
            for (RegistryError error : list) {
                codeContext = error.getCodeContext();
            }
        }
        return codeContext;
    }
    /**
     *
     * @param submitObjectsRequest
     * @param targetObject
     * @return SubmitObjectsRequest
     */
    private SubmitObjectsRequest returnNewSubmitObjectRequest(final SubmitObjectsRequest submitObjectsRequest, final String targetObject) {
        ObjectFactory obj = new ObjectFactory();
        SubmitObjectsRequest newSubmitObjectRequest = obj.createSubmitObjectsRequest();
        RegistryObjectListType newRegistryObjectListType = new RegistryObjectListType();
        RegistryObjectListType registryObjectListType = submitObjectsRequest.getRegistryObjectList();
        List<JAXBElement<? extends IdentifiableType>> elements = registryObjectListType.getIdentifiable();
        
        oasis.names.tc.ebxml_regrep.xsd.rim._3.ObjectFactory objFactory = new oasis.names.tc.ebxml_regrep.xsd.rim._3.ObjectFactory();
        AssociationType1 associationType = new AssociationType1();
        associationType.setAssociationType("urn:ihe:iti:2010:AssociationType:UpdateAvailabilityStatus");
        associationType.setSourceObject("SubmissionSet01");
        associationType.setTargetObject(targetObject);
        associationType.setId("as01");
        JAXBElement<AssociationType1> newAssociation = objFactory.createAssociation(associationType);
        List<SlotType1> newslots = new ArrayList<SlotType1>();
        newslots.add(createSlot("NewStatus", "urn:oasis:names:tc:ebxml-regrep:StatusType:Deprecated"));
        newslots.add(createSlot("OriginalStatus", "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved"));
        newAssociation.getValue().getSlot().addAll(newslots);

        System.out.println("No.of Elements:::" + elements.size());
        int count = 0;
        for (JAXBElement jax : elements) {
            if (count != 0 && count != UtilConstants.VALUE_3) {
                newRegistryObjectListType.getIdentifiable().add(jax);
            } else if (count == UtilConstants.VALUE_3) {
                newRegistryObjectListType.getIdentifiable().add(newAssociation);
            }
            count ++;
        }
        newSubmitObjectRequest.setRegistryObjectList(newRegistryObjectListType);
        return newSubmitObjectRequest;
    }
    /**
     *
     * @param name
     * @param value
     * @return SlotType1
     */
    private static SlotType1 createSlot(final String name, final String value) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        slot.setValueList(new ValueListType());
        slot.getValueList().getValue().add(value);
        return slot;
    }
    /**
     * This class is to verify host name.
     */
    public class TestHostnameVerifier implements HostnameVerifier {
        /**
         *
         * @param arg0
         * @param arg1
         * @return boolean
         */
        public final boolean verify(final String arg0, final SSLSession arg1) {
            System.out.println("Inside TestHost");
            return true;
        }
    }
    /**
     * This class is to handle the SOAP Request and Response.
     */
    public class ClientHandlerResolver implements HandlerResolver {
        /**
         *
         * @param port_info
         * @return Handler
         */
        public final List<Handler> getHandlerChain(final PortInfo port_info) {
            List<Handler> handlerChain = new ArrayList<Handler>();
            LoggingHandler loggingHandler = new LoggingHandler("UpdateDocumentStatus");
            handlerChain.add(loggingHandler);
            return handlerChain;
        }
    }
}
