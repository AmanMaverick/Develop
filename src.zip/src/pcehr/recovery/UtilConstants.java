package pcehr.recovery;


/**
 * This class is to place constants
 */
public class UtilConstants {
    
    
    public static final int VALUE_0 = 0;
    public static final int VALUE_1 = 1;
    public static final int VALUE_2 = 2;
    public static final int VALUE_3 = 3;
    public static final int VALUE_4 = 4;
    public static final int VALUE_5 = 5;
    public static final int VALUE_6 = 6;
    public static final int VALUE_7 = 7;
    public static final int VALUE_8 = 8;
    
    public static final int VALUE_12 = 12;
    public static final int VALUE_13 = 13;
    public static final int VALUE_14 = 14;
    public static final int VALUE_16 = 16;
    public static final int VALUE_17 = 17;
    public static final int VALUE_18 = 18;
    public static final int VALUE_19 = 19;
    public static final int VALUE_20 = 20;
    public static final String PNA = "PNA";
    public static final String OSB = "OSB";
    public static final String OSB_REGISTER_PCEHR = "OSBRegisterPcehr";
    public static final String PERSIST_ATOMIC = "PersistAtomic";
    public static final String DELETE_DOCUMENT = "deleteDocument";
    public static final String CLEAN_RECORD_DELETE_DOCUMENTS = "cleanRecordDeleteDocuments";
    public static final String DEPR_ATOMICDATA = "DeprecateAtomicData";
    public static final String GET_ASSOCIATION = "getAssociation";
    public static final String GET_DOC_LIST = "getDocumentList";
    public static final String REMOVE_DOC = "RemoveDocument";
    public static final String PNA_ENDPOINT = "PNA_EndPoint";
    public static final String PNA_USERNAME = "PNA_Username";
    public static final String PNA_PASSWORD = "PNA_Password";
    public static final String PNA_UN_ENDPOINT = "PNA_UpdateNominated_EndPoint";
    public static final String PNA_UA_ENDPOINT = "PNA_UpdateAuth_EndPoint";
    public static final String PNA_CA_ENDPOINT = "PNA_CreateAuthRep_EndPoint";
    public static final String PNA_AR_RESTRICT_ENDPOINT = "PNA_ARRestrict";
    public static final String PNA_OIM_DISABLE_ENDPOINT = "PNA_OIMDisable";
    public static final String PNA_OIM_DISABLE_USERNAME = "PNA_OIMDisable_Username";
    public static final String PNA_OIM_DISABLE_PASSWORD = "PNA_OIMDisable_Password";
    public static final String PNA_OES_AC_ENDPOINT = "PNA_AuthoriseRestrict_EndPoint";
    public static final String PNA_AUTH_USERNAME = "PNA_AUTH_USERNAME";
    public static final String PNA_AUTH_PWD = "PNA_AUTH_PWD";
    
    public static final String OSB_ENDPOINT = "AuditInsert_EndPoint";
    public static final String REMOVE_DOC_ENDPOINT = "RemoveDocument_EndPoint";
    public static final String UNREMOVE_DOC_ENDPOINT = "UnremoveDocument_EndPoint";
    public static final String SYNC_IHI_ENDPOINT = "SynchroniseIHI_EndPoint";
    public static final String OSB_USERNAME = "OSB_Username";
    public static final String OSB_PASSWORD = "OSB_Password";
    public static final String HTB_ENDPOINT = "PersistAtomicData_EndPoint";
    public static final String DEPR_ATOMIC_ENDPOINT = "DeprecateAtomicData_EndPoint";
    public static final String UPDATE_DOC_STAT_ENDPOINT = "UpdateDocumentStatus_EndPoint";
    public static final String GET_DOC_LIST_ENDPOINT = "GetDocumentList_EndPoint";    
    public static final String HTB_USERNAME = "HTB_Username";
    public static final String HTB_PASSWORD = "HTB_Password";
    public static final String SQ_VALUE = "sourceQueueValue"; 
    public static final String JMSCONFIG_PROP = "JMSConfig.properties"; 
}
