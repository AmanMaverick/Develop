
package au.pcehr.ws.pna.pd;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the au.pcehr.ws.pna.pd package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PDUpdateNominatedRepresentativeResponse_QNAME = new QName("http://pd.pna.ws.pcehr.au/", "PD_updateNominatedRepresentative_Response");
    private final static QName _PDUpdateNominatedRepresentativeRequest_QNAME = new QName("http://pd.pna.ws.pcehr.au/", "PD_updateNominatedRepresentative_Request");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: au.pcehr.ws.pna.pd
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PDUpdateNominatedRepresentativeRequest }
     * 
     */
    public PDUpdateNominatedRepresentativeRequest createPDUpdateNominatedRepresentativeRequest() {
        return new PDUpdateNominatedRepresentativeRequest();
    }

    /**
     * Create an instance of {@link PDUpdateNominatedRepresentativeResponse }
     * 
     */
    public PDUpdateNominatedRepresentativeResponse createPDUpdateNominatedRepresentativeResponse() {
        return new PDUpdateNominatedRepresentativeResponse();
    }

    /**
     * Create an instance of {@link UpdateNominatedRepresentativeParameterList }
     * 
     */
    public UpdateNominatedRepresentativeParameterList createUpdateNominatedRepresentativeParameterList() {
        return new UpdateNominatedRepresentativeParameterList();
    }

    /**
     * Create an instance of {@link UpdateNominatedRepresentativeFunctionParameters }
     * 
     */
    public UpdateNominatedRepresentativeFunctionParameters createUpdateNominatedRepresentativeFunctionParameters() {
        return new UpdateNominatedRepresentativeFunctionParameters();
    }

    /**
     * Create an instance of {@link UpdateNominatedRepresentativeCommonParameters }
     * 
     */
    public UpdateNominatedRepresentativeCommonParameters createUpdateNominatedRepresentativeCommonParameters() {
        return new UpdateNominatedRepresentativeCommonParameters();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PDUpdateNominatedRepresentativeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://pd.pna.ws.pcehr.au/", name = "PD_updateNominatedRepresentative_Response")
    public JAXBElement<PDUpdateNominatedRepresentativeResponse> createPDUpdateNominatedRepresentativeResponse(PDUpdateNominatedRepresentativeResponse value) {
        return new JAXBElement<PDUpdateNominatedRepresentativeResponse>(_PDUpdateNominatedRepresentativeResponse_QNAME, PDUpdateNominatedRepresentativeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PDUpdateNominatedRepresentativeRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://pd.pna.ws.pcehr.au/", name = "PD_updateNominatedRepresentative_Request")
    public JAXBElement<PDUpdateNominatedRepresentativeRequest> createPDUpdateNominatedRepresentativeRequest(PDUpdateNominatedRepresentativeRequest value) {
        return new JAXBElement<PDUpdateNominatedRepresentativeRequest>(_PDUpdateNominatedRepresentativeRequest_QNAME, PDUpdateNominatedRepresentativeRequest.class, null, value);
    }

}
