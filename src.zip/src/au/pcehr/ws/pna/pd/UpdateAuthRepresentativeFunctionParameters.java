
package au.pcehr.ws.pna.pd;

import au.pcehr.ws.pna.common.AuthRepRelationshipTypeID;
import au.pcehr.ws.pna.common.Authority;
import au.pcehr.ws.pna.common.ConsentAttributeList;
import au.pcehr.ws.pna.common.RelationshipStatus;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for UpdateAuthRepresentativeFunctionParameters complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="UpdateAuthRepresentativeFunctionParameters">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="relationshipType" type="{http://common.pna.ws.pcehr.au/}authRepRelationshipTypeID"/>
 *         &lt;element name="relationshipStatus" type="{http://common.pna.ws.pcehr.au/}relationshipStatus" minOccurs="0"/>
 *         &lt;element name="relationshipStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="relationshipEndedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="relationshipEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="relationshipEndedReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="authority" type="{http://common.pna.ws.pcehr.au/}authority" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="relationshipReviewedDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="consentAttributeListConsidered" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="consentAttributeList" type="{http://common.pna.ws.pcehr.au/}consentAttributeList" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateAuthRepresentativeFunctionParameters", propOrder = {
    "relationshipType",
    "relationshipStatus",
    "relationshipStartDate",
    "relationshipEndedBy",
    "relationshipEndDate",
    "relationshipEndedReason",
    "authority",
    "relationshipReviewedDate",
    "consentAttributeListConsidered",
    "consentAttributeList"
})
public class UpdateAuthRepresentativeFunctionParameters {

    @XmlElement(required = true)
    protected AuthRepRelationshipTypeID relationshipType;
    protected RelationshipStatus relationshipStatus;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar relationshipStartDate;
    protected String relationshipEndedBy;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar relationshipEndDate;
    protected String relationshipEndedReason;
    protected List<Authority> authority;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar relationshipReviewedDate;
    protected Boolean consentAttributeListConsidered;
    protected List<ConsentAttributeList> consentAttributeList;

    /**
     * Gets the value of the relationshipType property.
     * 
     * @return
     *     possible object is
     *     {@link AuthRepRelationshipTypeID }
     *     
     */
    public AuthRepRelationshipTypeID getRelationshipType() {
        return relationshipType;
    }

    /**
     * Sets the value of the relationshipType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuthRepRelationshipTypeID }
     *     
     */
    public void setRelationshipType(AuthRepRelationshipTypeID value) {
        this.relationshipType = value;
    }

    /**
     * Gets the value of the relationshipStatus property.
     * 
     * @return
     *     possible object is
     *     {@link RelationshipStatus }
     *     
     */
    public RelationshipStatus getRelationshipStatus() {
        return relationshipStatus;
    }

    /**
     * Sets the value of the relationshipStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link RelationshipStatus }
     *     
     */
    public void setRelationshipStatus(RelationshipStatus value) {
        this.relationshipStatus = value;
    }

    /**
     * Gets the value of the relationshipStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRelationshipStartDate() {
        return relationshipStartDate;
    }

    /**
     * Sets the value of the relationshipStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRelationshipStartDate(XMLGregorianCalendar value) {
        this.relationshipStartDate = value;
    }

    /**
     * Gets the value of the relationshipEndedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipEndedBy() {
        return relationshipEndedBy;
    }

    /**
     * Sets the value of the relationshipEndedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipEndedBy(String value) {
        this.relationshipEndedBy = value;
    }

    /**
     * Gets the value of the relationshipEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRelationshipEndDate() {
        return relationshipEndDate;
    }

    /**
     * Sets the value of the relationshipEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRelationshipEndDate(XMLGregorianCalendar value) {
        this.relationshipEndDate = value;
    }

    /**
     * Gets the value of the relationshipEndedReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipEndedReason() {
        return relationshipEndedReason;
    }

    /**
     * Sets the value of the relationshipEndedReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipEndedReason(String value) {
        this.relationshipEndedReason = value;
    }

    /**
     * Gets the value of the authority property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the authority property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthority().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Authority }
     * 
     * 
     */
    public List<Authority> getAuthority() {
        if (authority == null) {
            authority = new ArrayList<Authority>();
        }
        return this.authority;
    }

    /**
     * Gets the value of the relationshipReviewedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRelationshipReviewedDate() {
        return relationshipReviewedDate;
    }

    /**
     * Sets the value of the relationshipReviewedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRelationshipReviewedDate(XMLGregorianCalendar value) {
        this.relationshipReviewedDate = value;
    }

    /**
     * Gets the value of the consentAttributeListConsidered property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConsentAttributeListConsidered() {
        return consentAttributeListConsidered;
    }

    /**
     * Sets the value of the consentAttributeListConsidered property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConsentAttributeListConsidered(Boolean value) {
        this.consentAttributeListConsidered = value;
    }

    /**
     * Gets the value of the consentAttributeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the consentAttributeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConsentAttributeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ConsentAttributeList }
     * 
     * 
     */
    public List<ConsentAttributeList> getConsentAttributeList() {
        if (consentAttributeList == null) {
            consentAttributeList = new ArrayList<ConsentAttributeList>();
        }
        return this.consentAttributeList;
    }

}
