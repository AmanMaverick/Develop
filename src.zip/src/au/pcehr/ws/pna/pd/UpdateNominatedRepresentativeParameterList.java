
package au.pcehr.ws.pna.pd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateNominatedRepresentativeParameterList complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="updateNominatedRepresentativeParameterList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="commonParameter" type="{http://pd.pna.ws.pcehr.au/}updateNominatedRepresentativeCommonParameters"/>
 *         &lt;element name="funcationParameter" type="{http://pd.pna.ws.pcehr.au/}updateNominatedRepresentativeFunctionParameters"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateNominatedRepresentativeParameterList", propOrder = {
    "commonParameter",
    "funcationParameter"
})
public class UpdateNominatedRepresentativeParameterList {

    @XmlElement(required = true)
    protected UpdateNominatedRepresentativeCommonParameters commonParameter;
    @XmlElement(required = true)
    protected UpdateNominatedRepresentativeFunctionParameters funcationParameter;

    /**
     * Gets the value of the commonParameter property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateNominatedRepresentativeCommonParameters }
     *     
     */
    public UpdateNominatedRepresentativeCommonParameters getCommonParameter() {
        return commonParameter;
    }

    /**
     * Sets the value of the commonParameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateNominatedRepresentativeCommonParameters }
     *     
     */
    public void setCommonParameter(UpdateNominatedRepresentativeCommonParameters value) {
        this.commonParameter = value;
    }

    /**
     * Gets the value of the funcationParameter property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateNominatedRepresentativeFunctionParameters }
     *     
     */
    public UpdateNominatedRepresentativeFunctionParameters getFuncationParameter() {
        return funcationParameter;
    }

    /**
     * Sets the value of the funcationParameter property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateNominatedRepresentativeFunctionParameters }
     *     
     */
    public void setFuncationParameter(UpdateNominatedRepresentativeFunctionParameters value) {
        this.funcationParameter = value;
    }

}
