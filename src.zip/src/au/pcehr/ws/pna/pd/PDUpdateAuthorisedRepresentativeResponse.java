
package au.pcehr.ws.pna.pd;

import au.pcehr.ws.pna.common.ApplicationResponse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PD_updateAuthorisedRepresentative_Response complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="PD_updateAuthorisedRepresentative_Response">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="resultStatus" type="{http://common.pna.ws.pcehr.au/}applicationResponse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PD_updateAuthorisedRepresentative_Response", propOrder = {
    "resultStatus"
})
public class PDUpdateAuthorisedRepresentativeResponse {

    @XmlElement(required = true)
    protected ApplicationResponse resultStatus;

    /**
     * Gets the value of the resultStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationResponse }
     *     
     */
    public ApplicationResponse getResultStatus() {
        return resultStatus;
    }

    /**
     * Sets the value of the resultStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationResponse }
     *     
     */
    public void setResultStatus(ApplicationResponse value) {
        this.resultStatus = value;
    }

}
