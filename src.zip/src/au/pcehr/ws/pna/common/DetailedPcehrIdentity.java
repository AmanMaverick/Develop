
package au.pcehr.ws.pna.common;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailedPcehrIdentity complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="DetailedPcehrIdentity">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userID" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="identityTCAcceptionStatus" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="identityTCAcceptedDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="identityTCAcceptedVersion" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="IHI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/>
 *         &lt;element name="identityLastUpdatDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="identityStatus" type="{http://common.pna.ws.pcehr.au/}validIdentityStatus"/>
 *         &lt;element name="actionState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identityIndependentMinor" type="{http://common.pna.ws.pcehr.au/}validIdentityIndependentMinor"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailedPcehrIdentity", propOrder = {
    "userID",
    "identityTCAcceptionStatus",
    "identityTCAcceptedDate",
    "identityTCAcceptedVersion",
    "ihi",
    "identityLastUpdatDate",
    "identityStatus",
    "actionState",
    "identityIndependentMinor"
})
public class DetailedPcehrIdentity {

    @XmlElement(required = true)
    protected BigInteger userID;
    protected boolean identityTCAcceptionStatus;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar identityTCAcceptedDate;
    @XmlElement(required = true)
    protected BigInteger identityTCAcceptedVersion;
    @XmlElement(name = "IHI")
    @XmlSchemaType(name = "anyURI")
    protected String ihi;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar identityLastUpdatDate;
    @XmlElement(required = true)
    protected ValidIdentityStatus identityStatus;
    protected String actionState;
    @XmlElement(required = true)
    protected ValidIdentityIndependentMinor identityIndependentMinor;

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setUserID(BigInteger value) {
        this.userID = value;
    }

    /**
     * Gets the value of the identityTCAcceptionStatus property.
     * 
     */
    public boolean isIdentityTCAcceptionStatus() {
        return identityTCAcceptionStatus;
    }

    /**
     * Sets the value of the identityTCAcceptionStatus property.
     * 
     */
    public void setIdentityTCAcceptionStatus(boolean value) {
        this.identityTCAcceptionStatus = value;
    }

    /**
     * Gets the value of the identityTCAcceptedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIdentityTCAcceptedDate() {
        return identityTCAcceptedDate;
    }

    /**
     * Sets the value of the identityTCAcceptedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIdentityTCAcceptedDate(XMLGregorianCalendar value) {
        this.identityTCAcceptedDate = value;
    }

    /**
     * Gets the value of the identityTCAcceptedVersion property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getIdentityTCAcceptedVersion() {
        return identityTCAcceptedVersion;
    }

    /**
     * Sets the value of the identityTCAcceptedVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setIdentityTCAcceptedVersion(BigInteger value) {
        this.identityTCAcceptedVersion = value;
    }

    /**
     * Gets the value of the iHI property.
     *
     * @return
     * possible object is
     * {@link String}
     *
     */
    public String getIHI() {
        return ihi;
    }

    /**
     * Sets the value of the iHI property.
     *
     * @param value
     * allowed object is
     * {@link String}
     *
     */
    public void setIHI(String value) {
        this.ihi = value;
    }

    /**
     * Gets the value of the identityLastUpdatDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIdentityLastUpdatDate() {
        return identityLastUpdatDate;
    }

    /**
     * Sets the value of the identityLastUpdatDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIdentityLastUpdatDate(XMLGregorianCalendar value) {
        this.identityLastUpdatDate = value;
    }

    /**
     * Gets the value of the identityStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ValidIdentityStatus }
     *     
     */
    public ValidIdentityStatus getIdentityStatus() {
        return identityStatus;
    }

    /**
     * Sets the value of the identityStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValidIdentityStatus }
     *     
     */
    public void setIdentityStatus(ValidIdentityStatus value) {
        this.identityStatus = value;
    }

    /**
     * Gets the value of the actionState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionState() {
        return actionState;
    }

    /**
     * Sets the value of the actionState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionState(String value) {
        this.actionState = value;
    }

    /**
     * Gets the value of the identityIndependentMinor property.
     * 
     * @return
     *     possible object is
     *     {@link ValidIdentityIndependentMinor }
     *     
     */
    public ValidIdentityIndependentMinor getIdentityIndependentMinor() {
        return identityIndependentMinor;
    }

    /**
     * Sets the value of the identityIndependentMinor property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValidIdentityIndependentMinor }
     *     
     */
    public void setIdentityIndependentMinor(ValidIdentityIndependentMinor value) {
        this.identityIndependentMinor = value;
    }

}
