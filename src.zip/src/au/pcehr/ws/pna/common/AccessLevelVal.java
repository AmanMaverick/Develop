
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccessLevelVal.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccessLevelVal">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="General Access"/>
 *     &lt;enumeration value="Limited Access"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "AccessLevelVal")
@XmlEnum
public enum AccessLevelVal {

    @XmlEnumValue("General Access")
    GENERAL_ACCESS("General Access"),
    @XmlEnumValue("Limited Access")
    LIMITED_ACCESS("Limited Access");
    private final String value;

    AccessLevelVal(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AccessLevelVal fromValue(String v) {
        for (AccessLevelVal c: AccessLevelVal.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
