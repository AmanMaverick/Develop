
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for accessChangeEventID.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="accessChangeEventID">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Notified when a new organisation accesses the PCEHR Record"/>
 *     &lt;enumeration value="Notified when a new organisation has accessed their PCEHR by asserting Emergency Access"/>
 *     &lt;enumeration value="Notified when a New Shared Health Summary has been uploaded to their PCEHR"/>
 *     &lt;enumeration value="Notified when a Nominated Representative has accessed their PCEHR"/>
 *     &lt;enumeration value="PCEHR deactivation"/>
 *     &lt;enumeration value="Notified when a Portal account is linked to their PCEHR"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "accessChangeEventID")
@XmlEnum
public enum AccessChangeEventID {

    @XmlEnumValue("Notified when a new organisation accesses the PCEHR Record")
    NOTIFIED_WHEN_A_NEW_ORGANISATION_ACCESSES_THE_PCEHR_RECORD("Notified when a new organisation accesses the PCEHR Record"),
    @XmlEnumValue("Notified when a new organisation has accessed their PCEHR by asserting Emergency Access")
    NOTIFIED_WHEN_A_NEW_ORGANISATION_HAS_ACCESSED_THEIR_PCEHR_BY_ASSERTING_EMERGENCY_ACCESS("Notified when a new organisation has accessed their PCEHR by asserting Emergency Access"),
    @XmlEnumValue("Notified when a New Shared Health Summary has been uploaded to their PCEHR")
    NOTIFIED_WHEN_A_NEW_SHARED_HEALTH_SUMMARY_HAS_BEEN_UPLOADED_TO_THEIR_PCEHR("Notified when a New Shared Health Summary has been uploaded to their PCEHR"),
    @XmlEnumValue("Notified when a Nominated Representative has accessed their PCEHR")
    NOTIFIED_WHEN_A_NOMINATED_REPRESENTATIVE_HAS_ACCESSED_THEIR_PCEHR("Notified when a Nominated Representative has accessed their PCEHR"),
    @XmlEnumValue("PCEHR deactivation")
    PCEHR_DEACTIVATION("PCEHR deactivation"),
    @XmlEnumValue("Notified when a Portal account is linked to their PCEHR")
    NOTIFIED_WHEN_A_PORTAL_ACCOUNT_IS_LINKED_TO_THEIR_PCEHR("Notified when a Portal account is linked to their PCEHR");
    private final String value;

    AccessChangeEventID(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AccessChangeEventID fromValue(String v) {
        for (AccessChangeEventID c: AccessChangeEventID.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
