
package au.pcehr.ws.pna.common;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for consentAttributeList complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="consentAttributeList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consenterOnMedicareCard" type="{http://common.pna.ws.pcehr.au/}consenterOnMedicareCard"/>
 *         &lt;element name="consentTypeID" type="{http://common.pna.ws.pcehr.au/}consentTypeID"/>
 *         &lt;element name="consentGivenBy" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="consentGivenDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="consentStatus" type="{http://common.pna.ws.pcehr.au/}consentStatus"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "consentAttributeList", propOrder = {
    "consenterOnMedicareCard",
    "consentTypeID",
    "consentGivenBy",
    "consentGivenDate",
    "consentStatus"
})
public class ConsentAttributeList {

    @XmlElement(required = true)
    protected ConsenterOnMedicareCard consenterOnMedicareCard;
    @XmlElement(required = true)
    protected ConsentTypeID consentTypeID;
    @XmlElement(required = true)
    protected BigInteger consentGivenBy;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar consentGivenDate;
    @XmlElement(required = true)
    protected ConsentStatus consentStatus;

    /**
     * Gets the value of the consenterOnMedicareCard property.
     * 
     * @return
     *     possible object is
     *     {@link ConsenterOnMedicareCard }
     *     
     */
    public ConsenterOnMedicareCard getConsenterOnMedicareCard() {
        return consenterOnMedicareCard;
    }

    /**
     * Sets the value of the consenterOnMedicareCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsenterOnMedicareCard }
     *     
     */
    public void setConsenterOnMedicareCard(ConsenterOnMedicareCard value) {
        this.consenterOnMedicareCard = value;
    }

    /**
     * Gets the value of the consentTypeID property.
     * 
     * @return
     *     possible object is
     *     {@link ConsentTypeID }
     *     
     */
    public ConsentTypeID getConsentTypeID() {
        return consentTypeID;
    }

    /**
     * Sets the value of the consentTypeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsentTypeID }
     *     
     */
    public void setConsentTypeID(ConsentTypeID value) {
        this.consentTypeID = value;
    }

    /**
     * Gets the value of the consentGivenBy property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getConsentGivenBy() {
        return consentGivenBy;
    }

    /**
     * Sets the value of the consentGivenBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setConsentGivenBy(BigInteger value) {
        this.consentGivenBy = value;
    }

    /**
     * Gets the value of the consentGivenDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getConsentGivenDate() {
        return consentGivenDate;
    }

    /**
     * Sets the value of the consentGivenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setConsentGivenDate(XMLGregorianCalendar value) {
        this.consentGivenDate = value;
    }

    /**
     * Gets the value of the consentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ConsentStatus }
     *     
     */
    public ConsentStatus getConsentStatus() {
        return consentStatus;
    }

    /**
     * Sets the value of the consentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsentStatus }
     *     
     */
    public void setConsentStatus(ConsentStatus value) {
        this.consentStatus = value;
    }

}
