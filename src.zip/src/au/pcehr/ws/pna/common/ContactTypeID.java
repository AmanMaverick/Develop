
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for contactTypeID.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="contactTypeID">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EMERGENCY CONTACT"/>
 *     &lt;enumeration value="NEXT OF KIN"/>
 *     &lt;enumeration value="CARER"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "contactTypeID")
@XmlEnum
public enum ContactTypeID {

    @XmlEnumValue("EMERGENCY CONTACT")
    EMERGENCY_CONTACT("EMERGENCY CONTACT"),
    @XmlEnumValue("NEXT OF KIN")
    NEXT_OF_KIN("NEXT OF KIN"),
    CARER("CARER");
    private final String value;

    ContactTypeID(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ContactTypeID fromValue(String v) {
        for (ContactTypeID c: ContactTypeID.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
