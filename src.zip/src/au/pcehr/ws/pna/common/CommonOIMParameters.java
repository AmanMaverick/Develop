
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for commonOIMParameters complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="commonOIMParameters">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="transactionID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sourceSystemID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="mbun" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pcehrIdentity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "commonOIMParameters", propOrder = {
    "transactionID",
    "sourceSystemID",
    "mbun",
    "systemName",
    "pcehrIdentity"
})
public class CommonOIMParameters {

    @XmlElement(required = true)
    protected String transactionID;
    @XmlElement(required = true)
    protected String sourceSystemID;
    @XmlElement(required = true)
    protected String mbun;
    @XmlElement(required = true)
    protected String systemName;
    @XmlElement(required = true)
    protected String pcehrIdentity;

    /**
     * Gets the value of the transactionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionID() {
        return transactionID;
    }

    /**
     * Sets the value of the transactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionID(String value) {
        this.transactionID = value;
    }

    /**
     * Gets the value of the sourceSystemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceSystemID() {
        return sourceSystemID;
    }

    /**
     * Sets the value of the sourceSystemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceSystemID(String value) {
        this.sourceSystemID = value;
    }

    /**
     * Gets the value of the mbun property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMbun() {
        return mbun;
    }

    /**
     * Sets the value of the mbun property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMbun(String value) {
        this.mbun = value;
    }

    /**
     * Gets the value of the systemName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemName() {
        return systemName;
    }

    /**
     * Sets the value of the systemName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemName(String value) {
        this.systemName = value;
    }

    /**
     * Gets the value of the pcehrIdentity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPcehrIdentity() {
        return pcehrIdentity;
    }

    /**
     * Sets the value of the pcehrIdentity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPcehrIdentity(String value) {
        this.pcehrIdentity = value;
    }

}
