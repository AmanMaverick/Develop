
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccessTypeVal.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccessTypeVal">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Provider Access"/>
 *     &lt;enumeration value="Emergency Access"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "AccessTypeVal")
@XmlEnum
public enum AccessTypeVal {

    @XmlEnumValue("Provider Access")
    PROVIDER_ACCESS("Provider Access"),
    @XmlEnumValue("Emergency Access")
    EMERGENCY_ACCESS("Emergency Access");
    private final String value;

    AccessTypeVal(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AccessTypeVal fromValue(String v) {
        for (AccessTypeVal c: AccessTypeVal.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
