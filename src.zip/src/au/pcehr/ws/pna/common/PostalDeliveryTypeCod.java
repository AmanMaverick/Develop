
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for postalDeliveryTypeCod.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="postalDeliveryTypeCod">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Care PO"/>
 *     &lt;enumeration value="CMA"/>
 *     &lt;enumeration value="CMB"/>
 *     &lt;enumeration value="GPO Box"/>
 *     &lt;enumeration value="Locked Bag"/>
 *     &lt;enumeration value="MS"/>
 *     &lt;enumeration value="PO Box"/>
 *     &lt;enumeration value="POR"/>
 *     &lt;enumeration value="Private Bag"/>
 *     &lt;enumeration value="RSD"/>
 *     &lt;enumeration value="RMB"/>
 *     &lt;enumeration value="RMS"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "postalDeliveryTypeCod")
@XmlEnum
public enum PostalDeliveryTypeCod {

    @XmlEnumValue("Care PO")
    CARE_PO("Care PO"),
    CMA("CMA"),
    CMB("CMB"),
    @XmlEnumValue("GPO Box")
    GPO_BOX("GPO Box"),
    @XmlEnumValue("Locked Bag")
    LOCKED_BAG("Locked Bag"),
    MS("MS"),
    @XmlEnumValue("PO Box")
    PO_BOX("PO Box"),
    POR("POR"),
    @XmlEnumValue("Private Bag")
    PRIVATE_BAG("Private Bag"),
    RSD("RSD"),
    RMB("RMB"),
    RMS("RMS");
    private final String value;

    PostalDeliveryTypeCod(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PostalDeliveryTypeCod fromValue(String v) {
        for (PostalDeliveryTypeCod c: PostalDeliveryTypeCod.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
