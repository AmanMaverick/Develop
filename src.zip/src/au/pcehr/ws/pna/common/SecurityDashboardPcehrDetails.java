
package au.pcehr.ws.pna.common;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for securityDashboardPcehrDetails complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="securityDashboardPcehrDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recordSearchable" type="{http://common.pna.ws.pcehr.au/}recordSearchable" minOccurs="0"/>
 *         &lt;element name="pacc" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;minLength value="4"/>
 *               &lt;maxLength value="8"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="paccx" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;minLength value="4"/>
 *               &lt;maxLength value="8"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="recordId" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "securityDashboardPcehrDetails", propOrder = {
    "recordSearchable",
    "pacc",
    "paccx",
    "recordId"
})
public class SecurityDashboardPcehrDetails {

    protected RecordSearchable recordSearchable;
    protected String pacc;
    protected String paccx;
    @XmlElement(required = true)
    protected BigInteger recordId;

    /**
     * Gets the value of the recordSearchable property.
     * 
     * @return
     *     possible object is
     *     {@link RecordSearchable }
     *     
     */
    public RecordSearchable getRecordSearchable() {
        return recordSearchable;
    }

    /**
     * Sets the value of the recordSearchable property.
     * 
     * @param value
     *     allowed object is
     *     {@link RecordSearchable }
     *     
     */
    public void setRecordSearchable(RecordSearchable value) {
        this.recordSearchable = value;
    }

    /**
     * Gets the value of the pacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPacc() {
        return pacc;
    }

    /**
     * Sets the value of the pacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPacc(String value) {
        this.pacc = value;
    }

    /**
     * Gets the value of the paccx property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaccx() {
        return paccx;
    }

    /**
     * Sets the value of the paccx property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaccx(String value) {
        this.paccx = value;
    }

    /**
     * Gets the value of the recordId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRecordId() {
        return recordId;
    }

    /**
     * Sets the value of the recordId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRecordId(BigInteger value) {
        this.recordId = value;
    }

}
