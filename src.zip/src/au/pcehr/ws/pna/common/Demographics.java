
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for demographics complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="demographics">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="name" type="{http://common.pna.ws.pcehr.au/}name" minOccurs="0"/>
 *         &lt;element name="dob" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateOfBirthAccuracyIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sex" type="{http://common.pna.ws.pcehr.au/}sex" minOccurs="0"/>
 *         &lt;element name="medicareCardNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dvaNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indigenousStatus" type="{http://common.pna.ws.pcehr.au/}IndigenousStatus" minOccurs="0"/>
 *         &lt;element name="address" type="{http://common.pna.ws.pcehr.au/}address" minOccurs="0"/>
 *         &lt;element name="ihiStatus" type="{http://common.pna.ws.pcehr.au/}IHIStatusVal" minOccurs="0"/>
 *         &lt;element name="ihiRecordStatus" type="{http://common.pna.ws.pcehr.au/}IHIRecordStatusVal" minOccurs="0"/>
 *         &lt;element name="lastUpdatedDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="homePhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mobilePhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "demographics", propOrder = {
    "name",
    "dob",
    "dateOfBirthAccuracyIndicator",
    "sex",
    "medicareCardNumber",
    "dvaNumber",
    "indigenousStatus",
    "veteranAndADFStatus",
    "address",
    "ihiStatus",
    "ihiRecordStatus",
    "lastUpdatedDate",
    "homePhoneNumber",
    "mobilePhoneNumber",
    "emailAddress",
    "generalContactNumber"
})
public class Demographics {

    protected Name name;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dob;
    protected String dateOfBirthAccuracyIndicator;
    protected Sex sex;
    protected String medicareCardNumber;
    protected String dvaNumber;
    protected IndigenousStatus indigenousStatus;
    protected Address address;
    protected IHIStatusVal ihiStatus;
    protected IHIRecordStatusVal ihiRecordStatus;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastUpdatedDate;
    protected String homePhoneNumber;
    protected String mobilePhoneNumber;
    protected String emailAddress;
    protected String generalContactNumber;
    protected String veteranAndADFStatus;

    /**
     * Gets the value of the name property.
     *
     * @return
     *     possible object is
     *     {@link Name }
     *
     */
    public Name getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link Name }
     *     
     */
    public void setName(Name value) {
        this.name = value;
    }

    /**
     * Gets the value of the dob property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDob() {
        return dob;
    }

    /**
     * Sets the value of the dob property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDob(XMLGregorianCalendar value) {
        this.dob = value;
    }

    /**
     * Gets the value of the dateOfBirthAccuracyIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfBirthAccuracyIndicator() {
        return dateOfBirthAccuracyIndicator;
    }

    /**
     * Sets the value of the dateOfBirthAccuracyIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfBirthAccuracyIndicator(String value) {
        this.dateOfBirthAccuracyIndicator = value;
    }

    /**
     * Gets the value of the sex property.
     * 
     * @return
     *     possible object is
     *     {@link Sex }
     *     
     */
    public Sex getSex() {
        return sex;
    }

    /**
     * Sets the value of the sex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Sex }
     *     
     */
    public void setSex(Sex value) {
        this.sex = value;
    }

    /**
     * Gets the value of the medicareCardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareCardNumber() {
        return medicareCardNumber;
    }

    /**
     * Sets the value of the medicareCardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareCardNumber(String value) {
        this.medicareCardNumber = value;
    }

    /**
     * Gets the value of the dvaNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDvaNumber() {
        return dvaNumber;
    }

    /**
     * Sets the value of the dvaNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDvaNumber(String value) {
        this.dvaNumber = value;
    }

    /**
     * Gets the value of the indigenousStatus property.
     * 
     * @return
     *     possible object is
     *     {@link IndigenousStatus }
     *     
     */
    public IndigenousStatus getIndigenousStatus() {
        return indigenousStatus;
    }

    /**
     * Sets the value of the indigenousStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link IndigenousStatus }
     *     
     */
    public void setIndigenousStatus(IndigenousStatus value) {
        this.indigenousStatus = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setAddress(Address value) {
        this.address = value;
    }

    /**
     * Gets the value of the ihiStatus property.
     * 
     * @return
     *     possible object is
     *     {@link IHIStatusVal }
     *     
     */
    public IHIStatusVal getIhiStatus() {
        return ihiStatus;
    }

    /**
     * Sets the value of the ihiStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link IHIStatusVal }
     *     
     */
    public void setIhiStatus(IHIStatusVal value) {
        this.ihiStatus = value;
    }

    /**
     * Gets the value of the ihiRecordStatus property.
     * 
     * @return
     *     possible object is
     *     {@link IHIRecordStatusVal }
     *     
     */
    public IHIRecordStatusVal getIhiRecordStatus() {
        return ihiRecordStatus;
    }

    /**
     * Sets the value of the ihiRecordStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link IHIRecordStatusVal }
     *     
     */
    public void setIhiRecordStatus(IHIRecordStatusVal value) {
        this.ihiRecordStatus = value;
    }

    /**
     * Gets the value of the lastUpdatedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    /**
     * Sets the value of the lastUpdatedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdatedDate(XMLGregorianCalendar value) {
        this.lastUpdatedDate = value;
    }

    /**
     * Gets the value of the homePhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }

    /**
     * Sets the value of the homePhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePhoneNumber(String value) {
        this.homePhoneNumber = value;
    }

    /**
     * Gets the value of the mobilePhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    /**
     * Sets the value of the mobilePhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobilePhoneNumber(String value) {
        this.mobilePhoneNumber = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the generalContactNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getGeneralContactNumber() {
        return generalContactNumber;
    }

    /**
     * Gets the value of the veteranAndADFStatus property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getVeteranAndADFStatus() {
        return veteranAndADFStatus;
    }

    /**
     * Sets the value of the generalContactNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setGeneralContactNumber(String value) {
        this.generalContactNumber = value;
    }

    /**
     * Sets the value of the veteranAndADFStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setVeteranAndADFStatus(String value) {
        this.veteranAndADFStatus = value;
    }

}
