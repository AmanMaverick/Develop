
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for securityDashboardOrgList complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="securityDashboardOrgList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="relationshipParty" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accessID" type="{http://common.pna.ws.pcehr.au/}AccessType"/>
 *         &lt;element name="relationshipDocAccessLevel" type="{http://common.pna.ws.pcehr.au/}relationshipDocAccessLevel"/>
 *         &lt;element name="organisationName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "securityDashboardOrgList", propOrder = {
    "relationshipParty",
    "accessID",
    "relationshipDocAccessLevel",
    "organisationName"
})
public class SecurityDashboardOrgList {

    @XmlElement(required = true)
    protected String relationshipParty;
    @XmlElement(required = true)
    protected AccessType accessID;
    @XmlElement(required = true)
    protected RelationshipDocAccessLevel relationshipDocAccessLevel;
    @XmlElement(required = true)
    protected String organisationName;

    /**
     * Gets the value of the relationshipParty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipParty() {
        return relationshipParty;
    }

    /**
     * Sets the value of the relationshipParty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipParty(String value) {
        this.relationshipParty = value;
    }

    /**
     * Gets the value of the accessID property.
     * 
     * @return
     *     possible object is
     *     {@link AccessType }
     *     
     */
    public AccessType getAccessID() {
        return accessID;
    }

    /**
     * Sets the value of the accessID property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccessType }
     *     
     */
    public void setAccessID(AccessType value) {
        this.accessID = value;
    }

    /**
     * Gets the value of the relationshipDocAccessLevel property.
     * 
     * @return
     *     possible object is
     *     {@link RelationshipDocAccessLevel }
     *     
     */
    public RelationshipDocAccessLevel getRelationshipDocAccessLevel() {
        return relationshipDocAccessLevel;
    }

    /**
     * Sets the value of the relationshipDocAccessLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link RelationshipDocAccessLevel }
     *     
     */
    public void setRelationshipDocAccessLevel(RelationshipDocAccessLevel value) {
        this.relationshipDocAccessLevel = value;
    }

    /**
     * Gets the value of the organisationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganisationName() {
        return organisationName;
    }

    /**
     * Sets the value of the organisationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganisationName(String value) {
        this.organisationName = value;
    }

}
