
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ecnAttributeList complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="ecnAttributeList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="contactTypeID" type="{http://common.pna.ws.pcehr.au/}contactTypeID"/>
 *         &lt;element name="contactName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="contactNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contactEmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contactRelationship" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ecnAttributeList", propOrder = {
    "contactTypeID",
    "contactName",
    "contactNumber",
    "contactEmailAddress",
    "contactRelationship"
})
public class EcnAttributeList {

    @XmlElement(required = true)
    protected ContactTypeID contactTypeID;
    @XmlElement(required = true)
    protected String contactName;
    protected String contactNumber;
    protected String contactEmailAddress;
    @XmlElement(required = true)
    protected String contactRelationship;

    /**
     * Gets the value of the contactTypeID property.
     * 
     * @return
     *     possible object is
     *     {@link ContactTypeID }
     *     
     */
    public ContactTypeID getContactTypeID() {
        return contactTypeID;
    }

    /**
     * Sets the value of the contactTypeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactTypeID }
     *     
     */
    public void setContactTypeID(ContactTypeID value) {
        this.contactTypeID = value;
    }

    /**
     * Gets the value of the contactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets the value of the contactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactName(String value) {
        this.contactName = value;
    }

    /**
     * Gets the value of the contactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * Sets the value of the contactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactNumber(String value) {
        this.contactNumber = value;
    }

    /**
     * Gets the value of the contactEmailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactEmailAddress() {
        return contactEmailAddress;
    }

    /**
     * Sets the value of the contactEmailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactEmailAddress(String value) {
        this.contactEmailAddress = value;
    }

    /**
     * Gets the value of the contactRelationship property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactRelationship() {
        return contactRelationship;
    }

    /**
     * Sets the value of the contactRelationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactRelationship(String value) {
        this.contactRelationship = value;
    }

}
