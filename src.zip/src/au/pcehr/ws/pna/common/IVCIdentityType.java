
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IVCIdentityType.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="IVCIdentityType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="New"/>
 *     &lt;enumeration value="Existing"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "IVCIdentityType")
@XmlEnum
public enum IVCIdentityType {

    @XmlEnumValue("New")
    NEW("New"),
    @XmlEnumValue("Existing")
    EXISTING("Existing");
    private final String value;

    IVCIdentityType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static IVCIdentityType fromValue(String v) {
        for (IVCIdentityType c: IVCIdentityType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
