
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for streetSuffixCode.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="streetSuffixCode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CN"/>
 *     &lt;enumeration value="E"/>
 *     &lt;enumeration value="EX"/>
 *     &lt;enumeration value="LR"/>
 *     &lt;enumeration value="N"/>
 *     &lt;enumeration value="NE"/>
 *     &lt;enumeration value="NW"/>
 *     &lt;enumeration value="S"/>
 *     &lt;enumeration value="SE"/>
 *     &lt;enumeration value="SW"/>
 *     &lt;enumeration value="UP"/>
 *     &lt;enumeration value="W"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "streetSuffixCode")
@XmlEnum
public enum StreetSuffixCode {

    CN,
    E,
    EX,
    LR,
    N,
    NE,
    NW,
    S,
    SE,
    SW,
    UP,
    W;

    public String value() {
        return name();
    }

    public static StreetSuffixCode fromValue(String v) {
        return valueOf(v);
    }

}
