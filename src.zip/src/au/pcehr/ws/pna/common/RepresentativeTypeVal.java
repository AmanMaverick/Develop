
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RepresentativeTypeVal.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="RepresentativeTypeVal">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Authorised Representative"/>
 *     &lt;enumeration value="Nominated Representative"/>
 *     &lt;enumeration value="Parent"/>
 *     &lt;enumeration value="Guardian"/>
 *     &lt;enumeration value="Legally Appointed Authorised Representative"/>
 *     &lt;enumeration value="Full Access Nominated Representative"/>
 *     &lt;enumeration value="Under 18 - Parental Responsibility"/>
 *     &lt;enumeration value="Under 18 - Legal Authority"/>
 *     &lt;enumeration value="Under 18 - Otherwise Appropriate Person"/>
 *     &lt;enumeration value="18 and Over - Legal Authority"/>
 *     &lt;enumeration value="18 and Over - Otherwise Appropriate Person"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "RepresentativeTypeVal")
@XmlEnum
public enum RepresentativeTypeVal {

    @XmlEnumValue("Authorised Representative")
    AUTHORISED_REPRESENTATIVE("Authorised Representative"),
    @XmlEnumValue("Nominated Representative")
    NOMINATED_REPRESENTATIVE("Nominated Representative"),
    @XmlEnumValue("Parent")
    PARENT("Parent"),
    @XmlEnumValue("Guardian")
    GUARDIAN("Guardian"),
    @XmlEnumValue("Legally Appointed Authorised Representative")
    LEGALLY_APPOINTED_AUTHORISED_REPRESENTATIVE("Legally Appointed Authorised Representative"),
    @XmlEnumValue("Full Access Nominated Representative")
    FULL_ACCESS_NOMINATED_REPRESENTATIVE("Full Access Nominated Representative"),
    @XmlEnumValue("Under 18 - Parental Responsibility")
    UNDER_18_PARENTAL_RESPONSIBILITY("Under 18 - Parental Responsibility"),
    @XmlEnumValue("Under 18 - Legal Authority")
    UNDER_18_LEGAL_AUTHORITY("Under 18 - Legal Authority"),
    @XmlEnumValue("Under 18 - Otherwise Appropriate Person")
    UNDER_18_OTHERWISE_APPROPRIATE_PERSON("Under 18 - Otherwise Appropriate Person"),
    @XmlEnumValue("18 and Over - Legal Authority")
    EIGHTEEN_AND_OVER_LEGAL_AUTHORITY("18 and Over - Legal Authority"),
    @XmlEnumValue("18 and Over - Otherwise Appropriate Person")
    EIGHTEEN_AND_OVER_OTHERWISE_APPROPRIATE_PERSON("18 and Over - Otherwise Appropriate Person");
    private final String value;

    RepresentativeTypeVal(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RepresentativeTypeVal fromValue(String v) {
        for (RepresentativeTypeVal c: RepresentativeTypeVal.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
