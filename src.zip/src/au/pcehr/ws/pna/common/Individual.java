
package au.pcehr.ws.pna.common;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Individual complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="Individual">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="number" type="{http://www.w3.org/2001/XMLSchema}anyURI"/>
 *         &lt;element name="medicareCardNumber" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="medicareCardIRN" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="dvaFileNumber" type="{http://www.w3.org/2001/XMLSchema}token" minOccurs="0"/>
 *         &lt;element name="IHIRecordStatus" type="{http://common.pna.ws.pcehr.au/}IHIRecordStatusVal"/>
 *         &lt;element name="IHIStatus" type="{http://common.pna.ws.pcehr.au/}IHIStatusVal"/>
 *         &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="sex" type="{http://common.pna.ws.pcehr.au/}sex"/>
 *         &lt;element name="Name" type="{http://common.pna.ws.pcehr.au/}name"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Individual", propOrder = {
    "number",
    "medicareCardNumber",
    "medicareCardIRN",
    "dvaFileNumber",
    "ihiRecordStatus",
    "ihiStatus",
    "dateOfBirth",
    "sex",
    "name",
    "veteranAndADFStatus",
    "indigenousStatus"
})
public class Individual {

    @XmlElement(required = true)
    @XmlSchemaType(name = "anyURI")
    protected String number;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String medicareCardNumber;
    protected BigInteger medicareCardIRN;
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "token")
    protected String dvaFileNumber;
    @XmlElement(name = "IHIRecordStatus", required = true)
    protected IHIRecordStatusVal ihiRecordStatus;
    @XmlElement(name = "IHIStatus", required = true)
    protected IHIStatusVal ihiStatus;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfBirth;
    @XmlElement(required = true)
    protected Sex sex;
    @XmlElement(name = "Name", required = true)
    protected Name name;
    protected IndigenousStatus indigenousStatus;
    protected String veteranAndADFStatus;

    /**
     * Gets the value of the number property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber(String value) {
        this.number = value;
    }

    /**
     * Gets the value of the medicareCardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareCardNumber() {
        return medicareCardNumber;
    }

    /**
     * Sets the value of the medicareCardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareCardNumber(String value) {
        this.medicareCardNumber = value;
    }

    /**
     * Gets the value of the medicareCardIRN property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMedicareCardIRN() {
        return medicareCardIRN;
    }

    /**
     * Sets the value of the medicareCardIRN property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMedicareCardIRN(BigInteger value) {
        this.medicareCardIRN = value;
    }

    /**
     * Gets the value of the dvaFileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDvaFileNumber() {
        return dvaFileNumber;
    }

    /**
     * Sets the value of the dvaFileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDvaFileNumber(String value) {
        this.dvaFileNumber = value;
    }

    /**
     * Gets the value of the ihiRecordStatus property.
     * 
     * @return
     *     possible object is
     *     {@link IHIRecordStatusVal }
     *     
     */
    public IHIRecordStatusVal getIHIRecordStatus() {
        return ihiRecordStatus;
    }

    /**
     * Sets the value of the ihiRecordStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link IHIRecordStatusVal }
     *     
     */
    public void setIHIRecordStatus(IHIRecordStatusVal value) {
        this.ihiRecordStatus = value;
    }

    /**
     * Gets the value of the ihiStatus property.
     * 
     * @return
     *     possible object is
     *     {@link IHIStatusVal }
     *     
     */
    public IHIStatusVal getIHIStatus() {
        return ihiStatus;
    }

    /**
     * Sets the value of the ihiStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link IHIStatusVal }
     *     
     */
    public void setIHIStatus(IHIStatusVal value) {
        this.ihiStatus = value;
    }

    /**
     * Gets the value of the dateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Sets the value of the dateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfBirth(XMLGregorianCalendar value) {
        this.dateOfBirth = value;
    }

    /**
     * Gets the value of the sex property.
     * 
     * @return
     *     possible object is
     *     {@link Sex }
     *     
     */
    public Sex getSex() {
        return sex;
    }

    /**
     * Sets the value of the sex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Sex }
     *     
     */
    public void setSex(Sex value) {
        this.sex = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link Name }
     *     
     */
    public Name getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link Name }
     *     
     */
    public void setName(Name value) {
        this.name = value;
    }

    /**
     * Gets the value of the indigenousStatus property.
     *
     * @return
     *     possible object is
     *     {@link IndigenousStatus }
     *
     */
    public IndigenousStatus getIndigenousStatus() {
        return indigenousStatus;
    }

    /**
     * Gets the value of the veteranAndADFStatus property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getVeteranAndADFStatus() {
        return veteranAndADFStatus;
    }

    /**
     * Sets the value of the indigenousStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link IndigenousStatus }
     *
     */
    public void setIndigenousStatus(IndigenousStatus value) {
        this.indigenousStatus = value;
    }

    /**
     * Sets the value of the veteranAndADFStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setVeteranAndADFStatus(String value) {
        this.veteranAndADFStatus = value;
    }

}
