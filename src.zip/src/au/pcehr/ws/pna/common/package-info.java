@javax.xml.bind.annotation.XmlSchema(namespace = "http://common.pna.ws.pcehr.au/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package au.pcehr.ws.pna.common;

