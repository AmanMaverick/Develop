
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for consentStatus.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="consentStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CONSENT NOT GIVEN"/>
 *     &lt;enumeration value="CONSENT GIVEN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "consentStatus")
@XmlEnum
public enum ConsentStatus {

    @XmlEnumValue("CONSENT NOT GIVEN")
    CONSENT_NOT_GIVEN("CONSENT NOT GIVEN"),
    @XmlEnumValue("CONSENT GIVEN")
    CONSENT_GIVEN("CONSENT GIVEN");
    private final String value;

    ConsentStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ConsentStatus fromValue(String v) {
        for (ConsentStatus c: ConsentStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
