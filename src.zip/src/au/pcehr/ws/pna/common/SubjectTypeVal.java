
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SubjectTypeVal.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SubjectTypeVal">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="HPI-O"/>
 *     &lt;enumeration value="PCEHR Identity"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "SubjectTypeVal")
@XmlEnum
public enum SubjectTypeVal {

    @XmlEnumValue("HPI-O")
    HPI_O("HPI-O"),
    @XmlEnumValue("PCEHR Identity")
    PCEHR_IDENTITY("PCEHR Identity");
    private final String value;

    SubjectTypeVal(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SubjectTypeVal fromValue(String v) {
        for (SubjectTypeVal c: SubjectTypeVal.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
