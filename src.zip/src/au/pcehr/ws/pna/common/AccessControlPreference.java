
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for accessControlPreference.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="accessControlPreference">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="BASIC ACCESS CONTROL SETTINGS"/>
 *     &lt;enumeration value="ADVANCE ACCESS CONTROL SETTINGS"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "accessControlPreference")
@XmlEnum
public enum AccessControlPreference {

    @XmlEnumValue("BASIC ACCESS CONTROL SETTINGS")
    BASIC_ACCESS_CONTROL_SETTINGS("BASIC ACCESS CONTROL SETTINGS"),
    @XmlEnumValue("ADVANCE ACCESS CONTROL SETTINGS")
    ADVANCE_ACCESS_CONTROL_SETTINGS("ADVANCE ACCESS CONTROL SETTINGS");
    private final String value;

    AccessControlPreference(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AccessControlPreference fromValue(String v) {
        for (AccessControlPreference c: AccessControlPreference.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
