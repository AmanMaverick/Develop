
package au.pcehr.ws.pna.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for relationshipDocAccessLevel.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="relationshipDocAccessLevel">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="General"/>
 *     &lt;enumeration value="Limited"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 */
@XmlType(name = "relationshipDocAccessLevel")
@XmlEnum
public enum RelationshipDocAccessLevel {

    @XmlEnumValue("General")
    GENERAL("General"),
    @XmlEnumValue("Limited")
    LIMITED("Limited");
    private final String value;

    RelationshipDocAccessLevel(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static RelationshipDocAccessLevel fromValue(String v) {
        for (RelationshipDocAccessLevel c: RelationshipDocAccessLevel.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
