package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepBO;
import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepClientResBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.ws.pna.common.ApplicationResponse;
import au.pcehr.ws.pna.common.AuthRepRelationshipTypeID;
import au.pcehr.ws.pna.common.Authority;
import au.pcehr.ws.pna.pd.CreateAuthRepFunctionParameter;
import au.pcehr.ws.pna.pd.CreateAuthRepcommonParameters;
import au.pcehr.ws.pna.pd.CreateAuthRepparameterList;
import au.pcehr.ws.pna.pd.PDCreateAuthorisedRepresentativeRequest;
import au.pcehr.ws.pna.pd.PDCreateAuthorisedRepresentativeResponse;
import au.pcehr.ws.pna.pd.PNAPCEHRCreateAuthorisedRepresentative;
import au.pcehr.ws.pna.pd.PNAPCEHRCreateAuthorisedRepresentativeWS;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.math.BigInteger;

import java.util.GregorianCalendar;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pcehr.recovery.UtilConstants;

@Service
public class ReactivateAuthRep {
    private static Logger LOG = Logger.getLogger(ReactivateAuthRep.class);
   
    @Autowired
    Decrypter decrypter;
    
    @Autowired
    private SOAPMessageUtil soapMessageUtil;
        
    @Autowired
    TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    
  
    /**
     *
     * @param myProp
     * @param RecordID
     * @param userID
     * @param created_by
     * @param rel_type
     * @param auth_type
     * @param auth_issue
     * @param auth_startdate
     * @param docType
     * @param transactionID
     * @param sourceSystemID
     * @return String
     */
    public final ReactivateAuthRepClientResBO create(ReactivateAuthRepBO reactivateAuthRepBO) {
        try{
            ReactivateAuthRepClientResBO reactivateAuthRepClientResBO = new ReactivateAuthRepClientResBO(); 
        PNAPCEHRCreateAuthorisedRepresentativeWS pNAPCEHRCreateAuthorisedRepresentativeWS = new PNAPCEHRCreateAuthorisedRepresentativeWS();
        pNAPCEHRCreateAuthorisedRepresentativeWS.setHandlerResolver(wSClientHandlerResolver);
        PNAPCEHRCreateAuthorisedRepresentative pNAPCEHRCreateAuthorisedRepresentative =
            pNAPCEHRCreateAuthorisedRepresentativeWS.getPNAPCEHRCreateAuthorisedRepresentativePort();
        Map<String, Object> requestContext =
            ((BindingProvider) pNAPCEHRCreateAuthorisedRepresentative).getRequestContext();
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,EndPointsConstants.PNA_CA_ENDPOINT);
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
        requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_USERNAME));
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_PASSWORD));         
        

        PDCreateAuthorisedRepresentativeRequest pDCreateAuthorisedRepresentativeRequest =
            new PDCreateAuthorisedRepresentativeRequest();
        CreateAuthRepparameterList createAuthRepparameterList = new CreateAuthRepparameterList();
        
        createAuthRepparameterList.setCommonParameters(createCommonParameters(reactivateAuthRepBO));
        createAuthRepparameterList.setFunctionParameters(createFunctionParameter(reactivateAuthRepBO));
        
        pDCreateAuthorisedRepresentativeRequest.setParameterList(createAuthRepparameterList);
        PDCreateAuthorisedRepresentativeResponse pDCreateAuthorisedRepresentativeResponse = pNAPCEHRCreateAuthorisedRepresentative.pdCreateAuthorisedRepresentative(pDCreateAuthorisedRepresentativeRequest);
        ApplicationResponse applicationResponse = new ApplicationResponse();
        applicationResponse = pDCreateAuthorisedRepresentativeResponse.getResultStatus();
        //getSoapRequestMsg();
        Map<String, Object> messageCtx = ((BindingProvider)pNAPCEHRCreateAuthorisedRepresentative).getResponseContext();
        
        LOG.debug("Calling Authorise Representative WS --- 4");
        LOG.debug("applicationResponse"+applicationResponse.getStatusDescription());
        reactivateAuthRepClientResBO.setApplicationResponse(applicationResponse);
        reactivateAuthRepClientResBO.setSoapReqRes(soapMessageUtil.getSoapMessages(messageCtx));
        return reactivateAuthRepClientResBO;
        }catch(Exception e){
            LOG.fatal("Exception Occured..",e);
        }
        
        return null;
      
    }
    
    private CreateAuthRepcommonParameters createCommonParameters(ReactivateAuthRepBO reactivateAuthRepBO){
        CreateAuthRepcommonParameters createAuthRepcommonParameters = new CreateAuthRepcommonParameters();
        createAuthRepcommonParameters.setTransactionID("Transaction ID");
        createAuthRepcommonParameters.setSourceSystemID("SourceSystemID");
        createAuthRepcommonParameters.setRecordIHI(reactivateAuthRepBO.getRecordIHI());
        createAuthRepcommonParameters.setPcehrIdentity(new BigInteger(reactivateAuthRepBO.getUserID()));
        return createAuthRepcommonParameters;
    }
    
    private CreateAuthRepFunctionParameter createFunctionParameter(ReactivateAuthRepBO reactivateAuthRepBO){
        CreateAuthRepFunctionParameter createAuthRepFunctionParameter = new CreateAuthRepFunctionParameter();
       LOG.debug("reactivateAuthRepBO.getUserID()"+reactivateAuthRepBO.getUserID());
        try {
            createAuthRepFunctionParameter = relationshipType(createAuthRepFunctionParameter,reactivateAuthRepBO);
            createAuthRepFunctionParameter.setRelationshipCreatedBy(reactivateAuthRepBO.getUserID());
            createAuthRepFunctionParameter.setRelationshipStartDate( DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar()));
            createAuthRepFunctionParameter.getAuthority().add(createAuthority(reactivateAuthRepBO));
        } catch (DatatypeConfigurationException e) {
            LOG.fatal("Exception Occured..",e);
        }
        return createAuthRepFunctionParameter;   
    }
    
    private Authority createAuthority(ReactivateAuthRepBO reactivateAuthRepBO){
        Authority authority = new Authority();
        authority.setAuthorityType(getAuthorityType(reactivateAuthRepBO));
        authority.setAuthorityDocumentType(getDocumentType(reactivateAuthRepBO));
        authority.setIssuingAuthority(reactivateAuthRepBO.getAuth_issue());
        authority.setStartDate(soapMessageUtil.getexpiredate(reactivateAuthRepBO.getAuth_startdate()));
        return authority;
    }
    
    private String getDocumentType(ReactivateAuthRepBO reactivateAuthRepBO){
        if (reactivateAuthRepBO.getDocType() == UtilConstants.VALUE_1) {
            return "Medical Power of Attorney legal document";
        } else if (reactivateAuthRepBO.getDocType() == UtilConstants.VALUE_2) {
            return "Court Order";
        } else if (reactivateAuthRepBO.getDocType() == UtilConstants.VALUE_3) {
            return "Birth Certificate";
        }
        return null;
    }
    
    private String  getAuthorityType(ReactivateAuthRepBO reactivateAuthRepBO){
        if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_1) {
            return "Medical Power of Attorney";
        } else if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_2) {
            return "Guardianship";
        } else if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_3) {
           return "Parent";
        }else if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_4) {
           return "Under 18 - Parental Responsibility";
        }else if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_5) {
           return "Under 18 - Legal Authority";
        }else if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_6) {
           return "Under 18 - Otherwise Appropriate Person";
        }else if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_7) {
           return "18 and Over - Legal Authority";
        }else if (reactivateAuthRepBO.getAuth_type() == UtilConstants.VALUE_8) {
           return "18 and Over - Otherwise Appropriate Person";
        }
        return null;
    }
    /**
     *
     * @param createAuthRepFunctionParameter
     * @return
     */
    private CreateAuthRepFunctionParameter relationshipType(CreateAuthRepFunctionParameter createAuthRepFunctionParameter,ReactivateAuthRepBO reactivateAuthRepBO){
        LOG.debug("reactivateAuthRepBO.getRel_type()"+reactivateAuthRepBO.getRel_type());
        if (reactivateAuthRepBO.getRel_type().equalsIgnoreCase("5")) {
            createAuthRepFunctionParameter.setRelationshipType(AuthRepRelationshipTypeID.AUTHORISED_REPRESENTATIVE);
        }else if (reactivateAuthRepBO.getRel_type().equalsIgnoreCase("16")) {
                   createAuthRepFunctionParameter.setRelationshipType(AuthRepRelationshipTypeID.UNDER_18_PARENTAL_RESPONSIBILITY);
               } else if (reactivateAuthRepBO.getRel_type().equalsIgnoreCase("17")) {
            createAuthRepFunctionParameter.setRelationshipType(AuthRepRelationshipTypeID.UNDER_18_LEGAL_AUTHORITY);
        } else if (reactivateAuthRepBO.getRel_type().equalsIgnoreCase("18")) {
            createAuthRepFunctionParameter.setRelationshipType(AuthRepRelationshipTypeID.UNDER_18_OTHERWISE_APPROPRIATE_PERSON);
        } else if (reactivateAuthRepBO.getRel_type().equalsIgnoreCase("19")) {
            createAuthRepFunctionParameter.setRelationshipType(AuthRepRelationshipTypeID.EIGHTEEN_AND_OVER_LEGAL_AUTHORITY);
        } else if (reactivateAuthRepBO.getRel_type().equalsIgnoreCase("20")) {
            createAuthRepFunctionParameter.setRelationshipType(AuthRepRelationshipTypeID.EIGHTEEN_AND_OVER_OTHERWISE_APPROPRIATE_PERSON);
        }
        return createAuthRepFunctionParameter;
    }


    
   
}
