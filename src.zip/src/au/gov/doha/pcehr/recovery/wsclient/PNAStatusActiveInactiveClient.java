package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.bo.PNAStatusActiveInactiveClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.ws.pna.pd.PDSetPCEHRStatusRequest;
import au.pcehr.ws.pna.pd.PNA_PCEHR_setPCEHRStatus;
import au.pcehr.ws.pna.pd.PNA_PCEHR_setPCEHRStatusWS;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.Map;

import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * @author      Vikash Kumar Singh  PCEHR   Operations
 */
@Service
public class PNAStatusActiveInactiveClient {
    private static Logger LOG = Logger.getLogger(PNAStatusActiveInactiveClient.class);
        
    @Autowired
    Decrypter decrypter;
    
    @Autowired
    private SOAPMessageUtil soapMessageUtil;
        
    @Autowired
    TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    
    /**
     *
     * @param pnaStatusActiveInactiveClientBO
     * @return
     */
    public PNAStatusActiveInactiveClientBO pnaStatusUpdate(PNAStatusActiveInactiveClientBO pnaStatusActiveInactiveClientBO){
        
        PNA_PCEHR_setPCEHRStatusWS pNAPCEHRSetPCEHRStatusWS = new PNA_PCEHR_setPCEHRStatusWS();
        pNAPCEHRSetPCEHRStatusWS.setHandlerResolver(wSClientHandlerResolver);
        PNA_PCEHR_setPCEHRStatus pNAPCEHRSetPCEHRStatus = pNAPCEHRSetPCEHRStatusWS.getPNA_PCEHR_setPCEHRStatusPort();
        
        Map<String, Object> requestContext = ((BindingProvider) pNAPCEHRSetPCEHRStatus).getRequestContext();
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.PNA_ENDPOINT);
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
        requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_USERNAME));
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_PASSWORD));
        PDSetPCEHRStatusRequest setPCEHRStatusRequest = new PDSetPCEHRStatusRequest();
        setPCEHRStatusRequest.setParameterList(pnaStatusActiveInactiveClientBO.getPcehrStatusParameterList());
        pnaStatusActiveInactiveClientBO.setSetPCEHRStatusResponse(pNAPCEHRSetPCEHRStatus.pDsetPCEHRStatus(setPCEHRStatusRequest));
        
        LOG.debug("Result data"+pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultData());
        LOG.debug("val of endpoint"+pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusCode());
        LOG.debug("val of endpoint"+pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusDescription());
        Map<String, Object> messageCtx = ((BindingProvider)pNAPCEHRSetPCEHRStatus).getResponseContext();
        pnaStatusActiveInactiveClientBO.setSoapReqRes(soapMessageUtil.getSoapMessages(messageCtx));
        return pnaStatusActiveInactiveClientBO;
    }
}
