package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.bo.GetViewClientBO;
import au.gov.doha.pcehr.recovery.bo.HealthRecordExtractionErrorBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.docx.view.ApplicationResponse;
import au.pcehr.docx.view.CodedType;
import au.pcehr.docx.view.DocXViewPortType;
import au.pcehr.docx.view.DocXViewService;
import au.pcehr.docx.view.HealthRecordOverview;
import au.pcehr.docx.view.II;
import au.pcehr.docx.view.RetrieveConsolidatedView;
import au.pcehr.docx.view.hro.NewDocuments;
import au.pcehr.ws.pna.common.IHIRecordStatusVal;
import au.pcehr.ws.pna.common.IHIStatusVal;
import au.pcehr.ws.pna.common.Individual;
import au.pcehr.ws.pna.common.Name;
import au.pcehr.ws.pna.common.Sex;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.io.IOException;
import java.io.InputStream;

import java.net.MalformedURLException;
import java.net.URL;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.activation.DataHandler;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import javax.xml.ws.soap.SOAPBinding;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Client class for DocXView - HDR service.
 * @author  Vikash.c.kumar.singh
 * @since R 6.1.5
 * @see @link {au.pcehr.docx.view.DocXViewService}
 */
@Service
public class GetViewClient {
    private static Logger LOG = Logger.getLogger(GetViewClient.class);
    
    private static final String ROOT_INITIAL = "1.2.36.1.2001.1003.0.";
    private static final String SUCCESS_RESPONSE_HRO="Operation is successful";
    @Autowired
    TestHostnameVerifier testHostnameVerifier;

    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    
    @Autowired
    DateTimeUtil dateTimeUtil;
    @Autowired
    FileUtil fileUtil;
    @Autowired
    Decrypter decrypter;
    
    @Autowired
    SOAPMessageUtil soapMessageUtil;
    /**
     * @param getViewClientBO
     * @throws MalformedURLException
     * @throws ParseException
     * @throws DatatypeConfigurationException
     * @throws Exception
     */
    public GetViewClientBO retrieveConsolidatedView(GetViewClientBO getViewClientBO)   {
        InputStream in = null;
        try {
            URL url =new URL("https://npdashdr001.ehealth.gov.au:4444/DocXViewWS/DocXViewService/#%7Burn%3Aview.docx.pcehr.au%7DDocXViewService?wsdl");
            QName qname = new QName("urn:view.docx.pcehr.au", "DocXViewService");
            
            DocXViewService docXViewService = new DocXViewService(url,qname);
            docXViewService.setHandlerResolver(wSClientHandlerResolver);
            DocXViewPortType docXViewPortType = docXViewService.getDocXViewPort(new javax.xml.ws.soap.AddressingFeature(true, true));
            
            Map<String, Object> ctx = ((BindingProvider) docXViewPortType).getRequestContext();
            ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.DOCXVIEW_HDR_ENDOPINT);
            ctx.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.HDR_USERNAME));
            ctx.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.HDR_PASSWORD));
            BindingProvider bp = (BindingProvider) docXViewPortType;
            SOAPBinding binding = (SOAPBinding) bp.getBinding();
            binding.setMTOMEnabled(true);
            ctx.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            
            RetrieveConsolidatedView retrieveConsolidatedView = new RetrieveConsolidatedView();
            List<II> list = getRootList(getViewClientBO.getIhi());
            
            List<CodedType> confidentialityCode = getConfidentialityCode(getViewClientBO);
            Individual individualProfile = getIndividualProfile(getViewClientBO);
            RetrieveConsolidatedView.Map map = getRetrieveConsolidatedViewMap(getViewClientBO);
            
            Holder<ApplicationResponse> applicationResponse = new Holder<ApplicationResponse>();
            Holder<DataHandler> cdaData = new Holder<DataHandler> ();
            docXViewPortType.retrieveConsolidatedView(list , null, confidentialityCode, individualProfile, getViewClientBO.getViewType(), map, applicationResponse, cdaData);
            
           
           

            if(applicationResponse.value.getResponseDetail().equalsIgnoreCase(SUCCESS_RESPONSE_HRO)){
                LOG.debug("Success response:::");
                DataHandler dataHandler=(cdaData.value);
                
                in = dataHandler.getInputStream();
                byte[] byteArrayDocument=org.apache.commons.io.IOUtils.toByteArray(in);
                
                LOG.debug("length :: " +  byteArrayDocument.length);
                LOG.debug("value:::: " +  byteArrayDocument);
                getViewClientBO.setReposnseDcoument(byteArrayDocument);
            }else{
            LOG.debug("error response:::");
            HealthRecordExtractionErrorBO errorBO=fileUtil.createErrorBo(getViewClientBO.getIhi(), applicationResponse.value.getResponseDetail(),getViewClientBO.getViewType());
            getViewClientBO.setHealthRecordExtractionErrorBO(errorBO);
           // getViewClientBO.setSoapResponse(null);/*  */
            getViewClientBO.setReposnseDcoument(null);
            }
            
        }catch(Exception e){
            LOG.fatal("exception occured:::",e);
            HealthRecordExtractionErrorBO errorBO=fileUtil.createErrorBo(getViewClientBO.getIhi(), e.getMessage(),getViewClientBO.getViewType());
            getViewClientBO.setHealthRecordExtractionErrorBO(errorBO);
            getViewClientBO.setReposnseDcoument(null);
        }finally{
            try{
                if(in!=null)
            in.close();
            }catch(IOException ioe){
                LOG.fatal("Esception",ioe);
            }
        }
        return getViewClientBO;
    }
    
    /**
     *
     * @param getViewClientBO
     * @return
     * @throws MalformedURLException
     * @throws ParseException
     * @throws DatatypeConfigurationException
     * @throws Exception
     */
    public GetViewClientBO gethealthRecordOverview(GetViewClientBO getViewClientBO)  {
        try{
        URL url =new URL("https://npdashdr001.ehealth.gov.au:4444/DocXViewWS/DocXViewService/#%7Burn%3Aview.docx.pcehr.au%7DDocXViewService?wsdl");
        QName qname = new QName("urn:view.docx.pcehr.au", "DocXViewService");
        
        DocXViewService docXViewService = new DocXViewService(url,qname);
        docXViewService.setHandlerResolver(wSClientHandlerResolver);
        DocXViewPortType docXViewPortType = docXViewService.getDocXViewPort(new javax.xml.ws.soap.AddressingFeature(true, true));
        
        Map<String, Object> ctx = ((BindingProvider) docXViewPortType).getRequestContext();
        ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.DOCXVIEW_HDR_ENDOPINT);
        ctx.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.HDR_USERNAME));
        ctx.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.HDR_PASSWORD));
        ctx.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
        
        List<II> list = getRootList(getViewClientBO.getIhi());//Pass IHI
        
        List<CodedType> confidentialityCode = getConfidentialityCode(getViewClientBO);
        Individual individualProfile = getIndividualProfile(getViewClientBO);
        au.pcehr.docx.view.HealthRecordOverview.Map map = getHealthRecordOverviewMap();
        
        Holder<ApplicationResponse> applicationResponse = new Holder<ApplicationResponse>();
        Holder<au.pcehr.docx.view.hro.ViewMetadata> viewMetadata = new Holder<au.pcehr.docx.view.hro.ViewMetadata>();
        Holder<NewDocuments> newDocuments = new Holder<NewDocuments> ();
        Holder<au.pcehr.docx.view.hro.SharedHealthSummary> sharedHealthSummary = new Holder<au.pcehr.docx.view.hro.SharedHealthSummary>();
        Holder<au.pcehr.docx.view.hro.OtherLinks> otherLinks = new Holder<au.pcehr.docx.view.hro.OtherLinks>();
        Holder<au.pcehr.docx.view.hro.RecentDocuments> recentDocuments = new Holder<au.pcehr.docx.view.hro.RecentDocuments>();
        docXViewPortType.healthRecordOverview(list, null, confidentialityCode, individualProfile, null, null, map, applicationResponse, viewMetadata, newDocuments, sharedHealthSummary, otherLinks, recentDocuments);
            if(applicationResponse!=null && applicationResponse.value!=null && applicationResponse.value.getResponseDetail()!=null){
                if(applicationResponse.value.getResponseDetail().equalsIgnoreCase(SUCCESS_RESPONSE_HRO)){
                    LOG.debug("successfull reponse:::");
                    Map<String, Object> messageCtx = null;
                    messageCtx = ((BindingProvider) docXViewPortType).getResponseContext();
                    getViewClientBO.setSoapResponse(messageCtx.get("soapResponse").toString());
                }else{
                LOG.debug("error response:::");
                HealthRecordExtractionErrorBO errorBO=fileUtil.createErrorBo(getViewClientBO.getIhi(), applicationResponse.value.getResponseDetail(),getViewClientBO.getViewType());
                getViewClientBO.setHealthRecordExtractionErrorBO(errorBO);
                getViewClientBO.setSoapResponse(null);
            }
            }
       

        }catch(Exception e){
            LOG.fatal("exception occured:::",e);
            HealthRecordExtractionErrorBO errorBO=fileUtil.createErrorBo(getViewClientBO.getIhi(), e.getMessage(),getViewClientBO.getViewType());
            getViewClientBO.setHealthRecordExtractionErrorBO(errorBO);
            getViewClientBO.setSoapResponse(null);
        }
        return getViewClientBO;
    }
    
    /**
     *
     * @param ihi
     * @return
     */
    private List<II> getRootList(String ihi){
        List<II> list = new ArrayList<II>();
        II root = new II();
        root.setRoot(ROOT_INITIAL + ihi);
        list.add(root);
        return list;
    }

    /**
     *
     * @return
     */
    private List<CodedType> getConfidentialityCode(GetViewClientBO getViewClientBO) {
        List<CodedType> codedTypeList = new ArrayList<CodedType>();
        for(String confidentialityCode : getViewClientBO.getConfidentialityCode()){
            CodedType codedType = new CodedType();
            codedType.setCode(confidentialityCode);
            codedType.setCodeSystem("1.2.3.4.2");
            codedTypeList.add(codedType);
        }
        return codedTypeList;
    }
    
    /**
     *
     * @param ihi
     * @return
     * @throws ParseException
     * @throws DatatypeConfigurationException
     * @throws Exception
     */
    private Individual getIndividualProfile(GetViewClientBO getViewClientBO) throws ParseException, DatatypeConfigurationException,
                                                               Exception {
        Individual individualProfile = new Individual();
        individualProfile.setNumber(getViewClientBO.getIhi());
        individualProfile.setIHIRecordStatus(IHIRecordStatusVal.VERIFIED);
        individualProfile.setIHIStatus(IHIStatusVal.ACTIVE);
        individualProfile.setDateOfBirth(dateTimeUtil.getXMLGregorianCalendar(getViewClientBO.getDob()));
        if(getViewClientBO.getSex()==1)
            individualProfile.setSex(Sex.M);
        else if(getViewClientBO.getSex()==2)
            individualProfile.setSex(Sex.F);
        else if(getViewClientBO.getSex()==3)
            individualProfile.setSex(Sex.I);
        else if(getViewClientBO.getSex()==4)
            individualProfile.setSex(Sex.N);
        
        Name name= new Name();
        name.setFamilyName(getViewClientBO.getFamilyName());
        individualProfile.setName(name);
        return individualProfile;
    }
    
    
    /**
     *
     * @param getViewClientBO
     * @return
     */
    private RetrieveConsolidatedView.Map getRetrieveConsolidatedViewMap(GetViewClientBO getViewClientBO) throws ParseException,
                                                                                                                DatatypeConfigurationException,
                                                                                                                Exception {
        RetrieveConsolidatedView.Map map = new RetrieveConsolidatedView.Map();
        List<RetrieveConsolidatedView.Map.Entry> retrieveConsolidatedViewMap = map.getEntries();
        
        RetrieveConsolidatedView.Map.Entry versionEntry = new RetrieveConsolidatedView.Map.Entry();
        versionEntry.setKey("versionNumber");
        versionEntry.setValue("1.1");
        if(!"".equals(getViewClientBO.getToDate()) || !"".equals(getViewClientBO.getFromDate())){
            RetrieveConsolidatedView.Map.Entry toDateEntry = new RetrieveConsolidatedView.Map.Entry();        
            toDateEntry.setKey("toDate");
            XMLGregorianCalendar toXMLGregorianCalendarDate = dateTimeUtil.getXMLGregorianCalendar(getViewClientBO.getToDate());
            toDateEntry.setValue(formatDate(toXMLGregorianCalendarDate));
            
            RetrieveConsolidatedView.Map.Entry fromDateEntry = new RetrieveConsolidatedView.Map.Entry();
            XMLGregorianCalendar fromXMLGregorianCalendarDate = dateTimeUtil.getXMLGregorianCalendar(getViewClientBO.getFromDate());
            fromDateEntry.setKey("fromDate");
            fromDateEntry.setValue(formatDate(fromXMLGregorianCalendarDate));
            retrieveConsolidatedViewMap.add(toDateEntry);
            retrieveConsolidatedViewMap.add(fromDateEntry);
        }
        retrieveConsolidatedViewMap.add(versionEntry);
        return map;
    }

    /**
     *
     * @return
     */
    private HealthRecordOverview.Map getHealthRecordOverviewMap() {
        HealthRecordOverview.Map map = new HealthRecordOverview.Map();
        List<HealthRecordOverview.Map.Entry> healthRecordOverviewMap = map.getEntries();
        HealthRecordOverview.Map.Entry versionsEntry = new HealthRecordOverview.Map.Entry();
        versionsEntry.setKey("versionNumber");
        versionsEntry.setValue("1.1");
        
        HealthRecordOverview.Map.Entry clinicalSynopsisLengthEntry = new HealthRecordOverview.Map.Entry();
        clinicalSynopsisLengthEntry.setKey("clinicalSynopsisLength");
        clinicalSynopsisLengthEntry.setValue("0");
        
        HealthRecordOverview.Map.Entry utcEntry = new HealthRecordOverview.Map.Entry();
        utcEntry.setKey("UTC");
        utcEntry.setValue("false");
        
        healthRecordOverviewMap.add(versionsEntry);
        healthRecordOverviewMap.add(clinicalSynopsisLengthEntry);
        healthRecordOverviewMap.add(utcEntry);
        return map;
    }
    
    public String formatDate(XMLGregorianCalendar xmlDate){
        String formatedDate = null;
        SimpleDateFormat targetFormat = new SimpleDateFormat("YYYY-MM-dd");
        Date Converteddate = xmlDate.toGregorianCalendar().getTime();
        formatedDate=targetFormat.format(Converteddate);
        return formatedDate;
    }
}
