package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.net.electronichealth.ns.pcehr.svc.intsynchroniseihidetails._1.StandardError;
import au.net.electronichealth.ns.pcehr.svc.intsynchroniseihidetails._1.SynchroniseIHIDetails;
import au.net.electronichealth.ns.pcehr.svc.intsynchroniseihidetails._1.SynchroniseIHIDetailsPortType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.IDType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.synchroniseihidetails._1.SynchroniseIHIDetailsResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * Form class for IHI Synchronization
 * @Author Rakhi Tholia, Operations, PCEHR
 * @since 9th Apr 2015
 * @version Change-x
 */

@Service
public class SingleIHISynchronizeClient implements  HandlerResolver{
    private static Logger LOG = Logger.getLogger(SingleIHISynchronizeClient.class);
    
    @Autowired
    Decrypter decrypter;
    
    @Autowired
    TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    WSClientHandlerResolver wsClientHandlerResolver;
    /**
     * synchroniseIHIDetails method calls web service to synchroniza input IHI. 
     * @param responseStatus    
     * @param strIHI
     * @param strUsername
     * @return ResponseStatusType
     */
    public final ResponseStatusType synchroniseIHIDetails(ResponseStatusType responseStatus, final String strIHI,
                                                          final String strUsername) {
        try {
            SynchroniseIHIDetails synchroniseIHIDetails = new SynchroniseIHIDetails();
            synchroniseIHIDetails.setHandlerResolver(wsClientHandlerResolver);
            SynchroniseIHIDetailsPortType synchroniseIHIDetailsPortType =
                synchroniseIHIDetails.getSynchroniseIHIDetailsSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true,
                                                                                                                 true));
            Map<String, Object> ctxt = ((BindingProvider)synchroniseIHIDetailsPortType).getRequestContext();
            
            ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.SYNC_IHI_ENDPOINT);
            ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            ctxt.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
            ctxt.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD));
            au.net.electronichealth.ns.pcehr.xsd.interfaces.synchroniseihidetails._1.SynchroniseIHIDetails syncIHIDetails =
                new au.net.electronichealth.ns.pcehr.xsd.interfaces.synchroniseihidetails._1.SynchroniseIHIDetails();
            syncIHIDetails.setIDType(IDType.IHI);
            syncIHIDetails.setIDNumber(strIHI);

            IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();

            IntPCEHRHeader.User user = new IntPCEHRHeader.User();
            user.setIDType("LocalSystemIdentifier");
            user.setID(strUsername);
            user.setRole("PCEHR_SYSTEM_OPERATOR");
            user.setUserName(strUsername);
            user.setUseRoleForAudit(false);
            intPCEHRHeader.setUser(user);

            IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
            productType.setVendor("NIO");
            productType.setProductName("synchroniseIHIDetails");
            productType.setProductVersion(EndPointsConstants.PRODUCT_VERSION);
            productType.setPlatform("Jump Host");
            intPCEHRHeader.setProductType(productType);

            IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
            clientSystem.setSystemID(EndPointsConstants.HOST_NAME);
            clientSystem.setSystemType("Admin");
            intPCEHRHeader.setClientSystem(clientSystem);

            IntPCEHRHeader.AccessingOrganisation accessingOrg = new IntPCEHRHeader.AccessingOrganisation();
            accessingOrg.setOrganisationID("");
            accessingOrg.setOrganisationName("");
            intPCEHRHeader.setAccessingOrganisation(accessingOrg);
            intPCEHRHeader.setOverrideLogLevel(false);
            intPCEHRHeader.setIhiNumber(strIHI);

            Holder<SynchroniseIHIDetailsResponse> holder = new Holder<SynchroniseIHIDetailsResponse>();
            SynchroniseIHIDetailsResponse syncIHIRes = new SynchroniseIHIDetailsResponse();
            
            holder.value = syncIHIRes;
            try {
                synchroniseIHIDetailsPortType.synchroniseIHIDetails(syncIHIDetails, holder, intPCEHRHeader);
                syncIHIRes = holder.value;
                responseStatus =  syncIHIRes.getResponseStatus();
                LOG.debug("syncIHIRes Status :: " + syncIHIRes.getResponseStatus().getDescription());
                Map<String, Object> messageCtx = ((BindingProvider)synchroniseIHIDetailsPortType).getResponseContext();
                String doc = (messageCtx.get("soapResponse")).toString();
                LOG.debug("SOAP message Response in syncIHI Client : - " + doc);
            } catch (StandardError error) {
                error.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        LOG.debug("Synchronise IHI Details :: " + responseStatus.getCode());
        return responseStatus;
    }

    @Override
    public List<Handler> getHandlerChain(PortInfo portInfo) {
        // TODO Implement this method
        return Collections.emptyList();
    }
}
