package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.bo.GetDocumentListClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import com.sun.xml.ws.developer.JAXWSProperties;

import ihe.iti.xds_b._2007.DocumentRegistryPortType;
import ihe.iti.xds_b._2007.DocumentRegistryService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.ws.BindingProvider;

import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryRequest;
import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryResponse;
import oasis.names.tc.ebxml_regrep.xsd.query._3.ResponseOptionType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.AdhocQueryType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ExtrinsicObjectType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.IdentifiableType;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.SlotType1;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ValueListType;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GetDocumentListClient {
    private static Logger LOG = Logger.getLogger(GetDocumentListClient.class);
    public static final String DOCENTRY_STATUS_APPROVED_AND_DEPRICATD = "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved','urn:oasis:names:tc:ebxml-regrep:StatusType:Deprecated";
    public static final String DOCENTRY_STATUS_APPROVED_AND_DELETED = "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved','urn:orcl.reg:names:StatusType:Deleted";
    public static final String DOCENTRY_STATUS_APPROVED = "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved";
    public static final String DOCENTRY_STATUS_DEPRICATD = "urn:oasis:names:tc:ebxml-regrep:StatusType:Deprecated";
    public static final String DOCENTRY_STATUS_DELETED="urn:orcl.reg:names:StatusType:Deleted";
    public static final String ADHOC_QUERY_ID_PATIENT = "urn:uuid:14d4debf-8f97-4251-9a74-a90016b0af0d";
    public static final String DOCUMENT_ENTRY_UNIQUE_ID= "$XDSDocumentEntryUniqueId";
    public static final String DOCUMENT_PATIENT_ID= "$XDSDocumentEntryPatientId";
    public static final String IHI_ISO = "^^^&1.2.36.1.2001.1003.0&ISO";    
    public static final String ADHOC_QUERY_ID="urn:uuid:5c4f972b-d56b-40ac-a5fc-c8ca9b40b9d4";
    
    @Autowired
    DateTimeUtil dateTimeUtil;
    @Autowired
    TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    
    public AdhocQueryResponse getDocListWsCall(GetDocumentListClientBO getDocumentListClientBO)throws WebServiceClientException{
        AdhocQueryResponse adhocQueryResponse= null;
        
        String ihi=getDocumentListClientBO.getIhi();
        try {

            DocumentRegistryService documentRegistryService = new DocumentRegistryService();
            documentRegistryService.setHandlerResolver(wSClientHandlerResolver);
           
            DocumentRegistryPortType documentRegistryPortType =
                documentRegistryService.getDocumentRegistryPortSoap12(new javax.xml.ws.soap.AddressingFeature(true, true));
            LOG.debug("wsdl address" + EndPointsConstants.GET_DOC_LIST_ENDPOINT);
            Map<String, Object> ctxt = ((BindingProvider)documentRegistryPortType).getRequestContext();
            ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.GET_DOC_LIST_ENDPOINT);
            ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER,testHostnameVerifier);
            ResponseOptionType responseOptionType = new ResponseOptionType();
            responseOptionType.setReturnType("LeafClass");
            responseOptionType.setReturnComposedObjects(true);
            AdhocQueryType adhocQueryType = new AdhocQueryType();
            List<SlotType1> newslots = new ArrayList<SlotType1>();
            
            if(getDocumentListClientBO.getDocumentEntryStatus()!=null && getDocumentListClientBO.getDocumentEntryStatus().size()>0){
                newslots.add(createSlot("$XDSDocumentEntryStatus", getDocumentListClientBO.getDocumentEntryStatus(),""));
                //newslots.add(createStatusSlot("$XDSDocumentEntryStatus", getDocumentListClientBO.getDocEntryStatus()));
            }
            if(getDocumentListClientBO.getDocumentEntryPatientId()!=null&&getDocumentListClientBO.getDocumentEntryPatientId().size()>0){
                newslots.add(createSlotForIHI(DOCUMENT_PATIENT_ID, getDocumentListClientBO.getDocumentEntryPatientId(),IHI_ISO));    
            }
            if(getDocumentListClientBO.getDocumentEntryUniqueId()!=null && getDocumentListClientBO.getDocumentEntryUniqueId().size()>0){
                newslots.add(createSlot(DOCUMENT_ENTRY_UNIQUE_ID, getDocumentListClientBO.getDocumentEntryUniqueId(),""));
            }
            if(getDocumentListClientBO.getDocumentEntryTypeCode()!=null && getDocumentListClientBO.getDocumentEntryTypeCode().size()>0){
                newslots.add(createSlot("$XDSDocumentEntryTypeCode", getDocumentListClientBO.getDocumentEntryTypeCode(),""));
            }
            if(getDocumentListClientBO.getDocumentEntryServiceStartTimeFrom()!=null ){
                
                newslots.add(createSlot("$XDSDocumentEntryServiceStartTimeFrom", getDocumentListClientBO.getDocumentEntryServiceStartTimeFrom()));
            }
            if(getDocumentListClientBO.getDocumentEntryServiceStartTimeTo()!=null ){
                //increasing to date by 1 day to get all the documents uploaded for the whole date
                newslots.add(createSlot("$XDSDocumentEntryServiceStartTimeTo", getDocumentListClientBO.getDocumentEntryServiceStartTimeTo()));
            }
            adhocQueryType.getSlot().addAll(newslots);
            adhocQueryType.setId(getDocumentListClientBO.getAdhocQueryID());
            AdhocQueryRequest adhocQueryRequest = new AdhocQueryRequest();
            adhocQueryRequest.setAdhocQuery(adhocQueryType);
            adhocQueryRequest.setResponseOption(responseOptionType);
            LOG.debug("1");

             adhocQueryResponse =
                documentRegistryPortType.documentRegistryRegistryStoredQuery(adhocQueryRequest);
            
        }catch (Exception e) {
                LOG.fatal("Exception::;" + e);
                throw new WebServiceClientException(e.getMessage(),e);
        }
        LOG.info("leaving getDocListWsCall method of RetrieveDcoumentListService..");
            
        return adhocQueryResponse;
    }
    
    

    /**
     * This mehthod returns a map 
     * @return
     */
    public HashMap getDocListMapWsCall(GetDocumentListClientBO getDocumentListClientBO){
       HashMap iDListHashMap = new HashMap();
    try {
      
       AdhocQueryResponse adhocQueryResponse =getDocListWsCall(getDocumentListClientBO);
       LOG.debug("2");
       List<JAXBElement<? extends IdentifiableType>> identifiable =
           adhocQueryResponse.getRegistryObjectList().getIdentifiable();
       for (int j = 0; j < identifiable.size(); j++) {
           for (int i = 0; i < ((ExtrinsicObjectType)identifiable.get(j).getValue()).getExternalIdentifier().size();
                i++) {
               String temp =
                   ((ExtrinsicObjectType)identifiable.get(j).getValue()).getExternalIdentifier().get(i).getValue().toString();
               if (!temp.contains("ISO")) {
                   iDListHashMap.put(identifiable.get(j).getValue().getId(), temp);
               }
           }
       }
    }
       catch (Exception e) {
           LOG.fatal("Exception::;" + e);


       }LOG.debug("iDListHashMap" + iDListHashMap.size());
       LOG.info("leaving getDocListWsCall method of RetrieveDcoumentListService..");
       return iDListHashMap;
    }
    
    /**
     *
     * @param name
     * @param value
     * @return
     */
    private  SlotType1 createSlot(final String name, final List<String> value,String append) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        ValueListType valueListType = new ValueListType();
        for(String val : value){
            valueListType.getValue().add("('"+val+append+"')");
        }
        slot.setValueList(valueListType);
        return slot;
    }
    
    /**
     *
     * @param name
     * @param value
     * @return
     */
    private  SlotType1 createSlotForIHI(final String name, final List<String> value,String append) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        ValueListType valueListType = new ValueListType();
        for(String val : value){
            valueListType.getValue().add("'"+val+append+"'");
        }
        slot.setValueList(valueListType);
        return slot;
    }
    
    /**
     *
     * @param name
     * @param value
     * @return
     */
    private static SlotType1 createSlot(final String name, final String value) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        slot.setValueList(new ValueListType());
        slot.getValueList().getValue().add(value);
        return slot;
    }

    /**
     *
     * @param name
     * @param value1
     * @return
     */
    private static SlotType1 createStatusSlot(final String name, final String value1) {
        SlotType1 slot = new SlotType1();
        slot.setName(name);
        slot.setValueList(new ValueListType());
        slot.getValueList().getValue().add(value1);

        return slot;
    }
    

  
    
}
