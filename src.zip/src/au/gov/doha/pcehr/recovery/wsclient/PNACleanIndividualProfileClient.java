package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.bo.PNACleanIndividualProfileClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.ws.pna.common.ApplicationResponse;
import au.pcehr.ws.pna.pd.CleanupIndividualProfileCommonParameters;
import au.pcehr.ws.pna.pd.CleanupIndividualProfileFunctionParameters;
import au.pcehr.ws.pna.pd.CleanupIndividualProfileParameterList;
import au.pcehr.ws.pna.pd.PDCleanupIndividualProfileRequest;
import au.pcehr.ws.pna.pd.PDCleanupIndividualProfileResponse;
import au.pcehr.ws.pna.pd.PNAPCEHRCleanupIndividualProfile;
import au.pcehr.ws.pna.pd.PNAPCEHRCleanupIndividualProfileWS;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PNACleanIndividualProfileClient {
   
   
    @Autowired
    TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    
    @Autowired
    Decrypter decrypter;
    
    private PNACleanIndividualProfileClientBO pNACleanIndividualProfileClientBO;
        private static Logger LOG = Logger.getLogger(PNACleanIndividualProfileClient.class);
   /**
     *
     * @return
     */
        public List cleanIndividualProfile(PNACleanIndividualProfileClientBO pNACleanIndividualProfileClientBO){
    LOG.info("Entering cleanIndividualProfile ");
    List returnList = new ArrayList();
    String[] returnData = null;
    String sourceSystemID = "ADM";
    String transactionID = UUID.randomUUID().toString();
    try {
       

        CleanupIndividualProfileCommonParameters cleanupIndividualProfileCommonParameters =
            new CleanupIndividualProfileCommonParameters();
        cleanupIndividualProfileCommonParameters.setTransactionID(transactionID);
        cleanupIndividualProfileCommonParameters.setSourceSystemID(sourceSystemID);

        CleanupIndividualProfileFunctionParameters cleanupIndividualProfileFunctionParameters =
            new CleanupIndividualProfileFunctionParameters();
        cleanupIndividualProfileFunctionParameters.setIHI(pNACleanIndividualProfileClientBO.getIhi());

      
        
        
        ApplicationResponse applicationResponse = new ApplicationResponse();
        try{
        PNAPCEHRCleanupIndividualProfileWS pNAPCEHRCleanupIndividualProfileWS;
        pNAPCEHRCleanupIndividualProfileWS = new PNAPCEHRCleanupIndividualProfileWS();
        pNAPCEHRCleanupIndividualProfileWS.setHandlerResolver(wSClientHandlerResolver);
        PNAPCEHRCleanupIndividualProfile pNAPCEHRCleanupIndividualProfile;
        pNAPCEHRCleanupIndividualProfile = pNAPCEHRCleanupIndividualProfileWS.getPNAPCEHRCleanupIndividualProfilePort();
        Map<String, Object> requestContext =
            ((BindingProvider) pNAPCEHRCleanupIndividualProfile).getRequestContext();
        Decrypter decrypter = new Decrypter();
      
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.PNA_CIP_ENDPOINT);
      
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
      
        requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_USERNAME));
      
        requestContext.put(BindingProvider.PASSWORD_PROPERTY,  decrypter.decryption(EndPointsConstants.PNA_PASSWORD));        
        XMLGregorianCalendar xgcal = null;
        try {
            GregorianCalendar gcal = new GregorianCalendar();
            xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
        } catch (Exception e) {
        LOG.fatal("Eeception..."+e);
        }
        CleanupIndividualProfileParameterList cleanupIndividualProfileParameterList;
        cleanupIndividualProfileParameterList = new CleanupIndividualProfileParameterList();
        cleanupIndividualProfileParameterList.setCommonParameters(cleanupIndividualProfileCommonParameters);
        cleanupIndividualProfileParameterList.setFunctionalParameters(cleanupIndividualProfileFunctionParameters);
        PDCleanupIndividualProfileRequest pDCleanupIndividualProfileRequest;
        pDCleanupIndividualProfileRequest = new PDCleanupIndividualProfileRequest();
        pDCleanupIndividualProfileRequest.setParameterList(cleanupIndividualProfileParameterList);
        PDCleanupIndividualProfileResponse pDCleanupIndividualProfileResponse;
        pDCleanupIndividualProfileResponse = pNAPCEHRCleanupIndividualProfile.pDcleanupIndividualProfile(pDCleanupIndividualProfileRequest);
        
        applicationResponse = pDCleanupIndividualProfileResponse.getResultStatus();
        LOG.debug("leaving PNACleanIndividualProfile");
        
        }catch(Exception e){
          LOG.fatal("Eeception"+e);
        }
        
        
        
        if (null != applicationResponse) {
            returnData = new String[2];
            returnData[0] = applicationResponse.getStatusCode().toString();
            returnData[1] = applicationResponse.getStatusDescription();
            returnList.add(returnData);
            LOG.debug("response status code :::" + returnData[0]);
            LOG.debug("response status description :::" + returnData[1]);
        }
    } catch (Exception e) {
        LOG.fatal("Eeception"+e);
        returnData = new String[2];
        returnData[0] = "Exception";
        returnData[1] = e.getMessage();
        returnList.add(returnData);
        return returnList;
    }
    LOG.info("Leaving cleanIndividualProfile method ");
    return returnList;
        }


}
