package au.gov.doha.pcehr.recovery.wsclient;

//import au.pcehr.ws.pna.common.Individual;
import au.gov.doha.pcehr.recovery.bo.RegisterPCEHRClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.net.electronichealth.ns.pcehr.svc.intregisterpcehr._2.RegisterPCEHRPortType;
import au.net.electronichealth.ns.pcehr.svc.intregisterpcehr._2.RegisterPCEHRService;
import au.net.electronichealth.ns.pcehr.svc.intregisterpcehr._2.StandardErrorMsg;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ContactDetailsType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.NameTypeSupp;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.registerpcehr._2.RegisterPCEHR;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.registerpcehr._2.RegisterPCEHR.Individual;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.registerpcehr._2.RegisterPCEHR.Representative;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.registerpcehr._2.RegisterPCEHRResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pcehr.recovery.MyAuthenticator;

@Service
public class RegisterPCEHRClient {
    
    private static final String CONSENT_NOT_GIVEN = "ConsentNotGiven";
    private static final String CONSENT_GIVEN = "ConsentGiven";
    private static final String INDIGENOUS_STATUS = "9";
    private static final String CHANNEL = "response";
    private static Logger LOG = Logger.getLogger(RegisterPCEHRClient.class);
    
    @Autowired
    Decrypter decrypter;
    
    @Autowired
    private SOAPMessageUtil soapMessageUtil;
    
    @Autowired
    private TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    private WSClientHandlerResolver wsClientHandlerResolver;
    

    /**
     *
     * @param testInProductionWSCleintBO
     */
    public RegisterPCEHRResponse register(RegisterPCEHRClientBO testInProductionWSCleintBO) throws StandardErrorMsg {
        Decrypter decrypt = new Decrypter();
        Holder<RegisterPCEHRResponse> responseDetail = new Holder<RegisterPCEHRResponse>();
        XMLGregorianCalendar xgcal = null;

        LOG.debug("entering register method");
        try {
            URL url = null;
            try {
                
                url = new URL("http://localhost:8011/#%7Bhttp%3A%2F%2Fns.electronichealth.net.au%2Fpcehr%2Fsvc%2FintRegisterPCEHR%2F2.0%7DregisterPCEHRService?wsdl");

            } catch (MalformedURLException e) {
                LOG.fatal("Exception...", e);
            }
            QName qname = new QName("http://ns.electronichealth.net.au/pcehr/svc/intRegisterPCEHR/2.0", "registerPCEHRService");
            
            MyAuthenticator myAuth =
                new MyAuthenticator(EndPointsConstants.OSB_USERNAME,EndPointsConstants.OSB_PASSWORD);
            Authenticator.setDefault(myAuth);

            RegisterPCEHRService registerPCEHRService = new RegisterPCEHRService(url, qname);
            registerPCEHRService.setHandlerResolver(wsClientHandlerResolver);
            RegisterPCEHRPortType registerPCEHRPortType =
                registerPCEHRService.getRegisterPCEHRSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true, true));
            //BinndingProvider
            Map<String, Object> ctx = ((BindingProvider) registerPCEHRPortType).getRequestContext();
            ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, (EndPointsConstants.OSB_REGISTER_PCEHR));
            ctx.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            ctx.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
            ctx.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD));


            //creating the request object IntPCEHRHeader
            //check the import should point to correct jar
            IntPCEHRHeader header = setHeader(testInProductionWSCleintBO);

            //creating the request object RegisterPCEHR
            RegisterPCEHR registerPCEHR = new RegisterPCEHR();
            //Individual
            Individual individual = new Individual();
            //fileds of Individual
            Individual.Demographics indDemographics = new Individual.Demographics();

            NameTypeSupp indDemographicsnameTypeSupp = new NameTypeSupp();
            indDemographicsnameTypeSupp.setFamilyName(testInProductionWSCleintBO.getLastName());
            indDemographics.setDateOfBirth((testInProductionWSCleintBO.getDateOfBirth()));
            indDemographics.setName(indDemographicsnameTypeSupp);
            indDemographics.setSex(testInProductionWSCleintBO.getSex());
            
            //need to set fileds of Demographics
            individual.setDemographics(indDemographics);
            //Representative

            //Assertions
            RegisterPCEHR.Assertions assertions = getAsserationDetails(testInProductionWSCleintBO);
            
            if (testInProductionWSCleintBO.getIndividualType() != null &&
                testInProductionWSCleintBO.getIndividualType().equalsIgnoreCase("Dependent")) {


                Representative representative = getRpreseentaiveDetails(testInProductionWSCleintBO);
                //fields pf Representative

                //set Represetative for with registerPCEHR object
                registerPCEHR.setRepresentative(representative);
            }
            
            //   registerPCEHR.
            registerPCEHR.setIndividual(individual);

            registerPCEHR.setAssertions(assertions);

            //registerPCEHR.

            registerPCEHRPortType.registerPCEHR(registerPCEHR, responseDetail, header);
            //responseDetail=registerPCEHRPortType.registerPCEHR(registerPCEHR, header);
            LOG.debug("Leaving  register method");
            RegisterPCEHRResponse respone = null;
            if (responseDetail != null) {
                respone = responseDetail.value;

            }
            LOG.debug("Leaving  register method");
            return respone;

            // registerPCEHRPortType.r
        } catch (Exception e) {
            LOG.fatal("Exception...", e);
            throw e;
        }


    }

    /**
     *
     * @return
     */
    private Representative getRpreseentaiveDetails(RegisterPCEHRClientBO testInProductionWSCleintBO) {

        Representative representative = new Representative();
        //fields pf Representative
        Representative.Demographics arDemographics = new Representative.Demographics();
        //need to set fileds of Demographics
        NameTypeSupp arDemographicsnameTypeSupp = new NameTypeSupp();
        arDemographicsnameTypeSupp.setFamilyName(testInProductionWSCleintBO.getArLastName());
        arDemographics.setDateOfBirth((testInProductionWSCleintBO.getArDateOfBirth()));
        arDemographics.setName(arDemographicsnameTypeSupp);
        arDemographics.setSex(testInProductionWSCleintBO.getArSex());


        //list of authority is needed
        //clarifiactaion on document sighted and document details
        Representative.Authority arAuthoroity = new Representative.Authority();
        arAuthoroity.setAuthorityType(testInProductionWSCleintBO.getRelationshipType());
//        if (testInProductionWSCleintBO.getMedicareCardCheck() != null &&
//            testInProductionWSCleintBO.getMedicareCardCheck().equalsIgnoreCase("no")) {
        if(null!=testInProductionWSCleintBO.getDocumentSighted() && !testInProductionWSCleintBO.getDocumentSighted().equals(""))
           arAuthoroity.setAuthorityDocumentType(testInProductionWSCleintBO.getDocumentSighted());
        if(null!=testInProductionWSCleintBO.getDocDetail() && !testInProductionWSCleintBO.getDocDetail().equals(""))
            arAuthoroity.setIssuingAuthority(testInProductionWSCleintBO.getDocDetail());
              //arAuthoroity.setStartDate();
            arAuthoroity.setStartDate((testInProductionWSCleintBO.getAuthrityStartDate()));
            arAuthoroity.setEndDate((testInProductionWSCleintBO.getAuthrityEndDate()));
            arAuthoroity.setReviewDate((testInProductionWSCleintBO.getAuthrityReviewtDate()));
       // }
        //need to setfileds of authority
        representative.setIhiNumber(testInProductionWSCleintBO.getArIHI());
        representative.getAuthority().add(arAuthoroity);
        representative.setDemographics(arDemographics);
        return representative;

    }
/**
     *
     * @return
     */
    private RegisterPCEHR.Assertions getAsserationDetails(RegisterPCEHRClientBO testInProductionWSCleintBO) {
        RegisterPCEHR.Assertions assertions = new RegisterPCEHR.Assertions();
        //fields of assertions
        RegisterPCEHR.Assertions.Identity identity = new RegisterPCEHR.Assertions.Identity();
        if(testInProductionWSCleintBO.getHealthcareProviderAssertion()!=null && testInProductionWSCleintBO.getIndividualType().equals("Dependent")){
            String healthCareProviderassertion = testInProductionWSCleintBO.getHealthcareProviderAssertion();
            if(healthCareProviderassertion.equalsIgnoreCase("yes")){
                identity.setHealthcareProviderParentalAssertion(true);
            }else if(healthCareProviderassertion.equalsIgnoreCase("no")){
                identity.setHealthcareProviderParentalAssertion(false);
            }
        }
        //need clarification
        identity.setIndigenousStatus(INDIGENOUS_STATUS);
        RegisterPCEHR.Assertions.DocumentConsent documentConsent = new RegisterPCEHR.Assertions.DocumentConsent();
        //fileds of documentConsent
        RegisterPCEHR.Assertions.DocumentConsent.Document docMBS =
            new RegisterPCEHR.Assertions.DocumentConsent.Document();
        RegisterPCEHR.Assertions.DocumentConsent.Document docPBS =
            new RegisterPCEHR.Assertions.DocumentConsent.Document();
        RegisterPCEHR.Assertions.DocumentConsent.Document docAODR =
            new RegisterPCEHR.Assertions.DocumentConsent.Document();
        RegisterPCEHR.Assertions.DocumentConsent.Document docMBSPastAssimilation =
            new RegisterPCEHR.Assertions.DocumentConsent.Document();
        RegisterPCEHR.Assertions.DocumentConsent.Document docPBSPastAssimilation =
            new RegisterPCEHR.Assertions.DocumentConsent.Document();
        RegisterPCEHR.Assertions.DocumentConsent.Document docACIR =
            new RegisterPCEHR.Assertions.DocumentConsent.Document();


        docMBS.setType("MBS");
        if (testInProductionWSCleintBO.getMbsDVS() != null &&
            testInProductionWSCleintBO.getMbsDVS().equalsIgnoreCase("yes")) {
            docMBS.setStatus(CONSENT_GIVEN);
        }
        if (testInProductionWSCleintBO.getMbsDVS() != null &&
            testInProductionWSCleintBO.getMbsDVS().equalsIgnoreCase("no")) {
            docMBS.setStatus(CONSENT_NOT_GIVEN);
        }
        docPBS.setType("PBS");
        if (testInProductionWSCleintBO.getPbsRPBS() != null &&
            testInProductionWSCleintBO.getPbsRPBS().equalsIgnoreCase("yes")) {
            docPBS.setStatus(CONSENT_GIVEN);
        }
        if (testInProductionWSCleintBO.getPbsRPBS() != null &&
            testInProductionWSCleintBO.getPbsRPBS().equalsIgnoreCase("no")) {
            docPBS.setStatus(CONSENT_NOT_GIVEN);
        }
        docAODR.setType("AODR");
        if (testInProductionWSCleintBO.getAodr() != null &&
            testInProductionWSCleintBO.getAodr().equalsIgnoreCase("yes")) {
            docAODR.setStatus(CONSENT_GIVEN);
        }
        if (testInProductionWSCleintBO.getAodr() != null &&
            testInProductionWSCleintBO.getAodr().equalsIgnoreCase("no")) {
            docAODR.setStatus(CONSENT_NOT_GIVEN);
        }
        docMBSPastAssimilation.setType("MBSPastAssimilation");
        if (testInProductionWSCleintBO.getPastMBSdvs() != null &&
            testInProductionWSCleintBO.getPastMBSdvs().equalsIgnoreCase("yes")) {
            docMBSPastAssimilation.setStatus(CONSENT_GIVEN);
        }
        if (testInProductionWSCleintBO.getPastMBSdvs() != null &&
            testInProductionWSCleintBO.getPastMBSdvs().equalsIgnoreCase("no")) {
            docMBSPastAssimilation.setStatus(CONSENT_NOT_GIVEN);
        }
        docPBSPastAssimilation.setType("PBSPastAssimilation");
        if (testInProductionWSCleintBO.getPastPBSrpbs() != null &&
            testInProductionWSCleintBO.getPastPBSrpbs().equalsIgnoreCase("yes")) {
            docPBSPastAssimilation.setStatus(CONSENT_GIVEN);
        }
        if (testInProductionWSCleintBO.getPastPBSrpbs() != null &&
            testInProductionWSCleintBO.getPastPBSrpbs().equalsIgnoreCase("no")) {
            docPBSPastAssimilation.setStatus(CONSENT_NOT_GIVEN);
        }
        docACIR.setType("ACIR");
        if (testInProductionWSCleintBO.getAcir() != null &&
            testInProductionWSCleintBO.getAcir().equalsIgnoreCase("yes")) {
            docACIR.setStatus(CONSENT_GIVEN);
        }
        if (testInProductionWSCleintBO.getAcir() != null &&
            testInProductionWSCleintBO.getAcir().equalsIgnoreCase("no")) {
            docACIR.setStatus(CONSENT_NOT_GIVEN);
        }
        documentConsent.getDocument().add(docMBS);
        documentConsent.getDocument().add(docPBS);
        documentConsent.getDocument().add(docMBSPastAssimilation);
        documentConsent.getDocument().add(docPBSPastAssimilation);
        documentConsent.getDocument().add(docACIR);
        documentConsent.getDocument().add(docAODR);

        RegisterPCEHR.Assertions.IvcCorrespondence ivc = new RegisterPCEHR.Assertions.IvcCorrespondence();
        //chanel need clarification
        String notificationChannel = testInProductionWSCleintBO.getNotificationChannel();
        ivc.setChannel(notificationChannel);
        ContactDetailsType conatctDetailsType = new ContactDetailsType();
        if(notificationChannel.equals("sms")){
            conatctDetailsType.setMobilePhoneNumber(testInProductionWSCleintBO.getNotificationDetails());
        }else if(notificationChannel.equals("email")){
            conatctDetailsType.setEmailAddress(testInProductionWSCleintBO.getNotificationDetails());
        }else if(notificationChannel.equals("mail")){
            LOG.debug("setting NotificationLetterRequired for mail");
            assertions.setNotificationLetterRequired(true);
        }
        ivc.setContactDetails(conatctDetailsType);
        
        assertions.setIdentity(identity);
        assertions.setDocumentConsent(documentConsent);
        assertions.setIvcCorrespondence(ivc);
        
        //  assertions.setNotificationLetterRequired(true);
        //  assertions.setRepresentativeDeclaration(true);
        //required
        assertions.setAcceptedTermsAndConditions(true);
        if (testInProductionWSCleintBO.getIndividualType() != null &&
            testInProductionWSCleintBO.getIndividualType().equalsIgnoreCase("Dependent")) {
            assertions.setRepresentativeDeclaration(true);
        }
        return assertions;
    }

    /**
     *
     * @param testInProductionWSCleintBO
     * @return
     */
    public IntPCEHRHeader setHeader(RegisterPCEHRClientBO testInProductionWSCleintBO) {
        IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
        IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
        IntPCEHRHeader.User user = new IntPCEHRHeader.User();
        user.setIDType("LocalSystemIdentifier");
        //CHK
        LOG.debug("user id:::"+testInProductionWSCleintBO);
        LOG.debug("user id:::"+testInProductionWSCleintBO.getUserId());
        user.setID(testInProductionWSCleintBO.getUserId());
        user.setRole("PCEHR_SYSTEM_OPERATOR");  
        //CHK
        user.setUserName(testInProductionWSCleintBO.getUserId());
        user.setUseRoleForAudit(false);
        intPCEHRHeader.setUser(user);

        IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
        productType.setVendor("NIO");
        productType.setProductName("NIO Ops Tool");
        productType.setProductVersion(EndPointsConstants.PRODUCT_VERSION);
        productType.setPlatform("Windows");
        intPCEHRHeader.setProductType(productType);

        //CHK
        clientSystem.setSystemID(EndPointsConstants.HOST_NAME);
        clientSystem.setSystemType("Other");
        intPCEHRHeader.setClientSystem(clientSystem);

        intPCEHRHeader.setOverrideLogLevel(false);
        intPCEHRHeader.setIhiNumber(testInProductionWSCleintBO.getIhi());

        return intPCEHRHeader;
    }
}
