package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.bo.PNAUpdateNominateRepWSClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;

import au.pcehr.ws.pna.common.AccessType;
import au.pcehr.ws.pna.common.ApplicationResponse;
import au.pcehr.ws.pna.common.RelationshipStatus;
import au.pcehr.ws.pna.pd.PDUpdateNominatedRepresentativeRequest;
import au.pcehr.ws.pna.pd.PDUpdateNominatedRepresentativeResponse;
import au.pcehr.ws.pna.pd.PNAPCEHRUpdateNominatedRepresentative;
import au.pcehr.ws.pna.pd.PNAPCEHRUpdateNominatedRepresentativeWS;
import au.pcehr.ws.pna.pd.UpdateNominatedRepresentativeCommonParameters;
import au.pcehr.ws.pna.pd.UpdateNominatedRepresentativeFunctionParameters;
import au.pcehr.ws.pna.pd.UpdateNominatedRepresentativeParameterList;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.math.BigInteger;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;

import pcehr.recovery.LoggingHandler;
import pcehr.recovery.UtilConstants;


public class PNAUpdateNominateRepClient {
    
    @Autowired
    Decrypter decrypter;
    
    
    private static Logger LOG = Logger.getLogger(PNAUpdateNominateRepClient.class);
    
   private PNAUpdateNominateRepWSClientBO pnaUpdateNominateBo;;
    public void setPnaUpdateNominateBo(PNAUpdateNominateRepWSClientBO pnaUpdateNominateBo) {
        this.pnaUpdateNominateBo = pnaUpdateNominateBo;
    }

    public PNAUpdateNominateRepWSClientBO getPnaUpdateNominateBo() {
        return pnaUpdateNominateBo;
    }
    private StringBuffer soapMessage;
    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }
    /**
     *author sumanta
     * @return
     */
    public final ApplicationResponse update() {
        LOG.debug("Updating AR Status PNAUpdateNominateRepClient");
        
        PNAPCEHRUpdateNominatedRepresentativeWS pNAPCEHRUpdateNominatedRepresentativeWS;
        pNAPCEHRUpdateNominatedRepresentativeWS = new PNAPCEHRUpdateNominatedRepresentativeWS();
        pNAPCEHRUpdateNominatedRepresentativeWS.setHandlerResolver(new ClientHandlerResolver());
        PNAPCEHRUpdateNominatedRepresentative pNAPCEHRUpdateNominatedRepresentative;
        pNAPCEHRUpdateNominatedRepresentative = pNAPCEHRUpdateNominatedRepresentativeWS.getPNAPCEHRUpdateNominatedRepresentativePort();
        Map<String, Object> requestContext =
            ((BindingProvider) pNAPCEHRUpdateNominatedRepresentative).getRequestContext();
        
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.PNA_UPDATE_ENDPOINT);
        requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, new TestHostnameVerifier());
        requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_USERNAME));
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_PASSWORD));        
        XMLGregorianCalendar xgcal = null;
        try {
            GregorianCalendar gcal = new GregorianCalendar();
            xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
        } catch (Exception e) {
            System.out.println("Exception");
        }
        UpdateNominatedRepresentativeParameterList updateNominatedRepresentativeParameterList;
        updateNominatedRepresentativeParameterList = new UpdateNominatedRepresentativeParameterList();
        UpdateNominatedRepresentativeCommonParameters updateNominatedRepresentativeCommonParameters =
            new UpdateNominatedRepresentativeCommonParameters();
        BigInteger pcehrIdentity = new BigInteger(pnaUpdateNominateBo.getUserID());
        updateNominatedRepresentativeCommonParameters.setPcehrIdentity(pcehrIdentity);
        updateNominatedRepresentativeCommonParameters.setRecordIHI(pnaUpdateNominateBo.getIhi());
        updateNominatedRepresentativeCommonParameters.setSourceSystemID("Source System ID");
        updateNominatedRepresentativeCommonParameters.setTransactionID("Transaction ID");
        updateNominatedRepresentativeCommonParameters.setOldPreferredName(pnaUpdateNominateBo.getName());
        UpdateNominatedRepresentativeFunctionParameters updateNominatedRepresentativeFunctionParameters =
            new UpdateNominatedRepresentativeFunctionParameters();
        System.out.println("Acess type...."+pnaUpdateNominateBo.getAcc_type());
        if (pnaUpdateNominateBo.getAcc_type() == UtilConstants.VALUE_1) {
            System.out.println("Inside General");
            updateNominatedRepresentativeFunctionParameters.setAccessType(AccessType.GENERAL);
        } else if (pnaUpdateNominateBo.getAcc_type() == UtilConstants.VALUE_0) {
            updateNominatedRepresentativeFunctionParameters.setAccessType(AccessType.REVOKED);
        } else if (pnaUpdateNominateBo.getAcc_type() == UtilConstants.VALUE_2) {
            updateNominatedRepresentativeFunctionParameters.setAccessType(AccessType.LIMITED);
        }
        updateNominatedRepresentativeFunctionParameters.setRelationshipEndDate(xgcal);
        updateNominatedRepresentativeFunctionParameters.setRelationshipStatus(RelationshipStatus.IN_ACTIVE);
        updateNominatedRepresentativeParameterList.setCommonParameter(updateNominatedRepresentativeCommonParameters);
        updateNominatedRepresentativeParameterList.setFuncationParameter(updateNominatedRepresentativeFunctionParameters);
        PDUpdateNominatedRepresentativeRequest pDUpdateNominatedRepresentativeRequest;
        pDUpdateNominatedRepresentativeRequest = new PDUpdateNominatedRepresentativeRequest();
        pDUpdateNominatedRepresentativeRequest.setParameterList(updateNominatedRepresentativeParameterList);
        PDUpdateNominatedRepresentativeResponse pDUpdateNominatedRepresentativeResponse;
        pDUpdateNominatedRepresentativeResponse = pNAPCEHRUpdateNominatedRepresentative.pdUpdateNominatedRepresentative(pDUpdateNominatedRepresentativeRequest);
        ApplicationResponse applicationResponse = new ApplicationResponse();
        applicationResponse = pDUpdateNominatedRepresentativeResponse.getResultStatus();
        getSoapRequestMsg();
       LOG.debug("applicationResponse.getStatusCode().."+applicationResponse.getStatusCode());
        LOG.debug("applicationResponse.getStatusDescription().."+applicationResponse.getStatusDescription());
        return applicationResponse;
    }

    /**
     *
     * @return
     */
    private void getSoapRequestMsg(){
        StringBuffer soapMessagesg = new StringBuffer();
        soapMessagesg.setLength(0);
        if(null != LoggingHandler.lastSoapRequest) {
            soapMessagesg.append("PNA Update AR Status Request");
            soapMessagesg.append("\n" + LoggingHandler.lastSoapRequest.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
        } 
        if(null != LoggingHandler.lastSoapResponse) {
            soapMessagesg.append("---------------------------------------------------------");
            soapMessagesg.append("\n");
            soapMessagesg.append("\nPNA Update AR Status Response");
            soapMessagesg.append("\n" + LoggingHandler.lastSoapResponse.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
        }
      //  LOG.debug("LoggingHandler.lastSoapRequest"+LoggingHandler.lastSoapRequest);
        LOG.debug("soap response:::"+soapMessagesg.toString().replaceAll("&lt;", "<").replaceAll("&gt;", ">"));
        
        this.soapMessage = soapMessagesg;
    }

    


    /**
     * This class is to verify host name.
     */
    public static class TestHostnameVerifier implements HostnameVerifier {
        /**
         *
         * @param arg0
         * @param arg1
         * @return boolean
         */
        public final boolean verify(final String arg0, final SSLSession arg1) {
            return true;
        }
    }
    /**
     * This class is to handle the SOAP Request and Response.
     */
    public static class ClientHandlerResolver implements HandlerResolver {
        /**
         *
         * @param port_info
         * @return Handler
         */
        public final List<Handler> getHandlerChain(final PortInfo port_info) {
            List<Handler> handlerChain;
            handlerChain = new ArrayList<Handler>();
            LoggingHandler loggingHandler;
            loggingHandler = new LoggingHandler(UtilConstants.PNA);
            handlerChain.add(loggingHandler);
            return handlerChain;
        }
    }
}
