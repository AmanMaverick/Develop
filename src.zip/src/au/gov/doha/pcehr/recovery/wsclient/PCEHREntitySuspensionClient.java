package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.DisableEnableEntitiesForm;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.ws.pna.common.ApplicationResponse;
import au.pcehr.ws.pna.common.Status;
import au.pcehr.ws.pna.common.UserType;
import au.pcehr.ws.pna.pd.OIMDisableEntitiesRequest;
import au.pcehr.ws.pna.pd.OIMDisableEntitiesResponse;
import au.pcehr.ws.pna.pd.OIMEntityParams;
import au.pcehr.ws.pna.pd.PNA_PCEHR_OIM_disableEntities;
import au.pcehr.ws.pna.pd.PNA_PCEHR_OIM_disableEntitiesWS;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.Map;

import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PCEHREntitySuspensionClient {
    
    private static Logger LOG = Logger.getLogger(PCEHREntitySuspensionClient.class);
    @Autowired
    private SOAPMessageUtil soapMessageUtil;
    @Autowired
    private TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    private WSClientHandlerResolver wsClientHandlerResolver;
    
    @Autowired
    Decrypter decrypter;
    
    /**
     *
     * @param oIMDisableEntitiesRequest
     * @return
     */
    public DisableEnableEntitiesForm callPCEHREntitySuspensionClient(DisableEnableEntitiesForm disableEnableEntitiesBO, String entityId) throws RecoveryServiceException{
        OIMDisableEntitiesResponse response = null;
        

        try {
            
            OIMDisableEntitiesRequest oIMDisableEntitiesRequest = new OIMDisableEntitiesRequest();
            oIMDisableEntitiesRequest.setEntity(getOIMEntity(disableEnableEntitiesBO, entityId));
            LOG.debug("Entering doOimDisable method......");
            PNA_PCEHR_OIM_disableEntitiesWS pNAPCEHROIMDisableEntitiesWS = new PNA_PCEHR_OIM_disableEntitiesWS();
            pNAPCEHROIMDisableEntitiesWS.setHandlerResolver(wsClientHandlerResolver);
            PNA_PCEHR_OIM_disableEntities pNAPCEHROIMDisableEntities =
                pNAPCEHROIMDisableEntitiesWS.getPNA_PCEHR_OIM_disableEntitiesPort();
            BindingProvider bp = (BindingProvider)pNAPCEHROIMDisableEntities;
            Map<String, Object> requestContext = (Map<String, Object>)bp.getRequestContext();
            
            requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.PNA_OIM_DISABLE_ENDPOINT);
            requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_OIM_DISABLE_USERNAME));
            requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_OIM_DISABLE_PASSWORD));
            
            response = pNAPCEHROIMDisableEntities.pdoimDisableEntities(oIMDisableEntitiesRequest);


            ApplicationResponse applicationResponse = new ApplicationResponse();
            applicationResponse = response.getResultStatus();

            Map<String, Object> messageCtx = ((BindingProvider)pNAPCEHROIMDisableEntities).getResponseContext();
            String entitySoapMessage = soapMessageUtil.getSoapMessages(messageCtx);
            disableEnableEntitiesBO.setEntitySoapMessage(entitySoapMessage);
            disableEnableEntitiesBO.setSoapMessage(disableEnableEntitiesBO.getSoapMessage().append(entitySoapMessage));
            disableEnableEntitiesBO.setAlertMsg(disableEnableEntitiesBO.getAlertMsg().append( formAlertMessage(entityId,response.getResultStatus().getStatusDescription())));
            disableEnableEntitiesBO.setOimDisableEntitiesResponse(response);
            LOG.debug("Leaving doOimDisable method......");

        } catch (Exception e) {
            LOG.fatal("Exception occured.." ,e);
            throw new RecoveryServiceException(e);

        }
        return disableEnableEntitiesBO;
    }
    
    
    /**
     *
     * @param entityType
     * @return
     */
    public OIMEntityParams getOIMEntity(DisableEnableEntitiesForm disableEnableEntitiesBO, String entityId) {
        OIMEntityParams oIMEntityParams = new OIMEntityParams();
        String entityType = disableEnableEntitiesBO.getEntityType();
        String status = disableEnableEntitiesBO.getStatus();
        if ("HPIO".equals(entityType)) {
            oIMEntityParams.setEntityType(UserType.HPIO);
        } else if ("HPII".equals(entityType)) {
            oIMEntityParams.setEntityType(UserType.HPII);
        } else if ("CSP".equals(entityType)) {
            oIMEntityParams.setEntityType(UserType.CSP);
        } else if ("RRO".equals(entityType)) {
            oIMEntityParams.setEntityType(UserType.CRP);
        } else if ("ADMINPORTALLOGIN".equals(entityType)) {
            oIMEntityParams.setEntityType(UserType.ADMIN_PORTAL_USER);
        } else if ("REPORTINGPORTALLOGIN".equals(entityType)) {
            oIMEntityParams.setEntityType(UserType.REPORTING_PORTAL_USER);
        } else if ("TEMPLATEPORTALLOGIN".equals(entityType)) {
            oIMEntityParams.setEntityType(UserType.TEMPLATE_PORTAL_USER);
        }else if("MBUN".equals(entityType)){
            oIMEntityParams.setEntityType(UserType.CONSUMER_PORTAL_USER);
        }else if("CISSOFTWAREVERSION".equals(entityType)){
            oIMEntityParams.setEntityType(UserType.CIS);
        }
        
        oIMEntityParams.setEntityID(entityId);
        oIMEntityParams.setStatus(("DISABLE".equals(status)) ? Status.DISABLE : Status.ENABLE);
        return oIMEntityParams;
    }
    
    private StringBuffer formAlertMessage(String key,String value){
        StringBuffer alertMsg = new StringBuffer();
        alertMsg.setLength(0);
        alertMsg.append(key);
        alertMsg.append(":");
        alertMsg.append(value);
        alertMsg.append("\n");
        return alertMsg;
    }
    
}
