package au.gov.doha.pcehr.recovery.wsclient;


//import au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.UnremoveDocumentPortType;


//import au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.UnremoveDocumentClient;
//import au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.UnremoveDocumentPortTypeClient;


//import au.gov.doha.pcehr.recovery.wsclient.DocumentRemovalClient.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.bo.DocumentReinstateBO;
import au.gov.doha.pcehr.recovery.bo.DocumentReinstateErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentReinstateWSClientBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalWSClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.StandardError;
import au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.UnremoveDocument;
import au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.UnremoveDocumentPortType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.unremovedocument._1.UnremoveDocumentResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 *@author Sumanta.kumar.saha
 *This class is used to handle the client request for Reinstate of a document
 */
@Service
public class DocumentReinstateClient {
    @Autowired
    TestHostnameVerifier testHostnameVerifier;

    @Autowired
    WSClientHandlerResolver wSClientHandlerResolver;
    @Autowired
    SOAPMessageUtil soapMessageUtil;
    @Autowired
    FileUtil fileUtil;
    @Autowired
    Decrypter decrypter;
    
    private static Logger LOG = Logger.getLogger(DocumentReinstateClient.class);

   
    private String soapMessage;

  

    public void setSoapMessage(String soapMessage) {
        this.soapMessage = soapMessage;
    }

    public String getSoapMessage() {
        return soapMessage;
    }

    /**
     *
     * @return
     * @throws StandardError
     * @throws WebServiceClientException
     */
  /*  public ResponseStatusType reinstate(DocumentRemovalBO documentReinstateBO,DocumentReinstateWSClientBO documentReinstateWSClientBO, String removalType) throws StandardError, WebServiceClientException {
        //        LOG.debug("entering reinstate");

        //unremove new jar
        ResponseStatusType responseStatusType = null;
        StringBuffer response = new StringBuffer();
        UnremoveDocument unremoveDocument = new UnremoveDocument();
        unremoveDocument.setHandlerResolver(wSClientHandlerResolver);
        UnremoveDocumentPortType unremoveDocumentPortType =
            unremoveDocument.getUnremoveDocumentSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true, true));
        Map<String, Object> ctxt = ((BindingProvider) unremoveDocumentPortType).getRequestContext();
        
        LOG.debug(EndPointsConstants.UNREMOVE_DOC_ENDPOINT);

        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.UNREMOVE_DOC_ENDPOINT);
        ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
        ctxt.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
        ctxt.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD));


        au.net.electronichealth.ns.pcehr.xsd.interfaces.unremovedocument._1.UnremoveDocument unRemove =
            new au.net.electronichealth.ns.pcehr.xsd.interfaces.unremovedocument._1.UnremoveDocument();
        unRemove.setDocumentID(documentReinstateWSClientBO.getDocId());
        IntPCEHRHeader intPCEHRHeader = setHeader(documentReinstateWSClientBO);
        Holder<UnremoveDocumentResponse> holder = new Holder<UnremoveDocumentResponse>();
        UnremoveDocumentResponse urdr = new UnremoveDocumentResponse();
        //CHK
        urdr.setResponseStatus(responseStatusType);
        holder.value = urdr;
        Map<String, Object> messageCtx = null;
        try {
            unremoveDocumentPortType.unremoveDocument(unRemove, holder, intPCEHRHeader);
            urdr = holder.value;
            responseStatusType = urdr.getResponseStatus();
            messageCtx = ((BindingProvider) unremoveDocumentPortType).getResponseContext();
            getSoapReqRes(messageCtx);
        } catch (au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.StandardError error) {
            // getSoapRequestMsg();
                        
                        

            LOG.fatal("here....exception" + error);
            LOG.fatal("here....exception" + error.getFaultInfo().getMessage());
            messageCtx = ((BindingProvider) unremoveDocumentPortType).getResponseContext();
            LOG.debug("REINST%%%%%%%%%%%%%%"+messageCtx);
            getSoapReqRes(messageCtx);
            response.append("\n");

            response.append("\nError Message :" + error.getFaultInfo().getMessage());

            response.append("\n");
            throw new WebServiceClientException(response.toString(), error);

        }
        LOG.debug("response status" + responseStatusType.getDescription());

        return responseStatusType;
    }**/
    
    /**
     *
     * @return
     * @throws StandardError
     * @throws WebServiceClientException
     */
    public DocumentReinstateBO reinstate2(DocumentReinstateBO documentReinstateBO, DocumentReinstateWSClientBO documentReinstateWSClientBO, String removalType) throws StandardError, WebServiceClientException {
                       LOG.debug("entering reinstate in DocumentReinstate Client");
               ResponseStatusType responseStatusType = null;
               StringBuffer response = new StringBuffer();
               UnremoveDocument unremoveDocument = new UnremoveDocument();
               unremoveDocument.setHandlerResolver(wSClientHandlerResolver);
               UnremoveDocumentPortType unremoveDocumentPortType =
                   unremoveDocument.getUnremoveDocumentSOAP12Port(new javax.xml.ws.soap.AddressingFeature(true, true));
                               
                       //soap message
               // SOAPMessageContext sOAPMessageContext        
               Map<String, Object> ctxt = ((BindingProvider) unremoveDocumentPortType).getRequestContext();
               
               LOG.debug(EndPointsConstants.UNREMOVE_DOC_ENDPOINT);

               ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.UNREMOVE_DOC_ENDPOINT);
               ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
               ctxt.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
               ctxt.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD));


               au.net.electronichealth.ns.pcehr.xsd.interfaces.unremovedocument._1.UnremoveDocument unRemove =
                   new au.net.electronichealth.ns.pcehr.xsd.interfaces.unremovedocument._1.UnremoveDocument();
               unRemove.setDocumentID(documentReinstateWSClientBO.getDocId());
                       //IHI
               IntPCEHRHeader intPCEHRHeader = setHeader(documentReinstateWSClientBO);
               Holder<UnremoveDocumentResponse> holder = new Holder<UnremoveDocumentResponse>();
               UnremoveDocumentResponse urdr = new UnremoveDocumentResponse();
               //CHK
               urdr.setResponseStatus(responseStatusType);
               holder.value = urdr;
               Map<String, Object> messageCtx = null;
               try {
                   unremoveDocumentPortType.unremoveDocument(unRemove, holder, intPCEHRHeader);
                   urdr = holder.value;
                   responseStatusType = urdr.getResponseStatus();
                   messageCtx = ((BindingProvider) unremoveDocumentPortType).getResponseContext();
                   getSoapReqRes(messageCtx);
                               //for success pass message
                   if(removalType.equals("bulk")){                      
                    DocumentReinstateErrorBO bo=fileUtil.createDocumentReinstateErrorBO(documentReinstateWSClientBO.getIhi(), documentReinstateWSClientBO.getDocId(), "PASS", responseStatusType.getDescription());
                 if(documentReinstateBO.getListDocReinstateErrorBO()!=null){    
                     documentReinstateBO.getListDocReinstateErrorBO().add(bo);
                 }
                 else{
                     List<DocumentReinstateErrorBO> listDocReinstateErrorBO=new ArrayList<DocumentReinstateErrorBO>();
                     listDocReinstateErrorBO.add(bo);
                     documentReinstateBO.getListDocReinstateErrorBO().add(bo);
                 }
                   }
               } catch (au.net.electronichealth.ns.pcehr.svc.intunremovedocument._1.StandardError error) {
                   // getSoapRequestMsg();
                   LOG.fatal("here....exception" + error);
                   LOG.fatal("here....exception" + error.getFaultInfo().getMessage());
                   messageCtx = ((BindingProvider) unremoveDocumentPortType).getResponseContext();
                   getSoapReqRes(messageCtx);
                         //for pcehr error
                if(removalType.equals("bulk")){      
                 DocumentReinstateErrorBO bo=fileUtil.createDocumentReinstateErrorBO(documentReinstateWSClientBO.getIhi(), documentReinstateWSClientBO.getDocId(), "FAIL", error.getFaultInfo().getMessage());
                 if(documentReinstateBO.getListDocReinstateErrorBO()!=null){
                      LOG.debug("ERROR BO CREATING::::");
                      documentReinstateBO.getListDocReinstateErrorBO().add(bo);
                 }
                 else{
                     LOG.debug("ERROR BO CREATING null::::");
                     List<DocumentReinstateErrorBO> listDocReinstateErrorBO=new ArrayList<DocumentReinstateErrorBO>();
                     listDocReinstateErrorBO.add(bo);
                     documentReinstateBO.getListDocReinstateErrorBO().add(bo);
                 }
                   }
                    else{
                    response.append("\n");
                    response.append("\nError Message :" + error.getFaultInfo().getMessage());
                    response.append("\n");
                   throw new WebServiceClientException(response.toString(), error);
                               }
               }catch (Exception e) {
                   LOG.fatal("exception::..." + e);
                   //for genral exception
                   if(removalType.equals("bulk")){
                   LOG.debug("Inside Bulk Reinstate FAIL!!!");
                   DocumentReinstateErrorBO bo=fileUtil.createDocumentReinstateErrorBO(documentReinstateWSClientBO.getIhi(), documentReinstateWSClientBO.getDocId(), "FAIL", e.getMessage());
                   if(documentReinstateBO.getListDocReinstateErrorBO()!=null){
                       documentReinstateBO.getListDocReinstateErrorBO().add(bo);
                   }
                   else{
                       List<DocumentReinstateErrorBO> listDocReinstateErrorBO=new ArrayList<DocumentReinstateErrorBO>();
                       listDocReinstateErrorBO.add(bo);
                       documentReinstateBO.getListDocReinstateErrorBO().add(bo);
                   }
               }
               }
                if(responseStatusType!=null){
                documentReinstateBO.setResponseCode(responseStatusType.getCode());
                documentReinstateBO.setResponseDescription(responseStatusType.getDescription());
               LOG.debug("response status" + responseStatusType.getDescription());
                        }
                         LOG.debug("Leaving remove in DocumentReinstateClient ");
            return documentReinstateBO;
           
           }

    /**
     *
     * @param ihi
     * @return
     */

    public IntPCEHRHeader setHeader(DocumentReinstateWSClientBO documentReinstateWSClientBO) {
        HttpServletRequest req =
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String userName = req.getUserPrincipal().getName();
        IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
        IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
        IntPCEHRHeader.User user = new IntPCEHRHeader.User();
        user.setIDType("LocalSystemIdentifier");
        //CHK
        user.setID("00000000");
        user.setRole("PCEHR_SYSTEM_OPERATOR");
        //CHK
        user.setUserName(userName);
        user.setUseRoleForAudit(false);
        intPCEHRHeader.setUser(user);

        IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
        productType.setVendor("NIO");
        productType.setProductName("Ops Tool");
        productType.setProductVersion("1.0");
        productType.setPlatform("Jump Host");
        intPCEHRHeader.setProductType(productType);

        //CHK
        clientSystem.setSystemID(EndPointsConstants.HOST_NAME);
        clientSystem.setSystemType("Admin");
        intPCEHRHeader.setClientSystem(clientSystem);

        intPCEHRHeader.setOverrideLogLevel(false);
        intPCEHRHeader.setIhiNumber(documentReinstateWSClientBO.getIhi());
        return intPCEHRHeader;
    }

 /*      public IntPCEHRHeader setHeader(String ihi) {
        HttpServletRequest req =
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String userName = req.getUserPrincipal().getName();
        IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
        IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
        IntPCEHRHeader.User user = new IntPCEHRHeader.User();
        user.setIDType("LocalSystemIdentifier");
        //CHK
        user.setID("00000000");
        user.setRole("PCEHR_SYSTEM_OPERATOR");
        //CHK
        user.setUserName(userName);
        user.setUseRoleForAudit(false);
        intPCEHRHeader.setUser(user);

        IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
        productType.setVendor("NIO");
        productType.setProductName("Ops Tool");
        productType.setProductVersion("1.0");
        productType.setPlatform("Jump Host");
        intPCEHRHeader.setProductType(productType);

        //CHK
        clientSystem.setSystemID(EndPointsConstants.HOST_NAME);
        clientSystem.setSystemType("Admin");
        intPCEHRHeader.setClientSystem(clientSystem);

        intPCEHRHeader.setOverrideLogLevel(false);
        intPCEHRHeader.setIhiNumber(ihi);
        return intPCEHRHeader;
    }**/

    /**
     *
     * @return
     */
    private void getSoapReqRes(Map<String, Object> messageCtx) {


        this.soapMessage = soapMessageUtil.getSoapMessages(messageCtx);
    }
}
