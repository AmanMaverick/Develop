package au.gov.doha.pcehr.recovery.wsclient;


import au.gov.doha.pcehr.recovery.bo.ARrestrictionBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.SOAPMessageUtil;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.ws.pna.common.Action;
import au.pcehr.ws.pna.common.ApplicationResponse;
import au.pcehr.ws.pna.pd.PDSetARRestrictionRequest;
import au.pcehr.ws.pna.pd.PDSetARRestrictionResponse;
import au.pcehr.ws.pna.pd.PNAPCEHRSetARRestriction;
import au.pcehr.ws.pna.pd.PNAPCEHRSetARRestrictionWS;
import au.pcehr.ws.pna.pd.SetARRestrictionCommonParameters;
import au.pcehr.ws.pna.pd.SetARRestrictionFunctionParameters;
import au.pcehr.ws.pna.pd.SetARRestrictionParameterList;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * This class is proxy for PNA Create Authorized Representatives Webservice.
 * @autor Vikash Kumar Singh, AO, PCEHR
 */
@Component
public class PNAARRestricterClient {
    
    private static Logger log = Logger.getLogger(PNAARRestricterClient.class);
    
    @Autowired
    private TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    private WSClientHandlerResolver wsClientHandlerResolver;
    
    @Autowired
    private SOAPMessageUtil soapMessageUtil;
    
    @Autowired
    Decrypter decrypter;
    
    private String soapMessage;


    public String getSoapMessage() {
        return soapMessage;
    }

    /**
     *
     * @param aRrestrictBO
     * @return
     */
    public final ApplicationResponse pnaPCEHRPNA_ARRestricter(ARrestrictionBO arRestrictionBO, String expiryDateFormat) throws ParseException,
                                                                                                      DatatypeConfigurationException,
                                                                                                      Exception {
           log.debug("inside pnaPCEHRPNA_ARRestricter");
           PNAPCEHRSetARRestrictionWS pNAPCEHRSetARRestrictionWS = new PNAPCEHRSetARRestrictionWS();
           pNAPCEHRSetARRestrictionWS.setHandlerResolver(wsClientHandlerResolver);
           PNAPCEHRSetARRestriction pNAPCEHRSetARRestriction = pNAPCEHRSetARRestrictionWS.getPNAPCEHRSetARRestrictionPort();
           Map<String, Object> requestContext = ((BindingProvider)pNAPCEHRSetARRestriction).getRequestContext();
           
           requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.PNA_AR_RESTRICT_ENDPOINT);
           requestContext.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
           requestContext.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_USERNAME));
           requestContext.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.PNA_PASSWORD));
           SetARRestrictionCommonParameters setARRestrictionCommonParameters = new SetARRestrictionCommonParameters();
           setARRestrictionCommonParameters.setIHI(arRestrictionBO.getIHI());
           if(arRestrictionBO.getActionType().equals("CREATE"))
               setARRestrictionCommonParameters.setAction(Action.CREATE);
           else
           if(arRestrictionBO.getActionType().equals("UPDATE"))
               setARRestrictionCommonParameters.setAction(Action.UPDATE);
           else
           if(arRestrictionBO.getActionType().equals("REMOVE"))
               setARRestrictionCommonParameters.setAction(Action.REMOVE);
           SetARRestrictionFunctionParameters setARRestrictionFunctionParameters = new SetARRestrictionFunctionParameters();
           setARRestrictionFunctionParameters.setExpiryDate(getexpiredate(arRestrictionBO.getExpireDate(), expiryDateFormat));
           setARRestrictionFunctionParameters.setJiraID(arRestrictionBO.getJiraId());
           SetARRestrictionParameterList setARRestrictionParameterList = new SetARRestrictionParameterList();
           setARRestrictionParameterList.setCommonParameters(setARRestrictionCommonParameters);
           setARRestrictionParameterList.setFunctionalParameters(setARRestrictionFunctionParameters);
           PDSetARRestrictionRequest setARRestrictionRequest = new PDSetARRestrictionRequest();
           setARRestrictionRequest.setParameterList(setARRestrictionParameterList);
           PDSetARRestrictionResponse setARRestrictionResponse = pNAPCEHRSetARRestriction.pDsetARRestriction(setARRestrictionRequest);
           ApplicationResponse applicationResponse = new ApplicationResponse();
           applicationResponse = setARRestrictionResponse.getResultStatus();
           //Map<String, Object> messageCtx = ((BindingProvider)pNAPCEHRSetARRestriction).getResponseContext();
           //this.soapMessage = soapMessageUtil.getSoapMessages(messageCtx);
           return applicationResponse;
       }
    
    /**
     *This method is to convert user input date to Gregorian Calendar date.
     * @param date
     * @return XMLGregorianCalendar
     */
    public XMLGregorianCalendar getexpiredate(final String date, String expiryDateFormat) {
        XMLGregorianCalendar xmlgcal = null;
        try {
            SimpleDateFormat format = new SimpleDateFormat(expiryDateFormat);
            Date date1 = format.parse(date);
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTime(date1);
            xmlgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
        } catch (Exception e) {
            e.getStackTrace();
        }
        return xmlgcal;
    }
}

