package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.bo.UpdateDocuementStatusClientBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.pcehr.docx.internal.ApplicationResponse;
import au.pcehr.docx.internal.DeprecateAtomicData;
import au.pcehr.docx.internal.DeprecateAtomicDataResponse;
import au.pcehr.docx.internal.DocXInternalPortType;
import au.pcehr.docx.internal.DocXInternalService;
import au.pcehr.docx.internal.ReactivateAtomicData;
import au.pcehr.docx.internal.ReactivateAtomicDataResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.net.URL;

import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceException;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * This webservice client handles deprication and reactivation of atomic data in HDR.
 * @author Sapna
 */
@Service
public class UpdateDocuementStatusClient {
    private static Logger LOG = Logger.getLogger(UpdateDocuementStatusClient.class);
    @Autowired
        Decrypter decrypter;

        @Autowired
        TestHostnameVerifier testHostnameVerifier;

        @Autowired
        WSClientHandlerResolver wsClientHandlerResolver;
    /**
     *
     * @param updateDocuementStatusClientBO
     * @return
     * @throws ErrorFaultMessage
     */
    public final ApplicationResponse executeDeprecateAtomicData(UpdateDocuementStatusClientBO updateDocuementStatusClientBO) throws WebServiceException {
       // DecryptString decrypt = new DecryptString();
     
        DeprecateAtomicDataResponse response = null;
        try {
            
            URL url =
                        new URL("https://localhost:4444/DocXInternalWSAb/DocXInternalService/#%7Burn%3Ainternal.docx.pcehr.au%7DDocXInternalService?wsdl");
                       QName qname = new QName("urn:internal.docx.pcehr.au", "DocXInternalService");   
                       
                       

                       DocXInternalService hTBPCEHRInternalWS = new DocXInternalService(url,qname); 


            hTBPCEHRInternalWS.setHandlerResolver(wsClientHandlerResolver);
            DocXInternalPortType hTBPCEHRInternalPort = hTBPCEHRInternalWS.getDocXInternalPort();


            Map<String, Object> ctxt = ((BindingProvider) hTBPCEHRInternalPort).getRequestContext();
            ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.DEPRECATE_ATOMIC_DATA_ENDPOINT);
            ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            ctxt.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.HTB_USERNAME));
            ctxt.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.HTB_PASSWORD));

            DeprecateAtomicData deprecateAtomicData = new DeprecateAtomicData();
            DeprecateAtomicData.InputProperties inputProperties = new DeprecateAtomicData.InputProperties();
                        DeprecateAtomicData.InputProperties.Entry entry = new DeprecateAtomicData.InputProperties.Entry();
                        entry.setKey("ihi");
                        entry.setValue("1.2.36.1.2001.1003.0."+updateDocuementStatusClientBO.getIhi());
                        inputProperties.getEntry().add(entry);
                        deprecateAtomicData.setInputProperties(inputProperties);
                        deprecateAtomicData.setDocumentId(updateDocuementStatusClientBO.getDocID());

                        response = hTBPCEHRInternalPort.deprecateAtomicData(deprecateAtomicData);
        
            return response.getApplicationResponse();
                    }catch (Exception e) {
                        LOG.fatal("exception ...", e);
                        throw new WebServiceException(e);
                    }
                    
                
}

    /**
     *
     * @param updateDocuementStatusClientBO
     * @return
     * @throws ErrorFaultMessage
     */
    public final ApplicationResponse executeReactivateAtomicData(UpdateDocuementStatusClientBO updateDocuementStatusClientBO) throws WebServiceException {
        
       
        try {
            LOG.debug(" enetring executeDeprecateAtomicData.......Sapna");


            URL url =
                       new URL("https://localhost:4444/DocXInternalWSAb/DocXInternalService/#%7Burn%3Ainternal.docx.pcehr.au%7DDocXInternalService?wsdl");
                       QName qname = new QName("urn:internal.docx.pcehr.au", "DocXInternalService");   
            
            DocXInternalService hTBPCEHRInternalWS = new DocXInternalService(url,qname); 

            hTBPCEHRInternalWS.setHandlerResolver(wsClientHandlerResolver);
            DocXInternalPortType hTBPCEHRInternalPort = hTBPCEHRInternalWS.getDocXInternalPort();


            Map<String, Object> ctxt = ((BindingProvider) hTBPCEHRInternalPort).getRequestContext();
            ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.DEPRECATE_ATOMIC_DATA_ENDPOINT);
            ctxt.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            ctxt.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.HTB_USERNAME));
            ctxt.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.HTB_PASSWORD));

            ReactivateAtomicData reactivateAtomicData = new ReactivateAtomicData();
                        
                        
                        ReactivateAtomicData.InputProperties inputProperties = new ReactivateAtomicData.InputProperties();
                        ReactivateAtomicData.InputProperties.Entry entry = new ReactivateAtomicData.InputProperties.Entry();
                        
                        entry.setKey("ihi");
                        entry.setValue("1.2.36.1.2001.1003.0."+updateDocuementStatusClientBO.getIhi());
                        inputProperties.getEntry().add(entry);
                        reactivateAtomicData.setInputProperties(inputProperties);
                        reactivateAtomicData.setDocumentId(updateDocuementStatusClientBO.getDocID());

                       ReactivateAtomicDataResponse response = hTBPCEHRInternalPort.reactivateAtomicData(reactivateAtomicData);
                        return response.getApplicationResponse();
                    }catch (Exception e) {
                        LOG.fatal("exception ...", e);
                        throw new WebServiceException(e);
                    }
                    
                }
}

   