package au.gov.doha.pcehr.recovery.wsclient;

import au.gov.doha.pcehr.recovery.bo.SearchIHIBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.Decrypter;
import au.gov.doha.pcehr.recovery.util.TestHostnameVerifier;
import au.gov.doha.pcehr.recovery.wsclient.handlerResolver.WSClientHandlerResolver;

import au.net.electronichealth.ns.pcehr.svc.intsearchihi._1.SearchIHI;
import au.net.electronichealth.ns.pcehr.svc.intsearchihi._1.SearchIHIPortType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.NameTypeSupp;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHIResponse;

import com.sun.xml.ws.developer.JAXWSProperties;

import java.net.URL;

import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pcehr.recovery.LoggingHandler;

/**
 * This class Client for the OSB service Search IHI based on the demographics details.
 * @author Sapna
 */
@Service
public class SearchIHIClient {
    private static Logger LOG = Logger.getLogger(SearchIHIClient.class);
    
    @Autowired
    Decrypter decrypter;
    
    @Autowired
    private TestHostnameVerifier testHostnameVerifier;
    
    @Autowired
    private WSClientHandlerResolver wsClientHandlerResolver;
    
    @Autowired
    DateTimeUtil dateTimeUtil;
    /**
     * This method Calls of OSB search IHI webservice client.
     * @param searchIHIBO
     */
    public SearchIHIResponse searchIHI(SearchIHIBO searchIHIBO) throws WebServiceClientException{
        SearchIHIResponse res = null;
        try{
            LOG.debug("SEARCH_IHI_END_POINT"+EndPointsConstants.SEARCH_IHI);
            URL url =new URL("http://localhost:8011/#%7Bhttp%3A%2F%2Fns.electronichealth.net.au%2Fpcehr%2Fsvc%2FintSearchIHI%2F1.0%7DsearchIHI?wsdl");
            QName qname = new QName("http://ns.electronichealth.net.au/pcehr/svc/intSearchIHI/1.0", "searchIHI");
            SearchIHI searchIHI = new SearchIHI(url,qname);
            searchIHI.setHandlerResolver(wsClientHandlerResolver);
         
            
         
            SearchIHIPortType searchIHIPortType = searchIHI.getSearchIHISOAP12Port(new javax.xml.ws.soap.AddressingFeature(true, true));
            //BinndingProvider
            Map<String, Object> ctx = ((BindingProvider) searchIHIPortType).getRequestContext();
            ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, EndPointsConstants.SEARCH_IHI);
            ctx.put(JAXWSProperties.HOSTNAME_VERIFIER, testHostnameVerifier);
            ctx.put(BindingProvider.USERNAME_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_USERNAME));
            ctx.put(BindingProvider.PASSWORD_PROPERTY, decrypter.decryption(EndPointsConstants.OSB_PASSWORD));

            IntPCEHRHeader intPCEHRHeader = getINTPCEHRHeader(searchIHIBO);
            au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHI searchIHIReq = new au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHI();
            au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHI.Individual individual = new au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHI.Individual();
            searchIHIReq.setIndividual(getIndividual(searchIHIBO));
            Holder<SearchIHIResponse> holder = new Holder<SearchIHIResponse>();
            searchIHIPortType.searchIHI(searchIHIReq, holder, intPCEHRHeader);
            if(holder!=null){
               res = holder.value;
            }
        }catch(au.net.electronichealth.ns.pcehr.svc.intsearchihi._1.StandardError standError) {
            LOG.fatal("Exception occured",standError);
            throw new WebServiceClientException(standError.getMessage(),standError);
                                      
        }catch(Exception e){
            getSoapRequestMsg();
            LOG.fatal("Exception occured..",e);
        }
        return res;
    }
    
    /**
     * Get individual details.
     * @param searchIHIBO
     * @return
     */
    private NameTypeSupp getName(SearchIHIBO searchIHIBO){
        
        NameTypeSupp nameDtl = new NameTypeSupp();
        nameDtl.setFamilyName(searchIHIBO.getLastName());
        return nameDtl;
    }
    
    /**
     * Get individual details.
     * @param searchIHIBO
     * @return
     */
    private au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHI.Individual getIndividual(SearchIHIBO searchIHIBO) throws WebServiceClientException{
        au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHI.Individual individual = null;
        try{
            individual = new au.net.electronichealth.ns.pcehr.xsd.interfaces.searchihi._1.SearchIHI.Individual();
            individual.setSex(searchIHIBO.getSex());
            
            XMLGregorianCalendar date = dateTimeUtil.getXMLGregorianCalendar(searchIHIBO.getDateOfBirth());
            individual.setDateOfBirth(date);
            individual.setName(getName(searchIHIBO));
        } catch(Exception e){
            LOG.fatal("Exception occured",e);
          throw new WebServiceClientException(e);  
        }
        return individual;    
    }
    /**
     * This method sets the PCEHR header
     * @param testInProductionWSCleintBO
     * @return
     */
    public IntPCEHRHeader getINTPCEHRHeader(SearchIHIBO searchIHIBO) {
        IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
        IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
        IntPCEHRHeader.User user = new IntPCEHRHeader.User();
        user.setID(searchIHIBO.getUserID());
        user.setIDType(searchIHIBO.getIdType());
        user.setRole(searchIHIBO.getRole());  
        user.setUserName(searchIHIBO.getUserID());
        user.setUseRoleForAudit(searchIHIBO.isUseRoleForAudit());
        intPCEHRHeader.setUser(user);

        IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
        productType.setVendor(searchIHIBO.getVendor());
        productType.setProductName(searchIHIBO.getProductName());
        productType.setProductVersion(searchIHIBO.getProductVersion());
        productType.setPlatform(searchIHIBO.getPlatform());
        intPCEHRHeader.setProductType(productType);


        clientSystem.setSystemID(searchIHIBO.getSystemID());
        clientSystem.setSystemType("Other");
        intPCEHRHeader.setClientSystem(clientSystem);

        intPCEHRHeader.setOverrideLogLevel(searchIHIBO.getOverrideLogLevel());
        intPCEHRHeader.setIhiNumber(searchIHIBO.getIhi());
        return intPCEHRHeader;
    }
//    /**
//     * This class is to verify host name.
//     */
//    public static class TestHostnameVerifier implements HostnameVerifier {
//        /**
//         *
//         * @param arg0
//         * @param arg1
//         * @return boolean
//         */
//        public final boolean verify(final String arg0, final SSLSession arg1) {
//            return true;
//        }
//    }
//
//    /**
//     * This class is to handle the SOAP Request and Response.
//     */
//    public static class ClientHandlerResolver implements HandlerResolver {
//        /**
//         *
//         * @param port_info
//         * @return Handler
//         */
//        public final List<Handler> getHandlerChain(final PortInfo port_info) {
//            List<Handler> handlerChain;
//            handlerChain = new ArrayList<Handler>();
//            LoggingHandler loggingHandler;
//            loggingHandler = new LoggingHandler(UtilConstants.OSB_REGISTER_PCEHR);
//            handlerChain.add(loggingHandler);
//            return handlerChain;
//        }
//    }

    /**
     *
     */
    private void getSoapRequestMsg() {
        StringBuffer soapMessagesg = new StringBuffer();
        soapMessagesg.setLength(0);
        if (null != LoggingHandler.lastSoapRequest) {
            soapMessagesg.append("Register PCEHR Request ");
            soapMessagesg.append("\n" + LoggingHandler.lastSoapRequest.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
            LOG.debug("soap request " + LoggingHandler.lastSoapRequest.replaceAll("&lt;", "<").replaceAll("&gt;", ">"));
            LOG.debug("Completed there **************************");
        }
        if (null != LoggingHandler.lastSoapResponse) {
            soapMessagesg.append("\n");
            soapMessagesg.append("\nRegister PCEHR Response");
            soapMessagesg.append("\n" +
                                 LoggingHandler.lastSoapResponse.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
        }
        LOG.debug("soap response New:::" + soapMessagesg.toString().replaceAll("&lt;", "<").replaceAll("&gt;", ">"));

        
    }

}
