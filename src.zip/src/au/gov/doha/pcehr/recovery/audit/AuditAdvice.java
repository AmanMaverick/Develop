package au.gov.doha.pcehr.recovery.audit;


import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


@Aspect
public class AuditAdvice {
    
    final Logger LOG = LoggerFactory.getLogger("AuditLogFile");
    @Before("execution(  public String au.gov.doha.pcehr.recovery.controller.*Controller.*(..))&& @annotation(auditAnnotation)) ")
    public void myBeforeLogger(AuditBefore auditAnnotation){
        /**
        On every request, the DispatcherServlet binds the current HttpServletRequest to a static ThreadLocal object in 
        the RequestContextHolder. You can retrieve it when executing within the same Thread
        **/
        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String currentUser = (req!=null && req.getUserPrincipal()!=null) ? req.getUserPrincipal().getName():"Session Timeout";
        LOG.error(" {} - {}", auditAnnotation.value(), currentUser);
        
    }
    
}
