package au.gov.doha.pcehr.recovery.servlets;

import au.gov.doha.pcehr.recovery.dao.IdentityRemovalDao;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class UserController extends HttpServlet {
    private static Logger LOG = Logger.getLogger(UserController.class);
    private static String LIST_USER = "/ListUser.jsp";
    private IdentityRemovalDao dao;


    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        //String ihi = request.getParameter("ihi");
        LOG.debug("in try block"+request.toString());
//        if (action.equalsIgnoreCase("delete")){
//            int ihi = Integer.parseInt(request.getParameter("ihi"));
//            try {
//                LOG.debug("in try block");
//                dao.deleteUser(ihi);
//                request.setAttribute("ihi",ihi);
//                System.out.println("ihi deleted");
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
           
              
        
         RequestDispatcher view = request.getRequestDispatcher(LIST_USER);
        view.forward(request, response);
    }
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.debug("In GET method"+request.toString());
        
        RequestDispatcher view = request.getRequestDispatcher(LIST_USER);
        view.forward(request, response);
    }
}
