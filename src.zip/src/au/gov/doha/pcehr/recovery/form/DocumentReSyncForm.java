package au.gov.doha.pcehr.recovery.form;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public class DocumentReSyncForm {
    private MultipartFile file;
    private String userName;
    private List<String> docIdList;
    private Map<String,String> status;
    private Map<String,String> auditStatus;

    public void setAuditStatus(Map<String, String> auditStatus) {
        this.auditStatus = auditStatus;
    }

    public Map<String, String> getAuditStatus() {
        return auditStatus;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public void setStatus(Map<String, String> status) {
        this.status = status;
    }

    public Map<String, String> getStatus() {
        return status;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setIhiList(List<String> docIdList) {
        this.docIdList = docIdList;
    }

    public List<String> getDocIdList() {
        return docIdList;
    }
}
