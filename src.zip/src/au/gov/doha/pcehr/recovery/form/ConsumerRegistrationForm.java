package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.ConsumerRegistrationBO;

import java.util.List;

public class ConsumerRegistrationForm {
    private String fromDate;
    private String toDate;
    private List<ConsumerRegistrationBO> oimConsumerErrorList;

    public void setOimConsumerErrorList(List<ConsumerRegistrationBO> oimConsumerErrorList) {
        this.oimConsumerErrorList = oimConsumerErrorList;
    }

    public List<ConsumerRegistrationBO> getOimConsumerErrorList() {
        return oimConsumerErrorList;
    }


    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getToDate() {
        return toDate;
    }
}
