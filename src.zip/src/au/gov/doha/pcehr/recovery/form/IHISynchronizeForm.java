package au.gov.doha.pcehr.recovery.form;


import au.gov.doha.pcehr.recovery.bo.IHISynchronizationStatusBO;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;


/**
 * Form class for IHI Synchronization
 * @Author Rakhi Tholia, Operations, PCEHR
 * @since 9th Apr 2015
 * @version Change-x
 */
public class IHISynchronizeForm {
    private String ihi;
    private String status;
    private String syncType;
    private MultipartFile file;
    private String userName;
    private String bulkStatus;
    List<IHISynchronizationStatusBO> ihiSyncStatusList;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }


    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setBulkStatus(String bulkStatus) {
        this.bulkStatus = bulkStatus;
    }

    public String getBulkStatus() {
        return bulkStatus;
    }

    public void setSyncType(String syncType) {
        this.syncType = syncType;
    }

    public String getSyncType() {
        return syncType;
    }

    public void setIhiSyncStatusList(List<IHISynchronizationStatusBO> ihiSyncStatusList) {
        this.ihiSyncStatusList = ihiSyncStatusList;
    }

    public List<IHISynchronizationStatusBO> getIhiSyncStatusList() {
        return ihiSyncStatusList;
    }
}
