package au.gov.doha.pcehr.recovery.form;


import org.springframework.web.multipart.MultipartFile;


/**
 * Business objects for ART Extractions
 * @Author Vikash Kumar Singh, Operations, PCEHR
 * @since 02nd Dec 2014
 * @version Change-x
 */
public class ARTExtractionForm extends ARTExtractionListForm {
   
    private String userId;
    private String blobDocId;
    private MultipartFile file;
    
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setBlobDocId(String blobDocId) {
        this.blobDocId = blobDocId;
    }

    public String getBlobDocId() {
        return blobDocId;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }
}
