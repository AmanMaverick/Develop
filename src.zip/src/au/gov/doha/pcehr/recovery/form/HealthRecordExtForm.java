package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.HealthRecordExtractionErrorBO;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

/**
 * Form object for Health record Extraction JSP.
 * @author  Aman Sharma
 * @since R 6.0.4
 */
public class HealthRecordExtForm {
    
    private MultipartFile ihiExtractionLst;
   
    private String viewType;
    private List<String> ihiList;
    private String fromDate;
    private String toDate;
    private List<String> confidentiality;
    //for error handling
    private List<HealthRecordExtractionErrorBO> listHealthRecordExtractionErrorBO;
    private String finalStatusCSVFileName;
    private int viesExtractedCount;
    public void setIhiList(List<String> ihiList) {
        this.ihiList = ihiList;
    }

    public List<String> getIhiList() {
        return ihiList;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setViewType(String viewType) {
        this.viewType = viewType;
    }

    public String getViewType() {
        return viewType;
    }

    public void setIhiExtractionLst(MultipartFile ihiExtractionLst) {
        this.ihiExtractionLst = ihiExtractionLst;
    }

    public MultipartFile getIhiExtractionLst() {
        return ihiExtractionLst;
    }


    public void setConfidentiality(List<String> confidentiality) {
        this.confidentiality = confidentiality;
    }

    public List<String> getConfidentiality() {
        return confidentiality;
    }

    public void setListHealthRecordExtractionErrorBO(List<HealthRecordExtractionErrorBO> listHealthRecordExtractionErrorBO) {
        this.listHealthRecordExtractionErrorBO = listHealthRecordExtractionErrorBO;
    }

    public List<HealthRecordExtractionErrorBO> getListHealthRecordExtractionErrorBO() {
        return listHealthRecordExtractionErrorBO;
    }

    public void setFinalStatusCSVFileName(String finalStatusCSVFileName) {
        this.finalStatusCSVFileName = finalStatusCSVFileName;
    }

    public String getFinalStatusCSVFileName() {
        return finalStatusCSVFileName;
    }

    public void setViesExtractedCount(int viesExtractedCount) {
        this.viesExtractedCount = viesExtractedCount;
    }

    public int getViesExtractedCount() {
        return viesExtractedCount;
    }

}
