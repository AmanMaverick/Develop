package au.gov.doha.pcehr.recovery.form;

import java.math.BigDecimal;

import java.util.List;

/**
 * Object class to collect Form details for DLQ
 * @author Vikash Kumar Singh
 * Since 10th March 2015
 */
public class DLQMessageForm{
    //selected values from DLQToollanding.jsp page
    private String queueType;   //BUSINESS EVENT NAME 
    private String queueSize;
    private String deliveryCount;
    
    //List to display on dropdown box of DLQToollanding.jsp page
    private List queueTypeList;
    private List queueSizeList;
    private List deliveryCountList;
    private  String inputErrorCode;
    private  String inputErrorCount;
    
    //DLQMessageView.jsp objects
    private  String errorCode;
    private  String description;
    private  String errorCount;

    //To capture list of selected error code from DLQMessageView.jsp
    private List<String> errorCodeList;
    
    //For State Change Message
    private String state;
    private BigDecimal count;
    
    //For DLQ Detail Message
    private  String intgrationID;
    private  String messageID;
    private  String errorDetails;
    private  String replayState;
    private  String deliveryCountValue;
    
    //To capture list of selected error code from DLQMessageVerification.jsp
    private List<String> integrationIdList;
    private String integrationId;
    
    public void setQueueType(String queueType) {
        this.queueType = queueType;
    }

    public String getQueueType() {
        return queueType;
    }

    public void setQueueSize(String queueSize) {
        this.queueSize = queueSize;
    }

    public String getQueueSize() {
        return queueSize;
    }

    public void setDeliveryCount(String deliveryCount) {
        this.deliveryCount = deliveryCount;
    }

    public String getDeliveryCount() {
        return deliveryCount;
    }
    
    public void setQueueTypeList(List queueTypeList) {
        this.queueTypeList = queueTypeList;
    }

    public List getQueueTypeList() {
        return queueTypeList;
    }

    public void setQueueSizeList(List queueSizeList) {
        this.queueSizeList = queueSizeList;
    }

    public List getQueueSizeList() {
        return queueSizeList;
    }

    public void setDeliveryCountList(List deliveryCountList) {
        this.deliveryCountList = deliveryCountList;
    }

    public List getDeliveryCountList() {
        return deliveryCountList;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setErrorCount(String errorCount) {
        this.errorCount = errorCount;
    }

    public String getErrorCount() {
        return errorCount;
    }

    public void setErrorCodeList(List<String> errorCodeList) {
        this.errorCodeList = errorCodeList;
    }

    public List<String> getErrorCodeList() {
        return errorCodeList;
    }


    public void setState(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setCount(BigDecimal  count) {
        this.count = count;
    }

    public BigDecimal getCount() {
        return count;
    }


    public void setIntgrationID(String intgrationID) {
        this.intgrationID = intgrationID;
    }

    public String getIntgrationID() {
        return intgrationID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public String getMessageID() {
        return messageID;
    }

    public void setErrorDetails(String errorDetails) {
        this.errorDetails = errorDetails;
    }

    public String getErrorDetails() {
        return errorDetails;
    }

    public void setReplayState(String replayState) {
        this.replayState = replayState;
    }

    public String getReplayState() {
        return replayState;
    }

    public void setDeliveryCountValue(String deliveryCountValue) {
        this.deliveryCountValue = deliveryCountValue;
    }

    public String getDeliveryCountValue() {
        return deliveryCountValue;
    }


    public void setIntegrationIdList(List<String> integrationIdList) {
        this.integrationIdList = integrationIdList;
    }

    public List<String> getIntegrationIdList() {
        return integrationIdList;
    }

    public void setIntegrationId(String integrationId) {
        this.integrationId = integrationId;
    }

    public String getIntegrationId() {
        return integrationId;
    }

    public void setInputErrorCode(String inputErrorCode) {
        this.inputErrorCode = inputErrorCode;
    }

    public String getInputErrorCode() {
        return inputErrorCode;
    }

    public void setInputErrorCount(String inputErrorCount) {
        this.inputErrorCount = inputErrorCount;
    }

    public String getInputErrorCount() {
        return inputErrorCount;
    }
}
