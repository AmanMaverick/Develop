package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.ConsumerRegistrationOIDBO;

import java.util.List;

public class ConsumerRegistrationOIDForm {

    private String fromDate;
    private String toDate;
    private List<ConsumerRegistrationOIDBO> errorList;
    
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getToDate() {
        return toDate;
    }
    
    public void setErrorList(List<ConsumerRegistrationOIDBO> errorList) {
        this.errorList = errorList;
    }

    public List<ConsumerRegistrationOIDBO> getErrorList() {
        return errorList;
    }


}
