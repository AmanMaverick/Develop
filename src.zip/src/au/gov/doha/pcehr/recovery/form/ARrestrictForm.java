package au.gov.doha.pcehr.recovery.form;

import org.springframework.web.multipart.MultipartFile;


public class ARrestrictForm
{

    private String IHI;
    private String userID;
    private String action_type;
    private String jira_id;
    private String operatorName;
    private String expire_date;
    private StringBuffer alertMessage;
    private StringBuffer soapMessage;
    private MultipartFile file;
    private String dateOfBirth;
    private String operationType;
    public void setIHI(String IHI)
    {
        this.IHI = IHI;
    }

    public String getIHI()
    {
        return IHI;
    }

    public void setUserID(String userID)
    {
        this.userID = userID;
    }

    public String getUserID()
    {
        return userID;
    }

    public void setAction_type(String action_type)
    {
        this.action_type = action_type;
    }

    public String getAction_type()
    {
        return action_type;
    }

    public void setJira_id(String jira_id)
    {
        this.jira_id = jira_id;
    }

    public String getJira_id()
    {
        return jira_id;
    }

    public void setExpire_date(String expire_date)
    {
        this.expire_date = expire_date;
    }

    public String getExpire_date()
    {
        return expire_date;
    }

    public void setAlertMessage(StringBuffer alertMessage)
    {
        this.alertMessage = alertMessage;
    }

    public StringBuffer getAlertMessage()
    {
        return alertMessage;
    }

    public void setSoapMessage(StringBuffer soapMessage)
    {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage()
    {
        return soapMessage;
    }

    public void setOperatorName(String operatorName)
    {
        this.operatorName = operatorName;
    }

    public String getOperatorName()
    {
        return operatorName;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getOperationType() {
        return operationType;
    }
}
