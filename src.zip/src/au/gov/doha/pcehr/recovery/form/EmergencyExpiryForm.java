package au.gov.doha.pcehr.recovery.form;

import au.gov.doha.pcehr.recovery.bo.EmergencyAccessExpiryBO;

import java.util.List;

/**
 * Business objects for Emergency Access Expiry Report
 * @Author Dinesh Kaki, Operations, PCEHR
 * @Since Jan 2015
 * @version Change-x
 */


public class EmergencyExpiryForm {

    private String date;
    private List<EmergencyAccessExpiryBO> expiryList;
    
    public void setDate(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }
    
    public void setExpiryList(List<EmergencyAccessExpiryBO> expiryList) {
        this.expiryList = expiryList;
    }

    public List<EmergencyAccessExpiryBO> getExpiryList() {
        return expiryList;
    }
}
