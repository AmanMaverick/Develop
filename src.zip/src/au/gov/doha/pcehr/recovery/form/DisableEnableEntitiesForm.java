package au.gov.doha.pcehr.recovery.form;

import au.pcehr.ws.pna.pd.OIMDisableEntitiesResponse;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;


public class DisableEnableEntitiesForm {
    
    private String entityType;
    private String entitiesID;
    private MultipartFile file;
    private String status;
    private String operatorName;
    private String userID;
    private List<String> entities;
    private String entitySoapMessage;
    private StringBuffer soapMessage;
    private StringBuffer alertMsg;
    private OIMDisableEntitiesResponse oimDisableEntitiesResponse;

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntitiesID(String entitiesID) {
        this.entitiesID = entitiesID;
    }

    public String getEntitiesID() {
        return entitiesID;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }


    public void setEntitySoapMessage(String entitySoapMessage) {
        this.entitySoapMessage = entitySoapMessage;
    }

    public String getEntitySoapMessage() {
        return entitySoapMessage;
    }

    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }

    public void setAlertMsg(StringBuffer alertMsg) {
        this.alertMsg = alertMsg;
    }

    public StringBuffer getAlertMsg() {
        return alertMsg;
    }

    public void setEntities(List<String> entities) {
        this.entities = entities;
    }

    public List<String> getEntities() {
        return entities;
    }


    public void setOimDisableEntitiesResponse(OIMDisableEntitiesResponse oimDisableEntitiesResponse) {
        this.oimDisableEntitiesResponse = oimDisableEntitiesResponse;
    }

    public OIMDisableEntitiesResponse getOimDisableEntitiesResponse() {
        return oimDisableEntitiesResponse;
    }

}
