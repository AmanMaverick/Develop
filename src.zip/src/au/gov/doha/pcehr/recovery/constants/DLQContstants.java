package au.gov.doha.pcehr.recovery.constants;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.Properties;

import org.apache.log4j.Logger;


public class DLQContstants {
    private static Logger LOG = Logger.getLogger(DLQContstants.class);
    public static String QUEUE_TYPE = "";
    public static String QUEUE_SIZE = "";
    public static String DELIVERY_COUNT = "";

    static {

        try {
            Properties myProp = new Properties();
            String os = System.getProperty("os.name");
            String configFileLocation1 = null;
            configFileLocation1 = System.getProperty("user.dir") + File.separator+"Configuration"+File.separator+"DLQConfigurationProp.properties";
            LOG.debug("configFileLocation1"+configFileLocation1);
            
            myProp.load(new FileInputStream(configFileLocation1));
            QUEUE_TYPE = myProp.getProperty("QueueType");
            QUEUE_SIZE = myProp.getProperty("QueueSize");
            DELIVERY_COUNT = myProp.getProperty("DeliveryCount");
        } catch (IOException ioe) {
            LOG.fatal("Exception occured while instantiating constants..", ioe);
            System.out.println("I/O Exception.");
            ioe.printStackTrace();
        }
    }
    
}
