package au.gov.doha.pcehr.recovery.constants;

import java.io.File;

import org.apache.log4j.Logger;


public class DTFolderLocationConstants {
    private static Logger LOG = Logger.getLogger(DTFolderLocationConstants.class);

    public static String EXTRACTED_FILES_FROM_WEBSERVICE ="";
    
    public static String STYLE_SHEET_LOCATION_XML ="";
    
    public static String STYLE_SHEET_LOCATION_HTML ="";
    
    public static String DOC_LOCATION_IHE_XDM ="";
    
    public static String DOC_LOCATION_CDA ="";
    //for only cda in floder styrcute
    public static String DOC_LOCATION_OLNYCDA ="";
    
    public static String STYLE_SHEET_APPLIED_DOCS_LOCATION ="";
  
    public static String WITHOUT_STYLESHEET_DOCS ="";

    public static String ZIPPED_FOLDER_LOCATION = "";
    public static String ERROR_FILE_LOCATION = "";



    static{
        
        try{
    String os = System.getProperty("os.name");
    String fileSeperator=File.separator;
    String fileLocation = null;
    if (null != os && os.contains("Linux")) {
        fileLocation = System.getProperty("user.dir") + fileSeperator+"DocumentTransformation"+fileSeperator;
        EXTRACTED_FILES_FROM_WEBSERVICE=fileLocation+"ExtractedFilesFormWebservice";    
        STYLE_SHEET_LOCATION_XML=fileLocation+"stylesheet"+fileSeperator+"XML"+fileSeperator+"De-Identification_CDA_Stylesheet_v0.1.xsl";
      //  STYLE_SHEET_LOCATION_XML=fileLocation+"stylesheet/XML/genericNewTest.xsl";
        
       
        STYLE_SHEET_LOCATION_HTML=fileLocation+"stylesheet"+fileSeperator+"HTML"+fileSeperator+"NEHTA_Generic_CDA_Stylesheet-1.2.8x.xsl";
       // STYLE_SHEET_LOCATION_HTML=fileLocation+"stylesheet/HTML/genericNewTest.xsl";
        DOC_LOCATION_IHE_XDM=fileLocation+"ExtractedFilesFormWebservice"+fileSeperator+"IHE_XDM"+fileSeperator+"SUBSET01"+fileSeperator;
        DOC_LOCATION_CDA=fileLocation+"ExtractedFilesFormWebservice"+fileSeperator+"CDA"+fileSeperator+"CDADoc"+fileSeperator;
        //for only cda in floder styrcute
        DOC_LOCATION_OLNYCDA= fileLocation+"ExtractedFilesFormWebservice"+fileSeperator+"CDA"+fileSeperator;
        STYLE_SHEET_APPLIED_DOCS_LOCATION=fileLocation+"StyleSheetApplidDocs";
        WITHOUT_STYLESHEET_DOCS=fileLocation+"WithoutStyleSheetDocs";
        ZIPPED_FOLDER_LOCATION=fileLocation+"ZippedFolder"+fileSeperator;
        ERROR_FILE_LOCATION=fileLocation+"ErrorCSV"+fileSeperator;
        LOG.debug("fileLocation..."+fileLocation);
    } else {
        fileLocation = System.getProperty("user.dir") + "\\DocumentTransformation\\";
        EXTRACTED_FILES_FROM_WEBSERVICE=fileLocation+"ExtractedFilesFormWebservice";    
        STYLE_SHEET_LOCATION_XML=fileLocation+"stylesheet\\XML\\De-Identification_CDA_Stylesheet_v0.1.xsl";
       // STYLE_SHEET_LOCATION_XML=fileLocation+"stylesheet\\XML\\genericNewTest.xsl";
        STYLE_SHEET_LOCATION_HTML=fileLocation+"stylesheet\\HTML\\NEHTA_Generic_CDA_Stylesheet-1.2.8x.xsl";
        //STYLE_SHEET_LOCATION_HTML=fileLocation+"stylesheet\\HTML\\genericNewTest.xsl";
        DOC_LOCATION_IHE_XDM=fileLocation+"ExtractedFilesFormWebservice\\IHE_XDM\\SUBSET01\\";
        DOC_LOCATION_CDA=fileLocation+"ExtractedFilesFormWebservice\\CDA\\CDADoc\\";
        //for only cda in floder styrcute
        DOC_LOCATION_OLNYCDA=fileLocation+"ExtractedFilesFormWebservice\\CDA\\";
        STYLE_SHEET_APPLIED_DOCS_LOCATION=fileLocation+"StyleSheetApplidDocs";
        WITHOUT_STYLESHEET_DOCS=fileLocation+"WithoutStyleSheetDocs";
        ZIPPED_FOLDER_LOCATION=fileLocation+"ZippedFolder\\";
        ERROR_FILE_LOCATION=fileLocation+"ErrorCSV\\";
        LOG.debug("fileLocation..."+fileLocation);
    }
           
        }catch(Exception e){
            LOG.fatal("Exception occured while instantiating constants..",e);
        }
    }
}
