package au.gov.doha.pcehr.recovery.constants;


public class AuditConstants {
    public static final String VENDOR = "NIO";
    public static final String COMPONENT_SOURCE="NIO";
    public static final String PRODUCT_NAME = "OPS Tool";
    public static final String PRODUCT_VERSION="1.1";
    public static final String PLATFORM="Jump Host";
    public static final String MESSAGE_LOG_LEVEL="AUDIT";
    public static final String SOAP_MESSAGE="";
    public static final String STATUS_CODE="";
    public static final boolean STATUS=true;
}
