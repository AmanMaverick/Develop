package au.gov.doha.pcehr.recovery.constants;


public class AuditMessageConstants {
    public static final String LOGIN = "NIOOps Tool - Application Login";
    public static final String LOGOUT = "NIOOps Tool - Application LOGOUT";
    public static final String ARRESTRICT_LANDINGPAGE_MESAGGE = "Authorised Representative Restriction - Landing Page Accessed";
    public static final String ARRESTRICT_OPERATION_MESAGGE = "Authorised Representative Restriction - Operation Performed";
    public static final String ART_LANDINGPAGE_MESAGGE = "ART Extraction Tool - Search Page Accessed";
    public static final String ART_SEARCH_MESAGGE = "ART Extraction Tool - Search Operation Performed";
    public static final String ART_SINGLE_FILE_DOWNLOAD_MESAGGE = "ART Extraction Tool - Single File Download Performed";
    public static final String ART_BULK_FILE_DOWNLOAD_MESAGGE = "ART Extraction Tool - Bulk File Download Performed";
    public static final String ART_BULK_SEARCH_MESAGGE = "ART Extraction Tool - Bulk Search Operation Performed";
    public static final String DOC_TRANSFORMATION_LANDING_PAGE = "Document Transformation Tool - Landing Page Accessed";
    public static final String DOC_TRANSFORMATION_OPERATION = "Document Transformation Tool - Operation Performed";
    public static final String DOCUMENT_RE_SYNCHRONISATION_LANDING_PAGE = "Document Re-Synchronisation - Landing Page Accessed";
    public static final String DOCUMENT_RE_SYNCHRONISATION = "Document Re-Synchronisation - Operation Performed";
    public static final String REMOVE_REINSTATE_DOCUMENT = "Remove & Re-instate Document - Landing Page Accessed";
    public static final String REMOVE_DOCUMENT_OPERATION = "Remove & Re-instate Document - Remove Document Operation Performed";
    public static final String REINSTATE_DOCUMENT_OPERATION = "Remove & Re-instate Document - Document Re-instate Operation Performed";
    public static final String EMERGENCY_ACCESS_EXPIRY_REPORT_PAGE = "Emergency Access Expiry Report - Landing Page Accessed";
    public static final String GET_EMERGENCY_LIST = "Emergency Access Expiry Report - Operation Performed to get Emergency Access Expiry Report";
    public static final String PNA_STATUS_UPDATE_PAGE = "PCEHR Record Status Update - Landing Page Accessed";
    public static final String PNA_STATUS_UPDATE_OPERATION = "PCEHR Record Status Update - PNA Status Update Operation Performed";
    public static final String REACTIVE_AUTH_REP_Page = "Reactivate Authorized Representatives - Landing Page Accessed";
    public static final String REACTIVE_AUTH_REP_OPERATION = "Reactivate Authorized Representatives - PNA Status Update Operation Performed";
    
    public static final String SUSPEND_REP_PAGE = "Suspend Representatives - Landing Page Accessed";
    public static final String SUSPEND_REP_OPERATION = "Suspend Representatives - Suspend AR Operation Performed";
    
    public static final String DLQ_LANDINGPAGE_MESAGGE = "DLQ Replay Tool - Search Page Accessed";
    public static final String DLQ_SEARCH_OPERATIONS = "DLQ Replay Tool - DLQ Message Replay Search Operation Performed";
    public static final String DLQ_BACK_TO_SEARCH_RESULT = "DLQ Replay Tool - Back to Search Result Operation Performed";
    public static final String DLQ_PLAY_ERROR_CODE_OPERATIONS = "DLQ Replay Tool - Play operation performed on the Error Messages to be updated";
    public static final String DLQ_PLAY_INTEGRATION_ID_OPERATIONS = "DLQ Replay Tool - Play operation performed on Integration ID to be updated";
    public static final String DLQ_PLAY_ERROR_CODE_MESSAGES = "DLQ Replay Tool - DLQ Messages accessed for the specific Error Code";
    public static final String DLQ_PLAY_INTEGRATION_ID_MESSAGES = "DLQ Replay Tool - DLQ Messages accessed for the specific Integration Id";
    
    public static final String AUDIT_ENTRY_MISSING_PAGE = "Audit Entry Missing Data Fix - Landing Page Accessed";
    public static final String AUDIT_ENTRY_MISSING_OPERATION = "Audit Entry Missing Data Fix - Operation Performed";
    
    public static final String CLEAN_RECORD_PAGE = "Empty a Record(Clean) - Landing Page Accessed";
    public static final String PERFORM_RESET_INDIVIDUAL_PROFILE = "Empty a Record(Clean - Reset Individual Provile Operation Performed)";
    public static final String PERFORM_CLEAN_UP_PENDING_VERIFICATION = "Empty a Record(Clean) - Clean Up pending verification Operation Performed";
    public static final String PERFORM_REMOVE_DOCUMENT = "Empty a Record(Clean) - Remove Document Operation Performed";
    public static final String CONFIGURATION_ENDPOINT_PAGE = "Configure End Point - Configuration Page accessed ";
    public static final String CONFIG_ENDPOINT_UPDATE_OPERATION = "Configure End Point - Updated Endpoints Details";


    public static final String RECORD_IDENTITY_REMOVAL_PAGE = "Record and Identity Removal - Landing Page Accessed";
    public static final String GET_IHI_DEMOGRAPHIC_DETAIL = "Record and Identity Removal - Displayed IHI Demographic details";
    public static final String RECORD_REMOVAL_OPERATION = "Record and Identity Removal - Record Removal Operation Performed";
    public static final String IDENTITY_REMOVAL_OPERATION = "Record and Identity Removal - Identity Removal Operation Performed";
    public static final String IDENTITY_RECORD_REMOVAL_OPERATION = "Record and Identity Removal - Identity and Record Removal Operation Performed";
    public static final String REMOVAL_CHILD_RECORD_OPERATION = "Record and Identity Removal - Child Removal Removal with no Identity Operation Performed";
    
    public static final String IHI_DEMOGRAPHIC_SYNC_PAGE = "IHI Demographics Synchronization - Landing Page Accessed";
    public static final String SINGLE_IHI_DEMOGRAPHIC_SYNC_PAGE = "IHI Demographics Synchronization - Single IHI Demographics Synchronization Page Accessed";
    public static final String SINGLE_IHI_DEMOGRAPHIC_SYNC_OPERATION = "IHI Demographics Synchronization - Single IHI Demographics Synchronization Operation Performed";
    public static final String BULK_IHI_DEMOGRAPHIC_SYNC_OPERATION = "IHI Demographics Synchronization - Bulk IHI Demographics Synchronization Operation Performed";
    public static final String IHI_DEMOGRAPHIC_SYNC_TEMPLATE_DOWNLOAD = "IHI Demographics Synchronization - Sample Template File Download";
    public static final String BULK_IHI_DEMOGRAPHIC_SYNC_PAGE = "IHI Demographics Synchronization - Bulk IHI Demographics Synchronization Page Accessed";
    public static final String DISABLE_ENABLE_ENTITY_LANDING_PAGE = "Disable Re-Enable Entities - Landing Page Accessed";
    public static final String DISABLE_ENABLE_ENTITY_OPERATION = "Disable Re-Enable Entities - Operation Performed";
    
    public static final String TESTING_IN_PROD_LANDINGPAGE = "Testing in Production Tool - Landing Page Accessed";
    public static final String TESTING_IN_PROD_OPERATION = "Testing in Production Tool - ITI Creation Operation Performed";
    
    public static final String CONSUMER_REGISTRATION_LANDINGPAGE = "Consumer Registration - Landing Page Accessed";
    public static final String GET_CONSUMER_REGISTRATION_LIST = "Consumer Registration - Operation Performed to get Consumer Registration List";

    public static final String CONSUMER_REGISTRATION_OID_LANDINGPAGE = "Consumer Registration OID - Landing Page Accessed";
    public static final String GET_CONSUMER_REGISTRATION_OID_LIST = "Consumer Registration OID - Operation Performed to get Consumer Registration OID List";
    
    public static final String PROVIDER_REGISTRATION_LANDINGPAGE = "Provider Registration - Landing Page Accessed";
    public static final String GET_PROVIDER_REGISTRATION_LIST = "Provider Registration - Operation Performed to get Provider Registration List";
    
    public static final String PROVIDER_REGISTRATION_OID_LANDINGPAGE = "Provider Registration OID - Landing Page Accessed";
    public static final String GET_PROVIDER_REGISTRATION_OID_LIST = "Provider Registration OID - Operation Performed to get Provider Registration OID List";
    
    public static final String PROVIDER_ORG_REGISTRATION_LANDINGPAGE = "Provider Organisation Registration - Landing Page Accessed";
    public static final String GET_PROVIDER_ORG_REGISTRATION_LIST = "Provider Organisation Registration - Operation Performed to get Provider Organisation Registration Error List";
    
    public static final String PROVIDER_ORG_VERIFICATION_LANDINGPAGE = "Provider Organisation Verification - Landing Page Accessed";
    public static final String GET_PROVIDER_ORG_VERIFICATION_LIST = "Provider Organisation Verification - Operation Performed to get Provider Organisation Verification List";
    
    
    public static final String AUDIT_HEALTH_RECORD_EXT_LANDING_PAGE = "";
    public static final String AUDIT_HEALTH_RECORD_EXT_SUBMIT = "";

    public static final String BULK_REGISTRATION_LANDIGPAGE="Bulk Registration  - Landing Page Accessed.";
    public static final String BULK_REGISTRATION_VALIDATE="Bulk Registration  - Validate IHI Info.";
    public static final String BULK_REGISTRATION_VALIDATE_EXTRACT="Bulk Registration  - Validate and Extract File to Database - Validate.";
    public static final String BULK_REGISTRATION_VALIDATE_PUSH_TO_DB="Bulk Registration  - Validate and Extract File to Database - Push to Database.";
    public static final String BULK_REGISTRATION_OUTPIT_LINK_VALIDATE_EXTRACT="Bulk Registration  - Validate and Extract File to Database - Output Link.";
    public static final String BULK_REGISTRATION_OUTPIT_LINK_PUSH_TO_DB="Bulk Registration  - Push To Database - Output Link.";
    public static final String BULK_REGISTRATION_RECONSILE_DATA = "" ;

    public static final String VALIDATE_AND_BULK_RECORD_CREATION = "";
    public static final String BULK_REGISTRATION_STATUS = "Bulk Registration - Generate Status for the IHIs";
    public static final String BULK_REGISTRATION_VALIDATE_STOP="";
    public static final String BULK_REGISTRATION_RECORD_CREATION_STOP = "" ;
    public static final String BULK_REGISTRATION_RECORD_VALIDATE_AND_CREATION_STOP = "" ;

    public static final String MOBILE_APPLICATION_TOOL_LANDIGPAGE = "Mobile Application Tool  - Landing Page Accessed.";
}
