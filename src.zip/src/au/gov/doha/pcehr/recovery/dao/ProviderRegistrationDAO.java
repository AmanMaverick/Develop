package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.ProviderRegistrationBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ProviderRegistrationForm;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

/**
 * DAO class that interacts with the DataBase to fetch Data
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Apr 2015
 * @version Change-x
 */


@Component
public class ProviderRegistrationDAO {
    
    private static Logger LOG = Logger.getLogger(ProviderRegistrationDAO.class);
   
    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJDBCTemplate;
    
    @Value( "${PROVIDER_REG_DAO.GET_PROVIDER_LIST}" )
    private String PROVIDER_REGISTRATION_QUERY;
    
    /**
     * This method is called from the service class to perform Database related task for Consumer Registration OID.
     * @param providerRegistrationForm
     * @return
     * @throws RecoveryDAOException
     */
   
    public ProviderRegistrationForm fetchProviderRegistrationList(ProviderRegistrationForm providerRegistrationForm) throws RecoveryDAOException{                                                                                                
        List<ProviderRegistrationBO> providerRegistrationList = new ArrayList<ProviderRegistrationBO>();
        LOG.debug("Entered providerRegistrationOIDList Method in DAO.... ");
    
        try {
            providerRegistrationList =
                    osbJDBCTemplate.query(PROVIDER_REGISTRATION_QUERY   , new Object[]{providerRegistrationForm.getFromDate(),providerRegistrationForm.getToDate()},
            
                                          new RowMapper<ProviderRegistrationBO>() {
              
                        public ProviderRegistrationBO mapRow(ResultSet rs, int rowNum) throws SQLException {
                            ProviderRegistrationBO providerRegsitrationRpt = new ProviderRegistrationBO();
                            providerRegsitrationRpt.setUser_id(rs.getString("user_id"));
                          providerRegsitrationRpt.setDate(rs.getDate("TRANSACTION_DATE"));
                            return providerRegsitrationRpt;
                        }
                    });
            providerRegistrationForm.setErrorList(providerRegistrationList);
            
            if(providerRegistrationList.isEmpty())
                System.out.println("No Error Users found in OID");
            
        } catch (Exception e) {
            LOG.fatal("Exception occured in DAO try block", e);
                throw new RecoveryDAOException(e);
        }
        LOG.debug("Leaving DAO Class");  
    return providerRegistrationForm;
    }
   
}
