package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.DocTransformationErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationRLSBO;
import au.gov.doha.pcehr.recovery.constants.DTClassCodePropertiesConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;


/**
 * DAO to perform all Rls get document query call
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 30 Dec 2014
 * @version Change-0.2 ,change: added method to get the documnet ids from osb audit log table to handle date range condition
 */
public class DocumentTransformationDAO {
    private static Logger LOG = Logger.getLogger(DocumentTransformationDAO.class);
    private static final String UPLOAD_DOC_BUSNIESS_EVENT = "uploadDocument";
    @Autowired
    @Qualifier("rlsNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    @Qualifier("osbNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate osbNamedParameterJdbcTemplate;
    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJdbcTemplate;
    @Autowired
    @Qualifier("rlsJDBCTemplate")
    private JdbcTemplate rlsJDBCTemplate;

    @Autowired
    DateTimeUtil dateTimeUtil;

    /**
     * This method retrieves the document ID for the given Date range.
     * @param form
     * @return
     */
    public List<String> getDocumentId(DocumentTransformationForm form) throws RecoveryDAOException {

        StringBuffer rlsQuery = new StringBuffer();
        List<String> docList = new ArrayList<String>();
        rlsQuery.append("select distinct substr(patient_id,0,16) patient_id from doc_entry");

        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;

        try {

            conn = rlsJDBCTemplate.getDataSource().getConnection();
            pStmt = conn.prepareStatement(rlsQuery.toString());
            pStmt.setFetchSize(50000);
            rst = pStmt.executeQuery();
            while (rst.next()) {
                docList.add(rst.getString("patient_id"));
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            if (rst != null) {
                try {
                    rst.close();
                } catch (SQLException e) {
                }
            }
            if (pStmt != null) {
                try {
                    pStmt.close();
                } catch (SQLException e) {
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                }
            }
        }
        LOG.debug("Doc List Size " + docList.size());
        return docList;

    }

    /**
     * This method retrives the
     * @param form
     * @return
     */
    public DocumentTransformationForm getDocListDateRange(DocumentTransformationForm form) {
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        HashMap<String, List<DocumentTransformationRLSBO>> getDocClntMap =
            new HashMap<String, List<DocumentTransformationRLSBO>>();


        FileUtil fileutil = new FileUtil();
        List<String> class_codes = getPropertiesValues(form);

        LOG.debug("calss code value in list..." + class_codes);


        try {
            StringBuffer rlsQuery = new StringBuffer();
            rlsQuery.append("SELECT ");
            rlsQuery.append("IHI_DATA.IHI as IHI,IHI_DATA.DOC_UID as DOC_UID,IHI_DATA.class_code as CLASS_CODE, ");
            rlsQuery.append("IHI_DATA.REPOSITORY_ID  as REPOSITORY_ID ");
            rlsQuery.append(" FROM ( SELECT PATIENT_ID IHI,DOC_UID DOC_UID, TYPE_CD class_code, ");
            rlsQuery.append("EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Slot[@name=\"repositoryUniqueId\"]/ValueList/Value/text()', ");
            rlsQuery.append("'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() REPOSITORY_ID ");
            rlsQuery.append(" FROM hrlcore.DOC_ENTRY where 1= 1  and  TO_DATE(TO_CHAR(INSERT_DT ,'DD-MM-YYYY'),'DD/MM/YYYY') BETWEEN to_date( ? ,'DD/MM/YYYY') AND TO_DATE( ? ,'DD/MM/YYYY') ");

            if (class_codes != null && class_codes.size() > 0) {
                rlsQuery.append("and TYPE_CD in ( ");
                for (int i = 0; i < class_codes.size(); i++) {
                    if (i == class_codes.size() - 1) {
                        rlsQuery.append("? )");
                    } else {
                        rlsQuery.append("?,");
                    }
                }
            }


            if (form.getDocStatus() != null && form.getDocStatus().size() > 0) {
                rlsQuery.append("and status in ( ");
                for (int i = 0; i < form.getDocStatus().size(); i++) {
                    if (i == form.getDocStatus().size() - 1) {
                        rlsQuery.append("? )");
                    } else {

                        rlsQuery.append("?,");
                    }
                }
            }

            rlsQuery.append(" ) IHI_DATA ");

            LOG.debug("Query--->" + rlsQuery.toString());


            conn = rlsJDBCTemplate.getDataSource().getConnection();
            pStmt = conn.prepareStatement(rlsQuery.toString());
            pStmt.setFetchSize(500);
            pStmt.setObject(1, form.getCreationTime());
            pStmt.setObject(2, form.getEndTime());
            int size = 3;

            for (int i = 3, y = 0; y < class_codes.size(); i++, y++) {
                pStmt.setObject(i, class_codes.get(y));
                LOG.debug(class_codes.get(y) + "Size" + i);
                size++;

            }
            // size=size+class_codes.size();
            for (int i = size, y = 0; y < form.getDocStatus().size(); i++, y++) {
                pStmt.setObject(i, form.getDocStatus().get(y));
                LOG.debug(form.getDocStatus().get(y) + "Size" + i);
            }

            rst = pStmt.executeQuery();

            while (rst.next()) {

                DocumentTransformationRLSBO bo = new DocumentTransformationRLSBO();

                bo.setDocmentType(rst.getString("CLASS_CODE"));
                bo.setDocumentID(rst.getString("DOC_UID"));
                bo.setIhi(rst.getString("IHI").substring(0, 16));
                bo.setRepositoryID(rst.getString("REPOSITORY_ID"));

                List<DocumentTransformationRLSBO> listGetDocLstBo = null;
                if (getDocClntMap.containsKey(bo.getIhi())) {
                    //Checking for the uniq
                    listGetDocLstBo = getDocClntMap.get(bo.getIhi());
                    boolean docStatus = false;
                    for (DocumentTransformationRLSBO documentTransformationRLSBO : listGetDocLstBo) {
                        if (documentTransformationRLSBO.getDocumentID().equals(bo.getDocumentID())) {
                            docStatus = true;
                        }
                    }
                    if (!docStatus) {
                        listGetDocLstBo.add(bo);
                        getDocClntMap.put(bo.getIhi(), listGetDocLstBo);
                    }
                } else {
                    listGetDocLstBo = new ArrayList<DocumentTransformationRLSBO>();
                    listGetDocLstBo.add(bo);
                    getDocClntMap.put(bo.getIhi(), listGetDocLstBo);
                }
                LOG.debug("IHI key " + bo.getIhi() + "...list size.." + listGetDocLstBo.size());

            }

        } catch (Exception e) {
            LOG.fatal("Exception occured", e);

        } finally {
            if (rst != null) {
                try {
                    rst.close();
                } catch (SQLException e) {
                }
            }
            if (pStmt != null) {
                try {
                    pStmt.close();
                } catch (SQLException e) {
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                }
            }
        }

        form.setIhiRlsMap(getDocClntMap);
        return form;
    }

    /**
     *Used to execute the get Document RLS query
     * @param form
     * @return
     */
    public DocumentTransformationForm getDocList(DocumentTransformationForm form) {
        Map namedParameters = new HashMap();

        HashMap<String, List<DocumentTransformationRLSBO>> map = new HashMap();
        List<DocumentTransformationRLSBO> listBo = null;
        List<DocTransformationErrorBO> listErrorBo = null;
        FileUtil fileutil = new FileUtil();
        List<String> class_codes = getPropertiesValues(form);

        LOG.debug("calss code value in list..." + class_codes);
        for (int j = 0; j < class_codes.size(); j++) {
            LOG.debug("new class code value:::" + class_codes.get(j));

        }
        StringBuffer errorCsv = new StringBuffer();
        LOG.debug("before validate IHI count was..." + form.getIhiList().size());
        for (int i = 0; i < form.getIhiList().size(); i++) {
            boolean validateIhiFlag = validateIHI(form.getIhiList().get(i), form);
            if (validateIhiFlag == false) {
                LOG.debug("ihi validation falied..." + form.getIhiList().get(i));
                form.getIhiList().remove(form.getIhiList().get(i));
            }
        }
        LOG.debug("afetr validate IHI count is..." + form.getIhiList().size());
        for (int i = 0; i < form.getIhiList().size(); i++) {
            List<String> classCodeWithNoDOc = new ArrayList();
            List<String> classCodeWithDOc = new ArrayList();
            int loopCount = -1;
            listBo = new ArrayList<DocumentTransformationRLSBO>();

            String ihi = form.getIhiList().get(i);
            LOG.debug("rls query for ihi...." + ihi);
            try {
                StringBuffer rlsQuery = new StringBuffer();
                rlsQuery.append("SELECT ");
                rlsQuery.append("IHI_DATA.IHI as IHI,IHI_DATA.DOC_UID as DOC_UID,IHI_DATA.class_code as CLASS_CODE, ");
                rlsQuery.append("IHI_DATA.REPOSITORY_ID  as REPOSITORY_ID ");
                rlsQuery.append("FROM(SELECT PATIENT_ID IHI,DOC_UID DOC_UID, TYPE_CD class_code, ");
                rlsQuery.append("EXTRACT(XMLTYPE(DOCUMENT), '/ExtrinsicObject/Slot[@name=\"repositoryUniqueId\"]/ValueList/Value/text()', ");
                rlsQuery.append("'xmlns=urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0').GETSTRINGVAL() REPOSITORY_ID ");
                rlsQuery.append(" FROM hrlcore.DOC_ENTRY where TYPE_CD in (:class_codes) and ");

                if ("IHI".equals(form.getInputType())) {
                    LOG.debug("calling db for IHI ");
                    rlsQuery.append("PATIENT_ID =:PATIENT_ID");
                } else {
                    LOG.debug("calling db for doc_uid ");
                    rlsQuery.append("DOC_UID =:DOC_UID");

                }

                rlsQuery.append(" order by version desc ) IHI_DATA order by IHI_DATA.DOC_UID desc");
                if ("IHI".equals(form.getInputType())) {
                    namedParameters.put("PATIENT_ID", ihi + "^^^&1.2.36.1.2001.1003.0&ISO");
                } else {
                    namedParameters.put("DOC_UID", ihi);


                }


                namedParameters.put("class_codes", class_codes);
                List<Map<String, Object>> list =
                    namedParameterJdbcTemplate.queryForList(rlsQuery.toString(), namedParameters);
                LOG.debug("dao query size::::" + list.size());


                for (Map row : list) {

                    DocumentTransformationRLSBO bo = new DocumentTransformationRLSBO();
                    classCodeWithDOc.add(row.get("CLASS_CODE").toString());
                    bo.setDocmentType(row.get("CLASS_CODE").toString());
                    bo.setDocumentID(row.get("DOC_UID").toString());
                    LOG.debug("doc uid :::" + row.get("DOC_UID").toString());
                    //bo.setIhi(ihi);
                    bo.setIhi(row.get("IHI").toString().substring(0, 16));
                    bo.setRepositoryID(row.get("REPOSITORY_ID").toString());
                    if (listBo.size() > 0) {
                        if (!listBo.get(loopCount).getDocumentID().equals(row.get("DOC_UID").toString())) {
                            LOG.debug("entrting doc_uid to list..." + row.get("DOC_UID").toString());
                            listBo.add(bo);
                            loopCount++;
                        }
                    } else {
                        LOG.debug("entrting doc_uid to list..." + row.get("DOC_UID").toString());
                        listBo.add(bo);
                        loopCount++;
                    }

                }

                //code change for handling no doc found for every class code
                for (String classCode : class_codes) {
                    if (!classCodeWithDOc.contains(classCode)) {
                        classCodeWithNoDOc.add(classCode);
                    }
                }
                if (null != classCodeWithNoDOc && classCodeWithNoDOc.size() > 0) {
                    String sysDate = fileutil.getDateFormat();
                    LOG.debug("class code ith no documents are..." + classCodeWithNoDOc.toString());
                    DocTransformationErrorBO errorBo = new DocTransformationErrorBO();


                    errorBo =
                        fileutil.createErrorBo(ihi, "N/A", "no document ID found in RLS", classCodeWithNoDOc.toString(),
                                               "FAIL", sysDate);


                    if (form.getErrorBoList() != null) {
                        form.getErrorBoList().add(errorBo);
                    } else {
                        listErrorBo = new ArrayList<DocTransformationErrorBO>();
                        listErrorBo.add(errorBo);
                        form.setErrorBoList(listErrorBo);
                    }
                }
                //
                if ("IHI".equals(form.getInputType())) {
                    LOG.debug("creating map for IHI");
                    map.put(ihi, listBo);
                } else {
                    LOG.debug("creating map for doc_id");
                    if (listBo != null && listBo.size() > 0) {
                        LOG.debug("ihi found for the doc id..." + listBo.get(0).getIhi());
                        map.put(listBo.get(0).getIhi(), listBo);
                    } else {
                        LOG.debug("ihi not found for the doc id");
                        String sysDate = fileutil.getDateFormat();
                        DocTransformationErrorBO errorBo = new DocTransformationErrorBO();


                        errorBo =
                            fileutil.createErrorBo("N/A", ihi, "document ID not found in RLS", class_codes.toString(),
                                                   "FAIL", sysDate);


                        if (form.getErrorBoList() != null) {
                            form.getErrorBoList().add(errorBo);
                        } else {
                            listErrorBo = new ArrayList<DocTransformationErrorBO>();
                            listErrorBo.add(errorBo);
                            form.setErrorBoList(listErrorBo);
                        }
                    }
                }

            } catch (Exception e) {
                LOG.fatal("Exception Occured..", e);
            }
        }
        LOG.debug("error csv is..." + errorCsv);
        if (errorCsv != null && errorCsv.length() > 0) {

            LOG.debug("error csv is not null");
            form.setErrorCsv(errorCsv);
        }


        form.setIhiRlsMap(map);
        return form;
    }

    /**
     *
     * @param repId
     * @return
     */
    public String getWSAAction(String repId) {
        LOG.debug("entering getWSAAction....");
        LOG.debug("rep id...." + repId);
        String action = null;
        Map namedParameters = new HashMap();
        StringBuffer query = new StringBuffer();
        query.append("select location from PCEHR_OSB_AUDIT.REGISTRY where reposid=:repID");
        namedParameters.put("repID", repId);
        List<Map<String, Object>> list = osbNamedParameterJdbcTemplate.queryForList(query.toString(), namedParameters);
        for (Map row : list) {
            action = row.get("location").toString();
        }
        LOG.debug("Leaving getWSAAction....");
        LOG.debug("action is...." + action);

        return action;

    }


    /**
     *
     * @param ihi
     * @param form
     * @return
     */
    public boolean validateIHI(String ihi, DocumentTransformationForm form) {
        boolean flag = false;
        String errorMessage = "";
        FileUtil fileutil = new FileUtil();
        List<DocTransformationErrorBO> listErrorBo = new ArrayList<DocTransformationErrorBO>();
        LOG.debug("entering validateIHI....");
        LOG.debug("ihi ...." + ihi);

        Map namedParameters = new HashMap();
        StringBuffer query = new StringBuffer();
        if ("IHI".equals(form.getInputType())) {
            query.append("select PATIENT_ID  FROM hrlcore.DOC_ENTRY where PATIENT_ID =:PATIENT_ID");
            namedParameters.put("PATIENT_ID", ihi + "^^^&1.2.36.1.2001.1003.0&ISO");
            errorMessage = "IHI not found in RLS";
        } else {
            query.append("select PATIENT_ID  FROM hrlcore.DOC_ENTRY where DOC_UID =:DOC_UID");
            namedParameters.put("DOC_UID", ihi);
            errorMessage = "Document Id not found in RLS";
        }


        List<Map<String, Object>> list = namedParameterJdbcTemplate.queryForList(query.toString(), namedParameters);
        if (list.size() == 0) {
            LOG.debug("validation falied ...." + ihi);
            flag = false;
            DocTransformationErrorBO errorBo = new DocTransformationErrorBO();
            String sysDate = fileutil.getDateFormat();

            errorBo = fileutil.createErrorBo(ihi, "N/A", errorMessage, "N/A", "FAIL", sysDate);

            if (form.getErrorBoList() != null) {
                form.getErrorBoList().add(errorBo);
            } else {
                listErrorBo = new ArrayList<DocTransformationErrorBO>();
                listErrorBo.add(errorBo);
                form.setErrorBoList(listErrorBo);
            }

        } else {
            LOG.debug("validation success ...." + ihi);
            flag = true;
        }

        LOG.debug("leaving validateIHI....");


        return flag;

    }


    /**
     *
     * @return
     */
    public List<String> getDisplayClassCodeValues() {
        LOG.debug("enetring getDisplayClassCodeValues...");
        List<String> list = new ArrayList();
        Set set = DTClassCodePropertiesConstants.classCodeMap.entrySet();
        Iterator k = set.iterator();
        while (k.hasNext()) {
            Map.Entry me = (Map.Entry) k.next();

            list.add(me.getKey().toString().replaceAll("_", " "));
        }
        LOG.debug("Leaving getDisplayClassCodeValues..." + list.size());
        return list;
    }

    /**
     *
     * @param form
     * @return
     */
    public List<String> getPropertiesValues(DocumentTransformationForm form) {
        LOG.debug("enetring getPropertiesValues1...");
        List<String> codeList = new ArrayList();
        List<String> userSelectedclassCodes = form.getDocumentType();
        if (userSelectedclassCodes != null && userSelectedclassCodes.size() > 0) {
            for (int i = 0; i < userSelectedclassCodes.size(); i++) {
                Set set = DTClassCodePropertiesConstants.classCodeMap.entrySet();
                Iterator k = set.iterator();
                while (k.hasNext()) {
                    Map.Entry me = (Map.Entry) k.next();
                    if (me.getKey().toString().replaceAll("_", " ").equalsIgnoreCase(userSelectedclassCodes.get(i)))
                        if (me.getValue().toString().contains(",")) {
                            LOG.debug("class code with comma.." + me.getValue().toString());
                            for (int j = 0; j < me.getValue().toString().split(",").length; j++) {
                                LOG.debug("class code afetr separating comma .." +
                                          me.getValue().toString().split(",")[j]);
                                codeList.add((me.getValue().toString().split(","))[j].toString());

                            }
                        } else {
                            codeList.add(me.getValue().toString());
                        }
                }
            }
        }
        LOG.debug("Leaving getPropertiesValues1...codeList size.." + codeList.size());
        return codeList;
    }



   /**
     *This query is used to get the document ids from osb audit log table 
     * @param form
     * @return
     */


    @SuppressWarnings("unchecked")
    public List<String> getDocumentListFromOSBAudit(DocumentTransformationForm form) {
        
        Connection conn =null;
        ResultSet rs=null;
        PreparedStatement ps=null;
        List<String> documentIdList = new ArrayList<String>();
        LOG.debug("Enteruing getDocumentListFromOSBAudit");
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            String incrementedDate=icreamentDay(form.getEndTime());
            Date date1= formatter.parse(form.getCreationTime());
           
             Date date2= formatter.parse(incrementedDate);
            LOG.debug("dates:::"+date1+"....."+date2);
            StringBuffer getDocumentListQuery = new StringBuffer();
            getDocumentListQuery.append("SELECT DISTINCT subject,subject_type ");
            getDocumentListQuery.append("FROM PCEHR_OSB_AUDIT.AUDIT_LOG ");
            getDocumentListQuery.append("WHERE operation_performed ='uploadDocument' ");
            getDocumentListQuery.append("AND transaction_date >= ?  ");
            getDocumentListQuery.append("AND transaction_date <  ?  ");
             conn = osbJdbcTemplate.getDataSource().getConnection();
            
             ps=conn.prepareStatement(getDocumentListQuery.toString());
            ps.setDate(1, new java.sql.Date(date1.getTime()));
            ps.setDate(2, new java.sql.Date(date2.getTime()));
             rs=ps.executeQuery();
            while(rs.next()){
                if (rs.getString("subject_type") != null && rs.getString("subject_type").equals("DocumentID"))
                    documentIdList.add(rs.getString("subject").toString());
               
            
            }
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
        }
            finally {
                        if (rs != null) {
                            try {
                                rs.close();
                            } catch (SQLException e) {
                            }
                        }
                        if (ps != null) {
                            try {
                                ps.close();
                            } catch (SQLException e) {
                            }
                        }
                        if (conn != null) {
                            try {
                                conn.close();
                            } catch (SQLException e) {
                            }
                        }
                    
        }
        LOG.debug("list size..." + documentIdList.size());
        LOG.debug("Leaving getDocumentListFromOSBAudit");
        
        return documentIdList;
    }
    /**
     *
     * @param date
     * @return
     */
    private String icreamentDay(String strDate) {
        
        LOG.debug("inside icreamentDay..."+strDate);
        String modifeidDate="";
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = null;
        try {

            date = formatter.parse(strDate);
            LOG.debug("date..." + date);


        } catch (Exception e) {
            LOG.fatal("exception e.." + e);
        }
        Calendar calender = Calendar.getInstance();
        calender.setTime(date);
        calender.add(calender.DATE, 1);
        date = calender.getTime();
        modifeidDate=formatter.format(date).toString();
        LOG.debug("Leaving icreamentDay..."+modifeidDate);
        
        return modifeidDate;
    }
}
