package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;


/**
 * This DAO layer fetch data from PNA DB for Reactivate Auth Rep.
 * @Author Vikash/Sumanta/Sapna
 */
public class ReactiveAuthRepDAO {
    private static Logger LOG = Logger.getLogger(ReactiveAuthRepDAO.class);
    
    
    @Autowired
    @Qualifier("pnaNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    /**
     *
     * @param ihi
     * @return
     * @throws RecoveryDAOException
     */
    public int getStatus(String ihi) throws RecoveryDAOException {
        LOG.debug("inside getStatus..");
      
        int flag = 0;
        Map namedParameters = new HashMap();
        try {
            StringBuffer query = new StringBuffer();
            query.append("select RECORD_REPRESENTATIVE_STATUS from OES_PNADB.pcehr_record where ihi= :ihi ");
            namedParameters.put("ihi", ihi);
            
            List<Map<String,Object>> list = namedParameterJdbcTemplate.queryForList(query.toString(), namedParameters);
            LOG.debug("Values..."+list);
            if(list!=null || list.size()>0){
             //No record
                flag=  2;      
            }
            for(Map row:list){
                           Integer rep_statu = Integer.parseInt(row.get("RECORD_REPRESENTATIVE_STATUS").toString());
                LOG.debug("rep_statu --------  :: "+rep_statu);
                if(rep_statu.intValue()==1){
                    //Reject
                   flag=  1;
                }else {
                    //Valid
                    flag =0;
                }
            }
            LOG.debug("flag"+flag);
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } 
        return flag;
    }
    
    /**
     *
     * @param ihi
     * @param rep_ihi
     */
    public List<ReactivateAuthRepBO> fetchReactiveAuth_Record(String ihi, String rep_ihi)throws RecoveryDAOException {
        List<ReactivateAuthRepBO> reactivateAuthRepList=new ArrayList<ReactivateAuthRepBO>();
        
        Map namedParameters = new HashMap();
        try{
            StringBuffer query = new StringBuffer();
            query.append("select iden.record_id RECORD_ID ,iden.RELATIONSHIP_CREATED_BY RELATIONSHIP_CREATED_BY,iden.user_id USER_ID,auth.AUTHORITY_TYPE AUTHORITY_TYPE, ");
            query.append("auth.issuing_authority ISSUING_AUTHORITY,To_CHAR(auth.authority_start_date,'ddMMyyyy') AUTHORITY_START_DATE,auth.authority_doc_type authority_doc_type ");
            query.append("from OES_PNADB.identity_record_relationship iden,OES_PNADB.authority_relationship auth,OES_PNADB.pcehr_identity piden ");  
            query.append("where iden.user_id in (select user_id from OES_PNADB.identity_record_relationship ");
            query.append("where record_id in (select record_id from OES_PNADB.pcehr_record where ihi= :ihi)) ");
            query.append("and iden.record_id in (select record_id from OES_PNADB.pcehr_record where ihi= :ihi ) ");
            query.append("and iden.RELATIONSHIP_TYPE_ID IN (16,17,18,19,20) ");
            query.append("and iden.relationship_status_id = 1 ");
            query.append("and auth.user_id in (select user_id from OES_PNADB.identity_record_relationship ");
            query.append("where record_id in (select record_id from OES_PNADB.pcehr_record where ihi= :ihi )) ");
            query.append("and auth.record_id in (select record_id from OES_PNADB.pcehr_record where ihi= :ihi ) ");
            query.append("and piden.ihi= :rep_ihi ");
            query.append("and auth.AUTHORITY_STATUS = 0 ");
            query.append("and auth.user_id = iden.user_id ");
            query.append("and iden.user_id= piden.user_id ");
            query.append("and auth.record_id = iden.record_id");
            LOG.debug("Record ihi ::" + ihi);
            LOG.debug("Record rep_ihi ::" + rep_ihi);
            namedParameters.put("ihi", ihi);
            namedParameters.put("rep_ihi", rep_ihi);
            List<Map<String,Object>> list = namedParameterJdbcTemplate.queryForList(query.toString(), namedParameters);
            for(Map row:list){
                LOG.debug("Authority Type ::" + row.get("AUTHORITY_TYPE").toString());
                ReactivateAuthRepBO reactivateAuthRepBO = new ReactivateAuthRepBO();
                reactivateAuthRepBO.setRecordId(row.get("RECORD_ID").toString());
                reactivateAuthRepBO.setCreated_by((String)row.get("RELATIONSHIP_CREATED_BY"));
                reactivateAuthRepBO.setUserID(row.get("USER_ID").toString());
                reactivateAuthRepBO.setAuth_type(Integer.parseInt(row.get("AUTHORITY_TYPE").toString()));
                reactivateAuthRepBO.setAuth_issue((String)row.get("ISSUING_AUTHORITY"));
                reactivateAuthRepBO.setAuth_startdate((String)row.get("AUTHORITY_START_DATE"));
                if(row.get("AUTHORITY_DOC_TYPE") !=null){
                    reactivateAuthRepBO.setDocType(Integer.parseInt(row.get("AUTHORITY_DOC_TYPE").toString()));
                }
             //   reactivateAuthRepBO.setDocType(Integer.parseInt(row.get("AUTHORITY_DOC_TYPE") !=null ? row.get("AUTHORITY_DOC_TYPE").toString());
              //  reactivateAuthRepBO.setDocType(Integer.parseInt(row.get("AUTHORITY_DOC_TYPE").toString()));
                reactivateAuthRepList.add(reactivateAuthRepBO);
            }
            
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } 
        return reactivateAuthRepList;  
    }
  
 
}
