package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.ProviderRegistrationOIDBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ProviderRegistrationOIDForm;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

/**
 * DAO class that interacts with the DataBase to fetch Data
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Apr 2015
 * @version Change-x
 */

@Component
public class ProviderRegistrationOIDDAO {
    private static Logger LOG = Logger.getLogger(ProviderRegistrationOIDDAO.class);

    @Autowired
    @Qualifier("oimJDBCTemplate")
    private JdbcTemplate oimJDBCTemplate;

    @Value("${PROVIDER_REG_OID_DAO.GET_PROVIDER_LIST}")
    private String PROVIDER_REGISTRATION_OID_QUERY;

    /**
     * This method is called from the service class to perform Database related task for Consumer Registration OID.
     * @param providerRegistrationOIDForm
     * @return
     * @throws RecoveryDAOException
     */
    public ProviderRegistrationOIDForm fetchProviderRegistrationOIDList(ProviderRegistrationOIDForm providerRegistrationOIDForm) throws RecoveryDAOException {
        List<ProviderRegistrationOIDBO> providerRegistrationOIDList = new ArrayList<ProviderRegistrationOIDBO>();
        LOG.debug("Entered providerRegistrationOIDList Method in DAO.... ");

        try {
            providerRegistrationOIDList = oimJDBCTemplate.query(PROVIDER_REGISTRATION_OID_QUERY, new Object[] {
                                                                providerRegistrationOIDForm.getFromDate(),
                                                                providerRegistrationOIDForm.getToDate()},
                  new RowMapper<ProviderRegistrationOIDBO>() {

                    public ProviderRegistrationOIDBO mapRow(ResultSet rs,int rowNum) throws SQLException {
                        ProviderRegistrationOIDBO providerRegsitrationOIDRpt = new ProviderRegistrationOIDBO();
                        providerRegsitrationOIDRpt.setUser_login(rs.getString("usr_login"));
                        providerRegsitrationOIDRpt.setDate(rs.getDate("usr_create"));
                        return providerRegsitrationOIDRpt;
                    }
                });

            providerRegistrationOIDForm.setErrorList(providerRegistrationOIDList);
            LOG.debug(" List is" +providerRegistrationOIDList);
        } catch (Exception e) {
            LOG.fatal("Exception occured in DAO try block", e);
            throw new RecoveryDAOException(e);
        }
        LOG.debug("Leaving DAO Class");
        return providerRegistrationOIDForm;
    }

}
