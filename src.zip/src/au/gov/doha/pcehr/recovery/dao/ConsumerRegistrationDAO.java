package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.ConsumerRegistrationBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ConsumerRegistrationForm;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class ConsumerRegistrationDAO {
    
    private static Logger LOG = Logger.getLogger(ConsumerRegistrationDAO.class);
    
    @Autowired
    @Qualifier("pnaJDBCTemplate")
    private JdbcTemplate pnaJDBCTemplate;
    
    @Autowired
    @Qualifier("oimJDBCTemplate")
    private JdbcTemplate oimJDBCTemplate;
    
    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJDBCTemplate;
    
    @Value( "${CONSUMER_REG_DAO.GET_UID_UPDATE}" )
    private String CONSUMER_REG_PNA;
    
    @Value( "${CONSUMER_REG_DAO.GET_STATUS}" )
    private String CONSUMER_REG_OSB;
    
    @Value( "${CONSUMER_REG_DAO.GET_TOKEN_COUNT}" )
    private String CONSUMER_REG_OIM;
    
    
    
    /**
     *
     * @param consumerRegistrationForm
     * @return
     * @throws RecoveryDAOException
     */
    public ConsumerRegistrationForm fetchConsumerRegistrationList(ConsumerRegistrationForm consumerRegistrationForm) throws RecoveryDAOException{                                                                                                
        
        List<Map<String,Object>> consumerRegistrationList = new ArrayList<Map<String,Object>>();
        
        LOG.debug("Entered consumerRegistrationOIDList Method in DAO.... ");
        String mBunRequest = null,mBun = null;
        int oim_pcehridentity = 0;
        try {
            int i=0;
            List<ConsumerRegistrationBO> consumerRegistrationListPNA =getUserIDList(consumerRegistrationForm);
            for(ConsumerRegistrationBO consumerRegistrationBO : consumerRegistrationListPNA){
                i++;
               oim_pcehridentity =  checkConsumerRegistraionInOIM(consumerRegistrationForm,consumerRegistrationBO.getUserId());
                if(oim_pcehridentity == 0) {   
                    LOG.info("User ID " +consumerRegistrationBO.getUserId());
                    mBunRequest = osbJDBCTemplate.queryForObject(CONSUMER_REG_OSB,new Object[]{"%"+consumerRegistrationBO.getUserId()+"</ns1:pcehrIdentity>%"},String.class);
                    
                    mBun = mBunRequest.substring(mBunRequest.indexOf("mbun"), mBunRequest.indexOf("mbun>"));
                    mBun = mBun.substring(mBun.indexOf(">") + 1, mBun.indexOf("<"));
                    consumerRegistrationBO.setMBun(mBun);
                    consumerRegistrationListPNA.set(i, consumerRegistrationBO);
                }
            } 
            consumerRegistrationForm.setOimConsumerErrorList(consumerRegistrationListPNA);
        } catch (Exception e) {
            LOG.fatal("Exception occured in DAO try block", e);
            //throw new RecoveryDAOException(e);
        } 
        LOG.debug("Leaving DAO Class");  
        return consumerRegistrationForm;
    }
    
    /**
     *
     * @param consumerRegistrationForm
     * @param userid
     * @return
     */
    private int checkConsumerRegistraionInOIM(ConsumerRegistrationForm consumerRegistrationForm,String userid){
        int oim_pcehridentity=0;
        try{
            oim_pcehridentity =  oimJDBCTemplate.queryForObject(CONSUMER_REG_OIM,new Object[]{userid},Integer.class);   
        
        }catch(Exception e){
        LOG.fatal("Exception occured",new RecoveryDAOException(e));
        }
        return oim_pcehridentity;
    }
    
    /**
     * This method retrieves userid and there last update date from the  PCEHR_Identity table
     * @param consumerRegistrationForm
     */
    private List<ConsumerRegistrationBO> getUserIDList(ConsumerRegistrationForm consumerRegistrationForm){
        List<ConsumerRegistrationBO> consumerRegistrationListPNA = new ArrayList<ConsumerRegistrationBO>();
        try {
            consumerRegistrationListPNA =
                    pnaJDBCTemplate.query(CONSUMER_REG_PNA, new Object[] { consumerRegistrationForm.getFromDate(),consumerRegistrationForm.getToDate() },
                                          new RowMapper<ConsumerRegistrationBO>() {
                        public ConsumerRegistrationBO mapRow(ResultSet rs, int rowNum) throws SQLException {
                            ConsumerRegistrationBO ConsumerRegistrationRpt = new ConsumerRegistrationBO();
                            ConsumerRegistrationRpt.setUserId(rs.getString("USER_ID"));
                            ConsumerRegistrationRpt.setUDate(rs.getDate("identity_last_update_date"));
                            return ConsumerRegistrationRpt;}}
            );
        }catch(Exception e){
          LOG.fatal("Exception occured",new RecoveryDAOException(e));      
        }
        return consumerRegistrationListPNA;
    }
}