package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.util.DBUtility;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import pcehr.recovery.DataBaseConnection;


/**
 *
 * This DAO layer fetch data from PNA DB and also delete record from DB.
 * @Author Vikash/Sumanta/Sapna
 */
public class IdentityRemovalDao {

    private static Logger LOG = Logger.getLogger(IdentityRemovalDao.class);

    /**
     * Deletes the identity record.
     * @param conn
     * @param ihi
     * @throws RecoveryDAOException
     */
    public void deleteIdentity(String ihi) throws RecoveryDAOException, Exception {
        LOG.debug("Enter into the deleteiDENTITY method:");
        CallableStatement callableStatement = null;
        Connection conn = DBUtility.getDataBaseConnectionObject("PNA");
        String removal_IDENTITY = "{call REMOVAL_IDENTITY(?)}";
        int deleteIdentityStatus;
        try {
            DataBaseConnection dbConnLocal;
            LOG.debug("CALL  Identity  Procedure:");
            callableStatement = conn.prepareCall(removal_IDENTITY);
            callableStatement.setString(1, ihi);
            callableStatement.executeUpdate();

        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(callableStatement);
            DBUtility.close(conn);
        }
    }

    /**
     * Deletes the IHI record.
     * @param conn
     * @param ihi
     * @throws RecoveryDAOException
     */

    public void deleteRecord(String ihi) throws RecoveryDAOException, Exception {
        LOG.debug("Enter into the deleterecord method:" + ihi);
        CallableStatement callableStatement = null;
        Connection conn = DBUtility.getDataBaseConnectionObject("PNA");
        String removal_RECORD = "{call REMOVAL_RECORD(?)}";
        int deleteRecordStatus;
        try {
            LOG.debug("Enter into try block:");
            DataBaseConnection dbConnLocal;
            LOG.debug("CALL  Record  Procedure:");
            callableStatement = conn.prepareCall(removal_RECORD);
            callableStatement.setString(1, ihi);
            callableStatement.executeUpdate();
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(callableStatement);
            DBUtility.close(conn);
        }
    }

    /**
     * Deletes Identity and Record .
     * @param conn
     * @param ihi
     * @throws RecoveryDAOException,Exception
     */
    public void deleteIdentityRecord(String ihi) throws RecoveryDAOException, Exception {
        LOG.debug("Enter into the deleteiDENTITYrecord method:" + ihi);
        CallableStatement callableStatement = null;
        Connection conn = DBUtility.getDataBaseConnectionObject("PNA");
        String identityremoval_RECORD = "{call REMOVE_RECORD_AND_IDENTITY(?)}";
        int deleteIdentityRecordStatus;
        try {
            LOG.debug("Enter into try block:");
            DataBaseConnection dbConnLocal;
            LOG.debug("CALL iDENTITY Record  Procedure:");
            callableStatement = conn.prepareCall(identityremoval_RECORD);
            callableStatement.setString(1, ihi);
            callableStatement.executeUpdate();

        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(callableStatement);
            DBUtility.close(conn);
        }
    }

    /**
     * Deletes  Child  Record .
     * @param conn
     * @param ihi
     * @throws RecoveryDAOException,Exception
     */
    public void deleteChildIdentity(String ihi) throws RecoveryDAOException, Exception {
        LOG.debug("Enter into the deleteChildIdentity method:" + ihi);
        CallableStatement callableStatement = null;
        Connection conn = DBUtility.getDataBaseConnectionObject("PNA");
        String identityremoval_RECORD = "{call Child_REC_Rem_with_NO_Identity(?)}";
        int deleteChildRecordStatus;
        try {
            LOG.debug("Enter into try block:");
            DataBaseConnection dbConnLocal;
            LOG.debug("CALL  ChildIDentity  Procedure:");
            callableStatement = conn.prepareCall(identityremoval_RECORD);
            callableStatement.setString(1, ihi);
            callableStatement.executeUpdate();
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(callableStatement);
            DBUtility.close(conn);
        }
    }
    /**
     * @param ihi
     * @request
     * @throws RecoveryDAOException
     */
    //    public HttpServletRequest deleteIHI(String ihi,HttpServletRequest request) throws RecoveryDAOException {
    //        LOG.debug("Entered the delete record"+ihi);
    //        Connection conn = null;
    //
    //       int deleteRecordStatus;
    //       int deleteIdentityStatus;
    //       int deleteIdentityRecordStatus;
    //        int deleteChildRecordStatus;
    //     try{
    //            LOG.debug("Entered in the deleteIHI ");
    //        DataBaseConnection dbConnLocal;
    //        conn = DBUtility.getDataBaseConnectionObject("PNA");
    //        conn.setAutoCommit(false);
    //
    //        deleteRecordStatus=deleteRecord( ihi);
    //        deleteIdentityStatus=deleteIdentity(conn, ihi);
    //        deleteIdentityRecordStatus= deleteIdentityRecord(ihi);
    //        deleteChildRecordStatus=deleteChildIdentity(conn,ihi);
    //        conn.commit();
    //     }catch (Exception e){
    //            DBUtility.rollback(conn);
    //            LOG.fatal("Exception Occured..", e);
    //            throw new RecoveryDAOException(e);
    //     }finally {
    //            DBUtility.close(conn);
    //     }
    //     if(deleteRecordStatus>0){
    //     LOG.debug("deletestaus is >0");
    //         request.setAttribute("deleteStatus", "Success");
    //     }
    //     else{
    //         request.setAttribute("deleteStatus", "Fail");
    //     }
    //     if(deleteIdentityStatus>0){
    //            request.setAttribute("deleteStatus", "Success");
    //        }
    //        else{
    //            request.setAttribute("deleteStatus", "Fail");
    //        }
    //        if(deleteIdentityRecordStatus>0){
    //            request.setAttribute("deleteStatus", "Success");
    //        }
    //        else{
    //            request.setAttribute("deleteStatus", "Fail");
    //        }
    //        if(deleteChildRecordStatus>0){
    //        LOG.debug("deletestaus is >0");
    //            request.setAttribute("deleteStatus", "Success");
    //        }
    //        else{
    //            LOG.debug("deletestatus is 0...");
    //            request.setAttribute("deleteStatus", "Fail");
    //        }
    //     return request;
    //    }
    //


    /**
     * This method fetches the IHI data from DEMOGRAPHICS table from PNA database.
     * @param identityRemovalBO
     * @return
     * @throws RecoveryDAOException
     */
    public List<String> fetchRecordIHI(IdentityRemovalBO identityRemovalBO) throws RecoveryDAOException {
        String ihi = identityRemovalBO.getIhi();
        LOG.debug("Entered the fetch record" + ihi);
        List ihiList;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst = null;

        try {
            DataBaseConnection dbConnLocal;
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            ihiList = new ArrayList();
            StringBuffer query = new StringBuffer();
            query.append("select ihi,family_name,given_name,to_char(dob,'dd/MM/yyyy') dob,sex");
            query.append(" from oes_pnadb.DEMOGRAPHICS ");
            query.append(" where IHI= ? ");
            pstmt = conn.prepareStatement(query.toString());
            pstmt.setString(1, ihi);
            rst = pstmt.executeQuery();
            while (rst.next()) {
                LOG.debug("Entered thewhile loop.....");
                identityRemovalBO.setIhi(rst.getString("ihi"));
                identityRemovalBO.setFamily_Name(rst.getString("family_name"));
                identityRemovalBO.setGiven_Name(rst.getString("given_name"));
                identityRemovalBO.setDob(rst.getString("dob"));
                identityRemovalBO.setSex(rst.getString("sex"));
                ihiList.add(identityRemovalBO);
                LOG.debug("ihiList..." + ihiList.toString());

            }


        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(rst);
            DBUtility.close(pstmt);
            DBUtility.close(conn);
        }
        return ihiList;
    }

    /**
     *This method fetches the IHI data from DEMOGRAPHICS table from PNA database.
     * @param identityRemovalBO
     * @return
     * @throws RecoveryDAOException
     */
    public List<String> fetchIdentityIHI(IdentityRemovalBO identityRemovalBO) throws RecoveryDAOException {
        String ihi = identityRemovalBO.getIhi();
        LOG.debug("Entered the fetch identity" + ihi);
        List ihiList;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst = null;

        try {
            DataBaseConnection dbConnLocal;
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            ihiList = new ArrayList();
            StringBuffer query = new StringBuffer();
            query.append("select ihi,family_name,given_name,to_char(dob,'dd/MM/yyyy') dob,sex");
            query.append(" from oes_pnadb.DEMOGRAPHICS ");
            query.append(" where IHI= ? ");
            pstmt = conn.prepareStatement(query.toString());
            pstmt.setString(1, ihi);
            rst = pstmt.executeQuery();
            while (rst.next()) {
                LOG.debug("Entered thewhile loop.....");
                identityRemovalBO.setIhi(rst.getString("ihi"));
                identityRemovalBO.setFamily_Name(rst.getString("family_name"));
                identityRemovalBO.setGiven_Name(rst.getString("given_name"));
                identityRemovalBO.setDob(rst.getString("dob"));
                identityRemovalBO.setSex(rst.getString("sex"));
                ihiList.add(identityRemovalBO);
                LOG.debug("ihiList..." + ihiList.toString());
            }


        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(rst);
            DBUtility.close(pstmt);
            DBUtility.close(conn);
        }
        return ihiList;
    }

    /**
     * This method fetches the IHI data from DEMOGRAPHICS table from PNA database.
     * @param identityRemovalBO
     * @return
     * @throws RecoveryDAOException
     */
    public List<String> fetchRecordIdentityIHI(IdentityRemovalBO identityRemovalBO) throws RecoveryDAOException {
        String ihi = identityRemovalBO.getIhi();
        LOG.debug("Entered the fetchRecordIdentity " + ihi);
        List ihiList;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst = null;

        try {
            DataBaseConnection dbConnLocal;
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            ihiList = new ArrayList();
            StringBuffer query = new StringBuffer();
            query.append("select ihi,family_name,given_name,to_char(dob,'dd/MM/yyyy') dob,sex  ");
            query.append(" from oes_pnadb.DEMOGRAPHICS ");
            query.append(" where IHI= ? ");
            pstmt = conn.prepareStatement(query.toString());
            pstmt.setString(1, ihi);
            rst = pstmt.executeQuery();
            while (rst.next()) {
                LOG.debug("Entered thewhile loop.....");
                identityRemovalBO.setIhi(rst.getString("ihi"));
                identityRemovalBO.setFamily_Name(rst.getString("family_name"));
                identityRemovalBO.setGiven_Name(rst.getString("given_name"));
                identityRemovalBO.setDob(rst.getString("dob"));
                identityRemovalBO.setSex(rst.getString("sex"));
                ihiList.add(identityRemovalBO);
                LOG.debug("ihiList..." + ihiList.toString());

            }


        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);

        } finally {
            DBUtility.close(rst);
            DBUtility.close(pstmt);
            DBUtility.close(conn);
        }
        return ihiList;
    }

    /**
     * This method fetches the IHI data from DEMOGRAPHICS table from PNA database.
     * @param identityRemovalBO
     * @return
     * @throws RecoveryDAOException
     */
    public List<String> fetchChildIdentityIHI(IdentityRemovalBO identityRemovalBO) throws RecoveryDAOException {
        String ihi = identityRemovalBO.getIhi();
        LOG.debug("Entered the fetchChildIdentityIHI " + ihi);
        List ihiList;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst = null;

        try {
            DataBaseConnection dbConnLocal;
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            ihiList = new ArrayList();
            StringBuffer query = new StringBuffer();
            query.append("select ihi,family_name,given_name,to_char(dob,'dd/MM/yyyy') dob ,sex");
            query.append(" from oes_pnadb.DEMOGRAPHICS ");
            query.append(" where IHI= ? ");
            pstmt = conn.prepareStatement(query.toString());
            pstmt.setString(1, ihi);
            rst = pstmt.executeQuery();
            while (rst.next()) {
                LOG.debug("Entered thewhile loop.....");
                identityRemovalBO.setIhi(rst.getString("ihi"));
                identityRemovalBO.setFamily_Name(rst.getString("family_name"));
                identityRemovalBO.setGiven_Name(rst.getString("given_name"));
                identityRemovalBO.setDob(rst.getString("dob"));
                identityRemovalBO.setSex(rst.getString("sex"));
                ihiList.add(identityRemovalBO);
                LOG.debug("ihiList..." + ihiList.toString());

            }


        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);

        } finally {
            DBUtility.close(rst);
            DBUtility.close(pstmt);
            DBUtility.close(conn);
        }
        return ihiList;
    }

    /**
     * This method checks the record iHI is exist or not
     * @param IHI
     * @return
     * @throws RecoveryDAOException
     */
    public boolean validateRecordIHI(String IHI) throws RecoveryDAOException {
        LOG.debug("entering ValidateRecordIHI..." + IHI);
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        boolean flag = false;
        try {
            StringBuffer query = new StringBuffer();
            query.append("SELECT * FROM oes_pnadb.PCEHR_RECORD WHERE IHI = ? ");
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, IHI);
            rst = pStmt.executeQuery();
            if(rst.next()) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(rst);
            DBUtility.close(pStmt);
            DBUtility.close(conn);
        }
        LOG.debug("flag value..." + flag);
        return flag;
    }

    /**
     * This method checks the identity of  iHI is exist or not
     * @param IHI
     * @return
     * @throws RecoveryDAOException
     */
    public boolean validateIdentityIHI(String IHI) throws RecoveryDAOException {
        LOG.debug("entering ValidateIdentityIHI .." + IHI);
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        boolean flag = false;
        try {
            StringBuffer query = new StringBuffer();
            query.append("SELECT * FROM oes_pnadb.PCEHR_IDENTITY WHERE IHI = ? ");
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, IHI);
            rst = pStmt.executeQuery();
            while (rst.next()) {
                flag = true;
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(rst);
            DBUtility.close(pStmt);
            DBUtility.close(conn);
        }
        LOG.debug("flag value..." + flag);
        return flag;
    }

    /**
     * This method checks  iHI is Authorise restrictied  or not
     * @param IHI
     * @return
     * @throws RecoveryDAOException
     */
    public boolean arIHIRestricted(String IHI) throws RecoveryDAOException {
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        boolean flag = false;
        try {
            StringBuffer query = new StringBuffer();
            query.append("SELECT COUNT(*)");
            query.append(" FROM oes_pnadb.RESTRICTED_REGISTRATION");
            query.append(" WHERE RESTRICTED_REGISTRATION.RESTRICTED_IHI = ?");
            query.append(" AND TRUNC(RESTRICTED_REGISTRATION.RESTRICTION_EXPIRY) > TRUNC(SYSDATE)");
            
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, IHI);
            rst = pStmt.executeQuery();
            while (rst.next()) {
                LOG.debug("Resticted value...." + rst.getInt(1));
                if (rst.getInt(1) > 0) {
                    LOG.debug("IHI is Resticted");
                    flag = true;

                }
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(rst);
            DBUtility.close(pStmt);
            DBUtility.close(conn);
        }
        LOG.debug("flag value..." + flag);
        return flag;

    }
}
