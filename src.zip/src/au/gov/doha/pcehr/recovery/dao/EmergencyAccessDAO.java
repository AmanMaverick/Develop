package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.EmergencyAccessExpiryBO;
import au.gov.doha.pcehr.recovery.form.EmergencyExpiryForm;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.ParseException;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

/**
 * DAO class that interacts with the DataBase to fetch Data
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Jan 2015
 * @version Change-x
 */
@Component
public class EmergencyAccessDAO {

    @Autowired
    @Qualifier("pnaJDBCTemplate")
    private JdbcTemplate pnaJdbcTemplate;
    
    @Value( "${EMERGENCYACCESSDAO.GET_EMERGENCY_EXPIRY_LIST}" )
    private String EMERGENCY_EXPIRY_LIST_QUERY;
    
    private static Logger LOG = Logger.getLogger(EmergencyAccessDAO.class);

    /**
     * This method is called from the service class to perform Database related task for Emergency Access Expiry.
     * Accesses Data from Database and inserts into List
     * @param emergencyExpiryForm
     * @return
     * @throws RecoveryDAOException
     * @throws ParseException
     */
    public EmergencyExpiryForm fetchEmergencyExpiryList(EmergencyExpiryForm emergencyExpiryForm) throws RecoveryDAOException{                                                                                                
        List<EmergencyAccessExpiryBO> emergencyAccessExpiryRptList = new ArrayList<EmergencyAccessExpiryBO>();
        LOG.debug("Entered fetchEmergencyExpiryList Method in DAO.... ");
        try {
            emergencyAccessExpiryRptList =
                    pnaJdbcTemplate.query(EMERGENCY_EXPIRY_LIST_QUERY, new Object[] { emergencyExpiryForm.getDate() },new RowMapper<EmergencyAccessExpiryBO>() {
                        public EmergencyAccessExpiryBO mapRow(ResultSet rs, int rowNum) throws SQLException {
                            EmergencyAccessExpiryBO emergencyAccessExpiryRpt = new EmergencyAccessExpiryBO();
                            emergencyAccessExpiryRpt.setRelationshipParty(rs.getString("RELATIONSHIP_PARTY"));
                            emergencyAccessExpiryRpt.setIhi(rs.getString("IHI"));
                            emergencyAccessExpiryRpt.setGivenName(rs.getString("GIVEN_NAME"));
                            emergencyAccessExpiryRpt.setFamilyName(rs.getString("FAMILY_NAME"));
                            emergencyAccessExpiryRpt.setDob(rs.getDate("DOB"));
                            
                            emergencyAccessExpiryRpt.setRelationShipStartDate(rs.getDate("RELATIONSHIP_START_DATE"));
                            
                            return emergencyAccessExpiryRpt;
                        }
                    });
            LOG.info("emergencyAccessExpiryRptList size :: " + emergencyAccessExpiryRptList.size());
            emergencyExpiryForm.setExpiryList(emergencyAccessExpiryRptList);
        } catch (Exception e) {
            LOG.fatal("Exception occured in DAO try block", e);
                throw new RecoveryDAOException(e);
        }
        return emergencyExpiryForm;
    }
}
