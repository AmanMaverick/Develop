package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DocumentReSyncDAO {

    private static Logger LOG = Logger.getLogger(DocumentTransformationDAO.class);
    @Autowired
    @Qualifier("rlsNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate rlsNamedParameterJdbcTemplate;

    @Autowired
    @Qualifier("htbNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate htbNamedParameterJdbcTemplate;

    @Value("${DOCUMENT_RE_SYNC.GET_IHI}")
    private String get_document;

    @Value("${DOCUMENT_RE_SYNC.GET_IHI_HDR}")
    private String get_document_hdr;

    /**
     *This method retrieves the IHI for the give document id from RLS DataBase.
     * @param docId
     * @return ihi
     * @throws RecoveryDAOException
     */
    public String getIHIfromRLS(String docId) throws RecoveryDAOException {
        String ihi = null;
        try {
            LOG.info("Checking for Document in RLS");
            Map<String, String> namedParameters = new HashMap<String, String>();
            namedParameters.put("docID", docId);
            List<Map<String, Object>> list = rlsNamedParameterJdbcTemplate.queryForList(get_document, namedParameters);
            for (Map row : list) {
                ihi = (String) row.get("IHI");
                LOG.info("In RLS List " + ihi);
            }
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryDAOException(e);
        }
        return ((ihi != null && ihi.length() > 0) ? ihi.substring(0, 16) : null);
    }

    /**
     * This method retrieves the IHI for the give document id from HDR DataBase.
     * @param docId
     * @return ihi
     * @throws RecoveryDAOException
     */
    public String getIHIfromHDR(String docId) throws RecoveryDAOException {
        String HDR_ihi = null;
        try {
            LOG.info("Checking for Document in HDR");
            Map<String, String> namedParameters = new HashMap<String, String>();
            namedParameters.put("docID", docId);
            List<Map<String, Object>> list = htbNamedParameterJdbcTemplate.queryForList(get_document_hdr, namedParameters);
            for (Map row : list) {
                HDR_ihi = (String) row.get("IHI");
                LOG.info("In HDR List " + HDR_ihi);
            }
        } catch (Exception e) {
            LOG.fatal("Exception occured", e);
            throw new RecoveryDAOException(e);
        }
        return ((HDR_ihi != null && HDR_ihi.length() > 0) ? HDR_ihi.substring(0, 16) : null);
    }
}
