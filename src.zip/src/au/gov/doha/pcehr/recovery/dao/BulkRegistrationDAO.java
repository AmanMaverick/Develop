package au.gov.doha.pcehr.recovery.dao;

import au.gov.doha.pcehr.recovery.bo.BulkRegistrationStatusBO;
import au.gov.doha.pcehr.recovery.bo.ReconcileDataReportBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.BulkRegistrationForm;

import java.math.BigDecimal;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.NumberFormat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;


/**
 * Used for DB interaction for Bulk registration process.
 * @author Rakhi Tholia
 * @since 4th Dec 2015
 * @version Change-x
 */

@Component
public class BulkRegistrationDAO {
    private static Logger LOG = Logger.getLogger(BulkRegistrationDAO.class);    
    
    @Value("${BULKREG_GET_IHI_STATUS}")
    private String getBulkRegIHIStatus;
        
    @Value("${BULKREG_WHERE_CLAUSE}")
     private String whereClause;   
        
    @Value("${BULKREG_GET_COUNT_STAGING_PRIMARY}")
    private String stagingPrimaryCountQuery;   
//    
//    @Value("{BULKREG_GET_ERROR_CODE}")
//    private String distinctErrorCode;
    
    @Value("{BULKREG_RECONCILE_REPORT_QUERY}")
    private String reconcileReportQuery;
    
    @Autowired
    @Qualifier("osbBulkRegJdbcTemplate")
    private JdbcTemplate osbBulkRegJdbcTemplate;
    
    
    
    @Autowired
    @Qualifier("osbBulkRegNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate osbBulkRegNamedParameterJdbcTemplate;
     
    private static final String NIO_BULK_REG_UPDATE="NIO_BULK_REG_UPDATE";
    
    private static final String NIO_BULK_REG_STOP="NIO_BULK_REG_STOP";
    
    private static final String BULK_REG_STATE_RC = "RC";
    
    private static final String WHERE_CLAUSE="WHERE_CLAUSE";
    
    private static final String WHERE_CLAUSE_PARAMETER="WHERE_CLAUSE_PARAMETER";
    
    
    
    /**
     * To getthe count on No. of Rows in Staging Table.
     * @return
     * @throws RecoveryDAOException
     */
    public long getStagingPrimaryCount()throws RecoveryDAOException{        
       long count = osbBulkRegJdbcTemplate.queryForLong(stagingPrimaryCountQuery,null);
       return count;
    }
    
    /**
     * Calls callBulkRegProc method 
     * with state 'V' for validateIHIinfo
     * @param bulkRegistrationForm
     * @return
     */
    public BulkRegistrationForm validateIHIInfo(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException{
        int action=0;
        if("Validate ALL IHIs".equals(bulkRegistrationForm.getValidateAction())){
            callBulkRegProc(bulkRegistrationForm, 0, "V", 1);
        }else if("Select IHI List for Validation".equals(bulkRegistrationForm.getValidateAction())){
            callBulkRegProc(bulkRegistrationForm, 0, "V", 2);
        }else if("Select Number of Rows for Validation".equals(bulkRegistrationForm.getValidateAction())){
            callBulkRegProc(bulkRegistrationForm, bulkRegistrationForm.getValidateNoOfRows(), "V", 3);
        }
        
        return bulkRegistrationForm;
    }
        
    /**
     * This method generates the where clause for the given parameer.
     * @param bulkRegistrationForm
     * @return
     */
    private  Map<String,Object>  getWhereClause(BulkRegistrationForm bulkRegistrationForm){
        Map<String,Object> whereClauseData = new HashMap<String,Object>();
         StringBuffer whereClause = new StringBuffer(); 
         
        Map<String,String> namedParameters = new HashMap<String,String>();
        List<Object> params = new ArrayList<Object>();
        
        if(!bulkRegistrationForm.getReconRegistrationError().equals("") && bulkRegistrationForm.getReconRegistrationError()!=null && bulkRegistrationForm.getReconRegistrationError().length()>0){
            whereClause.append(" AND BULK_ERROR_CODE = ? ");
            
            params.add( bulkRegistrationForm.getReconRegistrationError());
        }
        if(bulkRegistrationForm.getReconRegistrationState()!=null && bulkRegistrationForm.getReconRegistrationState().length()>0){
            if("V".equals(bulkRegistrationForm.getReconRegistrationState()) || "R".equals(bulkRegistrationForm.getReconRegistrationState())
               || "VR".equals(bulkRegistrationForm.getReconRegistrationState())){
                whereClause.append(" AND BULKREG_ACTION = ? ");       
            }else{
                whereClause.append(" AND BULKREG_STATE = ? ");
            }
            params.add( bulkRegistrationForm.getReconRegistrationState());
           
        }
        if("reconcileRepo".equals(bulkRegistrationForm.getReconReportType())){
            whereClause.append(" AND BULKREG_STATE != ? ");
            params.add( "RC");
        }
        whereClauseData.put(WHERE_CLAUSE_PARAMETER,params);
        whereClauseData.put(WHERE_CLAUSE,whereClause.toString());
        return whereClauseData;
    }
    
        
    
    /**
     
     * @param bulkRegistrationForm
     * @return
     */
    public BulkRegistrationForm generateReconsileRport(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException {
        bulkRegistrationForm=getSummaryReport(bulkRegistrationForm);
        bulkRegistrationForm=getDetailedReport(bulkRegistrationForm);
        return bulkRegistrationForm;
    }
    
    /**
     *
     * @param bulkRegistrationForm
     * @return
     */
    private BulkRegistrationForm getSummaryReport(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException {
        List<ReconcileDataReportBO> reconcileDataReportBOLst = new ArrayList<ReconcileDataReportBO>();
        Connection conn = null;
        PreparedStatement pStmt  = null;
        ResultSet rst = null;
        try{
            StringBuffer query = new StringBuffer();
            query.append(" SELECT record_required, ");
            query.append("   BULKREG_FLAG , ");
            query.append("   COUNT(*) TOTAL_COUNT ");
            query.append(" FROM STAGING_PRIMARY ");
            /*  for defect : eHeal00013862 changed the YTrue condition to TrueFalse as True is the value present in DB for record required*/
            /* changed the NTrue condition to FalseTrue as True is the value present in DB for record required*/
            query.append(" WHERE (record_required||BULKREG_FLAG) IN ('TrueFalse','FalseTrue','TrueTrue','FalseFalse') ");
            query.append(" GROUP BY record_required,BULKREG_FLAG ");
                        
            LOG.debug("Query-->"+query.toString());
            conn = osbBulkRegJdbcTemplate.getDataSource().getConnection();
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setFetchSize(50000);
           
            rst = pStmt.executeQuery();
            int i=0;
            while(rst.next()){
                i++;
                if(i%50000==0){
                    LOG.debug("Fetching"+i);
                }
                ReconcileDataReportBO reconcileDataReportBO = new ReconcileDataReportBO();
                reconcileDataReportBO.setCount((BigDecimal)rst.getObject("TOTAL_COUNT"));
                reconcileDataReportBO.setRecord_required((String)rst.getObject("RECORD_REQUIRED"));
                reconcileDataReportBO.setBulkreg_flag((String)rst.getObject("BULKREG_FLAG"));
                reconcileDataReportBOLst.add(reconcileDataReportBO);
            }
            bulkRegistrationForm.setReconcileDataReportSummaryBOLst(reconcileDataReportBOLst);
                
        }catch(Exception e){
            LOG.fatal("Exception occured",e);
            throw new RecoveryDAOException(e);
        }finally{
            if(rst!=null){
                try {
                    rst.close();
                } catch (SQLException e) {
                }
            }
            if(pStmt!=null){
                try {
                    pStmt.close();
                } catch (SQLException e) {
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                }
            }
        }
        return bulkRegistrationForm;
    }
    /**
     *
     * @param bulkRegistrationForm
     * @return
     */
    private BulkRegistrationForm getDetailedReport(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException {
        List<ReconcileDataReportBO> reconcileDataReportBOLst = new ArrayList<ReconcileDataReportBO>();
        Connection conn = null;
        PreparedStatement pStmt  = null;
        ResultSet rst = null;
        try{
            StringBuffer query = new StringBuffer();
            query.append(" SELECT a.ihi,  ");
            query.append("   a.RECORD_REQUIRED ,  ");
            query.append("   b.RECORD_NOT_REQD_REASON_DESC ,  ");
            query.append("   a.BULKREG_MESSAGE_ID ,  ");
            query.append("   a.BULKREG_INTEGRATION_ID,  ");
            query.append("   a.BULKREG_ERROR_CODE,  ");
            query.append("   a.BULKREG_LAST_UPDATED_DATE,  ");
            query.append("   a.BULKREG_FLAG,  ");
            query.append("   a.OPTOUT_FLAG,  ");
            query.append("   a.EXTRACT_FILE_NAME  ");
            query.append(" FROM STAGING_PRIMARY a,  ");
            query.append("   (SELECT ihi,  ");
            query.append("     RECORD_NOT_REQD_REASON_DESC  ");
            query.append("   FROM STAGING_INELIGIBLE_REASONS a,  ");
            query.append("     RECORD_NOT_REQUIRED_REASON_ID b  ");
            query.append("   WHERE a.RECORD_NOT_REQUIRED_REASON_ID = b.RECORD_NOT_REQUIRED_REASON_ID  ");
            query.append("   ) b  ");
            query.append(" WHERE a.ihi=b.ihi(+)  ");
            /* for defect : eHeal00013862  changed the YTrue condition to TrueFalse as True is the value present in DB for record required*/
            /* changed the NTrue condition to FalseTrue as True is the value present in DB for record required*/
            query.append(" AND (record_required||BULKREG_FLAG) IN ('TrueFalse','FalseTrue') order by ihi ASC ");
           
                        
            LOG.debug("Query-->"+query.toString());
            conn = osbBulkRegJdbcTemplate.getDataSource().getConnection();
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setFetchSize(50000);
           
            rst = pStmt.executeQuery();
            int i=0;
            while(rst.next()){
                i++;
                if(i%50000==0){
                    LOG.debug("Fetching"+i);
                }
                ReconcileDataReportBO reconcileDataReportBO = new ReconcileDataReportBO();
                reconcileDataReportBO.setIHI((BigDecimal)rst.getObject("IHI"));
                reconcileDataReportBO.setRecord_required((String)rst.getObject("RECORD_REQUIRED"));
                reconcileDataReportBO.setRecord_not_required((String)rst.getObject("RECORD_NOT_REQD_REASON_DESC"));
                
                reconcileDataReportBO.setBulkreg_message_id((String) rst.getObject("BULKREG_MESSAGE_ID"));
                
                reconcileDataReportBO.setBulkreg_integration_id((String)rst.getObject("BULKREG_INTEGRATION_ID"));
                reconcileDataReportBO.setBulkreg_error_code((String)rst.getObject("BULKREG_ERROR_CODE"));
                if(null!=rst.getObject("BULKREG_LAST_UPDATED_DATE")){
                reconcileDataReportBO.setBulkreg_last_updated_date(rst.getObject("BULKREG_LAST_UPDATED_DATE").toString());
                }
                reconcileDataReportBO.setBulkreg_flag((String)rst.getObject("BULKREG_FLAG"));;
                reconcileDataReportBO.setOptout_flag((String)rst.getObject("OPTOUT_FLAG"));;
                reconcileDataReportBO.setExtract_file_name((String)rst.getObject("EXTRACT_FILE_NAME"));
                
                reconcileDataReportBOLst.add(reconcileDataReportBO);
            }
            bulkRegistrationForm.setReconcileDataReportDetailedBOLst(reconcileDataReportBOLst);
                
        }catch(Exception e){
            LOG.fatal("Exception occured",e);
            throw new RecoveryDAOException(e);
        }finally{
            if(rst!=null){
                try {
                    rst.close();
                } catch (SQLException e) {
                }
            }
            if(pStmt!=null){
                try {
                    pStmt.close();
                } catch (SQLException e) {
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                }
            }
        }
        return bulkRegistrationForm;
    }
    /**
     
     * @param bulkRegistrationForm
     * @return
     */
    public BulkRegistrationForm generateDescripencyRport(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException {
        List<ReconcileDataReportBO> reconcileDataReportBOLst = new ArrayList<ReconcileDataReportBO>();
        Connection conn = null;
        PreparedStatement pStmt  = null;
        ResultSet rst = null;
        try{
            StringBuffer query = new StringBuffer();
            //GEt where clause
            Map<String,Object> whereClauseData = getWhereClause(bulkRegistrationForm);
            //Form the query
           
            query.append(" SELECT IHI,BULKREG_STATE,BULKREG_ERROR_CODE FROM STAGING_PRIMARY where 1 = 1 ").append(whereClauseData.get(WHERE_CLAUSE));
            
            LOG.debug("New Query 1-->"+query.toString());
            conn = osbBulkRegJdbcTemplate.getDataSource().getConnection();
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setFetchSize(50000);
            List<Object> whereClasuseData = (List<Object>) whereClauseData.get(WHERE_CLAUSE_PARAMETER);
            for(int i=0;i<whereClasuseData.size();i++){
                pStmt.setObject(i+1, whereClasuseData.get(i));
            }
            rst = pStmt.executeQuery();
            int i=0;
            while(rst.next()){
                i++;
                if(i%50000==0){
                    LOG.debug("Fetching"+i);
                }
                ReconcileDataReportBO reconcileDataReportBO = new ReconcileDataReportBO();
                reconcileDataReportBO.setIHI((BigDecimal)rst.getObject("IHI"));
                reconcileDataReportBO.setBulkreg_state((String)rst.getObject("BULKREG_STATE"));
                reconcileDataReportBO.setBulkreg_error_code((String)rst.getObject("BULKREG_ERROR_CODE"));
                reconcileDataReportBOLst.add(reconcileDataReportBO);
            }
            bulkRegistrationForm.setReconcileDataReportBOLst(reconcileDataReportBOLst);
                
        }catch(Exception e){
            LOG.fatal("Exception occured",e);
            throw new RecoveryDAOException(e);
        }finally{
            if(rst!=null){
                try {
                    rst.close();
                } catch (SQLException e) {
                }
            }
            if(pStmt!=null){
                try {
                    pStmt.close();
                } catch (SQLException e) {
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                }
            }
        }
        
        return bulkRegistrationForm;
    }
    
     /**
        * @param bulkRegistrationForm
      * @return
      */
     public BulkRegistrationForm generateDescripencyRportFEAndAll(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException {
         List<ReconcileDataReportBO> reconcileDataReportBOLst = new ArrayList<ReconcileDataReportBO>();
         Connection conn = null;
         PreparedStatement pStmt = null;
         ResultSet rst = null;
         try {
             StringBuffer query = new StringBuffer();
             //GEt where clause
             Map<String, Object> whereClauseData = getWhereClause(bulkRegistrationForm);
             //Form the query


             query.append("SELECT ");
             query.append("DISTINCT A.IHI,A.BULKREG_STATE,  ");
             query.append(" CASE ");
             query.append("   WHEN a.BULKREG_STATE = 'FE' ");
             query.append("   THEN B.BULK_ERROR_CODE ");
             query.append("  WHEN a.BULKREG_STATE = 'TE' ");
             query.append("  THEN a.BULKREG_ERROR_CODE ");
             query.append("END AS BULK_ERROR_CODE, ");
             query.append("  CASE ");
             query.append("   WHEN a.BULKREG_STATE IN ('FE') ");
             query.append("  THEN B.BULKREG_ERROR_DESCRIPTION ");
             query.append("  WHEN a.BULKREG_STATE = 'TE'      THEN null ");
             query.append(" END AS BULKREG_ERROR_DESCRIPTION ");
             query.append("  FROM STAGING_PRIMARY A, ");
             query.append("  (SELECT BULKREG_ERROR_CODE BULK_ERROR_CODE, ");
             query.append("    BULKREG_ERROR_DESCRIPTION, ");
             query.append("    BULKREG_MESSAGE_ID, replace(BULKREG_INTEGRATION_ID, '_validate','') as BULKREG_INTEGRATION_ID ");
             query.append("  FROM STAGING_ERROR ");
             query.append(" ) B ");
             query.append(" WHERE A.BULKREG_INTEGRATION_ID=b.BULKREG_INTEGRATION_ID(+) ").append(whereClauseData.get(WHERE_CLAUSE));

             LOG.debug("Query-->" + query.toString());
             conn = osbBulkRegJdbcTemplate.getDataSource().getConnection();
             pStmt = conn.prepareStatement(query.toString());
             pStmt.setFetchSize(50000);
             List<Object> whereClasuseData = (List<Object>) whereClauseData.get(WHERE_CLAUSE_PARAMETER);
             for (int i = 0; i < whereClasuseData.size(); i++) {
                 pStmt.setObject(i + 1, whereClasuseData.get(i));
             }
             rst = pStmt.executeQuery();
             int i = 0;
             while (rst.next()) {
                 i++;
                 if (i % 50000 == 0) {
                     LOG.debug("Fetching" + i);
                 }
                 ReconcileDataReportBO reconcileDataReportBO = new ReconcileDataReportBO();
                 reconcileDataReportBO.setIHI((BigDecimal) rst.getObject("IHI"));
                 reconcileDataReportBO.setBulkreg_state((String) rst.getObject("BULKREG_STATE"));
                 reconcileDataReportBO.setBulkreg_error_code((String) rst.getObject("BULK_ERROR_CODE"));
                 reconcileDataReportBO.setBulkreg_error_desc((String) rst.getObject("BULKREG_ERROR_DESCRIPTION"));
                 reconcileDataReportBOLst.add(reconcileDataReportBO);
             }
             bulkRegistrationForm.setReconcileDataReportBOLst(reconcileDataReportBOLst);

         } catch (Exception e) {
             LOG.fatal("Exception occured", e);
             throw new RecoveryDAOException(e);
         } finally {
             if (rst != null) {
                 try {
                     rst.close();
                 } catch (SQLException e) {
                 }
             }
             if (pStmt != null) {
                 try {
                     pStmt.close();
                 } catch (SQLException e) {
                 }
             }
             if (conn != null) {
                 try {
                     conn.close();
                 } catch (SQLException e) {
                 }
             }
         }

         return bulkRegistrationForm;
     }
    /**
     * This method returns the distinct error code.Exception is not throwned to higher level as it will stop the page loding.
     * @return
     */
    public List<String> getDistinctErrorCode(){
        List<String> errorCode = new ArrayList<String>();
        try{
        
            List<Map<String, Object>> list =  osbBulkRegJdbcTemplate.queryForList("select distinct BULKREG_ERROR_CODE from STAGING_error where bulkreg_error_code is not null ");
            for(Map<String,Object> data : list){
                errorCode.add((String)data.get("bulkreg_error_code"));
            }    
            
        }catch(Exception e){
            LOG.fatal("Exception occured",e);
        }
        return errorCode;
        
    }
    
    /**
     * This method call the stop process.
     * OPT = 1  All IHI  based on given condition
     * OPT = 2 All File IHI
     * OPT = 3 for given row numss
     * @param state
     * @param action
     * @param ihiList
     * @param rowNum
     */
public void stopOSBProcess(String state,int action,String[] ihiList,long rowNum) throws RecoveryDAOException{
        
        SimpleJdbcCall simpleJdbcCall =
            new SimpleJdbcCall(osbBulkRegJdbcTemplate).withSchemaName("OSB_OPTOUT_STAGING").withProcedureName(NIO_BULK_REG_STOP).declareParameters(new SqlParameter("STATE",
                                                                                                                                                                   OracleTypes.VARCHAR),
                                                                                                                                                  new SqlParameter("OPT",
                                                                                                                                                                   OracleTypes.INTEGER),
                                                                                                                                                  new SqlParameter("ARR",
                                                                                                                                                                   OracleTypes.ARRAY,
                                                                                                                                                                   "TAB_VAR_ARRAY"),
                                                                                                                                                  new SqlParameter("ROW_NUM",
                                                                                                                                                                   OracleTypes.INTEGER));

        try {
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("STATE", state);
            inParamMap.put("OPT", action);
            inParamMap.put("ARR", new SqlArrayValue(ihiList));
            inParamMap.put("ROW_NUM",rowNum);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            simpleJdbcCall.execute(in);
            
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e.getMessage(), e);
        }
        
    }
    /**
     * Calls callBulkRegProc method
     * with state 'R' for bulkRecordCreation
     * @param bulkRegistrationForm
     * @return
     * @throws RecoveryDAOException
     */
    public BulkRegistrationForm bulkRecordCreation(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException{
        if("Create Records for ALL IHIs".equals(bulkRegistrationForm.getRecordCreationAction())){
            callBulkRegProc(bulkRegistrationForm, 0, "R", 1);
        }else if("Create Record for List of IHIs".equals(bulkRegistrationForm.getRecordCreationAction())){
            callBulkRegProc(bulkRegistrationForm, 0, "R", 2);
        }else if("Create Records for a Specified Number of Rows".equals(bulkRegistrationForm.getRecordCreationAction())){
            callBulkRegProc(bulkRegistrationForm, bulkRegistrationForm.getRecordCreationNoOfRows(), "R", 3);
        }
        return bulkRegistrationForm;
    }
    
    
    /**
     * Calls callBulkRegProc method 
     * with state 'VR' for validateAndBulkRecordCreation
     * @param bulkRegistrationForm
     * @return
     * @throws RecoveryDAOException
     */
    public BulkRegistrationForm validateAndBulkRecordCreation(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException{
        
        if("Validate and Register for ALL IHIs".equals(bulkRegistrationForm.getValidateAndRecordCreation())){
            callBulkRegProc(bulkRegistrationForm,0,"VR",1);
        }else if("Validate and Register for a List of IHIs".equals(bulkRegistrationForm.getValidateAndRecordCreation())){
            callBulkRegProc(bulkRegistrationForm,0,"VR",2);
        }else if("Validate and Register for Specified Number of Rows".equals(bulkRegistrationForm.getValidateAndRecordCreation())){
            callBulkRegProc(bulkRegistrationForm,bulkRegistrationForm.getValidateAndCreateNoOfRows(),"VR",3);
        }
        
        return bulkRegistrationForm;
    }
    
    
    /**
     * Calls NIO_BULK_REG_UPDATE stored procedure
     * with appropriate input parameters
     * @param bulkRegistrationForm
     * @param ihi
     * @param allIHI
     * @param rows
     * @return
     * @throws RecoveryDAOException
     */
    private void callBulkRegProc(BulkRegistrationForm bulkRegistrationForm, long rownum, String state,
                                int action) throws RecoveryDAOException{
        if(osbBulkRegJdbcTemplate == null){
          LOG.debug("Datasource is null");   
        }
        SimpleJdbcCall simpleJdbcCall =
            new SimpleJdbcCall(osbBulkRegJdbcTemplate).withSchemaName("OSB_OPTOUT_STAGING").withProcedureName(NIO_BULK_REG_UPDATE).declareParameters(new SqlParameter("STATE",
                                                                                                                                                                   OracleTypes.VARCHAR),
                                                                                                                                                  new SqlParameter("OPT",
                                                                                                                                                                   OracleTypes.INTEGER),
                                                                                                                                                  new SqlParameter("ARR",
                                                                                                                                                                   OracleTypes.ARRAY,
                                                                                                                                                                   "TAB_VAR_ARRAY"),
                                                                                                                                                  new SqlParameter("ROW_NUM",
                                                                                                                                                                   OracleTypes.INTEGER));

        try {
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("STATE", state);
            inParamMap.put("OPT", action);
            inParamMap.put("ARR", new SqlArrayValue(bulkRegistrationForm.getIhiList()));
            inParamMap.put("ROW_NUM",rownum);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            simpleJdbcCall.execute(in);
            
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e.getMessage(), e);
        }
    }
    
    
    /**
     * 
     * @param bulkRegistrationForm
     * @return
     * @throws RecoveryDAOException
     */
    public BulkRegistrationForm bulkRegStatus(BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException{
            LOG.info("bulkRegistrationForm.getStatusAction()::::"+bulkRegistrationForm.getStatusAction());
            getStatusReport(bulkRegistrationForm);
    
            return bulkRegistrationForm;
    }
    
    
    
    
    
    /**
       *This method will generate the status for the List of IHIs
       * @param bulkRegistrationForm
       * @return bulkRegistrationForm
       * @throws RecoveryDAOException
       */
      private BulkRegistrationForm getStatusReport(BulkRegistrationForm bulkRegistrationForm)throws RecoveryDAOException{    
          Connection conn = null;
          try{
              LOG.info("bulkRegistrationForm.getBulkStatusAction()..."+bulkRegistrationForm.getBulkStatusAction());
             List<BulkRegistrationStatusBO> statusBoList = new ArrayList<BulkRegistrationStatusBO>();
              conn = osbBulkRegJdbcTemplate.getDataSource().getConnection();
              if("ALL IHI".equals(bulkRegistrationForm.getStatusAction())){
                 statusBoList=  getALLIHI(conn,bulkRegistrationForm);
              }else if("List of IHIs".equals(bulkRegistrationForm.getStatusAction())){
                  statusBoList = getforGivenIHI(conn,bulkRegistrationForm.getIhiList());
              }else if("File Name".equals(bulkRegistrationForm.getStatusAction())) {
                  statusBoList = getByFile(conn,bulkRegistrationForm);
              }
             
             bulkRegistrationForm.setBulkGenerationStatusReport(statusBoList);                      
          }catch(Exception ex){
              LOG.fatal("Exception Occured",ex);
              throw new RecoveryDAOException(ex.getMessage(),ex);
          }finally{
              if(conn!=null)
                try {
                   conn.close();
                } catch (SQLException e) {
                }
        }
          return bulkRegistrationForm;
      }

    /**
     *
     * @param conn
     * @param arr
     * @return
     * @throws RecoveryDAOException
     */
    private List<BulkRegistrationStatusBO>  getforGivenIHI(Connection conn,String[] arr) throws RecoveryDAOException {
            List<BulkRegistrationStatusBO> bulkRegistrationStatusBOList = new ArrayList<BulkRegistrationStatusBO>();
            CallableStatement callableStatement = null;
            ResultSet rs = null;
            try{
                ArrayDescriptor des = ArrayDescriptor.createDescriptor("OSB_OPTOUT_STAGING.TAB_VAR_ARRAY", conn);
                ARRAY array_to_pass = new ARRAY(des,conn,arr);
                LOG.debug("converted String array to Oracle.sql array");
                
                callableStatement = conn.prepareCall("{call bulkRegistrationStatus(?,?,?)}");
                callableStatement.setFetchSize(100000);
                //bulkRegistrationStatus is a stored procedure
                callableStatement.setInt(1, 1);
                callableStatement.setArray(2, array_to_pass);
                callableStatement.registerOutParameter(3, OracleTypes.CURSOR);

                // execute getDBUSERCursor store procedure
                callableStatement.executeUpdate();

                // get cursor and cast it to ResultSet
                rs = (ResultSet) callableStatement.getObject(3);

                // loop it like normal
                while (rs.next()) {
                    BulkRegistrationStatusBO bo = new BulkRegistrationStatusBO();
                    bo.setIHI(rs.getBigDecimal("IHI"));
                    bo.setState(rs.getString("state"));
                    bo.setError(rs.getString("error"));
                    bulkRegistrationStatusBOList.add(bo);
                }           
                
            }catch(Exception e){
                        LOG.fatal("Exception has occured..",e);
                        throw new RecoveryDAOException(e);
            }finally{
                
            }
            return bulkRegistrationStatusBOList;    
        }    
    
    /**
     * This method is fetches the status from the Staging primay table.
     * Note Fetch size is configured to increase the performance.
     * @param conn
     * @return
     * @throws RecoveryDAOException
     */
    private List<BulkRegistrationStatusBO>  getALLIHI(Connection conn,BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException {
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        StringBuffer query = new StringBuffer();
        try{
            query.append("select bulkreg_State state,count(*) count  ");
            query.append("from STAGING_PRIMARY where bulkreg_State in ('L','O','RC','FE','TE','VC',null) ");
            query.append("group by bulkreg_State ");
            
            pStmt = conn.prepareStatement(query.toString());
            
            pStmt.setFetchSize(100);
            rst = pStmt.executeQuery();
            List<BulkRegistrationStatusBO> bulkRegistrationStatusBOList = new ArrayList<BulkRegistrationStatusBO>();
            int i=0;
            BulkRegistrationStatusBO bo = new BulkRegistrationStatusBO();
            while(rst.next()){
                bo = setStateInBo( rst.getString("state"),NumberFormat.getNumberInstance(Locale.US).format(rst.getInt("count")),bo);
            }
            bo.setTotalIHI(NumberFormat.getNumberInstance(Locale.US).format(getStagingPrimaryCount()));
            
            bulkRegistrationStatusBOList.add(bo);
            return bulkRegistrationStatusBOList;

        }catch(Exception e){
            LOG.fatal("Exception has occured..",e);
            throw new RecoveryDAOException(e);
        }finally{
            if(rst!=null){
                try {
                    rst.close();
                } catch (SQLException e) {
                }
            }
            if(pStmt!=null){
                try {
                    pStmt.close();
                } catch (SQLException e) {
                }
            }
        }
    }
    
    /**
     *
     * @param state
     * @param count
     * @param bo
     * @return
     */
    private BulkRegistrationStatusBO setStateInBo(String state,String count,BulkRegistrationStatusBO bo){
        //('L','O','RC','FE','TE','VC',null)
        if("VC".equals(state)){
            bo.setValidationCompleted(count);
        }else if("L".equals(state)){
            bo.setLoaded(count);
        }else if("O".equals(state)){
            bo.setOmitted(count);
        }else if("RC".equals(state)){
            bo.setRegistrationCompleted(count);
        }else if("FE".equals(state)){
            bo.setFunctionalError(count);
        }else if("TE".equals(state)){
            bo.setTechnicalError(count);
        }else if(state ==null || state.length()==0){
            bo.setNulldata(count);
        }
        return bo;    
    }
    
    /**
     * This method is fetches the status from the Staging primay table.
     * Note Fetch size is configured to increase the performance.
     * @param conn
     * @return
     * @throws RecoveryDAOException
     */
    private List<BulkRegistrationStatusBO>  getByFile(Connection conn,BulkRegistrationForm bulkRegistrationForm) throws RecoveryDAOException{
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        StringBuffer query = new StringBuffer();
        
        String tmpFile = null;
        String currentFile = null;
        BulkRegistrationStatusBO bo = new BulkRegistrationStatusBO();
        try{
            query.append("select extract_file_name,state, count,total from (  ");
            query.append("select extract_file_name,bulkreg_State state,count(*) count,sum(count(*)) over(partition by  extract_file_name) as total ");
            query.append("from STAGING_PRIMARY group by extract_file_name,bulkreg_State ) where state in ('L','O','RC','FE','TE','VC',null) ");
            if(bulkRegistrationForm.getInputDHSFileName()!=null && bulkRegistrationForm.getInputDHSFileName().length()>0){
                query.append(" and extract_file_name = ? ");
            }
            query.append(" order by  extract_file_name,state ");
            
            pStmt = conn.prepareStatement(query.toString());
            if(bulkRegistrationForm.getInputDHSFileName()!=null && bulkRegistrationForm.getInputDHSFileName().length()>0){
               pStmt.setString(1, bulkRegistrationForm.getInputDHSFileName());
            }
            pStmt.setFetchSize(100);
            rst = pStmt.executeQuery();
            List<BulkRegistrationStatusBO> bulkRegistrationStatusBOList = new ArrayList<BulkRegistrationStatusBO>();
            while(rst.next()){
                if(tmpFile==null){
                    currentFile = tmpFile = rst.getString("extract_file_name");
                }else {
                    currentFile = rst.getString("extract_file_name");
                }
                if(!currentFile.equals(tmpFile)){
                    bulkRegistrationStatusBOList.add(bo);
                    bo = new BulkRegistrationStatusBO();
                    tmpFile = currentFile;
                }
                bo.setFileName( rst.getString("extract_file_name"));
                bo = setStateInBo( rst.getString("state"),NumberFormat.getNumberInstance(Locale.US).format(rst.getInt("count")),bo);
                bo.setTotalIHI(NumberFormat.getNumberInstance(Locale.US).format(rst.getInt("total")));
            }
            bulkRegistrationStatusBOList.add(bo);
            return bulkRegistrationStatusBOList;

        }catch(Exception e){
            LOG.fatal("Exception has occured..",e);
            throw new RecoveryDAOException(e);
        }finally{
            if(rst!=null){
                try {
                    rst.close();
                } catch (SQLException e) {
                }
            }
            if(pStmt!=null){
                try {
                    pStmt.close();
                } catch (SQLException e) {
                }
            }
            
        }
         
    }
    
    public int getRecordRequiredTrueCount(){
        String query = "select count(*) from STAGING_PRIMARY where record_required = 'True'";
        int count = osbBulkRegJdbcTemplate.queryForInt(query);
        LOG.debug("Inside getRecordRequiredTrueCount - " + count);
        return count;
    }
}
