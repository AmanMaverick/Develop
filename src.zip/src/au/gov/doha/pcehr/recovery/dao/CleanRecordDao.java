package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.util.DBUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;


/**
 * This DAO layer fetch data from PNA DB for Clean Record.
 * @Author Vikash/Sumanta
 * @since 8 April 2015
 * @version Change-x
 */
@Component
public class CleanRecordDao {
    private static Logger LOG = Logger.getLogger(CleanRecordDao.class);
    private static final String CLEANUP_PENDING_VERIFICATION = "cleanup_PendingVerification";
    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJdbcTemplate;
    @Autowired
    @Qualifier("osbNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate osbNamedParameterJdbcTemplate;
    public CleanRecordDao() {
        super();
    }

    /**
     *
     * @param ihi
     * @return
     */
    public boolean getStatus(String ihi) {
        boolean flag = false;
        LOG.debug("entering getStatus");
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        try {
            StringBuffer query = new StringBuffer();
            query.append("SELECT RECORD_STATUS FROM oes_pnadb.PCEHR_RECORD WHERE IHI = ? ");
            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, ihi);
            rst = pStmt.executeQuery();
            while (rst.next()) {
                LOG.debug("stataus is...." + rst.getString(1));
                if (Integer.parseInt(rst.getString(1)) == 0) {
                    LOG.debug("staus is active");
                    flag = true;

                }
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            // throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(rst);
            DBUtility.close(pStmt);
            DBUtility.close(conn);
        }
        LOG.debug("Leaving getStatus");
        //  return pNAStatusActiveInactiveBO;

        return flag;

    }

    /**
     *
     * @param ihi
     * @return
     */
    public boolean checkRestricted(String ihi) {
        boolean flag = false;
        LOG.debug("entering checkRestricted");
        Connection conn = null;
        PreparedStatement pStmt = null;
        ResultSet rst = null;
        try {
            StringBuffer query = new StringBuffer();
            query.append("SELECT COUNT(*) ");
            query.append("FROM oes_pnadb.RESTRICTED_REGISTRATION ");
            query.append("WHERE RESTRICTED_REGISTRATION.RESTRICTED_IHI = ? ");
            query.append("AND trunc(RESTRICTED_REGISTRATION.RESTRICTION_EXPIRY) > trunc(SYSDATE)");

            conn = DBUtility.getDataBaseConnectionObject("PNA");
            pStmt = conn.prepareStatement(query.toString());
            pStmt.setString(1, ihi);
            rst = pStmt.executeQuery();
            while (rst.next()) {
                LOG.debug("Resticted value...." + rst.getInt(1));
                if (rst.getInt(1) > 0) {
                    LOG.debug("IHI is Resticted");
                    flag = true;

                }
            }
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            // throw new RecoveryDAOException(e);
        } finally {
            DBUtility.close(rst);
            DBUtility.close(pStmt);
            DBUtility.close(conn);
        }
        LOG.debug("Leaving checkRestricted");
        //  return pNAStatusActiveInactiveBO;

        return flag;

    }

    /**
     *
     * @param ihi
     * @return
     */
    public int deleteNotificationsEntry(String ihi) throws RecoveryDAOException {


        LOG.debug("Inside DAO-Delete deleteNotificationsEntry Method");
        int deleteStatus=0;

        int notificationCountBeforeSpCall=getNotificationCount(ihi);
        if(notificationCountBeforeSpCall>0){
       SimpleJdbcCall simpleJdbcCall =
            new SimpleJdbcCall(osbJdbcTemplate).withSchemaName("PCEHR_OSB_AUDIT").withProcedureName(CLEANUP_PENDING_VERIFICATION);
     
        LOG.debug("simpleJdbcCall....." + simpleJdbcCall);
        try {
            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_IHI", ihi);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);
            LOG.debug("before calling procedure for CLEANUP_PENDING_VERIFICATION");
           simpleJdbcCall.execute(in);
            LOG.debug("after calling procedure for CLEANUP_PENDING_VERIFICATION");
        
        } catch (Exception e) {
            LOG.fatal("Exception Occured..", e);
            throw new RecoveryDAOException(e);
        }
            int notificationCountAfterSpCall=getNotificationCount(ihi);
            if(notificationCountAfterSpCall==0){
                deleteStatus=1;
            }else{
                deleteStatus=0;
            }
        } 
        LOG.debug("final deletion status:::"+deleteStatus);
        LOG.debug("Leaving DAO-Delete deleteNotificationsEntry Method");
        return deleteStatus;
    }
    /**
     *
     * @param ihi
     * @return
     */
    private int getNotificationCount(String ihi) throws RecoveryDAOException {
        LOG.debug("Entering  getNotificationCount Method");
        StringBuffer query = new StringBuffer();
        Map namedParameters = new HashMap();
        int count=0;
        try{
        query.append("select count(*) from PCEHR_OSB_AUDIT.notifications where IHI=:ihi");
            namedParameters.put("ihi", ihi);
             count = osbNamedParameterJdbcTemplate.queryForInt(query.toString(), namedParameters);
            LOG.debug("Count:::"+count);
                
        }catch(Exception e) {
          LOG.fatal("Exception:::",e); 
            throw new RecoveryDAOException(e);
        }
       
        LOG.debug("Leaving getNotificationCount Method");
        return count;
    }

}
