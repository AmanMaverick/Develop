package au.gov.doha.pcehr.recovery.dao;


import au.gov.doha.pcehr.recovery.bo.DLQMessageReplayBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.DLQMessageForm;

import java.math.BigDecimal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;


/**
 * @author sumanta.kumar.saha
 * This DAO layer handles the view Error, Search Message, Dlaq state change operations
 *
 * Version     Authour              Issue no.               Description                                                 Change
 * v1      sumanta.kumar.saha           n/a                Initial version                                              n/a
 * v2       Vikash Kumar Singh          NA                 Upgraded to Spring JDBC.                                     Updated whole class.
 * v3      sumanta.kumar.saha           n/a               Updated getDLQMessage method handle >= and = Delivery count    Updated getDLQMessage
 */     
@Component
public class DLQMessageDAO {
    private static Logger LOG = Logger.getLogger(DLQMessageDAO.class);

    @Autowired
    @Qualifier("osbJDBCTemplate")
    private JdbcTemplate osbJDBCTemplate;
    
    @Value("${VIEW_DLQ_ERROR_01}") 
    private String dlqErrorQuery01;
    
    @Value("${VIEW_DLQ_ERROR_02}") 
    private String dlqErrorQuery02;
    
    @Value("${UPDATE_DLQ_MESSAGE_STATE_CHANGE}") 
    private String updateDLQMessageStateQuery;
    
    @Value("${GET_DLQ_STATE_DETAIL}") 
    private String getDLQStateDetailQuery;
    
    @Value("${GET_DLQ_MESSAGE_LIST}") 
    private String getDLQMessageListQuery;
    
    @Value("${GET_DLQ_MESSAGE_LIST_02}") 
    private String getDLQMessageListQuery02;
    
    @Value("${GET_DLQ_MESSAGE_DB_DETAILS}") 
    private String getDLQMessageDBDetailsQuery;
    
    @Value("${UPDATE_DLQ_MESSAGE_FOR_INTEGRATION_ID}") 
    private String updateDLQMessageForIntegrationIdQuery;
    
    /**
     *
     * @param dlqMessage
     * @return
     * @throws RecoveryDAOException
     */
    public List<DLQMessageForm>  getDLQErrorDetail(DLQMessageForm dlqMessage) throws RecoveryDAOException {
        String inputErrorCode = dlqMessage.getInputErrorCode();
        String inputErrorCount = dlqMessage.getInputErrorCount();
        List<DLQMessageForm> dlqMessageList = new ArrayList<>();
        
        String businessEvent = dlqMessage.getQueueType();
        String queueSize = dlqMessage.getQueueSize().replace('<', ' ');
        String deliveryCount = dlqMessage.getDeliveryCount();
        StringBuffer dlqErrorQuery = new StringBuffer("");
        if(deliveryCount.charAt(0)=='L'){
            deliveryCount = dlqMessage.getDeliveryCount().replaceFirst("Less Than ", "");
            LOG.debug("deliveryCount value :: -  " + deliveryCount);
            dlqErrorQuery = dlqErrorQuery.append(dlqErrorQuery01);
        }else{
            LOG.debug("String contains - Greater Than or Equal to  ");
            deliveryCount = "4";
            dlqErrorQuery = dlqErrorQuery.append(dlqErrorQuery02);
        }
        
        Object[] paramArr;
        List<Object> param = new ArrayList<Object>();
        param.add(businessEvent);
        param.add(deliveryCount);
        param.add(queueSize);
        LOG.debug("inputErrorCode :: " + inputErrorCode);
        LOG.debug("inputErrorCount :: " + inputErrorCount);
        if((inputErrorCode != null && !"".equals(inputErrorCode)) || (inputErrorCount != null && !"".equals(inputErrorCount))){
            
           Map<String,List<Object>> queryParamMap = searchParameterizedDLQMessage(dlqMessage, dlqErrorQuery, param);
            Map.Entry<String,List<Object>> entry=queryParamMap.entrySet().iterator().next();
            dlqErrorQuery = new StringBuffer(entry.getKey());
            param = entry.getValue();
            LOG.debug("dlqErrorQuery 000 - :: " + dlqErrorQuery);
            LOG.debug("entry.getValue() - :: " + param);
        }
        paramArr = param.toArray(new String[param.size()]);
        try{
            dlqMessageList = osbJDBCTemplate.query(String.valueOf(dlqErrorQuery),
            paramArr,
            new RowMapper<DLQMessageForm>() {
                public DLQMessageForm mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DLQMessageForm dlqMessage = new DLQMessageForm();
                    dlqMessage.setErrorCode(rs.getString("ERROR_CODE"));
                    dlqMessage.setDescription(rs.getString("ERROR_DESCRIPTION"));
                    dlqMessage.setErrorCount(rs.getString("COUNT")); 
                    LOG.debug("Error Code - :: - " + dlqMessage.getErrorCode());
                    return dlqMessage;
                }
            });
            LOG.debug("dlqMessageList size :: " + dlqMessageList.size());
        }catch(Exception e){
            LOG.fatal("Exception occured in getDLQErrorDetail..." + e.getMessage());
            throw new RecoveryDAOException(e);
        }        
        return dlqMessageList;
    }
    
    /**
     *
     * @param dlqMessage
     * @return
     * @throws RecoveryDAOException
     */
    public List<DLQMessageForm> updateDLQMessageStateChange(DLQMessageForm dlqMessage) throws RecoveryDAOException {
        List<DLQMessageForm> dlqStateDetailList = new ArrayList<>();
        final List<String> errorCodeList = dlqMessage.getErrorCodeList();
        LOG.debug("errorCodeList ---- :: " + errorCodeList.size());
        final String businessEventName = dlqMessage.getQueueType();
        final String queueSize = dlqMessage.getQueueSize().replaceAll("<", "");
        //batch update for the errro code list on business event and queue size
        osbJDBCTemplate.batchUpdate(updateDLQMessageStateQuery,
        new BatchPreparedStatementSetter() {
                public void setValues(PreparedStatement ps, int i)throws SQLException {
                            
                    String errorCode = errorCodeList.get(i);
                    ps.setString(1, errorCode);
                    ps.setString(2, businessEventName);
                    ps.setString(3, queueSize);
                }
                public int getBatchSize() {
                        return errorCodeList.size();
                }
        });
        LOG.debug("Completed State Update.");
        List<Map<String, Object>> dlqStateLis = osbJDBCTemplate.queryForList(getDLQStateDetailQuery);
        for (Map<String, Object> map : dlqStateLis) {
            DLQMessageForm dlqState = new DLQMessageForm();
            dlqState.setQueueType(businessEventName);
            dlqState.setState((String)map.get("STATE"));
            dlqState.setCount((BigDecimal)map.get("COUNT"));
            dlqStateDetailList.add(dlqState);
        }
        LOG.debug("Completed State count.");
        return dlqStateDetailList;
    }
    
    /**
     *
     * @param dlqMessage
     * @return
     * @throws RecoveryDAOException
     */
    public List<DLQMessageForm> updateDLQMessageforIntegrationIdList(DLQMessageForm dlqMessage) throws RecoveryDAOException {
        List<DLQMessageForm> dlqStateDetailList = new ArrayList<>();
        final List<String> integrationIdList = dlqMessage.getIntegrationIdList();
        LOG.debug("integrationIdList ---- :: " + integrationIdList.size());
        final String businessEventName = dlqMessage.getQueueType();
        //batch update for the integration id list on business event
        osbJDBCTemplate.batchUpdate(updateDLQMessageForIntegrationIdQuery,
        new BatchPreparedStatementSetter() {
                public void setValues(PreparedStatement ps, int i)throws SQLException {
                            
                    String integrationId = integrationIdList.get(i);
                    ps.setString(1, integrationId);
                    ps.setString(2, businessEventName);
                    
                }
                public int getBatchSize() {
                        return integrationIdList.size();
                }
        });
        LOG.debug("Completed State Update.");
        List<Map<String, Object>> dlqStateLis = osbJDBCTemplate.queryForList(getDLQStateDetailQuery);
        for (Map<String, Object> map : dlqStateLis) {
            DLQMessageForm dlqState = new DLQMessageForm();
            dlqState.setQueueType(businessEventName);
            dlqState.setState((String)map.get("STATE"));
            dlqState.setCount((BigDecimal)map.get("COUNT"));
            dlqStateDetailList.add(dlqState);
        }
        LOG.debug("Completed State count.");
        return dlqStateDetailList;
    }
    
    /**
     *
     * @param dlqMessage
     * @return
     * @throws RecoveryDAOException
     */
    public List<DLQMessageForm> getDLQMessage(DLQMessageForm dlqMessage) throws RecoveryDAOException {
        List<DLQMessageForm> dlqMessageDetailList = new ArrayList<>();
        String errorCode = dlqMessage.getErrorCode();
        String businessEvent = dlqMessage.getQueueType();
     
        //delevery count code change for >= values ..
        //Author:-Sumanta
        String deliveryCount = dlqMessage.getDeliveryCount();
                String dlqMessageListQuery = "";
                if(deliveryCount.charAt(0)=='L'){
                    deliveryCount = dlqMessage.getDeliveryCount().replaceFirst("Less Than ", "");
                    dlqMessageListQuery = getDLQMessageListQuery;
                }else{
                    LOG.debug("String contains >= ");
                    deliveryCount = "4";
                    dlqMessageListQuery = getDLQMessageListQuery02;
                }
                //
        dlqMessageDetailList = osbJDBCTemplate.query(dlqMessageListQuery,
                        new Object[] {errorCode, businessEvent, deliveryCount},
                        new RowMapper<DLQMessageForm>() {
                            public DLQMessageForm mapRow(ResultSet rs, int rowNum) throws SQLException {
                                DLQMessageForm dlqMessage = new DLQMessageForm();
                                dlqMessage.setIntgrationID(rs.getString("INTEGRATION_ID"));
                                dlqMessage.setMessageID(rs.getString("MESSAGE_ID"));
                                dlqMessage.setQueueType(rs.getString("BUSINESS_EVENT_NAME"));
                                dlqMessage.setErrorCode(rs.getString("ERROR_CODE"));
                                dlqMessage.setErrorDetails(rs.getString("ERROR_DETAILS"));
                                dlqMessage.setState(rs.getString("STATE"));
                                dlqMessage.setDeliveryCount(rs.getString("DELIVERY_COUNT"));
                                
                                return dlqMessage;
                            }
                        });
        
        return dlqMessageDetailList;
    }
    
    public DLQMessageReplayBO getDLQMessageDBDetails(String integrationID) {
        LOG.debug("Inside getDLQMessageDBDetails.."+integrationID);
        List<DLQMessageReplayBO> dlqMessageReplayDetailList = new ArrayList<>();
        dlqMessageReplayDetailList = osbJDBCTemplate.query(getDLQMessageDBDetailsQuery,
                        new Object[] {integrationID},
                        new RowMapper<DLQMessageReplayBO>() {
                            public DLQMessageReplayBO mapRow(ResultSet rs, int rowNum) throws SQLException {
                                DLQMessageReplayBO dlqMessageReplay = new DLQMessageReplayBO();
                                dlqMessageReplay.setDbIntgrationID(rs.getString(1));
                                dlqMessageReplay.setMeessageId(rs.getString(2));
                                dlqMessageReplay.setUserType(rs.getString(3));
                                dlqMessageReplay.setUserId(rs.getString(4));
                                dlqMessageReplay.setIhi(rs.getString(5));
                                dlqMessageReplay.setSystemType(rs.getString(6));
                                dlqMessageReplay.setSystemId(rs.getString(7));
                                dlqMessageReplay.setAccessingOrgId(rs.getString(8));
                                dlqMessageReplay.setDocumnetId(rs.getString(9));
                                dlqMessageReplay.setDocumnetCode(rs.getString(10));
                                dlqMessageReplay.setConceptCode(rs.getString(11));
                                dlqMessageReplay.setCodeSystem(rs.getString(12));
                                dlqMessageReplay.setBusinessEvenetName(rs.getString(13));
                                dlqMessageReplay.setErrorEndpointId(rs.getString(15));
                                dlqMessageReplay.setDbErrorCode(rs.getString(16));
                                dlqMessageReplay.setErrorAdditionalDescription(rs.getString(17));
                                dlqMessageReplay.setDbErrorDetails(rs.getString(18));
                                dlqMessageReplay.setCreatedDate(rs.getString(19));
                                dlqMessageReplay.setLastUpdatedDate(rs.getString(20));
                                dlqMessageReplay.setDbState(rs.getString(21));
                                dlqMessageReplay.setDelliveryCount(rs.getString(22));
                                dlqMessageReplay.setPurge(rs.getString(23));
                                dlqMessageReplay.setPayload(rs.getString(24));
                                dlqMessageReplay.setDestType(rs.getString(25));
                                dlqMessageReplay.setDestUri(rs.getString(26));
                                dlqMessageReplay.setTicketNumber(rs.getString(27));
                                dlqMessageReplay.setRemarks(rs.getString(28));
                                
                                return dlqMessageReplay;
                            }
                        });
        LOG.debug("Inside getDLQMessageDBDetails completed" + dlqMessageReplayDetailList.size());
        return dlqMessageReplayDetailList.get(0);
    }

    private Map<String,List<Object>> searchParameterizedDLQMessage(DLQMessageForm dlqMessage, StringBuffer dlqErrorQuery,
                                                                    List<Object> param) {
        Map<String,List<Object>> queryParamMap = new HashMap<String,List<Object>>();
        dlqErrorQuery = new StringBuffer(dlqErrorQuery.substring(0, dlqErrorQuery.indexOf("GROUP BY")));
        LOG.debug("dlqErrorQuery 111 - :: " + dlqErrorQuery);
        if(!"".equals(dlqMessage.getInputErrorCode())){
            dlqErrorQuery.append(" and DLQ.ERROR_CODE IN (?");
            List<Object> errorCodeList = getObjectArray(dlqMessage.getInputErrorCode()) ; 
            dlqErrorQuery = updateQueryParam(errorCodeList, dlqErrorQuery);
            param.addAll( errorCodeList);
        }
        if(!"".equals(dlqMessage.getInputErrorCount())){
            dlqErrorQuery.append(" and ERROR_DESCRIPTION IN (?");
            List<Object> errorCountList = getObjectArray(dlqMessage.getInputErrorCount()) ; 
            dlqErrorQuery = updateQueryParam(errorCountList, dlqErrorQuery);
            param.addAll(errorCountList);
        }        
        dlqErrorQuery.append(" GROUP BY DLQ.ERROR_CODE, EC.ERROR_DESCRIPTION");
        queryParamMap.put(dlqErrorQuery.toString(), param);
        return queryParamMap;
    }
    
    private List<Object> getObjectArray(String str){
        Object[] arr = str.split(",");
        List<Object> list = new ArrayList<>();
        for(int i = 0; i < arr.length; i++){
            String txt = (String)arr[i];
            if(!"".equals(txt.trim()))
                list.add(arr[i]);
        }
        LOG.debug("---- " + list);
        return list;
    }
    
    private StringBuffer updateQueryParam(List<Object> objList, StringBuffer query){
        for(int i =0; i < objList.size()-1; i++)
            query.append(",?");
        query.append(")");
       return query;
    }
}
