package au.gov.doha.pcehr.recovery.view;

import au.gov.doha.pcehr.recovery.bo.DocumentReinstateBO;
import au.gov.doha.pcehr.recovery.bo.DocumentReinstateErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalErrorBO;
import au.gov.doha.pcehr.recovery.constants.RecoverConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import org.springframework.stereotype.Service;

/**This calss generates a xls report for bulk
 * record removal with IHI,DocumentID,Status,Error Description
 *
 */
@Service
public class DocumentReinstateReportView {
    private static Logger LOG = Logger.getLogger(DocumentReinstateReportView.class);
    private static final String FILE_NAME = "BulkDocumentReinstate.xls";
    
    public  Workbook buildExcelReport(DocumentReinstateBO documentReinstateBO)throws  RecoveryServiceException {
        List<DocumentReinstateErrorBO> errorBoList=documentReinstateBO.getListDocReinstateErrorBO();
            LOG.debug("Entered into excel creation for document reinstate");
            Workbook wb = new SXSSFWorkbook(100);
            
            SXSSFSheet sheet = (SXSSFSheet) wb.createSheet("Bulk Document Reinstate");
            sheet.createRow(0).createCell(0).setCellValue("Bulk Document Reinstate");
            sheet.createRow(1).createCell(0);
            
            SXSSFRow header = sheet.createRow(2);
            
            header.createCell(0).setCellValue("IHI");
            header.createCell(1).setCellValue("Document ID");
            header.createCell(2).setCellValue("Status");
            header.createCell(3).setCellValue("Error Description");
            
            int rowNum = 3;
            int sheetCount = 1;
            LOG.info("Size of object:::"+ +errorBoList.size());
            DataFormat format = wb.createDataFormat();
            
            for(DocumentReinstateErrorBO bo:errorBoList){
                if(rowNum>=RecoverConstants.EXCEL_FILE_LIMIT_SXSS){
                    sheet = (SXSSFSheet) wb.createSheet("Bulk Document Reinstate"+sheetCount);
                    rowNum=0;
                    sheetCount++;
                }
                SXSSFRow row = sheet.createRow(rowNum++);
//                bo.setIhi(bo.getIhi());
//                bo.setDocumentID(bo.getDocumentID());
//                bo.setStatus(bo.getStatus());
//                bo.setDescription(bo.getDescription());
                row.createCell(0).setCellValue(bo.getIhi());
                row.createCell(1).setCellValue(bo.getDocumentID());
                row.createCell(2).setCellValue(bo.getStatus());
                row.createCell(3).setCellValue(bo.getDescription());
                bo=null;
            }
            
        return wb;
        }
}
