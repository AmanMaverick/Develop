package au.gov.doha.pcehr.recovery.security;


import au.gov.doha.pcehr.recovery.bo.NIOUserDetails;

import java.util.ArrayList;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class NIOAuthenticationUserDetailsService implements AuthenticationUserDetailsService {
    final Logger LOG = LoggerFactory.getLogger(NIOAuthenticationUserDetailsService.class); 

    @Override
    public UserDetails loadUserDetails(Authentication user) throws UsernameNotFoundException {
        LOG.debug("I am in NIOAuthenticationUserDetailsService"+user.getPrincipal());
        NIOUserDetails userDetails = (NIOUserDetails)user.getPrincipal();
        if (user.getPrincipal() != null && "Admin".equals(userDetails.getRole())) {
                                Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
                                authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                            LOG.debug("CustomAuthenticationUserDetailsService.....Setting user: "+user.getPrincipal());
                                return new User(userDetails.getUser(), "none", true, true, true, true, authorities);
                        }else if (user.getPrincipal() != null && "Monitor".equals(userDetails.getRole())) {
                            Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
                            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                            LOG.debug("CustomAuthenticationUserDetailsService.....Setting user: "+user.getPrincipal());
                            return new User(userDetails.getUser(), "none", true, true, true, true, authorities);
                        }else if (user.getPrincipal() != null && "Operator".equals(userDetails.getRole())) {
                            Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
                            authorities.add(new SimpleGrantedAuthority("ROLE_OPERATOR"));
                            LOG.debug("CustomAuthenticationUserDetailsService.....Setting user: "+user.getPrincipal());
                            return new User(userDetails.getUser(), "none", true, true, true, true, authorities);
                        }
        LOG.debug("I am in NIOAuthenticationUserDetailsService");
                        return null;

    }
}
