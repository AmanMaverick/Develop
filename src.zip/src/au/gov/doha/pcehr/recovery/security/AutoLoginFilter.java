package au.gov.doha.pcehr.recovery.security;


import au.gov.doha.pcehr.recovery.bo.NIOUserDetails;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;

public class AutoLoginFilter extends AbstractPreAuthenticatedProcessingFilter {
    
    final Logger LOG = LoggerFactory.getLogger(AutoLoginFilter.class); 
    

    @Override
    protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
        // TODO Implement this method
        LOG.debug("I am in AutoLoginFilter Operator : - "+request.isUserInRole("Operator"));
        LOG.debug("I am in AutoLoginFilter Admin : - "+request.isUserInRole("Admin"));
        NIOUserDetails userDetails =  new NIOUserDetails();
        if(request.getUserPrincipal()!=null && request.isUserInRole("Admin")){
            userDetails.setUser(request.getUserPrincipal().getName());
            userDetails.setRole("Admin");
           // return request.getUserPrincipal().getName()+"~"+"Admin";
            return userDetails;
        }else  if(request.getUserPrincipal()!=null && request.isUserInRole("Monitor")){
            userDetails.setUser(request.getUserPrincipal().getName());
            userDetails.setRole("Monitor");
            //return request.getUserPrincipal().getName() +"~"+"Monitor";
            return userDetails;
        }if(request.getUserPrincipal()!=null && request.isUserInRole("Operator")){
            userDetails.setUser(request.getUserPrincipal().getName());
            userDetails.setRole("Operator");
            //return request.getUserPrincipal().getName() +"~"+"Monitor";
            return userDetails;
         }else {
             LOG.debug("Invalidated session in AutoLoginFilter");
             HttpSession session = request.getSession(false);
             if (session != null) {
                 session.invalidate();
             }
             //if(SecurityContextHolder.getContext().getAuthentication() != null){
                SecurityContextHolder.getContext().getAuthentication().setAuthenticated(false); 
             //}             
            return null;
         }
        //return null;
    }

    @Override
    protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
        // TODO Implement this method
            NIOUserDetails userDetails =  new NIOUserDetails();
            if(request.getUserPrincipal()!=null && request.isUserInRole("Admin")){
                userDetails.setUser(request.getUserPrincipal().getName());
                userDetails.setRole("Admin");
               // return request.getUserPrincipal().getName()+"~"+"Admin";
                return userDetails;
            }else  if(request.getUserPrincipal()!=null && request.isUserInRole("Monitor")){
                userDetails.setUser(request.getUserPrincipal().getName());
                userDetails.setRole("Monitor");
                //return request.getUserPrincipal().getName() +"~"+"Monitor";
                return userDetails;
            }if(request.getUserPrincipal()!=null && request.isUserInRole("Operator")){
                userDetails.setUser(request.getUserPrincipal().getName());
                userDetails.setRole("Operator");
                //return request.getUserPrincipal().getName() +"~"+"Monitor";
                return userDetails;
            }else
                    return null;
    }
}
