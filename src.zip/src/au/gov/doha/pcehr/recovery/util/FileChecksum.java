package au.gov.doha.pcehr.recovery.util;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;
@Component
public class FileChecksum {
    private static Logger LOG = Logger.getLogger(FileChecksum.class);
	/**
	 * This method Accepts "Users file CheckSum", "File Name", and
	 * "Algorithm Name" from user and return String Status as below: 1) Success
	 * - if All Validation is success 2) Checksum Mismatch - if Users input
	 * checksum mismatch with generated checksum 3) Invalid Method - If
	 * Algorithm is different from SHA-256/MD5 4) File Extension Error - if
	 * fileName contain Null or length lesser than 4 characters or fileName does
	 * not have extension
	 */
	public  String getFileChecksum(String CheckSum, String fileName,
			String method) throws Exception {
		/*
		 * file Name check- file length must be grater than 4 characters ".txt"
		 * file Name must have extension - Only extension we support is ".txt"
		 * file Name should not be Null
		 */
            
		LOG.debug("entering GetFileChecksum...");
	    LOG.debug("Checksum from UI..."+CheckSum);
	    LOG.debug("Checksum from UI..."+fileName);
//		if (fileName != null && fileName.length() > 4 && fileName.contains(".")) {
//			String extension = "";
//			int i = fileName.lastIndexOf('.');
//			int p = Math.max(fileName.lastIndexOf('/'),
//					fileName.lastIndexOf('\\'));
//
//			if (i > p) {
//				extension = fileName.substring(i + 1);
//			}

			/*
			 * Call SHA-256/MD5 Only if extension is txt Returns: @Success- if
			 * user input checksum match with generated checksum
			 * 
			 * @Checksum Mismatch: if Users input checksum mismatch with
			 * generated checksum
			 */
			//if (extension.equals("txt")
					//&& method.toLowerCase().equals("sha-256")) {
				if (bytesToHex(calculateSha256(Paths.get(fileName))).equals(
						CheckSum)) {
					return "Success";
				} else {
					return "Checksum Mismatch";
				}
			//} 
                        
//                        else if (extension.equals("txt")
//					&& method.toLowerCase().equals("md5")) {
//				if (bytesToHex(createMD5Checksum(fileName)).equals(CheckSum)) {
//					return "Success";
//				} else {
//					return "Checksum Mismatch";
//				}
//			} else {
//				return "Invalid Method";
//			}
		    //LOG.debug("entering GetFileChecksum...");
//		} else {
//			return "File Extension Error";
//		}
	   
	}

	/*
	 * This method uses MD5 Algorithm and created Hash Value CheckSum from Input
	 * file and Returns byte Array (generated from file input).
	 */
	private static byte[] createMD5Checksum(String filename) throws Exception {
		InputStream fis = new FileInputStream(filename);

		byte[] buffer = new byte[1024];
		MessageDigest complete = MessageDigest.getInstance("MD5");
		int numRead;

		do {
			numRead = fis.read(buffer);
			if (numRead > 0) {
				complete.update(buffer, 0, numRead);
			}
		} while (numRead != -1);

		fis.close();

		byte[] hashValue = complete.digest();
		return hashValue;
	}

	/*
	 * This method uses SHA-256 Algorithm and created Hash Value CheckSum from
	 * Input file and Returns byte Array (generated from file input).
	 */
	private static byte[] calculateSha256(Path path) throws IOException,
			NoSuchAlgorithmException {
		byte[] buffer = new byte[1024];
		MessageDigest digest = MessageDigest.getInstance("SHA-256");

		try(InputStream is = Files.newInputStream(path)) {
			while (true) {
				int readBytes = is.read(buffer);
				if (readBytes > 0)
					digest.update(buffer, 0, readBytes);
				else
					break;
			}
        }catch(Exception e){
            LOG.fatal("Exception:::",e);
        }
		byte[] hashValue = digest.digest();
		return hashValue;
	}

	/*
	 * This method used internally by GetFileChecksum for both the algorithm and
	 * converts Byte Array to Hexadecimal and then converted to user readable
	 * String.
	 */
	private static String bytesToHex(byte[] hashValue) {
		Formatter form = new Formatter();
		for (int i = 0; i < hashValue.length; i++)
			form.format("%02x", hashValue[i]);
		String result = form.toString();
		form.close();
	    LOG.debug("calculated Final checkSum val:::"+result);
		return result;
	}
/* This peace of code is used for Testing Purpose.
	public static void main(String[] args) {
		try {
			long startTime = System.nanoTime();
			String fileName = "Malicious.txt";
			System.out.println(GetFileChecksum(
					"9be1a5e2ecdb5a95588b43c6ebb9805b1", fileName, "SHA-256"));
			long endTime = System.nanoTime();
			System.out.println(" Took " + ((endTime - startTime) / 1000000)
					+ " milisec");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
}
