package au.gov.doha.pcehr.recovery.util;

import au.gov.doha.pcehr.recovery.bo.IdentityRemovalBO;

import com.google.gson.Gson;

import java.io.IOException;

import java.util.List;

import org.apache.log4j.Logger;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

/**
 * This class is meant to provide utilities related to JSON. Instead of sending list of any(generic) type from controller to jsp
 * as an hidden variable, here we can convert list into JSON format String or vice versa.
 *  @author   vikash.c.kumar.singh    PCEH    Operations
 *  @since    05th July, 2016
 *  @param <T>  Generic parameter to be set while creating JSONUtil object to perform generic operations.
 */
public class JSONUtil<T> {
    
    private static Logger LOG = Logger.getLogger(JSONUtil.class);
    
    /**
     *
     * @param list
     * @return
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public String toJSON(List<T> list) throws InstantiationException, IllegalAccessException {
        Gson gson = new Gson();
        StringBuilder sb = new StringBuilder("[");
        int i = list.size();
        int j = 0;
        for(Object obj : list){
            sb.append(gson.toJson(obj));
            j++;
            if(i != j){
                sb.append(",");
            }
        }
        sb.append("]");
        LOG.debug("JSON String is : " + sb.toString());
        
        return sb.toString();
    } 
    
    /**
     *
     * @param jsonString
     * @return
     * @throws IOException
     * @throws JsonParseException
     * @throws JsonMappingException
     */
    public List<IdentityRemovalBO> getJsonToIdentityRemovalBOList(String jsonString) throws IOException, JsonParseException,
                                                                             JsonMappingException {
        
        ObjectMapper objectMapper = new ObjectMapper(); 
        List<IdentityRemovalBO> list = objectMapper.readValue(jsonString, new TypeReference<List<IdentityRemovalBO>>() {});
        return list;
    }
}
