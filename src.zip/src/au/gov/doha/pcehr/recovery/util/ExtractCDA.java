package au.gov.doha.pcehr.recovery.util;


import com.evermind.util.Base64Utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import org.hl7.v3.POCDMT000040ClinicalDocument;


public class ExtractCDA {
    static Logger LOG = Logger.getLogger(ExtractCDA.class);

    private static JAXBContext context;

    public ExtractCDA() {
        super();
    }

    private static Pattern FILE_PATTERN = Pattern.compile(".*/.*/cda_root.xml");

    public JAXBElement<POCDMT000040ClinicalDocument> extract(char[] rawBase64) {


        //Take base64 encoded byte[] and turn into a
        try {   
            long startTimeDecode = System.currentTimeMillis();
            Base64Utils base64Decode = new Base64Utils();
            byte[] byteArray = base64Decode.decode(rawBase64);            
            long endTimeDecode = System.currentTimeMillis();
            LOG.info("Decode Base 64 file time = " + (endTimeDecode - startTimeDecode) + " miliseconds");
            long startTimeZip = System.currentTimeMillis();
            ByteArrayInputStream byteInputZip = new ByteArrayInputStream(byteArray);
            ZipInputStream zipIn = new ZipInputStream(byteInputZip);
            long endTimeZip = System.currentTimeMillis();
            LOG.info("Unzip Time = " + (endTimeZip - startTimeZip) + " miliseconds");
            long startTimeZipEntry = System.currentTimeMillis();
            ZipEntry nextEntry = null;
            ByteArrayOutputStream byteOutput = new ByteArrayOutputStream();
            boolean search = true;
            while (null != (nextEntry = zipIn.getNextEntry()) && search) {

                if (cdaFileMatcher(nextEntry.getName())) {
                    int data = 0;
                    while ((data = zipIn.read()) != -1) {
                        byteOutput.write(data);
                    }
                    // set search flag to false to break out of the zipEntry loop
                    search = false;
                }
            }

            long endTimeZipEntry = System.currentTimeMillis();

           LOG.info("Writing data from zip Entry to ByteArrayOutputStream = " +
                          (endTimeZipEntry - startTimeZipEntry) + " miliseconds");

            long startTimeJAXB = System.currentTimeMillis();

            JAXBElement<POCDMT000040ClinicalDocument> returnDoc = byteToJAXB(byteOutput.toByteArray()); 
            long endTimeJAXB = System.currentTimeMillis();
            LOG.info("byteToJAXB time = " + (endTimeJAXB - startTimeJAXB) + " miliseconds");
            return returnDoc;
        } catch (IOException ioe) {
            LOG.error("Could not extract document from HTB", ioe);
        } catch (Exception e) {
            LOG.error("Could not extract document from HTB", e);
        }
        return null;
    }

    private boolean cdaFileMatcher(String fileName) {
        Matcher m = FILE_PATTERN.matcher(fileName.toLowerCase());
        boolean matches = m.matches();
        return matches;
    }

    private static JAXBElement<POCDMT000040ClinicalDocument> byteToJAXB(byte[] document) throws Exception {
        InputStream in = new ByteArrayInputStream(document);
        try {
            if (context == null) {
                context = JAXBContext.newInstance("org.hl7.v3");
            }
            Unmarshaller unMarshaller = context.createUnmarshaller();

            JAXBElement<POCDMT000040ClinicalDocument> returnedDoc =
                (JAXBElement<POCDMT000040ClinicalDocument>)unMarshaller.unmarshal(in);
           

            return returnedDoc;
        } finally {
            in.close();
        }
    }
}
