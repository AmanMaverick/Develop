package au.gov.doha.pcehr.recovery.util;


import au.gov.doha.pcehr.recovery.bo.DocTransformationErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationStyleSheetBO;
import au.gov.doha.pcehr.recovery.constants.DTFolderLocationConstants;

import java.io.File;

import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;


/**
 * Util to perform all StyleSheet realated operation
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 2nd jan 2015
 * @version Change-x
 */
@Component
public class StyleSheetUtil {
    public StyleSheetUtil() {
        super();
    }
    private static Logger LOG = Logger.getLogger(StyleSheetUtil.class);
    private DocumentTransformationStyleSheetBO documentTransformationStyleSheetBO;

    /**
     **Used to apply the stylesheet on given xml files
     * @param finalFileName
     * @param finalEntryFileName
     * @param fileName
     * @param fileFormat
     */
    public void applyStyleSheet(DocumentTransformationForm form,String finalFileName, String finalEntryFileName, String fileName, String fileFormat,String deIdentification, StreamSource xmlStreamSource, StreamSource  htmlStreamSource,boolean finalOutput) {
        String xsltPathXML = DTFolderLocationConstants.STYLE_SHEET_LOCATION_XML;
        String xsltPathHTML = DTFolderLocationConstants.STYLE_SHEET_LOCATION_HTML;
        String sourcePath = "";
        StreamSource finalStreamSource=new StreamSource();
        FileUtil fileUtility = new FileUtil();

        if (finalEntryFileName.contains("IHE_XDM")) {
            sourcePath = DTFolderLocationConstants.DOC_LOCATION_IHE_XDM + finalFileName;
//CODE CHANGE TO HANDLE CDA.ZIP WITH ONLY CDA FOLDER
        } else if(finalEntryFileName.contains("CDADoc")) {
            sourcePath = DTFolderLocationConstants.DOC_LOCATION_CDA + finalFileName;
        } else{
            sourcePath = DTFolderLocationConstants.DOC_LOCATION_OLNYCDA + finalFileName;
        }

        String xsltPath = "";
        LOG.debug("inside applyStyleSheet...");
        LOG.debug("sourcePath...." + sourcePath);

        LOG.debug("fileFormat...." + fileFormat);
        String resultDir = DTFolderLocationConstants.STYLE_SHEET_APPLIED_DOCS_LOCATION + "/";
        File entryFolder = new File(resultDir, fileName.substring(0, fileName.length() - 5));
        if (!entryFolder.exists()) {
            LOG.debug("folder creation..." + entryFolder.getPath());
            entryFolder.mkdirs();
        }
        File parentFolder = new File(resultDir);
        String fieldList[] = parentFolder.list();
        if (fieldList != null) {
            for (int i = 0; i < fieldList.length; i++) {
                // if(fieldList[i].contains("."))
                LOG.debug("list of files in the folderr.." + fieldList[i]);
                if (fileName.contains(fieldList[i])) {
                    LOG.debug("resultDir....entryFolder..." + entryFolder.getName());
                    LOG.debug("resultDir....inloop..." + resultDir);
                    LOG.debug("resultDir....fieldList..." + fieldList[i]);
                    LOG.debug("resultDir....fileName.." + fileName);
                    if (fileFormat.equalsIgnoreCase("html")) {
                        LOG.debug("file format is XML and de-identification is YES and output format is HTML");
                        resultDir = resultDir + "/" + fieldList[i] + "/" + fileName + ".html";
                        xsltPath = xsltPathHTML;
                        finalStreamSource=htmlStreamSource;
                    }

                    else {
                        LOG.debug("file format is XML and de-identification is YES and output format is XML");
                        resultDir = resultDir + "/" + fieldList[i] + "/" + fileName + ".xml";
                        xsltPath = xsltPathXML;
                        finalStreamSource=xmlStreamSource;
                    }
                    LOG.debug("xsltPath...." + xsltPath);
                }
            }
        }

        LOG.debug("resultDir...." + resultDir);
        LOG.debug("folder name...." + fileName.substring(0, fileName.length() - 5));
        
        //if html and yes and finaloutput is false then soruce folder will be the destination folder
        if(fileFormat.equalsIgnoreCase("html") && deIdentification.equalsIgnoreCase("yes") && finalOutput==false){
          LOG.debug("inside html deIdentification yes and finalOutput false");
            resultDir=sourcePath;
            finalStreamSource=xmlStreamSource;
            xsltPath = xsltPathXML;
        }
        else if(fileFormat.equalsIgnoreCase("html") && deIdentification.equalsIgnoreCase("yes") && finalOutput==true){
            //resultDir=sourcePath;
            LOG.debug("inside html deIdentification yes and finalOutput true");
            finalStreamSource=htmlStreamSource;
            xsltPath = xsltPathHTML;
        }
        LOG.debug("final stylesheet value::resultDIR.."+resultDir);
        LOG.debug("final stylesheet value::xsltPath.."+xsltPath);
        LOG.debug("final stylesheet value::sourcePath.."+sourcePath);
        
       // System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
     
        SAXTransformerFactory tFactory=(SAXTransformerFactory)TransformerFactory.newInstance();
        StreamSource inputStreamSource=null;
        StreamResult outputStreamResult=null;
        try {
            //Transformer transformer = tFactory.newTransformer(new StreamSource(new File(xsltPath)));
            inputStreamSource=new StreamSource(new File(sourcePath)); 
            outputStreamResult=new StreamResult(new File(resultDir));
            Transformer transformer = tFactory.newTransformer(finalStreamSource);
            transformer.transform(inputStreamSource, outputStreamResult);
            // flag for cheking stylsheets applied succesfully for making audit for success IHI
            LOG.debug("audit required flag is true");
            form.setAuditRequired(true);
            //for cleaning documentPool
            transformer=null;
            inputStreamSource=null;
            outputStreamResult=null;
        } catch (Exception e) {
            LOG.fatal("Exception occured..", e);
            String sysDate=fileUtility.getDateFormat();
            DocTransformationErrorBO errorBo=
                            fileUtility.createErrorBo(documentTransformationStyleSheetBO.getIhi(),documentTransformationStyleSheetBO.getDocumentID(), e.getMessage(), documentTransformationStyleSheetBO.getDocumnetType(),"FAIL",sysDate
                                                      );
            //form.setWsResposeDoc(null);
            if(form.getErrorBoList()!=null){
                form.getErrorBoList().add(errorBo);
            }else{
                List<DocTransformationErrorBO> listErrorBo=new ArrayList<DocTransformationErrorBO>();
                listErrorBo.add(errorBo);
                form.setErrorBoList(listErrorBo);
            }
        }
        LOG.debug("leaving applyStyleSheet...");
    }

    public void setDocumentTransformationStyleSheetBO(DocumentTransformationStyleSheetBO documentTransformationStyleSheetBO) {
        this.documentTransformationStyleSheetBO = documentTransformationStyleSheetBO;
    }

    public DocumentTransformationStyleSheetBO getDocumentTransformationStyleSheetBO() {
        return documentTransformationStyleSheetBO;
    }
    
/**
     *
     * @param inputFilePath
     * @param xslFilePath
     * @param outputFileLocation
     */

        public  boolean applyStyleSheet(String inputFilePath, String xslFilePath, String outputFileLocation) {
           // System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
           LOG.debug("inside ..applyStyleSheet");
           boolean flag=true;
            SAXTransformerFactory tFactory = (SAXTransformerFactory) TransformerFactory.newInstance();
            StreamSource inputStreamSource = null;
            StreamResult outputStreamResult = null;
       // InputStream is=null;
       // inputStreamSource=new StreamSource(is);
           
            inputStreamSource = new StreamSource(new File(inputFilePath));
          
            outputStreamResult = new StreamResult(new File(outputFileLocation));

            Transformer transformer;
            try {
               
                //transformer = tFactory.newTransformer(new StreamSource(new File("C:\\PCEHR\\R7\\GetView Transformation work package\\Stylesheets\\MO.xsl")));
                transformer = tFactory.newTransformer(new StreamSource(new File(xslFilePath)));
                transformer.transform(inputStreamSource, outputStreamResult);
               

            } catch (TransformerConfigurationException e) {
               LOG.fatal("exception:::",e);
                flag=false;
            } catch (TransformerException e) {
                flag=false;
                LOG.fatal("exception:::",e);
            }finally{
                transformer=null;
                inputStreamSource=null;
                outputStreamResult=null;
            }
            
        LOG.debug("Leaving ..applyStyleSheet");
        return flag;
    }
}
