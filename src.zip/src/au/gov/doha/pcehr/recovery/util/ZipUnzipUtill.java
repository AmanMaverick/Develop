package au.gov.doha.pcehr.recovery.util;


import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;


/**
 * Util to perform all ZIP Unzip realated operation
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 2nd jan 2015
 * @version Change-x
 */
@Component
public class ZipUnzipUtill {


    private static Logger LOG = Logger.getLogger(ZipUnzipUtill.class);


    /**
     *Used to zip files
     * @param folderPath
     * @param zippedFolderLocation
     */
    public void zipFIles(String folderPath, String zippedFolderLocation, DocumentTransformationForm form) {
        LOG.debug("enerig zipFIles ..folder path" + folderPath); 
        

        try {
            Date dat = new Date();
            //ddMMyyyyhhmmss
            SimpleDateFormat ft =  new SimpleDateFormat ("yyyyMMdd_hh_mm_ss");
            String date= ft.format(dat);
            File parentFolder = new File(folderPath);
            String fieldList[] = parentFolder.list();
            zippedFolderLocation = zippedFolderLocation+form.getFileFormat();
            LOG.debug("zippedFolderLocation::::" + zippedFolderLocation);
            File formatFolder = new File(zippedFolderLocation);
            if (!formatFolder.exists()) {
                formatFolder.mkdirs();
                LOG.info("Created required directory.");
            }else{
                LOG.info("Dir is already available.");
            }
            
            List<String> zippedFileList = new ArrayList<String>();
            if (fieldList != null) {
                for (int j = 0; j < fieldList.length; j++) {
                    LOG.debug("fieldList values::::" + fieldList[j]);
                    String zipFolderStartName = fieldList[j].replaceAll("_ROOT_", "_");
                    zipFolderStartName=  zipFolderStartName+"_"+date;
                    LOG.debug("zipFolderStartName" + zipFolderStartName+"_"+date+"_");
                    File subParentFolder = new File(folderPath + "/" + fieldList[j]);
                    LOG.debug("subParentFolder...." + subParentFolder.getName());
                    String subFieldList[] = subParentFolder.list();
                    ZipOutputStream zos=null;
                    FileOutputStream fos =null;
                    if (subFieldList != null && subFieldList.length>0) {
                          fos   = new FileOutputStream(zippedFolderLocation +File.separator+ zipFolderStartName + ".zip");
                        zos  = new ZipOutputStream(fos);
                    zippedFileList.add(zipFolderStartName);
                    }
                    LOG.debug("subFieldList not null..." + subFieldList);
                    if (subFieldList != null && subFieldList.length>0) {
                        LOG.debug("subFieldList size..." + subFieldList.length);
                        for (int i = 0; i < subFieldList.length; i++) {
                            LOG.debug("subFieldList values::::" + subFieldList[i]);
                            byte[] buffer = new byte[1024];
                            ZipEntry ze = new ZipEntry(subFieldList[i]);
                            zos.putNextEntry(ze);
                            LOG.debug("subParentFolder.getAbsolutePath()...." + subParentFolder.getAbsolutePath());
                            FileInputStream in =
                                new FileInputStream(subParentFolder.getAbsolutePath() + "/" + subFieldList[i]);

                            int len;
                            while ((len = in.read(buffer)) > 0) {
                                zos.write(buffer, 0, len);
                            }

                            in.close();
                        }

                        zos.closeEntry();

                        //remember close it
                        zos.close();
                        if (fos != null) {
                            fos.close();
                        }
                    }
                }
            }
            LOG.debug("File compresion done");
            form.setZippedFileList(zippedFileList);
        } catch (IOException ex) {
            LOG.fatal("Exception occured..", ex);
        }
    }
    
    /**
     *
     * @param bytes
     * @param destination
     * @param fileName
     * @return
     * @throws Exception
     */
    public  boolean extractZip(byte bytes[],String destination,String fileName) throws Exception {
       
        FileOutputStream fos =null;
        boolean zipCreationStatus=false;
       // String fileName=
       try{
        fos   = new FileOutputStream(destination);
        
        //zos  = new ZipOutputStream(fos);
       
        fos.write(bytes);
            zipCreationStatus=true;
        }catch(Exception e){
            zipCreationStatus=false;
            throw new Exception(e);
       }finally{
           fos.close(); 
       }
       return zipCreationStatus;
    }
}

