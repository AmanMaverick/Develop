package au.gov.doha.pcehr.recovery.util;

import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;


/**
 * Class called from Validator class to check if given date  is valid
 * It is a spring bean.
 * @Author Dinesh Kaki, Operations, PCEHR
 * @since Jan,2015
 * @version - x
 */

public class    DateTimeUtil {
    private static Logger LOG = Logger.getLogger(DateTimeUtil.class);
  
   
   /**
     *
     * @param dateToValidate
     * @param dateFormat
     * @return
     */
    public boolean validatedate(final String dateToValidate,String dateFormat){
        LOG.debug("entering validatedate..."+dateToValidate);
        if (dateToValidate == null) {
            return false;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        sdf.setLenient(false);
        try {
            //if not valid, it will throw ParseException
           Date date = sdf.parse(dateToValidate);
        } catch (ParseException e) {
            LOG.error("Invalid date...");
            return false;
        }
        LOG.debug("valid date Leaving validatedate");
        return true;
    }
   
    
    /**
      *
      * @param dateToValidate
      * @param dateFormat
      * @return
      */
     public String getFormattedDate(final Date date,String dateFormat){
         
         //ddMMyyyyhhmmss
         SimpleDateFormat ft = new SimpleDateFormat(dateFormat);
     

         LOG.debug("valid date Leaving validatedate");
         return ft.format(date);
     }
   /**
     *Validation to check if toDate is greater than fromDate
     * @param fromDate
     * @param toDate
     * @return
     */
    public boolean reconDateOrder(String fromDate, String toDate) {
    boolean b = false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date1 = sdf.parse(fromDate);
            Date date2 = sdf.parse(toDate);
            if (date1.after(date2)) {
                LOG.debug("fromDate is after toDate");
                b = true;
            }else if (date2.after(date1)) {
                LOG.debug("fromDate is before toDate");
                b = false;
            } else{
                b=true;
            }
        } catch (ParseException e) {
            LOG.fatal("Parse exception occured",e);
        }
        return b;
    }
    

    /**
     *
     * @param date
     * @return
     * @throws ParseException
     * @throws DatatypeConfigurationException
     * @throws Exception
     */
    public XMLGregorianCalendar getXMLGregorianCalendar(String date) throws ParseException,
                                                                            DatatypeConfigurationException, Exception {
        LOG.debug("Start of method getXMLGregorianCalendar");
        XMLGregorianCalendar xmlCalender = null;
        GregorianCalendar calender = new GregorianCalendar();
        Date date1 = stringToJavaDate(date);
        if (null == date1) {
            throw new Exception("Invalid Service Stop Time " + date);
        } else {
            calender.setTime(date1);
        }
        xmlCalender = DatatypeFactory.newInstance().newXMLGregorianCalendar(calender);
        LOG.debug("End of method getXMLGregorianCalendar");
        return xmlCalender;
    }


    /**
     *
     * @param sDate
     * @return
     * @throws ParseException
     */
    public Date stringToJavaDate(String sDate) throws ParseException {
        LOG.debug("Start of method stringToJavaDate" + sDate);
        Date date = null;
        if (sDate.length() == 14) {
            date = new SimpleDateFormat("yyyyMMddHHmmss", Locale.ENGLISH).parse(sDate);
        } else if (sDate.length() == 12) {
            date = new SimpleDateFormat("yyyyMMddHHmm", Locale.ENGLISH).parse(sDate);
        } else if (sDate.length() == 8) {
            date = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).parse(sDate);
        } else if (sDate.length() == 10) {
            LOG.debug("sDate.length() == 10");
            date = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).parse(sDate);
        }

        LOG.debug("End of method stringToJavaDate" + date);
        return date;
    }
    
    /**
         *
         * @param xmlDate
         * @return
         */
        public String getXMLGregorianDateToCustomDateString(XMLGregorianCalendar xmlDate)   {
            LOG.debug("Start of method getXMLGregorianDateToCustomDateString:::" + xmlDate);
           String finalFormatedDate = null;
        
            if(null!=xmlDate){
                try{
            SimpleDateFormat targetFormat = new SimpleDateFormat("dd-MMM-yy");
            Date Converteddate=xmlDate.toGregorianCalendar().getTime();
            finalFormatedDate=targetFormat.format(Converteddate);
                }catch(Exception  e){
                    LOG.fatal("Exception... ",e);  
                }
            }

            LOG.debug("Leaving XMLGregorianDateToCustomDateString:::" + finalFormatedDate);
            return finalFormatedDate;
        }
    
    public static int getAge(Date dateOfBirth) {

        Calendar today = Calendar.getInstance();
        Calendar birthDate = Calendar.getInstance();

        int age = 0;

        birthDate.setTime(dateOfBirth);
        if (birthDate.after(today)) {
            throw new IllegalArgumentException("Can't be born in the future");
        }

        age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);

        // If birth date is greater than todays date (after 2 days adjustment of leap year) then decrement age one year   
        if ( (birthDate.get(Calendar.DAY_OF_YEAR) - today.get(Calendar.DAY_OF_YEAR) > 3) ||
                (birthDate.get(Calendar.MONTH) > today.get(Calendar.MONTH ))){
            age--;

         // If birth date and todays date are of same month and birth day of month is greater than todays day of month then decrement age
        }else if ((birthDate.get(Calendar.MONTH) == today.get(Calendar.MONTH )) &&
                  (birthDate.get(Calendar.DAY_OF_MONTH) > today.get(Calendar.DAY_OF_MONTH ))){
            age--;
        } else if ((birthDate.get(Calendar.MONTH) == today.get(Calendar.MONTH )) &&
                  (birthDate.get(Calendar.DAY_OF_MONTH) < today.get(Calendar.DAY_OF_MONTH ))){
            age++;
        }

        return age;
    }
    
    public String calculateAgeDateFromDOB(Date dob){
        Calendar cal = Calendar.getInstance();
        cal.setTime(dob);
        cal.add(Calendar.YEAR, 18);
        Date nextYear = cal.getTime();
        String newDate = getFormattedDate(nextYear, "dd.MM.yyyy");
        return newDate;
    }
    /**
     *
     * @param date
     * @return
     */
    public Date increaseDateByOne(Date date){
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(cal.DATE, 1);
        date=cal.getTime();
        return date;
        
    }
    
    public boolean validateDateForFutureDate(String expiryDate, String format) throws RecoveryServiceException {
        Date expDate;
        try {
            Date current = new Date();
            expDate = new SimpleDateFormat(format, Locale.ENGLISH).parse(expiryDate);
            //compare both dates
            if(expDate.after(current)){
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            LOG.fatal("Invalid date...", e);
            throw new RecoveryServiceException("Exception occured while validateing input Dates For Future Date", e);
        }     
    }    
    
    public String getXMLGregorianDateToSpecificDateFormat(XMLGregorianCalendar xmlDate,String dateFormar)   {
        LOG.debug("Start of method getXMLGregorianDateToCustomDateString:::" + xmlDate);
       String finalFormatedDate = null;
    
        if(null!=xmlDate){
            try{
        SimpleDateFormat targetFormat = new SimpleDateFormat(dateFormar);
        Date Converteddate=xmlDate.toGregorianCalendar().getTime();
        finalFormatedDate=targetFormat.format(Converteddate);
            }catch(Exception  e){
                LOG.fatal("Exception... ",e);  
            }
        }

        LOG.debug("Leaving XMLGregorianDateToCustomDateString:::" + finalFormatedDate);
        return finalFormatedDate;
    }
}
