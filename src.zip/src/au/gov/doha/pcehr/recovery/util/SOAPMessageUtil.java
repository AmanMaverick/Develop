package au.gov.doha.pcehr.recovery.util;

import java.io.IOException;
import java.io.StringWriter;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.stereotype.Component;

import org.w3c.dom.Node;

@Component
public class SOAPMessageUtil {
    public String serialiseSoapXml(final SOAPMessage message) {
      final SOAPPart soapPart = message.getSOAPPart();
      SOAPEnvelope soapEnv;
      try {
        soapEnv = soapPart.getEnvelope();
        return serialiseToString(soapEnv);
      } catch (SOAPException e) {
        return null;
      } catch (IOException e) {
        return null;
      }
    }
    
    private String serialiseToString(final Node soapEnv) throws IOException {
      final StringWriter writer = new StringWriter();
      final StreamResult result = new StreamResult(writer);
        try {
          final DOMSource source = new DOMSource(soapEnv);
          getTransformer().transform(source, result);
          writer.flush();
        } catch (TransformerConfigurationException e) {
          return null;
        } catch (TransformerException e) {
          return null;
        } finally {
          writer.close();
        }
      
      return writer.toString();
    }
    
    private Transformer getTransformer() throws TransformerConfigurationException {

      final TransformerFactory factory = TransformerFactory.newInstance();
      final Transformer transformer = factory.newTransformer();
      transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
      transformer.setOutputProperty(OutputKeys.INDENT, "yes");
      transformer.setOutputProperty(OutputKeys.METHOD, "xml");
      return transformer;
    }
    
    /**
     *This method is to convert user input date to Gregorian Calendar date.
     * @param date
     * @return XMLGregorianCalendar
     */
    public XMLGregorianCalendar getexpiredate(final String date) {
        XMLGregorianCalendar xmlgcal = null;
        try {
            SimpleDateFormat format = new SimpleDateFormat("ddMMyyyy");
            Date date1 = format.parse(date);
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTime(date1);
            xmlgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
        } catch (Exception e) {
            e.getStackTrace();
        }
        return xmlgcal;
    }

    public final String getSoapMessages(Map<String, Object> messageCtx ){
            StringBuffer soapMessagesg = new StringBuffer();
            if(null != messageCtx.get("soapRequest")) {
                soapMessagesg.append("\n......SOAP Request.....\n");
                soapMessagesg.append("\n" + messageCtx.get("soapRequest").toString());
            } 
            if(null != messageCtx.get("soapResponse")) {
                soapMessagesg.append("\n");
                soapMessagesg.append("\n......SOAP Response......\n");
                soapMessagesg.append("\n" + messageCtx.get("soapResponse").toString());
            }
            return soapMessagesg.toString();
        }
}
