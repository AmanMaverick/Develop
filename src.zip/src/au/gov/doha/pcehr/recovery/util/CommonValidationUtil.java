package au.gov.doha.pcehr.recovery.util;


import org.apache.log4j.Logger;

import org.springframework.stereotype.Repository;


@Repository
public class CommonValidationUtil {
    private static Logger LOG = Logger.getLogger(CommonValidationUtil.class);
    /**
     * This method checks if the given value is greater than or equal to max value and min value and return true or false accordingly.
     * @param value
     * @param maxValue
     * @param minValue
     * @return
     */
    public boolean lengthCheck(Integer value,int maxValue, int minValue){
        if(value !=null && (value < minValue || value > maxValue))
            return true;
        else 
            return false;
    }
}
