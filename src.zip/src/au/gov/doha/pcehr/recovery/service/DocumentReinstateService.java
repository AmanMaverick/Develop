package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.DocumentReinstateBO;
import au.gov.doha.pcehr.recovery.bo.DocumentReinstateErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentReinstateWSClientBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.wsclient.DocumentReinstateClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


/**
 * @author Sumanta Kumar Saha
 *This is a service layer for Document reinstate.
 */
@Service
public class DocumentReinstateService {
  
    private static Logger LOG = Logger.getLogger(DocumentReinstateService.class);
    private static final String PCEHR_SUCCESS = "PCEHR_SUCCESS";
    
    @Autowired
    MessageSource messageSource ;
    
    @Autowired
    DocumentReinstateClient documentReinstateClient;
    @Autowired
    FileUtil fileUtil;
    
    /**
     *
     * @param documentReinstateBO
     * @return DocumentlReinstateBO
       * @throws RecoveryServiceException
     */
    public  DocumentReinstateBO processSingleDocumentReinstate(DocumentReinstateBO documentReinstateBO) throws RecoveryServiceException {
        LOG.debug("entering Single processDocumentReinstate");
        LOG.debug("ihi value:::" + documentReinstateBO.getIhi()); 
        documentReinstateBO.setSoapMessage(new StringBuffer());
        documentReinstateBO.setAlertMessage(new StringBuffer());
        documentReinstateBO=performReinstate(documentReinstateBO,"single",documentReinstateBO);
        LOG.debug("leaving single processDocumentReinstate::::::"+documentReinstateBO.getSoapMessage());
        return documentReinstateBO;
        
    }
    
    /**
     * This method is called from the controller for bulk input.
     * @param documentReinstateBO
     * @return DocumentReinstateBO
     * @throws RecoveryServiceException
     */
    public DocumentReinstateBO processBulkDocumentReinstate(DocumentReinstateBO documentReinstateBO) throws RecoveryServiceException {
        LOG.debug("entering Bulk processDocumentReinstate");
        
        boolean deleteDocumentRespose;
       // String reasonForRemoval=documentReinstateBO.getResonForRemoval();
        List<DocumentReinstateBO> listInputBO= createDocumentReinstateBOListFromCSV(documentReinstateBO.getFile());
        LOG.debug("list size:::"+listInputBO.size());
        for(DocumentReinstateBO bo:listInputBO){
            //call validator
            deleteDocumentRespose = validateIHIFromCSV(documentReinstateBO,bo.getIhi(),bo.getDocumentId());
            
            LOG.debug("IHI::"+bo.getIhi());
            LOG.debug("Doc ID:::"+bo.getDocumentId());
            bo.setIhi(bo.getIhi());
            bo.setDocumentId(bo.getDocumentId());
            if(deleteDocumentRespose!=false){
                try{
                    documentReinstateBO=performReinstate(bo,"bulk",documentReinstateBO);
                   
                }catch(Exception e){
                    LOG.fatal("Exception...",e);
                }
            }
                LOG.debug("bo erro bo list:::"+documentReinstateBO.getListDocReinstateErrorBO().size());           
            }
        LOG.debug("leaving bulk processDocumentReinstate");
        return documentReinstateBO;
    }
    
    /**
     *
     * @param documentReinstateBO
     * @return DocumentlReinstateBO
     * @throws RecoveryServiceException
     */
    private DocumentReinstateBO performReinstate(DocumentReinstateBO documentReinstateBO,String removalType,DocumentReinstateBO mainDocumentReinstateBO) throws RecoveryServiceException {
        LOG.debug("entering performReinstate");
       
      //  documentReinstateClient.setDocumentReinstateWSClientBO(getDocumentReinstateWSClientBO(documentReinstateBO));
        try{
            try{
                mainDocumentReinstateBO =documentReinstateClient.reinstate2(mainDocumentReinstateBO, getDocumentReinstateWSClientBO(documentReinstateBO), removalType);
                if(removalType.equals("single")){
                    if(PCEHR_SUCCESS.equals((mainDocumentReinstateBO.getResponseCode()))){
                    mainDocumentReinstateBO.getAlertMessage().append(mainDocumentReinstateBO.getResponseDescription());
                    mainDocumentReinstateBO.getSoapMessage().append(mainDocumentReinstateBO.getResponseDescription());
                    LOG.debug("IFF getSoapMessage,...."+mainDocumentReinstateBO.getSoapMessage());
                    LOG.debug("IFF getResponseCode::::"+mainDocumentReinstateBO.getResponseCode());
                }else{
//                    documentReinstateBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{response.getDescription()},Locale.US));
//                    documentReinstateBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{response.getDescription()},Locale.US));
                                           mainDocumentReinstateBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg",
                                                                                        new Object[] { mainDocumentReinstateBO.getResponseDescription() },
                                                                                        Locale.US));
                    
                    mainDocumentReinstateBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg",
                                                                                        new Object[] { mainDocumentReinstateBO.getResponseDescription() },
                                                                                        Locale.US));
                    LOG.debug("ELSEgetSoapMessage...."+mainDocumentReinstateBO.getSoapMessage()); 
                }
                }
            
            }catch(WebServiceClientException exception){
//                documentReinstateBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{e.getMessage()},Locale.US));
//                documentReinstateBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg", new Object[]{e.getMessage()},Locale.US));
                if(removalType.equals("single")){
                mainDocumentReinstateBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg",
                                                                                    new Object[] { exception.getMessage() },
                                                                                    Locale.US));
                mainDocumentReinstateBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocReinstateFailureMsg",
                                                                                   new Object[] { exception.getMessage() },
                                                                                   Locale.US));
                LOG.debug("catchIFgetSoapMessage...."+mainDocumentReinstateBO.getSoapMessage());
            }
      
            }
            
            
            mainDocumentReinstateBO.setSoapMessage(documentReinstateBO.getSoapMessage().append(documentReinstateClient.getSoapMessage()));
        }catch(Exception e){
            if(removalType.equals("single"))
            throw new RecoveryServiceException(e);
        }
        LOG.debug("leaving performReinstate");
        return mainDocumentReinstateBO;
    }
    
    /**
     *
     * @param documentReinstateBO
     * @return DocumentReinstateWSClientBO
     */
    private DocumentReinstateWSClientBO getDocumentReinstateWSClientBO(DocumentReinstateBO documentReinstateBO){
        LOG.debug("entering getDocumentReinstateWSClientBO");
        DocumentReinstateWSClientBO documentReinstateWSClientBO=new DocumentReinstateWSClientBO();
        documentReinstateWSClientBO.setDocId(documentReinstateBO.getDocumentId());
        documentReinstateWSClientBO.setIhi(documentReinstateBO.getIhi());
        documentReinstateWSClientBO.setUsername(documentReinstateBO.getUsername());
        LOG.debug("leaving getDocumentReinstateWSClientBO");
        return documentReinstateWSClientBO;
    }
    /**
         *
         * @param file
         * @return
         */
        List<DocumentReinstateBO> createDocumentReinstateBOListFromCSV(MultipartFile file){
            List<DocumentReinstateBO> list=new ArrayList<DocumentReinstateBO>();
            BufferedReader br=null;
            try{
            br=new BufferedReader(new InputStreamReader(file.getInputStream()));
                int i=0;
                for(String line=br.readLine();line!=null;line=br.readLine()){
                    
                    if(i==0){
                        i++;
                        continue;
                    }
                    DocumentReinstateBO bo=new DocumentReinstateBO();
                    String arrInput[]=line.split(",");
                    if(arrInput!=null && arrInput.length==2){
                    bo.setIhi(line.split(",")[0]);
                    bo.setDocumentId(line.split(",")[1]);
                    list.add(bo);
                    }else if(arrInput!=null && arrInput.length==1){
                        
                        if(arrInput[0].length()>0){
                            bo.setIhi(arrInput[0]);
                            bo.setDocumentId("");
                            list.add(bo);
                        }
                    }
                }
            }catch(Exception e){
                LOG.fatal("EX:::",e);
            }    
            return list;
            
        }
    
    boolean validateIHIFromCSV(DocumentReinstateBO documentReinstateBO,String ihi,String docId){
        boolean csvInputValidation=true;
        if(ihi!=null && (!ihi.matches("[0-9]{16}"))){
            LOG.debug("IHI......NotValid.....");
            DocumentReinstateErrorBO bo=fileUtil.createDocumentReinstateErrorBO(ihi,docId,"FAIL","Invalid IHI");
            if(documentReinstateBO.getListDocReinstateErrorBO()!=null){
                
                documentReinstateBO.getListDocReinstateErrorBO().add(bo);
            }
            else{
                List<DocumentReinstateErrorBO> listDocReinstateErrorBO=new ArrayList<DocumentReinstateErrorBO>();
                listDocReinstateErrorBO.add(bo);
                documentReinstateBO.getListDocReinstateErrorBO().add(bo);
            }
            csvInputValidation=false;
        }
        try{
        LOG.debug("docId.length()...."+docId.length());
        }catch(Exception e){
            LOG.fatal("e..",e);
        }
         if(docId==null || docId.length()==0){
            LOG.debug("DoccumentID......NotValid.....");
           
            DocumentReinstateErrorBO bo=fileUtil.createDocumentReinstateErrorBO(ihi,docId,"FAIL","Please enter a valid document ID");
            if(documentReinstateBO.getListDocReinstateErrorBO()!=null){
                
                documentReinstateBO.getListDocReinstateErrorBO().add(bo);
            }
            else{
                List<DocumentReinstateErrorBO> listDocReinstateErrorBO=new ArrayList<DocumentReinstateErrorBO>();
                listDocReinstateErrorBO.add(bo);
                documentReinstateBO.getListDocReinstateErrorBO().add(bo);
            }
            csvInputValidation=false;
        }
        return csvInputValidation;
    }
}
