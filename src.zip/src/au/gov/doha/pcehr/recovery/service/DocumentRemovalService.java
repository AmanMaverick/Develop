package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalErrorBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalWSClientBO;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.wsclient.DocumentRemovalClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


/**
 * @author Sumanta Kumar Saha
 * V2 Bulk Removal , Aman Sharma
 * This is a service layer for Document remvoal.
 */
@Service
public class DocumentRemovalService {
    private static Logger LOG = Logger.getLogger(DocumentRemovalService.class);
    
    private static final String PCEHR_SUCCESS = "PCEHR_SUCCESS";
   
    @Autowired
    MessageSource messageSource;
    @Autowired
    DocumentRemovalClient documentRemovalClient;
    @Autowired
    FileUtil fileUtil;
    
    
    public static final String INVALID_IHI = "Ihi is not valid";
    public static final String INVALID_DATA_MESSAGE = "Inputs data is not valid";
    public static final String VALID_DATA_FILE_MESSAGE = "Success";
    public static final String INVALID_DATA_FILE_MESSAGE = "Fail";
  
    
    /**
     * This method is called from the controller for single input.
     * @param documentRemovalBO
     * @return DocumentRemovalBO
     * @throws RecoveryServiceException
     */
    public DocumentRemovalBO processSingleDocumentRemoval(DocumentRemovalBO documentRemovalBO) throws RecoveryServiceException {
        LOG.debug("entering processSingleDocumentRemoval");
        LOG.debug("ihi value:::" + documentRemovalBO.getIhi());    
        documentRemovalBO.setSoapMessage(new StringBuffer());
        documentRemovalBO.setAlertMessage(new StringBuffer());
        documentRemovalBO = performRemoval(documentRemovalBO,"single",documentRemovalBO);
        LOG.debug("leaving processDocumentRemoval");
        return documentRemovalBO;
    }
    
    /**
     * This method is called from the controller for bulk input.
     * @param documentRemovalBO
     * @return DocumentRemovalBO
     * @throws RecoveryServiceException
     * aman.c.sharma
     */
    public DocumentRemovalBO processBulkDocumentRemoval(DocumentRemovalBO documentRemovalBO) throws RecoveryServiceException {
        LOG.debug("entering processDocumentRemoval");
        
        boolean deleteDocumentRespose;
        String reasonForRemoval=documentRemovalBO.getResonForRemoval();
        List<DocumentRemovalBO> listInputBO= createDocumentRemovalBOListFromCSV(documentRemovalBO.getFile(),reasonForRemoval);
        LOG.debug("list size:::"+listInputBO.size());
        for(DocumentRemovalBO bo:listInputBO){
            //call validator
            deleteDocumentRespose = validateIHIFromCSV(documentRemovalBO,bo.getIhi(),bo.getDocumentId());
            
            LOG.debug("IHI::"+bo.getIhi());
            LOG.debug("Doc ID:::"+bo.getDocumentId());
            bo.setIhi(bo.getIhi());
            bo.setDocumentId(bo.getDocumentId());
            if(deleteDocumentRespose!=false){
                try{
                    documentRemovalBO=performRemoval(bo,"bulk",documentRemovalBO);
                   
                }catch(Exception e){
                    LOG.fatal("Exception...",e);
                }
            }
                LOG.debug("bo erro bo list:::"+documentRemovalBO.getListDocRemovalErrorBO().size());
            }
            
//        documentRemovalBO = performRemoval(documentRemovalBO);
        LOG.debug("leaving processDocumentRemoval");
        return documentRemovalBO;
    }

    /**
     * This method calls the webservice client for Document remvoal.
     * @param documentRemovalBO
     * @return DocumentRemovalBO
     */
    private DocumentRemovalBO performRemoval(DocumentRemovalBO documentRemovalBO,String removalType,DocumentRemovalBO mainDocumentRemovalBO) throws RecoveryServiceException {

        LOG.debug("entering performRemoval");
     
        try {
           
          //  documentRemovalClient.setDocumentRemovalWSClientBO(getDocumentRemovalClientBO(documentRemovalBO));
            //can return one consolidated message
            try {
                //call remove instead of remove2
                //ResponseStatusType response = documentRemovalClient.remove(getDocumentRemovalClientBO(documentRemovalBO));
               mainDocumentRemovalBO= documentRemovalClient.remove2(mainDocumentRemovalBO,getDocumentRemovalClientBO(documentRemovalBO),removalType);
                if(removalType.equals("single")){
                if (PCEHR_SUCCESS.equals(mainDocumentRemovalBO.getResponseCode())) {
                    mainDocumentRemovalBO.getAlertMessage().append(mainDocumentRemovalBO.getResponseDescription());
                    mainDocumentRemovalBO.getSoapMessage().append(mainDocumentRemovalBO.getResponseDescription());
                    LOG.debug("IFF getSoapMessage,...."+mainDocumentRemovalBO.getSoapMessage());
                    LOG.debug("IFF getResponseCode::::"+mainDocumentRemovalBO.getResponseCode());
                } else {
                    mainDocumentRemovalBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                        new Object[] { mainDocumentRemovalBO.getResponseDescription() },
                                                                                        Locale.US));
                    
                    mainDocumentRemovalBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                        new Object[] { mainDocumentRemovalBO.getResponseDescription() },
                                                                                        Locale.US));
                    LOG.debug("ELSEgetSoapMessage...."+mainDocumentRemovalBO.getSoapMessage());
                }
                }
            } catch (WebServiceClientException exception) {
              if(removalType.equals("single")){
                mainDocumentRemovalBO.getAlertMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                    new Object[] { exception.getMessage() },
                                                                                    Locale.US));
                mainDocumentRemovalBO.getSoapMessage().append(messageSource.getMessage("DocumentRemovalAttribute.DocRemovalFailureMsg",
                                                                                   new Object[] { exception.getMessage() },
                                                                                   Locale.US));
                LOG.debug("catchIFgetSoapMessage...."+mainDocumentRemovalBO.getSoapMessage());
            }
      
            
        }
            mainDocumentRemovalBO.setSoapMessage(mainDocumentRemovalBO.getSoapMessage().append(documentRemovalClient.getSoapMessage()));
           // }
        } catch (Exception e) {
            if(removalType.equals("single"))
            throw new RecoveryServiceException(e);
        }

        LOG.debug("leaving performRemoval");
        return mainDocumentRemovalBO;
    }

    /**
     * This method sets the business objects for Document removal.
     * @param DocumentRemovalBO
     * @return DocumentRemovalWSClientBO
     */
    private DocumentRemovalWSClientBO getDocumentRemovalClientBO(DocumentRemovalBO bo) {
        LOG.debug("entering getDocumentRemovalClientBO");
        DocumentRemovalWSClientBO clientBo = new DocumentRemovalWSClientBO();
        LOG.debug("valeus:::ihi" + bo.getIhi());
        LOG.debug("valeus:::Doc id" + bo.getDocumentId());
        LOG.debug("valeus::reson" + bo.getResonForRemoval());
        clientBo.setIhi(bo.getIhi());
        clientBo.setDocumentId(bo.getDocumentId());
        clientBo.setResonForRemoval(bo.getResonForRemoval());
        LOG.debug("leaving getDocumentRemovalClientBO");
        return clientBo;
    }

/**
     *
     * @param file
     * @return
     */
    List<DocumentRemovalBO> createDocumentRemovalBOListFromCSV(MultipartFile file,String reasonForRemoval){
//LOG.debug();
        List<DocumentRemovalBO> list=new ArrayList<DocumentRemovalBO>();
        BufferedReader br=null;
        try{
        br=new BufferedReader(new InputStreamReader(file.getInputStream()));
            int i=0;
            for(String line=br.readLine();line!=null;line=br.readLine()){
                
                if(i==0){
                    i++;
                    continue;
                }
                DocumentRemovalBO bo=new DocumentRemovalBO();
                String arrInput[]=line.split(",");
                if(arrInput!=null && arrInput.length==2){
                bo.setIhi(line.split(",")[0]);
                bo.setDocumentId(line.split(",")[1]);
                bo.setResonForRemoval(reasonForRemoval);
                list.add(bo);
                }else if(arrInput!=null && arrInput.length==1){
                    
                    if(arrInput[0].length()>0){
                        bo.setIhi(arrInput[0]);
                        bo.setDocumentId("");
                        list.add(bo);
                    }
                }
            }
        }catch(Exception e){
            LOG.fatal("EX:::",e);
        }
        //LOG.debug();        
        return list;
        
    }
    boolean validateIHIFromCSV(DocumentRemovalBO documentRemovalBO,String ihi,String docId){
        boolean csvInputValidation=true;
        if(ihi!=null && (!ihi.matches("[0-9]{16}"))){
            LOG.debug("IHI......NotValid.....");
            DocumentRemovalErrorBO bo=fileUtil.createDocumentRemovalErrorBO(ihi,docId,"FAIL","Invalid IHI");
            if(documentRemovalBO.getListDocRemovalErrorBO()!=null){
                
                documentRemovalBO.getListDocRemovalErrorBO().add(bo);
            }
            else{
                List<DocumentRemovalErrorBO> listDocRemovalErrorBO=new ArrayList<DocumentRemovalErrorBO>();
                listDocRemovalErrorBO.add(bo);
                documentRemovalBO.getListDocRemovalErrorBO().add(bo);
            }
            csvInputValidation=false;
        }
        try{
        LOG.debug("docId.length()...."+docId.length());
        }catch(Exception e){
            LOG.fatal("e..",e);
        }
         if(docId==null || docId.length()==0){
            LOG.debug("DoccumentID......NotValid.....");
           
            DocumentRemovalErrorBO bo=fileUtil.createDocumentRemovalErrorBO(ihi,docId,"FAIL","Please enter a valid document ID");
            if(documentRemovalBO.getListDocRemovalErrorBO()!=null){
                
                documentRemovalBO.getListDocRemovalErrorBO().add(bo);
            }
            else{
                List<DocumentRemovalErrorBO> listDocRemovalErrorBO=new ArrayList<DocumentRemovalErrorBO>();
                listDocRemovalErrorBO.add(bo);
                documentRemovalBO.getListDocRemovalErrorBO().add(bo);
            }
            csvInputValidation=false;
        }
        return csvInputValidation;
    }

}
