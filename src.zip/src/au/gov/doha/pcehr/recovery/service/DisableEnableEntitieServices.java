package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.constants.RecoverConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.DisableEnableEntitiesForm;
import au.gov.doha.pcehr.recovery.wsclient.PCEHREntitySuspensionClient;

import au.pcehr.ws.pna.common.ApplicationResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Service class to perform Disable Re-enable entity first. Secondly, to do audit entry for the operation performed.
 * @author Vikash Kumar Singh, Operations,  PCEHR
 * @since   23rd April 2015
 */
@Component
public class DisableEnableEntitieServices {
    private static Logger LOG = Logger.getLogger(DisableEnableEntitieServices.class);
    
//    private PCEHREntitySuspensionClient getPCEHREntitySuspensionClient(){
//        return new PCEHREntitySuspensionClient();
//    }
    
    @Autowired
    PCEHREntitySuspensionClient pcehrEntitySuspensionClient;
    @Autowired
    InsertAuditRecordService insertAuditRecordService;
    
    public DisableEnableEntitiesForm performOperation(DisableEnableEntitiesForm disableEnableEntities) throws RecoveryServiceException {
        disableEnableEntities.setSoapMessage(new StringBuffer());
        disableEnableEntities.setAlertMsg(new StringBuffer());
        List<String> entityIdList = getEntryListfromFile(disableEnableEntities);
        if(null!=disableEnableEntities.getEntitiesID() && !disableEnableEntities.getEntitiesID().equals(""))
        entityIdList.add(disableEnableEntities.getEntitiesID());
     
        disableEnableEntities.setEntities(entityIdList);
        disableEnableEntities = perfromSuspension(disableEnableEntities);
        return disableEnableEntities;
    }

    /**
     * 
     * @param bo
     * @return
     * @throws RecoveryServiceException
     */
    private DisableEnableEntitiesForm perfromSuspension( DisableEnableEntitiesForm disableEnableEntitiesBO) throws RecoveryServiceException{
        LOG.debug("Entering perfromSuspension method.");
        
        
      
        List<String> entityidList = disableEnableEntitiesBO.getEntities();
        AuditRecordBO auditBO = getAuditRecordBO(disableEnableEntitiesBO);
        
        LOG.debug("Entering doClientCall method...."+entityidList.size());
        try {
            //PCEHREntitySuspensionClient client = getPCEHREntitySuspensionClient();
            //pcehrEntitySuspensionClient.setStatus(bo.getStatus());
            //pcehrEntitySuspensionClient.setEntityType(bo.getEntityType());
            List code = Arrays.asList(RecoverConstants.SUSPENSION_ERROR_CODE);
            for (int i = 0; i < entityidList.size() ; i++) {
                if(entityidList.get(i)==null || entityidList.get(i).length()==0){
                continue;
                }
                //Webservice call for suspension
                //pcehrEntitySuspensionClient.setEntityID(entityidList.get(i));
                disableEnableEntitiesBO = pcehrEntitySuspensionClient.callPCEHREntitySuspensionClient(disableEnableEntitiesBO, entityidList.get(i) );
                
                //disableEnableEntitiesBO.setSoapMessage(disableEnableEntitiesBO.getSoapMessage().append(pcehrEntitySuspensionClient.getSoapMessage()));
                //disableEnableEntitiesBO.setAlertMsg(disableEnableEntitiesBO.getAlertMsg().append( formAlertMessage(entityidList.get(i),clientResp.getResultStatus().getStatusDescription())));
                ApplicationResponse applicationResponse = disableEnableEntitiesBO.getOimDisableEntitiesResponse().getResultStatus();
                //Webservice call for Audit
                auditBO.setSubject(entityidList.get(i));
                auditBO.setTransactionStatus(code.contains(applicationResponse.getStatusCode().toString())?"FAILED":"COMPLETED");
                auditBO.setMessageLogLevel(code.contains(applicationResponse.getStatusCode().toString())?"ERROR":"AUDIT");
                auditBO.setStatusCode(applicationResponse.getStatusCode().toString());
                auditBO.setStatus(code.contains(applicationResponse.getStatusCode().toString())?false:true);
                
                LOG.info("clientResp.getResultStatus().getStatusCode().toString()"+disableEnableEntitiesBO.getOimDisableEntitiesResponse().getResultStatus().getStatusCode().toString());
                auditBO.setDescription(applicationResponse.getStatusDescription());
                auditBO.setSoapMesage(disableEnableEntitiesBO.getEntitySoapMessage());
                auditBO = insertAuditRecordService.insertAudit(auditBO);
                disableEnableEntitiesBO.setSoapMessage(disableEnableEntitiesBO.getSoapMessage().append(auditBO.getResponseStatusMsg()));
                if(auditBO.getAlertMsg()!=null && auditBO.getAlertMsg().length()>0){
                    disableEnableEntitiesBO.setAlertMsg(disableEnableEntitiesBO.getAlertMsg().append( formAlertMessage(entityidList.get(i),auditBO.getAlertMsg())));
                }
                disableEnableEntitiesBO.setAlertMsg(disableEnableEntitiesBO.getAlertMsg().append("<BR>"));
                
            }
            
        }catch(RecoveryServiceException e){
            throw e;
        }catch(Exception e){
            LOG.fatal("Exception occured",e);
            throw new RecoveryServiceException(e);        
        }
       
        
        return disableEnableEntitiesBO;
    }
    
    /**
     * Setting values for insert audit update parameter
     * @param bo
     * @return
     */
    private AuditRecordBO getAuditRecordBO(DisableEnableEntitiesForm bo){
        String status = ("DISABLE".equals(bo.getStatus())) ? "disableAccess" : "reenableAccess";
        AuditRecordBO auditBO = new AuditRecordBO();
        auditBO.setActionType(bo.getEntityType());
        auditBO.setUserID(bo.getUserID());
       
        auditBO.setSystemOperatorName(bo.getOperatorName());
        auditBO.setUsername(bo.getOperatorName());
        auditBO.setActionType("Update");
        
        auditBO.setOperationPerfomed(status);
        auditBO.setBusinessEvent(status);
        auditBO.setSubjectType(bo.getEntityType());
        auditBO.setVendor("NIO");
        auditBO.setComponentSource("NIO");
        auditBO.setProductName("OPS Tool");
        auditBO.setEventSource("OPS Tool");
        auditBO.setProdoctVersion("1.1");
        auditBO.setPlatForm("Jump Host");
        LOG.info("Audit status value :: "+auditBO.isStatus());
        return auditBO;
    }
    
    private StringBuffer formAlertMessage(String key,String value){
        StringBuffer alertMsg = new StringBuffer();
        alertMsg.setLength(0);
        alertMsg.append(key);
        alertMsg.append(":");
        alertMsg.append(value);
        alertMsg.append("\n");
        return alertMsg;
    }

    /**
     * This method is to fetch the list of document ids
     * @param artExtractionBO
     * @return
     * @throws RecoveryServiceException
     */
   
    private static List<String> getEntryListfromFile(DisableEnableEntitiesForm disableEnableEntities) throws RecoveryServiceException{
        Set<String> documentIdLst = new HashSet< >();
        String csvSplitBy=",";
        String[] ihi = null;
        InputStreamReader inStreamReader = null;
        BufferedReader bReader = null;
        try {
            inStreamReader = new InputStreamReader(disableEnableEntities.getFile().getInputStream());
             bReader = new BufferedReader(inStreamReader);
            for(String line=bReader.readLine(); (line!=null) ; line=bReader.readLine()) {
                
                if(line != null && !line.equals(""))
                    
                    ihi = line.split(csvSplitBy);
                LOG.debug("getEntryListfromFile ihi list valus::"+ihi);
                    documentIdLst.addAll(Arrays.asList(ihi)); 
                LOG.debug("documentIdLst.size...."+documentIdLst.size());
            }
        } catch (IOException e) {
            throw new RecoveryServiceException(e);
        }finally{
            try{
                bReader.close();
                inStreamReader.close();
            }catch(Exception e){
                LOG.debug("Exception occured while colosing the resources..");
            }
        }
        return new ArrayList<String>(documentIdLst);
    }
    
}
