package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.dao.ProviderRegistrationOIDDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ProviderRegistrationOIDForm;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service class for Provider Registration OID
 * Obtains list from DAO class.
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Apr 2015
 * @version Change-x
 */


@Service
public class ProviderRegistrationOIDService {

    private static Logger LOG = Logger.getLogger(ProviderRegistrationOIDService.class);

    @Autowired
    private ProviderRegistrationOIDDAO providerRegistrationOIDDAO;
    
     /**
     * This method is called from the controller after validation is successful.
     * @param providerRegistrationOIDForm
     * @return
     * @throws RecoveryDAOException
     */
  
    public ProviderRegistrationOIDForm providerRegistrationOIDServiceMethod(ProviderRegistrationOIDForm providerRegistrationOIDForm) throws RecoveryDAOException,RecoveryServiceException {
        LOG.debug("Inside Service Class method");        
        try{
            providerRegistrationOIDForm =
                providerRegistrationOIDDAO.fetchProviderRegistrationOIDList(providerRegistrationOIDForm);
        }catch (RecoveryDAOException ex) {
              throw ex;   
          }catch(Exception e){
                  LOG.fatal("Exception Occured", e);
                  throw new RecoveryServiceException(e);    
          }        
        LOG.debug("Leaving Service Class");
        return providerRegistrationOIDForm;
    }

}