package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.GetDocumentListClientBO;
import au.gov.doha.pcehr.recovery.bo.UpdateDocuementStatusClientBO;
import au.gov.doha.pcehr.recovery.dao.DocumentReSyncDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.exception.WebServiceClientException;
import au.gov.doha.pcehr.recovery.form.DocumentReSyncForm;
import au.gov.doha.pcehr.recovery.wsclient.GetDocumentListClient;
import au.gov.doha.pcehr.recovery.wsclient.UpdateDocuementStatusClient;

import au.pcehr.docx.internal.ApplicationResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import javax.xml.bind.JAXBElement;

import oasis.names.tc.ebxml_regrep.xsd.query._3.AdhocQueryResponse;
import oasis.names.tc.ebxml_regrep.xsd.rim._3.ExtrinsicObjectType;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Service class for Document Re Synchronisation.
 * @author Sapna
 */
@Service
public class DocumentReSyncService {
    
    private static Logger LOG = Logger.getLogger(DocumentReSyncService.class);
    private static final String REACTIVATE = "reactivate";
    private static final String DEPRICATE = "depricate";
    private static final String APPROVED="urn:oasis:names:tc:ebxml-regrep:StatusType:Approved";
    @Autowired
    DocumentReSyncDAO documentReSyncDAO;
    @Autowired
    UpdateDocuementStatusClient updateDocuementStatusClient;
    @Autowired
    GetDocumentListClient getDocumentListClient;
    @Autowired
    InsertAuditRecordService insertAuditRecordService;
    

    /**
      * Fetches IHI from the DB for the given DocIDs and calls DeprecateAtomicData/ReactivateAtomicData webservices accordingly
      * @param documentReSyncForm
      * @return
      * @throws RecoveryServiceException
      */
     
     public DocumentReSyncForm processBulkIHI(DocumentReSyncForm documentReSyncForm) throws RecoveryServiceException {

         try {
             LOG.debug("Entered processBulkIHI..");
             Map<String, String> status = new HashMap<String, String>();

             Map<String, String> auditStatus = new HashMap<String, String>();
             documentReSyncForm.setStatus(status);
             documentReSyncForm.setAuditStatus(auditStatus);
             StringBuffer statusMessage = new StringBuffer();
             List<String> dicIdList = getDocIds(documentReSyncForm);
             documentReSyncForm.setIhiList(dicIdList);
             LOG.debug("Length of the document list " + dicIdList.size());
             for (String docId : dicIdList) {
                 try {
                     LOG.debug("Processing for Doc id: " + docId);
                     //Fetching IHI documentid
                     String ihi = documentReSyncDAO.getIHIfromRLS(docId);
                     String ihi_hdr = null;
                     
                     if (ihi == null) {
                         LOG.info("Document not available in RLS");
                         ihi_hdr = documentReSyncDAO.getIHIfromHDR(docId);

                         if (ihi_hdr == null) {
                             LOG.info("Document not available in both HTB and RLS ");
                             status.put(docId, "IHI Not Found.");
                             auditStatus.put(docId, "Not Applicable");
                             continue;
                         } 
                         else {
                             LOG.info("Deprecating Doc in HDR");
                             callDepricateAtomicData(documentReSyncForm, docId, ihi_hdr);
                             insertAudit(documentReSyncForm, docId, ihi_hdr);
                         }
                     }
                     else {
                         String docStatus = null;
                         //Checking if it has to be depricated or reactivated
                         docStatus = checkDepricateOrReactivate(documentReSyncForm, ihi, docId);
                         //Calling Webservice client for deprication/Reactivation
                         LOG.info(" docStatus " +docStatus);
                         if (REACTIVATE.equals(docStatus)) {
                             callReactivateAtomicData(documentReSyncForm, docId, ihi);
                         } else {
                             callDepricateAtomicData(documentReSyncForm, docId, ihi);
                         }
                     }

                     //Calling Audit
                     insertAudit(documentReSyncForm, docId, ihi);
                 } catch (RecoveryServiceException e) {
                     LOG.fatal("Exception has occured", e);
                 } catch (RecoveryDAOException e) {
                     LOG.fatal("Exception has occured", e);
                 } catch (WebServiceClientException e) {
                     LOG.fatal("Exception has occured", e);
                 }
             }
             LOG.debug("Processing completed.");
         } catch (Exception e) {
             LOG.fatal("Exception has occured", e);
             throw new RecoveryServiceException(e);
         }

         return documentReSyncForm;
     }
    
    /**
     * This method will call getAuditRecordBO to set all the reuest values into aRrestrictBO object for updating audit logs.
     * The returned object will be passed to insertAudit method of InsertAuditRecordService and audit details will be updated.
     * @param aRrestrict
     * @param status
     * @return ARrestrictBO
     * @throws RecoveryServiceException
     */
    private AuditRecordBO insertAudit(DocumentReSyncForm documentReSyncForm, String docId,String ihi) throws RecoveryServiceException
    {
        try{
            LOG.debug("Inside insertAudit Method .... ");
            AuditRecordBO auditRecord = getAuditRecordBO(documentReSyncForm, docId,ihi);
            auditRecord = insertAuditRecordService.insertAudit(auditRecord);
            LOG.debug("Return insertAudit Method .... ");
            Map<String,String> auditStatus = documentReSyncForm.getAuditStatus();
            auditStatus.put(docId, auditRecord.getAuditReponse()==null?auditRecord.getAlertMsg():auditRecord.getAuditReponse().getDescription());
            documentReSyncForm.setAuditStatus(auditStatus);
            return auditRecord;
        }catch(Exception e){
            LOG.fatal("Exception Occured", e);
            throw new RecoveryServiceException(e);    
        }
    }

    /**
     * Collecting data to perform Insert Audit.
     * @param aRrestrict
     * @param status
     * @return ARrestrictBO
     */
    private AuditRecordBO getAuditRecordBO(DocumentReSyncForm documentReSyncForm, String docId,String ihi)throws RecoveryServiceException
    {
        try{
            HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            String userId = req.getUserPrincipal().getName();;
            AuditRecordBO auditRecordBO = new AuditRecordBO();
            
            auditRecordBO.setUserID(userId);
            auditRecordBO.setUsername("PCEHR_SYSTEM_OPERATOR");
            auditRecordBO.setIhi(ihi);
            auditRecordBO.setVendor("NIO - PNA setARRestrictions");
            auditRecordBO.setProductName("documentSynchronisation");
            auditRecordBO.setProdoctVersion("1.1");
            auditRecordBO.setPlatForm("Jump Host");
            auditRecordBO.setTransactionStatus("COMPLETED");
            auditRecordBO.setBusinessEvent("documentSynchronisation");
            auditRecordBO.setComponentSource("NIO");
            auditRecordBO.setIhiName(ihi);
            auditRecordBO.setSubject(docId);
            auditRecordBO.setSubjectType("DocumentID");
            auditRecordBO.setOperationPerfomed("setARRestrictions");
            auditRecordBO.setReason(null);
            auditRecordBO.setActionType("Update");
 
            auditRecordBO.setOperationPerfomed("documentSynchronisation");
            auditRecordBO.setAccessConditions("OpenAccess");
            auditRecordBO.setAccessLevel("Self");
            auditRecordBO.setStatus(true);//TODO
            if(auditRecordBO.isStatus())
            {
                auditRecordBO.setStatusCode("PCEHR_SUCCESS");
                auditRecordBO.setDescription("Success");
            } else
            {
                auditRecordBO.setStatusCode("PCEHR_ERROR");
                auditRecordBO.setDescription("Error");
            }
            auditRecordBO.setMessageLogLevel("AUDIT");
            auditRecordBO.setSoapMesage("");
            return auditRecordBO;
        }catch(Exception e){
            LOG.fatal("Exception Occured", e);
            throw new RecoveryServiceException(e);    
        }
    }

    /**
     * This mentod calls the depricate atomic data
     * @param documentReSyncForm
     * @param docId
     * @param ihi
     * @return
     * @throws WebServiceClientException
     */
    private DocumentReSyncForm callDepricateAtomicData(DocumentReSyncForm documentReSyncForm,String docId,String ihi) throws WebServiceClientException{
        
        ApplicationResponse response = updateDocuementStatusClient.executeDeprecateAtomicData(getUpdateDocuementStatusClientBO(ihi,docId));
        Map status =  documentReSyncForm.getStatus();
        status.put(docId,response.getResponseDetail());
        documentReSyncForm.setStatus(status);
        return documentReSyncForm;
    }
    
    
    /**
     *  This method calls the reactivate atomic data.
     * @param documentReSyncForm
     * @param docId
     * @param ihi
     * @return
     * @throws WebServiceClientException
     */
    private DocumentReSyncForm callReactivateAtomicData(DocumentReSyncForm documentReSyncForm,String docId,String ihi)throws WebServiceClientException{
        ApplicationResponse response = updateDocuementStatusClient.executeReactivateAtomicData(getUpdateDocuementStatusClientBO(ihi,docId));
        Map status =  documentReSyncForm.getStatus();
        status.put(docId,response.getResponseDetail());
        documentReSyncForm.setStatus(status);
        return documentReSyncForm;
    }
    
    /**
     * This method creates the update document client BO object
     * @param ihi
     * @param docid
     * @return
     */
    private UpdateDocuementStatusClientBO getUpdateDocuementStatusClientBO(String ihi,String docid){
        UpdateDocuementStatusClientBO updateDocuementStatusClientBO = new UpdateDocuementStatusClientBO();
        updateDocuementStatusClientBO.setIhi(ihi);
        updateDocuementStatusClientBO.setDocID(docid);
        return updateDocuementStatusClientBO;
    }
    
    /**
     * Calls getdoucument list service and validate wheather the document is depreicated or not.
     * @param documentReSyncForm
     * @param ihi
     * @return
     */
    private String checkDepricateOrReactivate(DocumentReSyncForm documentReSyncForm,String ihi,String docId) throws WebServiceClientException{
        
        
        String versionName =null;
        ExtrinsicObjectType latestExtrinsicObject= null; 
        AdhocQueryResponse adhocQueryResponse = getDocumentListClient.getDocListWsCall(getGetDocumentBO(ihi,docId));
        
        List<JAXBElement<? extends oasis.names.tc.ebxml_regrep.xsd.rim._3.IdentifiableType>> identifiable =
            adhocQueryResponse.getRegistryObjectList().getIdentifiable();
        for (int j = 0; j < identifiable.size(); j++) {
            for (int i = 0; i < ((ExtrinsicObjectType)identifiable.get(j).getValue()).getExternalIdentifier().size();i++) {
                versionName = ((ExtrinsicObjectType)identifiable.get(j).getValue()).getVersionInfo().getVersionName();
                latestExtrinsicObject =(ExtrinsicObjectType)identifiable.get(j).getValue();
            }
        }
        LOG.debug("do status in RLS:::"+latestExtrinsicObject.getStatus());
        if((versionName!=null && Integer.parseInt(versionName)>0 )&& APPROVED.equals(latestExtrinsicObject.getStatus())){
            return REACTIVATE;
        }else{
            return DEPRICATE;
        }

    }
    
    /**
     * Get document list client BO
     * @param ihi
     * @return
     */
    private GetDocumentListClientBO getGetDocumentBO(String ihi,String docID){
        GetDocumentListClientBO getDocumentListClientBO = new GetDocumentListClientBO();
        getDocumentListClientBO.setIhi(ihi);
        getDocumentListClientBO.setDocEntryStatus(getDocumentListClient.DOCENTRY_STATUS_APPROVED_AND_DEPRICATD);
        getDocumentListClientBO.setIhiOrDocID("('"+docID+"')");
        
            List<String> docEntryStatus = new ArrayList<String>();
            docEntryStatus.add(getDocumentListClient.DOCENTRY_STATUS_APPROVED_AND_DEPRICATD);
            List<String> docid = new ArrayList<String>();
            docid.add(docID);
            getDocumentListClientBO.setDocumentEntryUniqueId(docid);
            getDocumentListClientBO.setXDSDocumentEntryId(getDocumentListClient.DOCUMENT_ENTRY_UNIQUE_ID);
            getDocumentListClientBO.setAdhocQueryID(getDocumentListClient.ADHOC_QUERY_ID);
            getDocumentListClientBO.setDocumentEntryStatus(docEntryStatus);
        
        return getDocumentListClientBO;
    }
    
    /**
     * This method retrieves the document id.
     * @param documentReSyncForm
     * @return
     * @throws RecoveryServiceException
     */
    private List<String> getDocIds(DocumentReSyncForm documentReSyncForm) throws RecoveryServiceException{
        HashSet<String> uniquDocIdSet = new HashSet<String>();
        Set<String> dicIdList = new HashSet<String>();
        String csvSplitBy = ",";
        String[] docId = null;
        InputStreamReader iStreamReader = null;
        BufferedReader bReader = null;
        try {
            iStreamReader = new InputStreamReader(documentReSyncForm.getFile().getInputStream());
             bReader = new BufferedReader(iStreamReader);
            for(String line=bReader.readLine(); line!=null; line=bReader.readLine()) {
                if(line != null && !line.equals(""))
                    docId = line.split(csvSplitBy);
                uniquDocIdSet.addAll(Arrays.asList(docId)); 
            }
            dicIdList.addAll(uniquDocIdSet);
            LOG.debug("DOc id List size ::"+dicIdList.size());
            documentReSyncForm.setFile(null);
        } catch (IOException e) {
            throw new RecoveryServiceException(e);
        }finally{
            try{
                bReader.close();
                iStreamReader.close();
            }catch(Exception e){
                LOG.debug("Exception occured while colosing the resources..");
                
            }
        }
        return new ArrayList<String>(dicIdList);
    }
}
