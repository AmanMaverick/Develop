package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.GetViewClientBO;
import au.gov.doha.pcehr.recovery.bo.HealthRecordExtractionErrorBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.constants.HealthRecordExtractionConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.HealthRecordExtForm;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.util.StyleSheetUtil;
import au.gov.doha.pcehr.recovery.wsclient.GetViewClient;

import java.io.File;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Service to perform extraction of health records.
 * @author  Aman Sharma
 * @since R 6.0.4
 */
@Service
public class HealthRecordExtService {
    private static Logger LOG = Logger.getLogger(HealthRecordExtService.class);
    @Autowired
    FileUtil fileUtil;
    @Autowired
    StyleSheetUtil styleSheetUtil;
    @Autowired
    GetViewClient getViewClient;

    @Autowired
    InsertAuditRecordService insertAuditRecordService;
    
    private static final String VIEW_TYPE_HRO = "HRO";
    private static final String VIEW_TYPE_MIV = "MIV";
    private static final String VIEW_TYPE_NPDR = "PDV";
    private static final String VIEW_TYPE_ALL = "ALL";
    private static final String CSV_FILE_STYLESHEET_APPLIED_SCUUCESS_MESSAGE = "Successfully Extraction with stylesheet";
     private static final String CSV_FILE_STYLESHEET_ERROR_MESSAGE ="Error in applying Stylesheet";
    /**
     * This method is called from controller class.
     * 1.Call client - Get view
     * 2.Apply style sheet.
     * 3.Save in specified location
     * @param healthRecordExtForm
     * @return
     * @throws RecoveryServiceException
     * @since  R6.1
     */
    public HealthRecordExtForm extractViews(HealthRecordExtForm healthRecordExtForm) throws RecoveryServiceException {
   
        String inputFileLocation = "";


        List<String> ihiList = fileUtil.readFileUniqueIHI(healthRecordExtForm.getIhiExtractionLst());
        //getViewClient.retrieveConsolidatedView(getGetViewClientBO(healthRecordExtForm, ihi));
        for (String ihi : ihiList) {
            LOG.debug("IHI ..." + ihi);
            try {
                String viewType = healthRecordExtForm.getViewType();
                LOG.debug("view type::::" + viewType);
                List<String> viewLst = getViewType( viewType);
                for(String view:viewLst){
                    if (view.equalsIgnoreCase(VIEW_TYPE_MIV) || view.equalsIgnoreCase(VIEW_TYPE_NPDR)) {
                             performretrieveConsolidatedViewWSCall(healthRecordExtForm, ihi, view);
                    } else if (view.equalsIgnoreCase(VIEW_TYPE_HRO)) {
                             performHealthRecordOverviewWSCall(healthRecordExtForm, ihi);
                     }
                }
                
                LOG.debug("creating csv error file ");
              
            } catch (Exception e) {
                LOG.fatal("Exception occured for IHI" + ihi, e);
            } finally {
                LOG.debug("deleting file::::" + inputFileLocation);

            }
            LOG.debug("Starting Logging for IHI :: " + ihi);
            AuditRecordBO auditBO = getAuditRecordBO(healthRecordExtForm, ihi);
            auditBO = insertAuditRecordService.insertAudit(auditBO);
            LOG.debug("Logging Completed Successfully for IHI :: " + ihi);
        }
        LOG.debug("final viwes extracted count ::"+healthRecordExtForm.getViesExtractedCount());
       String finalStatusCSVFileName=fileUtil.createCSVForErrorWritting(healthRecordExtForm.getListHealthRecordExtractionErrorBO());
        healthRecordExtForm.setFinalStatusCSVFileName(finalStatusCSVFileName);
        return healthRecordExtForm;
    }


    /**
     * 
     * @param viewType
     * @return
     */
    private List<String> getViewType(String viewType){
        
        List<String> viewList = new ArrayList<String>();
            if(VIEW_TYPE_ALL.equals(viewType)){
                viewList.add(VIEW_TYPE_MIV);
                viewList.add(VIEW_TYPE_NPDR);
                viewList.add(VIEW_TYPE_HRO);
            }else{
                viewList.add(viewType);
            }
            return viewList;
    }
    /**
     *
     * @param healthRecordExtForm
     * @param ihi
     * @return
     */
    private HealthRecordExtForm performHealthRecordOverviewWSCall(HealthRecordExtForm healthRecordExtForm, String ihi) {
        LOG.debug("Entering performHealthRecordOverviewWSCall");

        GetViewClientBO getViewClientBO =
            getViewClient.gethealthRecordOverview(getGetViewClientBO(healthRecordExtForm, VIEW_TYPE_HRO, ihi));
        if (getViewClientBO.getSoapResponse() != null) {
            LOG.debug("getViewClientBO.getSoapResponse() resposne is not null");
            byte[] responseBytes = getViewClientBO.getSoapResponse().getBytes();

            boolean stylesheetReturnStatus = performStylesheetApplying(responseBytes, VIEW_TYPE_HRO, ihi);
            if (stylesheetReturnStatus) {
                
                LOG.debug("Stylesheet applied succesffully");
                LOG.debug("viwes extracted count ::"+healthRecordExtForm.getViesExtractedCount());
                healthRecordExtForm.setViesExtractedCount(healthRecordExtForm.getViesExtractedCount()+1);
                HealthRecordExtractionErrorBO errorBO =
                    fileUtil.createErrorBo(ihi, CSV_FILE_STYLESHEET_APPLIED_SCUUCESS_MESSAGE, VIEW_TYPE_HRO);
                healthRecordExtForm = createErrorList(healthRecordExtForm, errorBO);

            } else {
                LOG.debug("Issue with appllying  Stylesheet");
                HealthRecordExtractionErrorBO errorBO =
                    fileUtil.createErrorBo(ihi, CSV_FILE_STYLESHEET_ERROR_MESSAGE, VIEW_TYPE_HRO);
                healthRecordExtForm = createErrorList(healthRecordExtForm, errorBO);
            }
        } else {
            LOG.debug("getViewClientBO.getSoapResponse() resposne  is null");
            healthRecordExtForm =
                createErrorList(healthRecordExtForm, getViewClientBO.getHealthRecordExtractionErrorBO());

        }
        LOG.debug("Leaving performHealthRecordOverviewWSCall");
        return healthRecordExtForm;
    }

    /**
     *
     * @param healthRecordExtForm
     * @param ihi
     * @param viewType
     * @return
     */
    private HealthRecordExtForm performretrieveConsolidatedViewWSCall(HealthRecordExtForm healthRecordExtForm,
                                                                      String ihi, String viewType) {
        LOG.debug("Entering performretrieveConsolidatedViewWSCall");
        GetViewClientBO getViewClientBO =
            getViewClient.retrieveConsolidatedView(getGetViewClientBO(healthRecordExtForm, viewType, ihi));
        if (getViewClientBO.getReposnseDcoument() != null) {
            LOG.debug("getViewClientBO.getReposnseDcoument() resposne is not null");
            byte[] responseBytes = getViewClientBO.getReposnseDcoument();
            boolean stylesheetReturnStatus = performStylesheetApplying(responseBytes, viewType, ihi);
            if (stylesheetReturnStatus) {
                LOG.debug("Stylesheet applied succesffully");
                LOG.debug("viwes extracted count ::"+healthRecordExtForm.getViesExtractedCount());
                healthRecordExtForm.setViesExtractedCount(healthRecordExtForm.getViesExtractedCount()+1);
                
                HealthRecordExtractionErrorBO errorBO =
                    fileUtil.createErrorBo(ihi, CSV_FILE_STYLESHEET_APPLIED_SCUUCESS_MESSAGE, viewType);
                healthRecordExtForm = createErrorList(healthRecordExtForm, errorBO);

            } else {
                LOG.debug("Issue with appllying  Stylesheet");
                HealthRecordExtractionErrorBO errorBO =
                    fileUtil.createErrorBo(ihi, CSV_FILE_STYLESHEET_ERROR_MESSAGE, viewType);
                healthRecordExtForm = createErrorList(healthRecordExtForm, errorBO);
            }
        } else {
            LOG.debug("getViewClientBO.getReposnseDcoument() resposne  is null");
            healthRecordExtForm =
                createErrorList(healthRecordExtForm, getViewClientBO.getHealthRecordExtractionErrorBO());
        }
        LOG.debug("Leaving performretrieveConsolidatedViewWSCall");
        return healthRecordExtForm;
    }

    /**
     *
     * @param healthRecordExtForm
     * @param viewType
     * @param ihi
     * @return
     */
    private GetViewClientBO getGetViewClientBO(HealthRecordExtForm healthRecordExtForm, String viewType, String ihi) {
            GetViewClientBO getViewClientBO = new GetViewClientBO();
            getViewClientBO.setFamilyName("XXXX");
            getViewClientBO.setLastName("XXXX");
            getViewClientBO.setSex(1);
            getViewClientBO.setDob("30/02/2015");
            getViewClientBO.setMedicareCardNumber("XXXX");
            getViewClientBO.setAusAdressLine("XXXX");
            getViewClientBO.setUnitType("XXXX");
            getViewClientBO.setUnitNumber("XXXX");
            getViewClientBO.setAddressSiteName("XXXX");
            
            getViewClientBO.setLevelNumber("XXXX");
            getViewClientBO.setLevelType("XXXX");
            getViewClientBO.setStreetNumber("XXXX");
            getViewClientBO.setLotNumber("XXXX");
            getViewClientBO.setStreetName("XXXX");
            
            getViewClientBO.setStreetTypeCode("XXXX");
            getViewClientBO.setStreetSuffixCode("XXXX");
            getViewClientBO.setIndigenousStatus(1);
            getViewClientBO.setVeteranAdfStatus("XXXX");
            
            getViewClientBO.setIhi(ihi);
            getViewClientBO.setViewType(viewType);
            getViewClientBO.setConfidentialityCode(healthRecordExtForm.getConfidentiality());
            getViewClientBO.setToDate(healthRecordExtForm.getToDate());
            getViewClientBO.setFromDate(healthRecordExtForm.getFromDate());
            return getViewClientBO; 
    }

    /**
     *
     * @param responseBytes
     * @param viewType
     * @param ihi
     */
    private boolean performStylesheetApplying(byte[] responseBytes, String viewType, String ihi) {
        LOG.debug("inside performStylesheetApplying....");
        boolean stylesheetReturnStatus = false;
        String fileSeperator = File.separator;
        Date date = new Date();
        String inputFileLocation = "";
        String xslFilePath = "";
        String fileName = "";
        //ddMMyyyyhhmmss
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd_hh_mm_ss");
        String currentDate = ft.format(date);
        fileName = viewType + "_" + ihi + "_" + currentDate;
        fileUtil.createNewDirectory(HealthRecordExtractionConstants.OUTPUT_FILE_LOCATION_HEALTH_RECORD_EXTRACTION, ihi);
        inputFileLocation =
            HealthRecordExtractionConstants.INPUT_FILE_LOCATION_HEALTH_RECORD_EXTRACTION + fileName + ".xml";
        String outputFileLocation =
            HealthRecordExtractionConstants.OUTPUT_FILE_LOCATION_HEALTH_RECORD_EXTRACTION + ihi + fileSeperator +
            fileName + ".html";
        xslFilePath = getStyleSheetLocation(viewType);


        try {
            fileUtil.bytesToFIleConverter(responseBytes, inputFileLocation);
            stylesheetReturnStatus = styleSheetUtil.applyStyleSheet(inputFileLocation, xslFilePath, outputFileLocation);
        } catch (Exception e) {
            LOG.debug("exception ::", e);
        } finally {
            LOG.debug("deleting file::::" + inputFileLocation);
            fileUtil.deleteFileFromLocal(inputFileLocation);
        }
        LOG.debug("Leaving performStylesheetApplying....");
        return stylesheetReturnStatus;
    }

    /**
     *
     * @param viewType
     * @return
     */
    private String getStyleSheetLocation(String viewType) {
        String xslFilePath = "";
        if (null != viewType && viewType.equalsIgnoreCase(VIEW_TYPE_HRO)) {
            xslFilePath = HealthRecordExtractionConstants.STYLE_SHEET_LOCATION_HRO;
        } else if (null != viewType && viewType.equalsIgnoreCase(VIEW_TYPE_MIV)) {
            xslFilePath = HealthRecordExtractionConstants.STYLE_SHEET_LOCATION_MIV;
        } else if (null != viewType && viewType.equalsIgnoreCase(VIEW_TYPE_NPDR)) {
            xslFilePath = HealthRecordExtractionConstants.STYLE_SHEET_LOCATION_NPDR;
        }
        return xslFilePath;
    }

    /**
     *
     * @param healthRecordExtForm
     * @param errorBO
     */
    private HealthRecordExtForm createErrorList(HealthRecordExtForm healthRecordExtForm,
                                                HealthRecordExtractionErrorBO errorBO) {
        LOG.debug("inside createErrorList..");
        if (null != healthRecordExtForm.getListHealthRecordExtractionErrorBO()) {
            healthRecordExtForm.getListHealthRecordExtractionErrorBO().add(errorBO);
        } else {
            List<HealthRecordExtractionErrorBO> listErrorBO = new ArrayList<HealthRecordExtractionErrorBO>();
            listErrorBO.add(errorBO);
            healthRecordExtForm.setListHealthRecordExtractionErrorBO(listErrorBO);
        }

        LOG.debug("Leaving createErrorList..");
        return healthRecordExtForm;
    }
    
    private AuditRecordBO getAuditRecordBO(HealthRecordExtForm healthRecordExtForm, String ihi) {
            AuditRecordBO auditRecordBO = new AuditRecordBO();
            HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            String userId = req.getUserPrincipal().getName();
            //need to check
            auditRecordBO.setUserID(userId);
            //need to check
            auditRecordBO.setUsername("PCEHR_SYSTEM_OPERATOR");
            auditRecordBO.setIhi(ihi);


            auditRecordBO.setVendor("NIO");
            auditRecordBO.setProductName("OPS Tool");
            auditRecordBO.setProdoctVersion(EndPointsConstants.PRODUCT_VERSION);
            auditRecordBO.setPlatForm("Jump Host");

            auditRecordBO.setTransactionStatus("COMPLETED");

            auditRecordBO.setBusinessEvent("ViewRetrieval");
            auditRecordBO.setComponentSource("NIO");

            auditRecordBO.setIhiName(ihi);

            auditRecordBO.setSubject(ihi);
            auditRecordBO.setActionType("Read");

            auditRecordBO.setSubjectType("IHI");

            auditRecordBO.setOperationPerfomed("ViewRetrieval");
            auditRecordBO.setReason(null);
            auditRecordBO.setAccessConditions("OpenAccess");
            auditRecordBO.setAccessLevel("Self");
            auditRecordBO.setDescription("Transaction completed");
            auditRecordBO.setMessageLogLevel("AUDIT");
            auditRecordBO.setStatus(true);
            auditRecordBO.setStatusCode("PCEHR_SUCCESS");
            auditRecordBO.setSoapMesage("");

            return auditRecordBO;
        }
}
