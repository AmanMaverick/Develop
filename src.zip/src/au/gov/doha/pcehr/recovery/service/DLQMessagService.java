package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.DLQMessageReplayBO;
import au.gov.doha.pcehr.recovery.constants.DLQContstants;
import au.gov.doha.pcehr.recovery.dao.DLQMessageDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.DLQMessageForm;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


/**
 * @author sumanta.kumar.saha
 * This service layer used to get the request from servlet and delegates it to DAOlayer.
 *
 * Version     Authour                 Issue no.             Description                     Change
 * v1       sumanta.kumar.saha           n/a                 Initial version                  n/a
 * v2       Vikash Kumar Singh           NA                  Upgraded to Spring.              Migrated complete class in Spring.
 */

@Service
public class DLQMessagService {
    private static Logger LOG = Logger.getLogger(DLQMessagService.class);
    
    @Autowired
    private DLQMessageDAO dlqMessageReplayDAO;
    
    @Value("${QueueType}") 
    private String queueType;
    
    @Value("${QueueSize}") 
    private String queueSize;
    
    @Value("${DeliveryCount}") 
    private String deliveryCount;
    
    /**
     *Get constants from DLQConfigurationProp.properties file present at -
     * /Operations/Oracle/Middleware/user_projects/domains/Operations_Recovery/Configuration in the server.
     * @param dlqMessageReplayObj
     * @return dlqMessageReplayObj
     */
    public DLQMessageForm getDLQReplayToolPageDetail(DLQMessageForm dlqMessageReplayObj) {
        LOG.info("Entering  getDLQMessageProperties");
        
//        List<String> queueTypeList = stringToList(queueType);
//        List<String> queueSizeList = stringToList(queueSize);
//        List<String> deliveryCountList = stringToList(deliveryCount);
        List<String> queueTypeList = stringToList(DLQContstants.QUEUE_TYPE);
        List<String> queueSizeList = stringToList(DLQContstants.QUEUE_SIZE);
        List<String> deliveryCountList = stringToList(DLQContstants.DELIVERY_COUNT);
        dlqMessageReplayObj.setDeliveryCountList(deliveryCountList);
        dlqMessageReplayObj.setQueueSizeList(queueSizeList);
        dlqMessageReplayObj.setQueueTypeList(queueTypeList);
        
        LOG.info("Leaving getDLQMessageProperties ");
        return dlqMessageReplayObj;
    }
    
    /**
     *
     * @param dlqMessage
     * @return
     * @throws RecoveryServiceException
     */
    public List<DLQMessageForm> searchDLQError(DLQMessageForm dlqMessage) throws RecoveryServiceException {
        LOG.info("entering service method of searchError");
        List<DLQMessageForm> dlqMessageList = new ArrayList<>();
        try {
            dlqMessageList = dlqMessageReplayDAO.getDLQErrorDetail(dlqMessage);
        } catch (RecoveryDAOException e) {
            throw new RecoveryServiceException();
        }
        LOG.info("leaving service method of searchError :: " + dlqMessageList.size());
        return dlqMessageList;
    }
    
    /**
     *
     * @param dlqMessage
     * @return
     * @throws RecoveryServiceException
     */
    public List<DLQMessageForm> performStateChange(DLQMessageForm dlqMessage) throws RecoveryServiceException {
        LOG.info("entering service method of searchError");
        List<DLQMessageForm> dlqStateList =  new ArrayList<>();
        try {
            dlqStateList = dlqMessageReplayDAO.updateDLQMessageStateChange(dlqMessage);
        } catch (RecoveryDAOException e) {
            throw new RecoveryServiceException();
        }
        LOG.info("leaving service method of dlqStateList :: " + dlqStateList.size());
        return dlqStateList;
    }

    /**
     *
     * @param dlqMessageDetail
     * @return
     * @throws RecoveryServiceException
     * @throws RecoveryDAOException
     */
    public List<DLQMessageForm> getMessageDetail(DLQMessageForm dlqMessageDetail)throws RecoveryServiceException,
                                                                                         RecoveryDAOException {
        LOG.debug("here in getMessageDetail in service layer");
        List<DLQMessageForm> dlqMessageDetailList = new ArrayList<>();
        dlqMessageDetailList = dlqMessageReplayDAO.getDLQMessage(dlqMessageDetail);
        return dlqMessageDetailList;
    }
    
    public DLQMessageReplayBO getMessageDBDetail(String integrationId)throws RecoveryServiceException,
                                                                                         RecoveryDAOException {
        DLQMessageReplayBO dlqMessageReplayDetail = new DLQMessageReplayBO();
        dlqMessageReplayDetail = dlqMessageReplayDAO.getDLQMessageDBDetails(integrationId);
        return dlqMessageReplayDetail;
    }
    
    /**
     *
     * @param dlqMessage
     * @return
     * @throws RecoveryServiceException
     */
    public List<DLQMessageForm> processDLQMessageIntegrationID(DLQMessageForm dlqMessage) throws RecoveryServiceException {
        LOG.info("entering service method of IntegrationID");
        List<DLQMessageForm> dlqStateList =  new ArrayList<>();
        try {
            dlqStateList = dlqMessageReplayDAO.updateDLQMessageforIntegrationIdList(dlqMessage);
        } catch (RecoveryDAOException e) {
            throw new RecoveryServiceException();
        }
        LOG.info("leaving service method of IntegrationID :: " + dlqStateList.size());
        return dlqStateList;
    }
    
    /**
     * Method to convert comma seperated string to list
     * @param propertyValue
     * @return
     */
    private List<String> stringToList(String propertyValue) {
        List<String> list = new ArrayList<String>();
        StringTokenizer data = new StringTokenizer(propertyValue, ",");
        while (data.hasMoreTokens()){
            list.add(data.nextElement().toString());
        }
        return list;
    }
}
