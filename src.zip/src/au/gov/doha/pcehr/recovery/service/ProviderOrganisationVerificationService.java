package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.dao.ProviderOrganisationVerificationDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ProviderOrganisationVerificationForm;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProviderOrganisationVerificationService {
  
    private static Logger LOG = Logger.getLogger(ProviderOrganisationVerificationService.class);

    @Autowired
    private ProviderOrganisationVerificationDAO providerOrganisationVerificationDAO;
    
    /**
     * This method is called from the controller after validation is successful.
     * @param ProviderOrganisationVerificationForm
     * @return
     * @throws RecoveryDAOException
     */
    
    public ProviderOrganisationVerificationForm providerOrganisationVerificationServiceMethod(ProviderOrganisationVerificationForm providerOrganisationVerificationForm) throws RecoveryDAOException,
                                                                                                                                                                                RecoveryServiceException {
      LOG.debug("Inside Service Class method");
        try{
            providerOrganisationVerificationForm = providerOrganisationVerificationDAO.fetchProviderOrganisationVerificationList(providerOrganisationVerificationForm);
        }catch (RecoveryDAOException ex) {
              throw ex;   
          }catch(Exception e){
                  LOG.fatal("Exception Occured", e);
                  throw new RecoveryServiceException(e);    
          }
        LOG.debug("Leaving Service Class");  
        return providerOrganisationVerificationForm;
        
    }
  
}
