package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.IdentityBlobDocs;
import au.gov.doha.pcehr.recovery.dao.ARTExtractionDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ARTExtractionForm;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * Service class to perform all ART Extraction task
 * @Author Vikash Kumar Singh, Operations, PCEHR
 * @since 02nd Dec 2014
 * @version Change-x
 */
@Service
public class ARTExtractionService{
    
    @Autowired
    private ARTExtractionDAO artExtractionDAO;
    
    @Autowired
    private FileUtil fileUtil;
    
    private static Logger LOG = Logger.getLogger(ARTExtractionService.class);
    
    /**
     * This method will prompt user to download single file.
     * @param docId
     * @return
     * @throws Exception
     */
    public void getDocumentWithBlob(long docId, HttpServletResponse response)throws RecoveryServiceException,RecoveryDAOException {
        IdentityBlobDocs document = null;
        
        try {
            document = artExtractionDAO.getDocumentWithBlob(docId);
            String fileExtension = fileUtil.getContentType(document.getBlobdocs(),null);
            LOG.debug("fileExtension :: " + fileExtension);
            document.setFileType(fileExtension);
            response.setContentType("application/download");
            response.setHeader("Content-Disposition","attachment;filename=\"" + fileUtil.getFileNameByType(document)+ "\"");
            byte[] imageBytes = document.getBlobdocs();
            response.getOutputStream().write(imageBytes);
        }catch (RecoveryDAOException ex) {
            throw ex;   
        }catch(Exception e){
                LOG.fatal("Exception Occured", e);
                throw new RecoveryServiceException(e);    
        }

        return;
    }
    
    /**
     * This method will bring List of ART Extraction data corresponding to a user Id or document Id
     * @param artExtractionForm
     * @return
     * @throws Exception
     */
    public ARTExtractionForm getARTSearchDoc(ARTExtractionForm artExtractionForm)throws RecoveryServiceException,
                                                                                         RecoveryDAOException {
        List<IdentityBlobDocs> docList = new ArrayList<IdentityBlobDocs>();
        try{
            if (artExtractionForm.getUserId()!=null && artExtractionForm.getUserId().length()>0) {
                //Getting Document for userID
                LOG.debug("Going for getDocumentByUserId" + artExtractionForm.getUserId());
                docList = artExtractionDAO.getDocumentByUserId(Long.parseLong(artExtractionForm.getUserId()));
            } else if ( artExtractionForm.getBlobDocId()!=null && artExtractionForm.getBlobDocId().length()>0) {
                //Getting Document using Identity Blob Document Id
                long blogDocId = Long.parseLong(artExtractionForm.getBlobDocId());
                docList = artExtractionDAO.getDocumentById(blogDocId);
            }
            artExtractionForm.setDocList(docList);
        } catch (RecoveryDAOException ex) {
            throw ex;   
        }catch(Exception e){
                LOG.fatal("Exception Occured", e);
                throw new RecoveryServiceException(e);    
        }
        return artExtractionForm;
    }
    
    /**
     *This method will create a zip file with all the files inside and prompt user to save that zip file
     * @param artExtractionForm
     * @param response
     * @throws Exception
     */
    public void getZippedDocument(ARTExtractionForm artExtractionForm, HttpServletResponse response)throws RecoveryServiceException,
                                                                                         RecoveryDAOException {
        try {
            
            
            Set<File> fileList = new HashSet<File>();
            
            for (int i = 0; i < artExtractionForm.getDocumentId().size() ; i++) {
                String documentId =  artExtractionForm.getDocumentId().get(i);
                File file = getBlobFile(new Long(documentId));
                if(file!= null ){
                 fileList.add(file);
                }
            }
            fileUtil.writeZipResponse(response, new ArrayList<File>(fileList));
            
        }  catch (RecoveryDAOException ex) {
            throw ex;   
        }catch(Exception e){
            LOG.fatal("Exception Occured", e);
            throw new RecoveryServiceException(e);    
        }
    }
    /**
     * This Method will bring the data from the data base corresponding to a document Id and 
     * using java.sql.Blob type it will return file
     * @param docId
     * @return File
     * @throws Exception
     */
    public File getBlobFile(long docId)throws  RecoveryServiceException, RecoveryDAOException {
        IdentityBlobDocs document = null;
        File file = null;
        try {
            document = artExtractionDAO.getDocumentWithBlob(docId);
            String fileType = fileUtil.getContentType(document.getBlobdocs(),null);
            document.setFileType(fileType);
            if(document!=null){
               file = fileUtil.getBytesFile( document);
            }
            
        } catch (RecoveryDAOException ex) {
            throw ex;   
        }catch(Exception e){
            LOG.fatal("Exception Occured", e);
            throw new RecoveryServiceException(e);    
        }

        return file;
    }
    
    /**
     * This method will first get all the document id from the file uploaded 
     * and then using those id to fetch the document detail for search result
     * @param artExtraction
     * @return
     * @throws Exception
     */
    public ARTExtractionForm getBulkSearchDocumentList(ARTExtractionForm artExtraction)throws Exception{
        List<IdentityBlobDocs> documentList = new ArrayList<IdentityBlobDocs>();
        
        try{
            List<String> userIdList = getUserIdList(artExtraction);
            for(int i = 0; i < userIdList.size(); i++){
                List<IdentityBlobDocs> document = new ArrayList<IdentityBlobDocs>();
                document = artExtractionDAO.getDocumentByUserId(Long.parseLong(userIdList.get(i)));
                if(document.size() > 0 && document.get(0) != null)
                documentList.add(document.get(0));
            }
            artExtraction.setDocList(documentList);
        }catch(Exception e){
            throw e;
        }        
        return artExtraction;
    }
    
    /**
     *This method is to fetch the list of document ids
     * @param artExtractionBO
     * @return
     * @throws RecoveryServiceException
     */
    private List<String> getUserIdList(ARTExtractionForm artExtractionBO) throws RecoveryServiceException{
        Set<String> documentIdLst = new HashSet<String>();
        String csvSplitBy = ",";
        String[] ihi = null;
        InputStreamReader inStreamReader = null;
        BufferedReader bReader = null;
        try {
            inStreamReader = new InputStreamReader(artExtractionBO.getFile().getInputStream());
             bReader = new BufferedReader(inStreamReader);
            for(String line=bReader.readLine(); line!=null; line=bReader.readLine()) {
                if(line != null && !line.equals(""))
                    ihi = line.split(csvSplitBy);
                    documentIdLst.addAll(Arrays.asList(ihi)); 
            }
        } catch (IOException e) {
            throw new RecoveryServiceException(e);
        }finally{
            try{
                bReader.close();
                inStreamReader.close();
            }catch(Exception e){
                LOG.debug("Exception occured while colosing the resources..");
            }
        }
        return new ArrayList<String>(documentIdLst);
    }

}
