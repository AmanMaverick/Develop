package au.gov.doha.pcehr.recovery.service;

import au.gov.doha.pcehr.recovery.bo.MobileVendorApplicationsClientBO;
import au.gov.doha.pcehr.recovery.form.MobileApplicationToolForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.wsclient.MobileVendorApplicationDetailsWsClient;

import au.net.electronichealth.ns.pcehr.xsd.interfaces.managevendorapplicationdetails._1.ManageVendorApplicationDetailsResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.text.ParseException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MobileApplicationToolService {
    public MobileApplicationToolService() {
        super();
    }
    private static Logger LOG = Logger.getLogger(MobileApplicationToolService.class);
    private static final String DATE_FORMAT= "dd/MM/yyyy";
    @Autowired
    MobileVendorApplicationDetailsWsClient mobileVendorApplicationDetailsWsClient;
    @Autowired
    DateTimeUtil dateTimeUtil;
  
    /**
     *
     * @return
     */
    public Map<String, String> retrieveApiListfromProps() {
        Map<String, String> apiMap = new HashMap<String, String>();
        Properties myProp = new Properties();
            String configFileLocation1 = null;
            configFileLocation1 = System.getProperty("user.dir") + File.separator+"Configuration"+File.separator+"MobileEnablementAPI.properties";
        FileInputStream fis=null;
        try {
            fis=new FileInputStream(configFileLocation1);
            myProp.load(fis);
            for(Object keySet:myProp.keySet()){
                String key=(String)keySet;
                apiMap.put(key,myProp.getProperty(key));
            }
            LOG.debug("Values.."+apiMap);
        } catch (FileNotFoundException e) {
            LOG.fatal("Exception occred",e);
            
        } catch (IOException e) {
            LOG.fatal("Exception occred",e);
        }finally{
            try {
                fis.close();
            } catch (IOException e) {
            }
        }
        
        return apiMap;
    }
    /**
     *This method is used to get the list of application
     * @param form
     * @return
     */
    
    
    public Map<String, String> retrieveApplciatonList() {
        LOG.debug("inside retrieveApplciatonList ..");

        Map<String, String> managedAppDetailsMap = mobileVendorApplicationDetailsWsClient.getApplicationList();

        LOG.debug("Leaving retrieveApplciatonList ..");
        return managedAppDetailsMap;
    }
/**
     *
     * @param appId
     * @param appDetails
     * @return
     */
    public List<String> retrieveApplciatonDetails(String appId, String appDetails) {
        LOG.debug("inside retrieveApplciatonDetails ..");
       List<String> applicationDetailsList=new ArrayList<String>();
        String appDetailsVals[] = null;
        if (null != appDetails && appDetails.length() > 0) {
            appDetailsVals = appDetails.split("~");
        }
        try {
            ManageVendorApplicationDetailsResponse response =
                mobileVendorApplicationDetailsWsClient.manageVendorApplicationDetails(createMobileVendorApplicationsClientBO(appId,
                                                                                                                             appDetailsVals));
            
            if(response!=null){
                applicationDetailsList.add(response.getApplicationID());
                applicationDetailsList.add(response.getGroupID().toString());
                applicationDetailsList.add(response.getVendorName());
                applicationDetailsList.add(response.getApplicationName());
                applicationDetailsList.add(response.getAlternateName());
                applicationDetailsList.add(response.getVersion());
                applicationDetailsList.add(response.getStatus());
                applicationDetailsList.add(response.getAuthCodeCallbackURL());
                applicationDetailsList.add(response.getEventNotificationCallbackURL());
                applicationDetailsList.add(response.getIntent());
                applicationDetailsList.add(response.getOS());
                String submissionDate=dateTimeUtil.getXMLGregorianDateToSpecificDateFormat(response.getSubmissionDate(), DATE_FORMAT);
                applicationDetailsList.add(submissionDate);
                applicationDetailsList.add(response.getIPRange());
                
                applicationDetailsList.add(response.getPrimaryFullName());
                applicationDetailsList.add(response.getPrimaryPhone());
                applicationDetailsList.add(response.getPrimaryMobile());
                applicationDetailsList.add(response.getPrimaryEmail());
                applicationDetailsList.add(response.getPrimaryBusinessAddress());
                applicationDetailsList.add(response.getPrimarySuburb());
                applicationDetailsList.add(response.getPrimaryPostcode());
                applicationDetailsList.add(response.getPrimaryState());
                
                applicationDetailsList.add(response.getSecondaryFullName());
                applicationDetailsList.add(response.getSecondaryPhone());
                applicationDetailsList.add(response.getSecondaryMobile());
                applicationDetailsList.add(response.getSecondaryEmail());
                applicationDetailsList.add(response.getSecondaryBusinessAddress());
                applicationDetailsList.add(response.getSecondarySuburb());
                applicationDetailsList.add(response.getSecondaryPostcode());
                applicationDetailsList.add(response.getSecondaryState());
                applicationDetailsList.add(response.getInteractionModel().toString());
                List<String> apiList=response.getMobileAPIList().getAPIID();
                for(int i=0;i<apiList.size();i++){
                    applicationDetailsList.add(apiList.get(i));
                }
               
                LOG.debug("pos cxode sec:::"+response.getMobileAPIList().getAPIID().toString());
                
            }
        
        } catch (Exception e) {
            LOG.fatal("Exception e" + e);
        }
        LOG.debug("Leaving retrieveApplciatonDetails ..");

           return applicationDetailsList;
    }

    /**
     *
     * @param form
     * @return
     */
    public MobileApplicationToolForm registerApplication(MobileApplicationToolForm form) {
        try {
            ManageVendorApplicationDetailsResponse response =mobileVendorApplicationDetailsWsClient.manageVendorApplicationDetails(createMobileVendorApplicationsClientBO(form,
                                                                                                                   mobileVendorApplicationDetailsWsClient.ACTION_REGISTER));
            form.setSoapResponseCode((response.getResponseStatus().getCode()));  
            form.setSoapResponseDescription((response.getResponseStatus().getDescription()));  
        } catch (au.net.electronichealth.ns.pcehr.svc.intmanagevendorapplicationdetails._1.StandardErrorMsg e) {
            LOG.fatal("Exception e::" + e.getFaultInfo().getErrorCode());
            form.setSoapResponseCode((e.getFaultInfo().getErrorCode().value()));  
            form.setSoapResponseDescription((e.getFaultInfo().getMessage())); 
        }
        return form;
    }

    /**
     *
     * @param form
     * @return
     */
    public MobileApplicationToolForm updateApplication(MobileApplicationToolForm form) {

        try {
            ManageVendorApplicationDetailsResponse response=mobileVendorApplicationDetailsWsClient.manageVendorApplicationDetails(createMobileVendorApplicationsClientBO(form,
                                                                                                                         mobileVendorApplicationDetailsWsClient.ACTION_UPDATE));
            
            form.setSoapResponseCode((response.getResponseStatus().getCode()));  
            form.setSoapResponseDescription((response.getResponseStatus().getDescription()));  
        } catch (au.net.electronichealth.ns.pcehr.svc.intmanagevendorapplicationdetails._1.StandardErrorMsg e) {
            LOG.fatal("Exception e::" + e);
            form.setSoapResponseCode((e.getFaultInfo().getErrorCode().value()));  
            form.setSoapResponseDescription((e.getFaultInfo().getMessage()));
        }
        return form;
    }

    /**
     *
     * @param form
     * @return
     */
    private MobileVendorApplicationsClientBO createMobileVendorApplicationsClientBO(MobileApplicationToolForm form,
                                                                                    String action) {
        LOG.debug("Enetring createMobileVendorApplicationsClientBO ..");
        LOG.debug("form.getGroupID()..."+form.getGroupID());
        LOG.debug("form.getApplication()..."+form.getApplication());
        LOG.debug("form.post cide sec()..."+form.getPostcodeSec());
          LOG.debug("...."+form.getEmailSec());
        MobileVendorApplicationsClientBO clientBO = new MobileVendorApplicationsClientBO();

        if (action.equals(mobileVendorApplicationDetailsWsClient.ACTION_REGISTER) || (action.equals(mobileVendorApplicationDetailsWsClient.ACTION_UPDATE) && "NO".equals(form.getIntMajor())))
            clientBO.setAction(mobileVendorApplicationDetailsWsClient.ACTION_REGISTER);
        else if (action.equals(mobileVendorApplicationDetailsWsClient.ACTION_UPDATE))
            clientBO.setAction(mobileVendorApplicationDetailsWsClient.ACTION_UPDATE);
        clientBO.setAppName(form.getAppName());
        clientBO.setIntent(form.getIntent());
        clientBO.setAlternateName(form.getAlternateName());
        clientBO.setApplicationId(form.getApplication());
        clientBO.setVersion(form.getVersion());
        clientBO.setVendorName(form.getVendorName());
        clientBO.setBusinessAddress(form.getBusinessAddress());
        clientBO.setCallbackURL(form.getCallbackURL());
        clientBO.setEmail(form.getEmail());
        clientBO.setEmailSec(form.getEmailSec());
        clientBO.setEventNotificationCallbackURL(form.getCallbackURLNoti());
        clientBO.setFullName(form.getFullName());
        clientBO.setFullNameSec(form.getFullNameSec());
        clientBO.setGroupID(form.getGroupID());
        clientBO.setIntModel(form.getIntModel());
        clientBO.setMobile(form.getMobile());
        clientBO.setMobileSec(form.getMobileSec());
        clientBO.setOs(form.getOs());
        clientBO.setPhone(form.getPhone());
        clientBO.setPhoneSec(form.getPhoneSec());
        clientBO.setPostcode(form.getPostcode());
        clientBO.setState(form.getState());
        clientBO.setStateSec(form.getStateSec());
        clientBO.setSuburb(form.getSuburb());
        clientBO.setSuburbSec(form.getSuburbSec());
        clientBO.setBusinessAddressSec(form.getBusinessAddressSec());
        clientBO.setPostcodeSec(form.getPostcodeSec());
        clientBO.setAPIList(form.getApilist());
        clientBO.setApplicationStatus(form.getApplicationStatus());
        clientBO.setIpRange(form.getIpRange());
        clientBO.setIntMajor(form.getIntMajor());
        XMLGregorianCalendar submissionDate =null;
        try {
          
            submissionDate  = dateTimeUtil.getXMLGregorianCalendar(form.getSubmissionDate());
          
        } catch (DatatypeConfigurationException e) {
        } catch (ParseException e) {
        } catch (Exception e) {
        }
        clientBO.setSubmissionDate(submissionDate);
        LOG.debug("Leaving createMobileVendorApplicationsClientBO ..");
        return clientBO;
    }

    /**
     *
     * @param appId
     * @param appDetails
     * @return
     */
    private MobileVendorApplicationsClientBO createMobileVendorApplicationsClientBO(String appId, String appDetails[]) {
        LOG.debug("Enetring createMobileVendorApplicationsClientBO ..");
        MobileVendorApplicationsClientBO clientBO = new MobileVendorApplicationsClientBO();


        clientBO.setAppName((appDetails != null && appDetails.length > 0) ? appDetails[0] : null);
        clientBO.setApplicationId(appId);
        clientBO.setVersion((appDetails != null && appDetails.length > 1) ? appDetails[1] : null);
        clientBO.setVendorName((appDetails != null && appDetails.length > 2) ? appDetails[2] : null);
        clientBO.setAction(mobileVendorApplicationDetailsWsClient.ACTION_APPLICATION);
        LOG.debug("Leaving createMobileVendorApplicationsClientBO ..");
        return clientBO;
    }
}
