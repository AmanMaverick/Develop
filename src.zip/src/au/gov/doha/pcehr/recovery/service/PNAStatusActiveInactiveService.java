package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.AuthoriseClientBO;
import au.gov.doha.pcehr.recovery.bo.PNAStatusActiveInactiveBO;
import au.gov.doha.pcehr.recovery.bo.PNAStatusActiveInactiveClientBO;
import au.gov.doha.pcehr.recovery.bo.ReactivateAuthRepClientResBO;
import au.gov.doha.pcehr.recovery.constants.RecoverConstants;
import au.gov.doha.pcehr.recovery.dao.PNAStatusActiveInactiveDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.wsclient.PNAPcehrAuthroseClient;
import au.gov.doha.pcehr.recovery.wsclient.PNAStatusActiveInactiveClient;
import au.gov.doha.pcehr.recovery.wsclient.ReactivateAuthRep;

import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord.EventRecord.LogEvent;

import au.pcehr.ws.pna.common.PcehrRecordCommonParameters;
import au.pcehr.ws.pna.common.RecordStatus;
import au.pcehr.ws.pna.pd.SetPCEHRStatusFunctionParameters;
import au.pcehr.ws.pna.pd.SetPCEHRStatusParameterList;

import java.math.BigInteger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PNAStatusActiveInactiveService {
    private static Logger LOG = Logger.getLogger(PNAStatusActiveInactiveService.class);

    @Autowired
    private ReactivateAuthRep reactivateAuthRepClient;

    @Autowired
    private PNAStatusActiveInactiveClient pnaStatusActiveInactiveClient;

    @Autowired
    private PNAPcehrAuthroseClient pnaPcehrAuthroseClient;

    @Autowired
    private InsertAuditRecordService audit;
    @Autowired
    private PNAStatusActiveInactiveDAO pnaStatusActiveInactiveDAO;

    public PNAStatusActiveInactiveDAO getPNAStatusActiveInactiveDAOObject() throws RecoveryServiceException {
        return pnaStatusActiveInactiveDAO;
    }

    /**
     * Validates if IHI exist
     * Validated is PNA as permitted or not and then perform the rest operation.
     * @Vikash/Shailendra
     * @return PNAStatusActiveInactiveBO
     * @throws RecoveryServiceException
     */
    public PNAStatusActiveInactiveBO getService(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) throws RecoveryServiceException {

        try {
            LOG.debug("entering service method");
            PNAStatusActiveInactiveDAO pNAStatusActiveInactiveDAO = getPNAStatusActiveInactiveDAOObject();
            pNAStatusActiveInactiveBO = pNAStatusActiveInactiveDAO.fetchPcehr_Record(pNAStatusActiveInactiveBO);


            pNAStatusActiveInactiveBO = validate(pNAStatusActiveInactiveBO);

            if (pNAStatusActiveInactiveBO.isValidationStatus()) {
                if (pNAStatusActiveInactiveBO.isValidationStatus() &&
                    "ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                    "self".equals(pNAStatusActiveInactiveBO.getRelationshipType()) &&
                    "CleanRecord".equals(pNAStatusActiveInactiveBO.getIsCleanRecord())) {
                    pNAStatusActiveInactiveBO = activateInactivateClientCall(pNAStatusActiveInactiveBO);
                } else if (pNAStatusActiveInactiveBO.isValidationStatus() &&
                           "ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                           "Authorized Representative Relation".equals(pNAStatusActiveInactiveBO.getRelationshipType()) &&
                           "CleanRecord".equals(pNAStatusActiveInactiveBO.getIsCleanRecord())) {
                    pNAStatusActiveInactiveBO = activateInactivateClientCall(pNAStatusActiveInactiveBO);
                    pNAStatusActiveInactiveBO = reactivateAuthRepClientCall(pNAStatusActiveInactiveBO);

                } else if (pNAStatusActiveInactiveBO.isValidationStatus()) {
                    pNAStatusActiveInactiveBO = activateInactivateClientCall(pNAStatusActiveInactiveBO);
                    LOG.debug("pNAStatusActiveInactiveBO.getRelationshipType()" +
                              pNAStatusActiveInactiveBO.getRelationshipType());
                    if ("Authorized Representative Relation".equals(pNAStatusActiveInactiveBO.getRelationshipType())) {
                        pNAStatusActiveInactiveBO = reactivateAuthRepClientCall(pNAStatusActiveInactiveBO);
                    }
                }
            }
            if (!pNAStatusActiveInactiveBO.isValidationStatus()) {
                pNAStatusActiveInactiveBO.setAlertMessage(pNAStatusActiveInactiveBO.getAlertMessage());
            } else {
                pNAStatusActiveInactiveBO.setAlertMessage(pNAStatusActiveInactiveBO.getWsStatusMessage());
            }

        } catch (RecoveryDAOException e) {
            throw new RecoveryServiceException();
        } catch (Exception e) {
            LOG.fatal("Exceptin occured", e);
            throw new RecoveryServiceException();
        }
        return pNAStatusActiveInactiveBO;
    }


    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     */
    private PNAStatusActiveInactiveBO checkPNAPcehrAuthrose(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) {
        AuthoriseClientBO authoriseClientBO = new AuthoriseClientBO();
        authoriseClientBO.setIhi(pNAStatusActiveInactiveBO.getIhi());
        LOG.debug("inside checkPNAPcehrAuthorse...");
        pnaPcehrAuthroseClient.pnaPcehrAuthorise(authoriseClientBO);
        pnaPcehrAuthroseClient.getOESFunctionalAuthoriseResponse().getResultStatus().getStatusCode();
        LOG.debug("pnaPcehrAuthroseClient.getOESFunctionalAuthoriseResponse().getResultStatus().getStatusCode().." +
                  pnaPcehrAuthroseClient.getOESFunctionalAuthoriseResponse().getResultStatus().getStatusCode());
        if ("109".equals(pnaPcehrAuthroseClient.getOESFunctionalAuthoriseResponse().getResultStatus().getStatusCode())) {
            pNAStatusActiveInactiveBO.setValidationStatus(false);
            pNAStatusActiveInactiveBO.setAlertMessage(pnaPcehrAuthroseClient.getOESFunctionalAuthoriseResponse().getResultStatus().getStatusDescription());
        } else {
            pNAStatusActiveInactiveBO.setValidationStatus(true);
        }
        LOG.debug("Validation status message checkPNAPcehrAuthrose" + pNAStatusActiveInactiveBO.isValidationStatus());
        return pNAStatusActiveInactiveBO;
    }

    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     */
    private PNAStatusActiveInactiveBO validate(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) throws RecoveryServiceException,
                                                                                                           RecoveryDAOException {
        pNAStatusActiveInactiveBO.setValidationStatus(false);
        PNAStatusActiveInactiveDAO dao = getPNAStatusActiveInactiveDAOObject();
        pNAStatusActiveInactiveBO = checkPNAPcehrAuthrose(pNAStatusActiveInactiveBO);
        if (!pNAStatusActiveInactiveBO.isValidationStatus()) {
            return pNAStatusActiveInactiveBO;
        }
        //Validate IHI
        boolean isIHIValid = dao.validateIHI(pNAStatusActiveInactiveBO.getIhi());
        if (!isIHIValid) {
            pNAStatusActiveInactiveBO.setValidationStatus(false);
            pNAStatusActiveInactiveBO.setAlertMessage("Invalid IHI.");
            return pNAStatusActiveInactiveBO;
        }
        if (pNAStatusActiveInactiveBO.getRepresentativeIHI() != null &&
            pNAStatusActiveInactiveBO.getRepresentativeIHI().length() > 0) {
            isIHIValid = dao.validateRepresentativeIHI(pNAStatusActiveInactiveBO.getRepresentativeIHI());
            if (!isIHIValid) {
                pNAStatusActiveInactiveBO.setValidationStatus(false);
                pNAStatusActiveInactiveBO.setAlertMessage("Invalid Representative IHI.");
                return pNAStatusActiveInactiveBO;
            }
        }
        if ("ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
            "CleanRecord".equals(pNAStatusActiveInactiveBO.getIsCleanRecord())) {
            LOG.debug("Validation status ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
            if ("ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                "3".equals(pNAStatusActiveInactiveBO.getRecordStatus())) {
                pNAStatusActiveInactiveBO.setValidationStatus(false);
                pNAStatusActiveInactiveBO.setAlertMessage("Record status is already Suspended , operation cannot be performed");
                LOG.debug("1Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
            } else if ("ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                       "0".equals(pNAStatusActiveInactiveBO.getRecordStatus())) {
                pNAStatusActiveInactiveBO.setAlertMessage("Record status is already Active , operation cannot be performed");
                pNAStatusActiveInactiveBO.setValidationStatus(false);
                LOG.debug("2Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
            } else {
                pNAStatusActiveInactiveBO.setValidationStatus(true);
                LOG.debug("3Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
            }
            return pNAStatusActiveInactiveBO;
        }


        if ("ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
            "0".equals(pNAStatusActiveInactiveBO.getRecordStatus())) {
            pNAStatusActiveInactiveBO.setAlertMessage("Record status is already Active , operation cannot be performed");
            pNAStatusActiveInactiveBO.setValidationStatus(false);
            LOG.debug("4Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
        } else if ("ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                   "1".equals(pNAStatusActiveInactiveBO.getRecordStatus()) &&
                   !"1".equals(pNAStatusActiveInactiveBO.getRecordDeactivationReason()) &&
                   !"6".equals(pNAStatusActiveInactiveBO.getRecordDeactivationReason())) {
            pNAStatusActiveInactiveBO.setAlertMessage("Record Re-activation reason is invalid, Operation cannot be performed");
            pNAStatusActiveInactiveBO.setValidationStatus(false);
            LOG.debug("5Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
        } else if ("IN_ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                   "1".equals(pNAStatusActiveInactiveBO.getRecordStatus())) {
            pNAStatusActiveInactiveBO.setAlertMessage("Record status is already In-Active , operation cannot be performed ");
            pNAStatusActiveInactiveBO.setValidationStatus(false);
            LOG.debug("6Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
        } else if ("IN_ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                   "2".equals(pNAStatusActiveInactiveBO.getRecordStatus())) {
            pNAStatusActiveInactiveBO.setAlertMessage("Record status is already Suspended , Inactive operation cannot be performed by NIO Tool ");
            pNAStatusActiveInactiveBO.setValidationStatus(false);
        } else if ("SUSPENDED".equals(pNAStatusActiveInactiveBO.getStatus()) &&
                   ("2".equals(pNAStatusActiveInactiveBO.getRecordStatus()) ||
                    "3".equals(pNAStatusActiveInactiveBO.getRecordStatus()))) {
            pNAStatusActiveInactiveBO.setAlertMessage("Record status is already Suspended , operation cannot be performed");
            pNAStatusActiveInactiveBO.setValidationStatus(false);
            LOG.debug("7Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
        } else {
            pNAStatusActiveInactiveBO.setValidationStatus(true);
            LOG.debug("8Validation staus ACTIVE" + pNAStatusActiveInactiveBO.isValidationStatus());
        }


        LOG.debug("Validation staus" + pNAStatusActiveInactiveBO.isValidationStatus());
        return pNAStatusActiveInactiveBO;
    }


    /**
     *
     * @return
     */
    private AuditRecordBO getAuditRecordBO(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) {
        LOG.debug("Setting Audit Record BO..");
        List errorCodeList = new ArrayList();
        AuditRecordBO auditBO = new AuditRecordBO();
        LOG.debug("in audit reason::....." + pNAStatusActiveInactiveBO.getReason());
        auditBO.setUserID(pNAStatusActiveInactiveBO.getUserID());

        auditBO.setSystemOperatorName(pNAStatusActiveInactiveBO.getOperatorName());
        auditBO.setUsername(pNAStatusActiveInactiveBO.getChangeBy());
        auditBO.setUserID(pNAStatusActiveInactiveBO.getUserID());
        auditBO.setIhi(pNAStatusActiveInactiveBO.getIhi());
        auditBO.setIhiName("NA");
        auditBO.setSubjectType("IHI");
        auditBO.setVendor("NIO");
        auditBO.setComponentSource("NIO");
        auditBO.setProductName("OPS Tool");

        auditBO.setProdoctVersion("1.1");
        auditBO.setPlatForm("Jump Host");

        if ("ACTIVE".equals(pNAStatusActiveInactiveBO.getStatus()) &&
            "CleanRecord".equals(pNAStatusActiveInactiveBO.getIsCleanRecord())) {
            auditBO.setOperationPerfomed("reactivatePCEHR");
            auditBO.setActionType("Create");
        } else if (pNAStatusActiveInactiveBO.getStatus().equals("ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("1")) {
            auditBO.setOperationPerfomed("reactivatePCEHR");
            auditBO.setReason(null);
            if (pNAStatusActiveInactiveBO.getRecordDeactivationReason().equals("2")) {
                auditBO.setActionType("Delete");
            } else {
                auditBO.setActionType("Create");
            }
            auditBO.setStatusPriorDeactivation("Deceased");
        } else if (pNAStatusActiveInactiveBO.getStatus().equals("ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("1")) {
            auditBO.setOperationPerfomed("restoreRecord");
            auditBO.setActionType("Create");
            auditBO.setReason(null);
        } else if (pNAStatusActiveInactiveBO.getStatus().equals("ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("2")) {
            auditBO.setOperationPerfomed("restoreRecord");
            auditBO.setActionType("Create");
            auditBO.setReason(null);
        } else if (pNAStatusActiveInactiveBO.getStatus().equals("SUSPENDED") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("0")) {
            LOG.debug("here in loppp...................................");
            auditBO.setOperationPerfomed("suspendRecord");
            auditBO.setStatusPriorDeactivation("Active");
            auditBO.setActionType("Delete");
            LOG.debug("reason::....." + pNAStatusActiveInactiveBO.getReason());
            if (pNAStatusActiveInactiveBO.getSuspensionReason().equals("Record under Investigation")) {
                LOG.debug("here in loppp...................................");
                auditBO.setReason("NoOwnershipOfPCEHR");

            }
        } else if (pNAStatusActiveInactiveBO.getStatus().equals("SUSPENDED") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("1")) {
            auditBO.setOperationPerfomed("lockRecord");
            auditBO.setActionType("Delete");
            if (pNAStatusActiveInactiveBO.getSuspensionReason().equals("Record under Investigation"))
                auditBO.setReason("NoOwnershipOfPCEHR");
        } else if (pNAStatusActiveInactiveBO.getStatus().equals("IN_ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("0")) {
            auditBO.setOperationPerfomed("deactivatePCEHR");
            auditBO.setStatusPriorDeactivation("Active");
            if (pNAStatusActiveInactiveBO.getReason().equals(RecoverConstants.PNA_STATUS_6)) {
                auditBO.setReason("IHINotActive");
                auditBO.setActionType("Delete");
            } else if (pNAStatusActiveInactiveBO.getReason().equals("Cancelled by System Operator")) {
                auditBO.setReason("IHINotActive");
                auditBO.setActionType("Delete");
            } else {
                auditBO.setReason(pNAStatusActiveInactiveBO.getReason());
                auditBO.setActionType("Create");
            }
        } else if (pNAStatusActiveInactiveBO.getStatus().equals("IN_ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("3")) {
            auditBO.setOperationPerfomed("unlockRecord");
            if (pNAStatusActiveInactiveBO.getReason().equals(RecoverConstants.PNA_STATUS_6)) {
                auditBO.setReason("IHINotActive");
                auditBO.setActionType("Update");
            } else if (pNAStatusActiveInactiveBO.getReason().equals("Cancelled by System Operator")) {
                auditBO.setReason("IHINotActive");
                auditBO.setActionType("Update");
            } else {
                auditBO.setActionType("Update");
                auditBO.setReason(pNAStatusActiveInactiveBO.getReason());
            }
        }
        LOG.debug("Status...." + pNAStatusActiveInactiveBO.getStatus());
        LOG.debug("Record Status...." + pNAStatusActiveInactiveBO.getRecordStatus());

        if (pNAStatusActiveInactiveBO.getStatus().equals("ACTIVE") &&
            pNAStatusActiveInactiveBO.getRecordStatus().equals("1")) {
            auditBO.setBusinessEvent("reactivatePCEHR");

        } else if (pNAStatusActiveInactiveBO.getStatus().equals("ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("2")) {
            auditBO.setBusinessEvent("restoreRecord");

        } else if (pNAStatusActiveInactiveBO.getStatus().equals("SUSPENDED") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("0")) {
            auditBO.setBusinessEvent("suspendRecord");

        } else if (pNAStatusActiveInactiveBO.getStatus().equals("SUSPENDED") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("1")) {
            auditBO.setBusinessEvent("lockRecord");

        } else if (pNAStatusActiveInactiveBO.getStatus().equals("IN_ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("0")) {
            auditBO.setBusinessEvent("deactivatePCEHR");

        } else if (pNAStatusActiveInactiveBO.getStatus().equals("IN_ACTIVE") &&
                   pNAStatusActiveInactiveBO.getRecordStatus().equals("3")) {
            auditBO.setBusinessEvent("unlockRecord");

        }
        LOG.info("val:::::" + auditBO.isStatus());
        return auditBO;
    }

    /**
     *Representing IHI client Call.
     * @param pNAStatusActiveInactiveBO
     * @return
     * @throws RecoveryServiceException
     */
    private PNAStatusActiveInactiveBO reactivateAuthRepClientCall(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) throws RecoveryServiceException {

        try {
            PNAStatusActiveInactiveDAO pNAStatusActiveInactiveDAO = getPNAStatusActiveInactiveDAOObject();
            pNAStatusActiveInactiveBO =
                pNAStatusActiveInactiveDAO.fetchReactivateAuthRepData(pNAStatusActiveInactiveBO);
            LOG.debug("Size of the list" + pNAStatusActiveInactiveBO.getReactivateAuthRepBO().size());
            for (int i = 0; i < pNAStatusActiveInactiveBO.getReactivateAuthRepBO().size(); i++) {
                LOG.debug("Calling the WS");
                ReactivateAuthRepClientResBO reactivateAuthRepClientResBO = reactivateAuthRepClient.create(pNAStatusActiveInactiveBO.getReactivateAuthRepBO().get(i));
                pNAStatusActiveInactiveBO.setSoapMessage(reactivateAuthRepClientResBO.getSoapReqRes()+
                                                         "\n Authorise Representative Relation Status : " +
                                                         reactivateAuthRepClientResBO.getApplicationResponse().getStatusDescription());

            }

        } catch (RecoveryServiceException e) {
            throw e;
        } catch (RecoveryDAOException e) {
            throw new RecoveryServiceException(e);
        }
        return pNAStatusActiveInactiveBO;
    }


    /**
     * Main webservice Call
     * @param pNAStatusActiveInactiveBO
     * @return
     */
    private PNAStatusActiveInactiveBO activateInactivateClientCall(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) {
        LOG.debug("entering PNAStatusActiveInactiveBO activateInactivateClientCall");
        LOG.debug("staus val in activateInactivateClientCall for in active or suspend" +
                  pNAStatusActiveInactiveBO.getReason());
        SetPCEHRStatusParameterList pcehrStatusParameterList = new SetPCEHRStatusParameterList();
        List code = Arrays.asList(RecoverConstants.PNA_STATUS_ERROR_CODE);
        pcehrStatusParameterList.setCommonParameters(getPcehrRecordCommonParameters(pNAStatusActiveInactiveBO));
        pcehrStatusParameterList.setFunctionParameters(getSetPCEHRStatusFunctionParameters(pNAStatusActiveInactiveBO));
        
        PNAStatusActiveInactiveClientBO pnaStatusActiveInactiveClientBO = new PNAStatusActiveInactiveClientBO();
        pnaStatusActiveInactiveClientBO.setPcehrStatusParameterList(pcehrStatusParameterList);
        
        
        
        pnaStatusActiveInactiveClientBO = pnaStatusActiveInactiveClient.pnaStatusUpdate(pnaStatusActiveInactiveClientBO);
        
        pNAStatusActiveInactiveBO.setSoapMessage(pnaStatusActiveInactiveClientBO.getSoapReqRes());
        pNAStatusActiveInactiveBO.setWsStatusMessage(pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusDescription());

        //Webservice call for Audit
        AuditRecordBO auditBO = getAuditRecordBO(pNAStatusActiveInactiveBO);


        auditBO.setSubject(pNAStatusActiveInactiveBO.getIhi());

        LogEvent logEvent = new LogEvent();
        LOG.debug("Status Code Value...." +
                  pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusCode());
        auditBO.setTransactionStatus(code.contains(pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusCode().toString()) ?
                                     "FAILED" : "COMPLETED");
        auditBO.setMessageLogLevel(code.contains(pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusCode().toString()) ?
                                   "ERROR" : "AUDIT");
        auditBO.setStatusCode(pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusCode().toString());
        auditBO.setStatus(code.contains(pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusCode().toString()) ?
                          false : true);
        LOG.debug("value chcke:" + pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse());
        auditBO.setDescription(pnaStatusActiveInactiveClientBO.getSetPCEHRStatusResponse().getResultStatus().getStatusDescription());

        auditBO.setSoapMesage(pnaStatusActiveInactiveClientBO.getSoapReqRes());
        auditBO = audit.insertAudit(auditBO);
        LOG.debug("alert Message :: " + auditBO.getAlertMsg());
        pNAStatusActiveInactiveBO.setAlertMessage(auditBO.getAlertMsg());
        LOG.debug("SOAP message after calling webservice" + pNAStatusActiveInactiveBO.getSoapMessage());
        pNAStatusActiveInactiveBO.setSoapMessage(pNAStatusActiveInactiveBO.getSoapMessage() +
                                                 auditBO.getResponseStatusMsg());

        LOG.debug("leaving PNAStatusActiveInactiveBO activateInactivateClientCall" +
                  pNAStatusActiveInactiveBO.getSoapMessage());
        return pNAStatusActiveInactiveBO;
    }


    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     */
    private PcehrRecordCommonParameters getPcehrRecordCommonParameters(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) {
        PcehrRecordCommonParameters parameter = new PcehrRecordCommonParameters();
        LOG.debug("vla" + pNAStatusActiveInactiveBO.getRecordId());
        LOG.debug("pNAStatusActiveInactiveBO.getIhi()" + pNAStatusActiveInactiveBO.getIhi());
        parameter.setIHI(pNAStatusActiveInactiveBO.getIhi());
        parameter.setSourceSystemID("Source System ID");
        parameter.setTransactionID("Transaction ID");
        parameter.setRecordID(new BigInteger(pNAStatusActiveInactiveBO.getRecordId()));
        LOG.debug("values:::::::1111.." + parameter.getRecordID());
        SetPCEHRStatusFunctionParameters pcehrStatusFunctionParameters;
        return parameter;
    }

    /**
     *
     * @param pNAStatusActiveInactiveBO
     * @return
     */
    private SetPCEHRStatusFunctionParameters getSetPCEHRStatusFunctionParameters(PNAStatusActiveInactiveBO pNAStatusActiveInactiveBO) {
        SetPCEHRStatusFunctionParameters setPCEHRStatusFunctionParameters = new SetPCEHRStatusFunctionParameters();
        LOG.debug("checkkk" + pNAStatusActiveInactiveBO.getStatus());
        if (pNAStatusActiveInactiveBO.getStatus().equals("ACTIVE")) {
            setPCEHRStatusFunctionParameters.setStatus(RecordStatus.ACTIVE);
            setPCEHRStatusFunctionParameters.setStatusChangeReason(pNAStatusActiveInactiveBO.getReason());
        } else if ("SUSPENDED".equals(pNAStatusActiveInactiveBO.getStatus())) {
            setPCEHRStatusFunctionParameters.setStatus(RecordStatus.SUSPENDED);
            setPCEHRStatusFunctionParameters.setStatusChangeReason(pNAStatusActiveInactiveBO.getSuspensionReason());
        } else {
            setPCEHRStatusFunctionParameters.setStatus(RecordStatus.IN_ACTIVE);
            setPCEHRStatusFunctionParameters.setStatusChangeReason(pNAStatusActiveInactiveBO.getInactiveReason());
        }

        setPCEHRStatusFunctionParameters.setStatusChangeBy(pNAStatusActiveInactiveBO.getChangeBy());

        LOG.debug("values:::::::" + setPCEHRStatusFunctionParameters.getStatusChangeReason());
        LOG.debug("values:::::::" + setPCEHRStatusFunctionParameters.getStatusChangeBy());
        LOG.debug("values:::::::" + setPCEHRStatusFunctionParameters.getStatus());

        return setPCEHRStatusFunctionParameters;
    }

}
