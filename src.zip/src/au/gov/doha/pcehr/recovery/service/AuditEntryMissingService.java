package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.bo.AuditEntryMissingBO;
import au.gov.doha.pcehr.recovery.bo.AuditRecordBO;
import au.gov.doha.pcehr.recovery.bo.OrganisationDtlBO;
import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;
import au.gov.doha.pcehr.recovery.dao.AuditEntryMissingDAO;
import au.gov.doha.pcehr.recovery.dao.OrganizationDetailsDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.AuditEntryMissingForm;
import au.gov.doha.pcehr.recovery.wsclient.InsertAuditRecordClient;

import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.AccessConditionsType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.AccessedEntityType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ParticipantActionType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ParticipantDetailsType;
import au.net.electronichealth.ns.pcehr.xsd.common.commoncoreelements._1.ResponseStatusType;
import au.net.electronichealth.ns.pcehr.xsd.common.intcommoncoreelements._1.IntPCEHRHeader;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord.EventRecord;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord.EventRecord.AuditEvent;
import au.net.electronichealth.ns.pcehr.xsd.interfaces.insertauditrecord._1.InsertAuditRecord.EventRecord.LogEvent;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pcehr.recovery.LoggingHandler;

/**
 *
 */

@Service
public class AuditEntryMissingService {
    private static Logger LOG = Logger.getLogger(AuditEntryMissingService.class);
    private static String toolType;     

    @Autowired
    private AuditEntryMissingDAO auditEntryMissingDAO;
    
    @Autowired
    private OrganizationDetailsDAO organizationDetailsDAO;
    @Autowired
    InsertAuditRecordClient insertAuditRecordClient;
    
    public AuditEntryMissingForm auditEntry(AuditEntryMissingForm auditEntryMissing, HttpServletResponse response) throws RecoveryServiceException,RecoveryDAOException{
        boolean isUnknownDocExists = false;
        boolean isUnknownAutExists = false;
        boolean isAccOrgExists = false;
        boolean isInheritOrgExists = false;
        try{            
            LOG.info("Entered into the auditEnry service method");
            String documentDetails = getDocIds(auditEntryMissing);
            toolType = auditEntryMissing.getDataFix();
            LOG.info("toolType ::"+toolType);            
            if(toolType.equalsIgnoreCase("OSB")){
                OutputStream outputStream = null;
                try{
                    List<AuditEntryMissingBO> auditEntryList = auditEntryMissingDAO.retrieveIHIDetailsFromRLS(documentDetails);     
                    LOG.info("calling getOutputResult "+auditEntryList.size());
                    String outputResult = getOutputResult(auditEntryList);
                    response.setContentType("text/csv");
                    response.setHeader("Content-disposition", "attachment; filename=\"AuditEntryMissingReport.csv\"");                
                    outputStream = response.getOutputStream();                    
                    outputStream.write(outputResult.getBytes());
                }catch(Exception e){
                    LOG.error("Excetption occured ::",e);
                    throw new RecoveryServiceException(e);
                }finally{
                       outputStream.flush();
                       outputStream.close();   
                }
                             
               
            }else{
                LOG.info("Tootype is RLS not the osb");
                List<OrganisationDtlBO> organizationDetails = organizationDetailsDAO.retrieveIHIDetailsFromRLS(documentDetails);
                LOG.info("Retrived the organization details from retrieveIHIDetailsFromRLS");
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HH:mm:ss").format(Calendar.getInstance().getTime());
                
                File file = new File("DocumentsUploadedbyAccessingORG.csv");
                if (!file.exists()){
                    file.createNewFile();
                }
                FileWriter fw = new FileWriter(file);
                
                File inheritingOrganizationFile = new File("PCEHR.ORGID.LIST.txt");
                FileWriter fileWriter = new FileWriter(inheritingOrganizationFile);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                BufferedWriter writer = new BufferedWriter(fw);
                
                File unknownDocFile = new File("UnknownDocumentId.csv");
                FileWriter unknownIdFw = new FileWriter(unknownDocFile);
                BufferedWriter unDocBufWriter = new BufferedWriter(unknownIdFw);
                
                File unknownAutFile = new File("UnknownAut.csv");
                FileWriter unknownAutFw = new FileWriter(unknownAutFile);
                BufferedWriter unDocAutWriter = new BufferedWriter(unknownAutFw);
                try{
                    for (OrganisationDtlBO organizationDetail : organizationDetails) {
                        LOG.info("we are under for loop");
                        if (null != organizationDetail.getAccessingOrgId() &&
                            null != organizationDetail.getInheritingOrgId()) {
                            if (organizationDetail.getAccessingOrgId().equalsIgnoreCase(organizationDetail.getInheritingOrgId())) {
                                isAccOrgExists = true;
                                writer.write(timeStamp);
                                writer.write(",");
                                writer.write(organizationDetail.getIhi());
                                writer.write(",");
                                writer.write(organizationDetail.getClinicalDocumentId());
                                writer.write(",");
                                writer.write(organizationDetail.getAccessingOrgId().substring(organizationDetail.getAccessingOrgId().lastIndexOf(".") +
                                                                                               1));
                                writer.write(",");
                                writer.newLine();
                            } else {
                                isInheritOrgExists = true;
                                bufferedWriter.write(timeStamp);
                                bufferedWriter.write(",");
                                bufferedWriter.write((organizationDetail.getIhi()));
                                bufferedWriter.write(",");
                                bufferedWriter.write(organizationDetail.getClinicalDocumentId());
                                bufferedWriter.write(",");
                                bufferedWriter.write(organizationDetail.getInheritingOrgId().substring(organizationDetail.getInheritingOrgId().lastIndexOf(".") +
                                                                                                      1));
                                bufferedWriter.write(",");
                                bufferedWriter.newLine();
                            }
                        } else {
                            if (null != organizationDetail.getUnknownDocumentId()) {
                                isUnknownDocExists = true;
                                unDocBufWriter.write(organizationDetail.getUnknownDocumentId());
                                unDocBufWriter.newLine();
                            } else if (null != organizationDetail.getUnknownAuthor()) {
                                isUnknownAutExists = true;
                                unDocAutWriter.write(organizationDetail.getUnknownAuthor());
                                unDocAutWriter.newLine();
                            }
                        }
                    }

                }catch(Exception e){
                    LOG.error("Excetption occured ::",e);
                    throw new RecoveryServiceException(e);
                }finally{
                    
                    try {
                        writer.close();
                        fw.close();
                    
                        bufferedWriter.close();
                        fileWriter.close();
                        unDocBufWriter.close();
                        unknownIdFw.close();
                        unDocAutWriter.close();
                        unknownAutFw.close();
                    } catch (IOException e) {
                        LOG.fatal("Exception Occured while closing resources", e);
                        throw new RecoveryServiceException(e);
                    }
                }
                
                if (isUnknownAutExists) {
                    LOG.debug("Unknon Aut exists");
                    auditEntryMissing.setUnknownAuthor(unknownAutFile.getAbsolutePath());
                }
                if (isUnknownDocExists) {
                    LOG.debug("Unknown Doc id exists");
                    auditEntryMissing.setUnknownDocId(unknownDocFile.getAbsolutePath());
                }
                if (isInheritOrgExists) {
                    LOG.debug("Inheriting Organization exists");
                    auditEntryMissing.setInheritOrganizationDetails(inheritingOrganizationFile.getAbsolutePath());
                }
                if (isAccOrgExists) {
                    LOG.debug("Accessing Organization exists");
                    LOG.info("file.getAbsolutePath:::::"+file.getAbsolutePath());
                    auditEntryMissing.setAccessOrganizationDetails(file.getAbsolutePath());
                }
            }            
        }catch(Exception e){
            LOG.fatal("Excetption occured ::",e);
            throw new RecoveryServiceException(e);
        }
        return auditEntryMissing;
    }
    
    /**
     * This method splits the document details such as IHI, DOCID, INTGID and adds to the list.
     * @param auditEntryMissingForm
     * @return String
     * @throws RecoveryServiceException
     */
    public String getDocIds(AuditEntryMissingForm auditEntryMissingForm) throws RecoveryServiceException{
            InputStreamReader inStreamReader = null;
            BufferedReader bReader = null;
            String[] docId = null;
            String csvSplitBy = ",";
            StringBuffer stringBuffer = new StringBuffer();        
            try {
                inStreamReader = new InputStreamReader(auditEntryMissingForm.getFile().getInputStream());
                bReader = new BufferedReader(inStreamReader);
                for(String line=bReader.readLine(); line!=null; line=bReader.readLine()) {
                    if(line != null && !line.equals("")){
                        docId = line.split(csvSplitBy);     //Splitting comma seperated values
                        for(int i=0; i<docId.length;i++ ){
                            stringBuffer.append(docId[i]);
                            stringBuffer.append("\n");
                        }
                    }
                          
                }
            } catch (Exception e) {
                throw new RecoveryServiceException(e);
            }finally{
                try{
                    bReader.close();
                    inStreamReader.close();
                }catch(Exception e){
                    LOG.debug("Exception occured while colosing the resources..");
                }
            }
            return stringBuffer.toString();
    }
    
    /**
     * Sets following Doc processing messages - 
     *  1. IHI Name not found. , 2. UNKNOWN CLASS CODE, 3. Audit or DLQ Entry Exists, 4. Document Does not exists in RLS, 5. SUCCESS
     * @param auditEntryList
     * @return returnData
     */
    public String getOutputResult(List<AuditEntryMissingBO> auditEntryList) throws RecoveryServiceException {
        LOG.info("Entered into the getOutputResult method");
        StringBuffer returnedData = new StringBuffer();
        AuditRecordBO auditRecordBO = new AuditRecordBO();
        try{
            for (AuditEntryMissingBO auditEntryMissingBO : auditEntryList) {
                
                if(auditEntryMissingBO.isRlsEntryExists() && !auditEntryMissingBO.isAuditEntryExists() && auditEntryMissingBO.isClassCodeExsits() && auditEntryMissingBO.getIhiName() == null){
                    LOG.debug("IHI Name not found for IHI - " + auditEntryMissingBO.getIhi());
                    returnedData.append(auditEntryMissingBO.getDocumentID());
                    returnedData.append(",");
                    returnedData.append("IHI Name not found.");
                    returnedData.append("\n");
                    continue;
                }
                if (auditEntryMissingBO.isRlsEntryExists() && !auditEntryMissingBO.isAuditEntryExists() && auditEntryMissingBO.isClassCodeExsits() ) {
                    //Webservice call for Audit
                    LOG.info("Webservice call for Audit");
                   
                    auditRecordBO = getAuditRecordBO(auditEntryMissingBO);
                }
                returnedData.append(auditEntryMissingBO.getDocumentID());
                returnedData.append(",");
                LOG.info("returnedData ::"+returnedData.toString());
                if (auditEntryMissingBO.isRlsEntryExists() && !auditEntryMissingBO.isAuditEntryExists()) {
                    LOG.info("RLS entry exists and Audit entry not exists");
                    if(!auditEntryMissingBO.isClassCodeExsits()){
                        LOG.debug("class code does not exists.....service");
                        returnedData.append("UNKNOWN CLASS CODE");                        
                    }else{
                        LOG.debug("class code exists.....service");
                    
                        if (auditRecordBO.getAlertMsg().equals("Insert Audit Failed")) {
                            returnedData.append("FAILED " + auditRecordBO.getResponseStatusMsg());
                        }else{
                            returnedData.append("SUCCESS");
                        }
                     }
                }else{
                    LOG.info("AuditEntryExists.....");
                    if (auditEntryMissingBO.isRlsEntryExists()) {
                        returnedData.append("Audit or DLQ Entry Exists");
                    } else {
                        returnedData.append("Document Does not exists in RLS");
                    }
                }
            
                returnedData.append("\n");
            }
        }catch(Exception e){
            LOG.info("Exception occured",e);
            throw new RecoveryServiceException(e);
        }        
        return returnedData.toString();       
    }

    
    private AuditRecordBO getAuditRecordBO(AuditEntryMissingBO auditEntryMissingBO) {
        LOG.debug("Start of method getAuditRecordBO");
        AuditRecordBO auditRecordBO = new AuditRecordBO();
        IntPCEHRHeader intPCEHRHeader = new IntPCEHRHeader();
        StringBuffer respStatus = new StringBuffer();
        try {
            // User
            IntPCEHRHeader.User user = new IntPCEHRHeader.User();
            user.setIDType("HPII");
            user.setID(auditEntryMissingBO.getAuthorPerson());
            user.setRole("HealthcareProvider");
            user.setUserName(auditEntryMissingBO.getAuthorPersonName());
            user.setUseRoleForAudit(false);
            intPCEHRHeader.setUser(user);
            // IHI Number
            intPCEHRHeader.setIhiNumber(auditEntryMissingBO.getIhi());
            // Product Type
            IntPCEHRHeader.ProductType productType = new IntPCEHRHeader.ProductType();
            productType.setVendor("PCEHR");
            productType.setProductName("PCEHR");
            productType.setProductVersion(EndPointsConstants.PRODUCT_VERSION);
            productType.setPlatform("1");
            intPCEHRHeader.setProductType(productType);
            // Client System
            IntPCEHRHeader.ClientSystem clientSystem = new IntPCEHRHeader.ClientSystem();
          
            
            clientSystem.setSystemID(auditEntryMissingBO.getSystemType()+"0001");
            clientSystem.setSystemType(auditEntryMissingBO.getSystemType());
             intPCEHRHeader.setClientSystem(clientSystem);
            // Accessing Org
            IntPCEHRHeader.AccessingOrganisation accessingOrg = new IntPCEHRHeader.AccessingOrganisation();
            accessingOrg.setOrganisationID(auditEntryMissingBO.getInheritingOrg());
            accessingOrg.setOrganisationName(auditEntryMissingBO.getInheritingOrgName());
            intPCEHRHeader.setAccessingOrganisation(accessingOrg);
            //Override Log Level
            intPCEHRHeader.setOverrideLogLevel(false);

            // Audit Event
            AuditEvent auditEvent = new AuditEvent();
            // Participant Details
            ParticipantDetailsType participantDetailsType = new ParticipantDetailsType();
            participantDetailsType.setParticipatingHPIO(auditEntryMissingBO.getAccessingOrg());
           participantDetailsType.setParticipatingHPIOName(auditEntryMissingBO.getAccessingOrgName());

            auditEvent.setParticipantDetails(participantDetailsType);
            // Accessed Entity
            AccessedEntityType accessedEntityType = new AccessedEntityType();
            accessedEntityType.setIhiName(auditEntryMissingBO.getIhiName());
            accessedEntityType.setSubject(auditEntryMissingBO.getDocumentID());
            accessedEntityType.setSubjectType("DocumentID");
            auditEvent.setAccessedEntity(accessedEntityType);
            //Participant Action
            ParticipantActionType participantActionType = new ParticipantActionType();
            LOG.debug("business event :::::"+auditEntryMissingBO.getOperationPerfomed());
            LOG.debug("OPP PERFORMED ........"+auditEntryMissingBO.getOperationPerfomed().equals("uploadDocumentMetadata"));
            if(auditEntryMissingBO.getOperationPerfomed().equals("uploadDocument") || 
               auditEntryMissingBO.getOperationPerfomed().equals("uploadDocumentMetadata")){
            participantActionType.setActionType("Create");
            }else if(auditEntryMissingBO.getOperationPerfomed().equals("uploadDocumentAmendment")||
                     auditEntryMissingBO.getOperationPerfomed().equals("uploadDocumentMetadataAmendment")){
                participantActionType.setActionType("Update");
            }
           
            participantActionType.setApprovalRole("");
            participantActionType.setOperationPerformed("");
            participantActionType.setApprovalName("");
            participantActionType.setStatusPriorDeactivation("");
            auditEvent.setParticipantAction(participantActionType);
            //Access Condition
            AccessConditionsType accessConditionsType = new AccessConditionsType();
            accessConditionsType.setAccessLevel(auditEntryMissingBO.getAccessLevel());
            accessConditionsType.setAccessPermission("Permit");
            auditEvent.setAccessConditions(accessConditionsType);

            //Log Event
            LogEvent logEvent = new LogEvent();
            ResponseStatusType responseStatusType = new ResponseStatusType();
            responseStatusType.setCode("PCEHR_SUCCESS");
            responseStatusType.setDescription("Business Transaction Completed");
            responseStatusType.setDetails("SUCCESS");
            logEvent.setStatusDetails(responseStatusType);
            logEvent.setMessageLogLevel("AUDIT");

            // Event Record
            EventRecord eventRecord = new EventRecord();
            eventRecord.setBusinessEvent(auditEntryMissingBO.getOperationPerfomed());
            eventRecord.setEventTimeStamp(getXMLGregorianCalendar(auditEntryMissingBO.getServiceStopTime()));
            eventRecord.setComponentSource("OSB Integration Layer");
            eventRecord.setTransactionStatus("COMPLETED");
            eventRecord.setLogEvent(logEvent);
            //auditEventID
            
            //UNCOMMENT THE BELOW LINE FOR NOTICATION CHAGNES FOR ACP DOCUMENTS
            auditEvent.setAuditEventID(auditEntryMissingBO.getAuditEventID());
            
            eventRecord.setAuditEvent(auditEvent);
            

            InsertAuditRecord insertAuditRecord = new InsertAuditRecord();
            insertAuditRecord.setEventRecord(eventRecord);

            //InsertAuditRecordClient insertAuditRecordProxy = new InsertAuditRecordClient();
            LoggingHandler.isAuditEntryMissing = true;
            if (null != auditEntryMissingBO.getIntegrationID() && !auditEntryMissingBO.getIntegrationID().isEmpty()) {
                LoggingHandler.integrationID = auditEntryMissingBO.getIntegrationID();
            } else {
                LoggingHandler.integrationID = "urn:uuid:" + UUID.randomUUID().toString() + "_DF";
            }
            if (null != auditEntryMissingBO.getMessageID() && !auditEntryMissingBO.getMessageID().isEmpty()) {
                LoggingHandler.messageID = auditEntryMissingBO.getMessageID();
            } else {
                LoggingHandler.messageID = "urn:uuid:" + UUID.randomUUID().toString() + "_DF";
            }
            ResponseStatusType response = insertAuditRecordClient.insertAudit(insertAuditRecord, intPCEHRHeader);
            LOG.debug("responseStatusType status" + (null != response));
            if (null != response) {
                auditRecordBO.setAuditReponse(response);
                respStatus.append("\nInsert Audit Response");
                respStatus.append("\n");
                respStatus.append("\nCode :: " + response.getCode());
                respStatus.append("\nDescription :: " + response.getDescription());
                respStatus.append("\nDetails :: " + response.getDetails());
                respStatus.append("\n");
                LOG.debug("Get response status message.." + respStatus.toString());
                auditRecordBO.setResponseStatusMsg(respStatus.toString());
                auditRecordBO.setAlertMsg("Insert Audit Success");
            } else {
                auditRecordBO.setAlertMsg("Insert Audit Failed");
                auditRecordBO.setResponseStatusMsg("Not able to reach the destination end point OR end point is wrong OR any other exception occurred. Please check the logs for more infomation");
            }
        } catch (au.net.electronichealth.ns.pcehr.svc.intinsertauditrecord._1.StandardError standError) {
            LOG.fatal("Audit StandardError : " + standError);
            LOG.fatal("Audit StandardError Message : " + standError.getFaultInfo().getMessage());
            respStatus.append("\nInsert Audit Response");
            respStatus.append("\nException Occurred<b>");
            respStatus.append("\nError Message : " + standError.getFaultInfo().getMessage());
            respStatus.append("\n");
            auditRecordBO.setResponseStatusMsg(standError.getFaultInfo().getMessage());
            auditRecordBO.setAlertMsg("Insert Audit Failed");
        } catch (Exception e) {
            LOG.debug("Exception Occurred :::" + e.getMessage());
            LOG.fatal("Exception Occurred", e);
            auditRecordBO.setAlertMsg("Insert Audit Failed");
            auditRecordBO.setResponseStatusMsg(e.getMessage());
        }finally{
            LoggingHandler.isAuditEntryMissing = false;
        }
        LOG.debug("End of method getAuditRecordBO");
        return auditRecordBO;
    }

    /**
     * 
     * @param date
     * @return
     * @throws ParseException
     * @throws DatatypeConfigurationException
     * @throws Exception
     */
    public XMLGregorianCalendar getXMLGregorianCalendar(String date) throws ParseException,
                                                                            DatatypeConfigurationException, Exception {
        LOG.debug("Start of method getXMLGregorianCalendar");
        XMLGregorianCalendar xmlCalender = null;
        GregorianCalendar calender = new GregorianCalendar();
        Date date1 = stringToJavaDate(date);
        if(null == date1) {
            throw new Exception("Invalid Service Stop Time " + date);
        } else {
            calender.setTime(date1);
        }
        xmlCalender = DatatypeFactory.newInstance().newXMLGregorianCalendar(calender);
        LOG.debug("End of method getXMLGregorianCalendar");
        return xmlCalender;
    }
    
    /**
     * This method converts the String date to Date.
     * @param sDate
     * @return date
     * @throws ParseException
     */
    public Date stringToJavaDate(String sDate) throws ParseException {
        LOG.debug("Start of method stringToJavaDate" + sDate);
        Date date = null;
        if(sDate.length() == 14) {
            date = new SimpleDateFormat("yyyyMMddHHmmss", Locale.ENGLISH).parse(sDate);
        } else if(sDate.length() == 12) {
            date = new SimpleDateFormat("yyyyMMddHHmm", Locale.ENGLISH).parse(sDate);
        } else if(sDate.length() == 8) {
            date = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).parse(sDate);
        }
        LOG.debug("End of method getXMLGregorianCalendar" + date);
        return date;
    }
    
    
}
