package au.gov.doha.pcehr.recovery.service;


import au.gov.doha.pcehr.recovery.dao.EmergencyAccessDAO;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.EmergencyExpiryForm;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * Service class for Emergency Access Expiry Report
 * Obtains list from DAO class.
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Jan 2015
 * @version Change-x
 */
@Service
public class EmergencyAccessService {

    private static Logger LOG = Logger.getLogger(EmergencyAccessService.class);

    @Autowired
    private EmergencyAccessDAO emergencyAccessDAO;

    /**
     * This method is called from the controller after validation is done.
     * @param emergencyExpiryBO
     * @return emergencyAccessExpiryList
     * @throws RecoveryServiceException
     * @throws RecoveryDAOException
     */
    public EmergencyExpiryForm emergencyAccessServicemethod(EmergencyExpiryForm emergencyExpiryForm) throws RecoveryDAOException {
        emergencyExpiryForm = emergencyAccessDAO.fetchEmergencyExpiryList(emergencyExpiryForm);                                                                                            
        return emergencyExpiryForm;
    }
}
