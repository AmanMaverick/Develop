package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.DLQMessageReplayBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.form.DLQMessageForm;
import au.gov.doha.pcehr.recovery.service.DLQMessagService;

import java.util.ArrayList;
import java.util.List;



import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


/**
 * This functionality is to update DLQ Status in OSB Database
 * @author Vikash Kumar Singh,  Operations Team, PCEHR
 * @since 13th April 2015
 * @version - X
 */
@Controller
public class DLQReplayController {
    private static Logger LOG = Logger.getLogger(DLQReplayController.class);
    private static final String EXCEPTION_PAGE = "NIO/Exception";
    private static final String DLQ_TOOL_LANDING_PAGE = "NIO/DLQToolLanding";
    private static final String DLQ_MESSAGE_VIEW_PAGE = "NIO/DLQMessageView";
    private static final String DLQ_MESSAGE_VERIFICATION_PAGE = "NIO/DLQMessageVerificationPage";
    private static final String DLQ_MESSAGE_REPLAY_PAGE = "NIO/DLQMessageReplayPage";
    private static final String DLQ_POPUP_PAGE = "NIO/DLQMessageReplayPopUp";
    
    @Autowired
    private DLQMessagService dlqMessagService;
    
   
    /**
     * For welcome.jsp link
     * @param dlqMessage
     * @return
     * @throws Exception
     */
    @AuditBefore(AuditMessageConstants.DLQ_LANDINGPAGE_MESAGGE)
    @RequestMapping(method = {RequestMethod.GET}, value="/DLQReplayTool" )
    public String dlqReplayToolMessageViewPage(@ModelAttribute("dlqMessage")DLQMessageForm dlqMessage)throws Exception {
        dlqMessage = dlqMessagService.getDLQReplayToolPageDetail(dlqMessage);
        return DLQ_TOOL_LANDING_PAGE;
    }
    
    /**
     * For search operation on landing page
     * @param dlqMessage
     * @param map
     * @return
     * @throws Exception
     */
    
    @AuditBefore(AuditMessageConstants.DLQ_SEARCH_OPERATIONS)
    @RequestMapping(method = {RequestMethod.POST}, value="/DLQReplayToolMessageView" )
    public String dlqReplayToolLandingPage(@ModelAttribute("dlqMessage")DLQMessageForm dlqMessage, ModelMap map)throws Exception {
        List<DLQMessageForm> dlqMessageList = new ArrayList<>();
        dlqMessage = dlqMessagService.getDLQReplayToolPageDetail(dlqMessage);
        dlqMessageList = dlqMessagService.searchDLQError(dlqMessage);
        map.addAttribute("dlqMessageList",dlqMessageList);
        return DLQ_MESSAGE_VIEW_PAGE;
    }
    
    /**
     * For Play Error Code
     * @param dlqMessage
     * @param map
     * @return
     * @throws Exception
     */
    @AuditBefore(AuditMessageConstants.DLQ_PLAY_ERROR_CODE_OPERATIONS)
    @RequestMapping(method = {RequestMethod.POST}, value="/DLQReplayToolPlay" )
    public String dlqReplayToolPlay(@ModelAttribute("dlqMessage")DLQMessageForm dlqMessage, ModelMap map)throws Exception {
        List<DLQMessageForm> dlqStateList =  new ArrayList<>();
        dlqStateList = dlqMessagService.performStateChange(dlqMessage);
        map.addAttribute("dlqStateList",dlqStateList);
        int errorCount = dlqMessage.getErrorCodeList().size();
        LOG.debug("msgViewBack---- :: " + errorCount);
        if(errorCount > 0){
            map.addAttribute("msgBack","msgSearchViewBack");
        }else{
            map.addAttribute("msgBack","replayMsgViewBack");
        }
        
        return DLQ_MESSAGE_VERIFICATION_PAGE;
    }
    
    /**
     *
     * @param dlqMessage
     * @param map
     * @return
     * @throws Exception
     */
    //For Play Integration ID List...
    @AuditBefore(AuditMessageConstants.DLQ_PLAY_INTEGRATION_ID_OPERATIONS)
    @RequestMapping(method = {RequestMethod.POST}, value="/DLQReplayIntegrationId" )
    public String playDLQForIntegrationID(@ModelAttribute("dlqMessage")DLQMessageForm dlqMessage, ModelMap map)throws Exception {
        LOG.debug("Inside getIntegrationIdList " + dlqMessage.getIntegrationIdList().size());
        List<DLQMessageForm> dlqStateList =  new ArrayList<>();
        dlqStateList = dlqMessagService.processDLQMessageIntegrationID(dlqMessage);
        map.addAttribute("dlqStateList",dlqStateList);
        map.addAttribute("msgBack","replayMsgViewBack");
        return DLQ_MESSAGE_VERIFICATION_PAGE;
    }
    
    
    
    /**
     * To handel exceptions
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleAllException(Exception ex) {
        LOG.info("Exception handler......");
        ModelAndView model = new ModelAndView(EXCEPTION_PAGE);
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex.getMessage());
        return model;
    }
    //.........................................................................................
    //for XSS change
    @AuditBefore(AuditMessageConstants.DLQ_PLAY_ERROR_CODE_MESSAGES)
    @RequestMapping(method = {RequestMethod.POST}, value="/DLQReplayMessageView" )
    public String getDLQMessageDetails2( @ModelAttribute("dlqMessage")DLQMessageForm dlqMessageDetail, ModelMap map)throws Exception {
        LOG.debug("Inside DLQReplayMessageView2");
       // DLQMessageForm dlqMessageDetail = new DLQMessageForm();
      
        List<DLQMessageForm> dlqMessageDetailList =  new ArrayList<>();
       // dlqMessageDetail.setErrorCode(request.getParameter("ErrorCode"));
       LOG.debug("ErrorCode...."+dlqMessageDetail.getErrorCode());
        LOG.debug("QueueType...."+dlqMessageDetail.getDeliveryCount());
        LOG.debug("getInputErrorCode...."+dlqMessageDetail.getInputErrorCode());
        LOG.debug("here......" + dlqMessageDetail.getInputErrorCount());
        dlqMessageDetailList = dlqMessagService.getMessageDetail(dlqMessageDetail);
        map.addAttribute("dlqMessage",dlqMessageDetail);
        map.addAttribute("dlqMessageDetailList",dlqMessageDetailList);
        return DLQ_MESSAGE_REPLAY_PAGE;
    }
    @RequestMapping(method = {RequestMethod.POST}, value="/DLQReplayToolMessageViewBack" )
    public String dlqReplayToolMessageViewBack2(@ModelAttribute("dlqMessage")DLQMessageForm dlqMessageDetail, ModelMap map)throws Exception {
        List<DLQMessageForm> dlqMessageList = new ArrayList<>();
        LOG.debug("Inside dlqReplayToolMessageViewBack2");
       // DLQMessageForm dlqMessageDetail = new DLQMessageForm();
        dlqMessageDetail = dlqMessagService.getDLQReplayToolPageDetail(dlqMessageDetail);
        //dlqMessageDetail.setErrorCode(request.getParameter("ErrorCode"));
//        dlqMessageDetail.setQueueType(request.getParameter("queueType"));
//        dlqMessageDetail.setQueueSize(request.getParameter("queueSize"));
//        dlqMessageDetail.setDeliveryCount(request.getParameterValues("deliveryCount")[0]);
        dlqMessageDetail = dlqMessagService.getDLQReplayToolPageDetail(dlqMessageDetail);
        dlqMessageList = dlqMessagService.searchDLQError(dlqMessageDetail);
        map.addAttribute("dlqMessageList",dlqMessageList);
        map.addAttribute("dlqMessage",dlqMessageDetail);
        return DLQ_MESSAGE_VIEW_PAGE;
    }
    
    @AuditBefore(AuditMessageConstants.DLQ_PLAY_INTEGRATION_ID_MESSAGES)
    @RequestMapping(method = {RequestMethod.POST}, value="/DLQMessageDBDetails" )
    public String getDLQMessageDBDetails(@ModelAttribute("dlqMessage")DLQMessageForm dlqMessageDetail, ModelMap map)throws Exception {
        LOG.debug("Inside getDLQMessageDBDetails");
        DLQMessageReplayBO dlqMessageReplayDetail =  new DLQMessageReplayBO();
        String integrationId = dlqMessageDetail.getIntgrationID();
        
        LOG.debug("integrartin id:::"+integrationId);
        dlqMessageReplayDetail = dlqMessagService.getMessageDBDetail(integrationId);
        map.addAttribute("dlqMessageReplayDetail",dlqMessageReplayDetail);
        return DLQ_POPUP_PAGE;
    }
   
    
}
