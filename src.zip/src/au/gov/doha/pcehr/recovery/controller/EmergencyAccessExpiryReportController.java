package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.EmergencyExpiryForm;
import au.gov.doha.pcehr.recovery.service.EmergencyAccessService;
import au.gov.doha.pcehr.recovery.validation.EmergencyAccessExpiryValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


/**
 * Controller class to perform all EmergencyAccessExpiryReport related task.
 * Redirects to Emergency Access Workaround operations and later on submit to Emergency Access Expiry List.
 * @Since Jan 2015
 * @Author Dinesh Kaki, Operations, PCEHR
 * @version Change-x
 */
@Controller
@RequestMapping("/EmergencyAccess**")
public class EmergencyAccessExpiryReportController {

    private static Logger LOG = Logger.getLogger(EmergencyAccessExpiryReportController.class);
    private static final String MAIN_PAGE_LINK = "/NIO/EmergencyAccessExpiry";
    private static final String MODEL_ATTRIBUTE = "EmergencyExpiryForm";
    private static final String PAGE_EXCEPTION = "NIO/Exception";

    @Autowired
    private EmergencyAccessService emergencyAccessService;

    @Autowired
    @Qualifier("emergencyAccessExpiryValidator")
    private EmergencyAccessExpiryValidator emergencyAccessExpiryValidator;

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(emergencyAccessExpiryValidator);
    }

    /**
     * This method is called when user clicks on Emergency access expiry in Work around menu section.
     * @param emergencyExpiryForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.EMERGENCY_ACCESS_EXPIRY_REPORT_PAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/EmergencyAccessExpiry")
    public String EmergencyAccessExpiryMenu(@ModelAttribute(MODEL_ATTRIBUTE)
        EmergencyExpiryForm emergencyExpiryForm) {
        LOG.debug("Inside Emergency Access page");
        return MAIN_PAGE_LINK;
    }


    /**
     *This method is called when user clicks submit in the Workaround Operations section.
     * @param emergencyExpiryForm
     * @param result
     * @return
     * @throws RecoveryDAOException
     */
     @AuditBefore(AuditMessageConstants.GET_EMERGENCY_LIST)
    @RequestMapping(method = RequestMethod.POST, params = "EmergencyAccessList=Submit")
    public String getEmergencyAccessExpiryList(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        EmergencyExpiryForm emergencyExpiryForm, BindingResult result) throws RecoveryDAOException {
        if (result.hasErrors()) {
            LOG.debug("Returning page to enter Date" + result.hasErrors());
            return MAIN_PAGE_LINK;
        }
        emergencyExpiryForm = emergencyAccessService.emergencyAccessServicemethod(emergencyExpiryForm);
        return "/NIO/EmergencyAccessExpiryList";
    }

    /**
     * This method is called when ServiceException occurs.
     * @param ex
     * @return model
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(Exception ex) {
        LOG.info("doaexception handler......");
        ModelAndView model = new ModelAndView(PAGE_EXCEPTION);
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex.getMessage());
        return model;
    }

}
