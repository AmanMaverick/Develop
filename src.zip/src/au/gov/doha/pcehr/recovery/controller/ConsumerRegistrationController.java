package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ConsumerRegistrationForm;
import au.gov.doha.pcehr.recovery.service.ConsumerRegistrationService;
import au.gov.doha.pcehr.recovery.validation.ConsumerRegistrationValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/ConsumerRegistrationCtrl**")
public class ConsumerRegistrationController {

    private static Logger LOG = Logger.getLogger(ConsumerRegistrationController.class);
    private static final String MAIN_PAGE_LINK = "/NIO/ConsumerRegistrationLandingPage";
    private static final String MODEL_ATTRIBUTE = "ConsumerRegistrationForm";
    private static final String PAGE_EXCEPTION = "NIO/Exception";
    

    @Autowired
    private ConsumerRegistrationService consumerRegistrationService;

    @Autowired
    private ConsumerRegistrationValidator consumerRegistrationValidator;

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(consumerRegistrationValidator);
    }
       

    /** 
     * This method is called when user clicks on Consumer Registration in Work around menu section.
     * @param consumerRegistrationForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.CONSUMER_REGISTRATION_LANDINGPAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/ConsumerRegistrationCtrl")
    public String ConsumerRegistrationMenu(@ModelAttribute(MODEL_ATTRIBUTE)
        ConsumerRegistrationForm consumerRegistrationForm) {
        LOG.debug("Inside Consumer Registration page");
        return MAIN_PAGE_LINK;
    }

 
    @AuditBefore(AuditMessageConstants.GET_CONSUMER_REGISTRATION_LIST)
    @RequestMapping(method = RequestMethod.POST, params = "ConsumerRegistrationSubmit=Submit")
    public String getConsumerRegistrationList(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        ConsumerRegistrationForm consumerRegistrationForm, BindingResult result) throws RecoveryDAOException {
        if (result.hasErrors()) {
            LOG.debug("Returning page to enter Date and errors -->" + result.hasErrors());
            return MAIN_PAGE_LINK;
        }
        LOG.debug("No Errors");
        consumerRegistrationForm = consumerRegistrationService.consumerRegistrationServicemethod(consumerRegistrationForm);
        LOG.debug("Leaving Controller Class ");
        return "/NIO/ConsumerRegistrationList";
    }



    /**
     * This method is called when ServiceException occurs.
     * @param ex
     * @return model
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(Exception e) {
        LOG.info("DAO_Exception handler......");
        ModelAndView model = new ModelAndView(PAGE_EXCEPTION);
        model.addObject("errorMsg", e.getMessage());
        LOG.debug("e.getMessage().............." + e.getMessage());
        return model;
    }


}
