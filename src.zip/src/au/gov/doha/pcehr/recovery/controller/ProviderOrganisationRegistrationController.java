package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ProviderOrganisationRegistrationForm;
import au.gov.doha.pcehr.recovery.service.ProviderOrganisationRegistrationService;
import au.gov.doha.pcehr.recovery.validation.ProviderOrganisationRegistrationValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/ProviderOrganisationRegistration**")
public class ProviderOrganisationRegistrationController {
    
    private static Logger LOG = Logger.getLogger(ProviderOrganisationRegistrationController.class);
    private static final String MAIN_PAGE_LINK = "/NIO/ProviderOrganisationRegistration";
    private static final String MODEL_ATTRIBUTE = "ProviderOrganisationRegistrationForm";
    private static final String FINAL_PAGE_LINK = "/NIO/ProviderOrganisationRegistrationList";
    private static final String PAGE_EXCEPTION = "NIO/Exception";
    

    @Autowired
    private ProviderOrganisationRegistrationService providerOrganisationRegistrationService;

    @Autowired
    private ProviderOrganisationRegistrationValidator providerOrganisationRegistrationValidator;

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(providerOrganisationRegistrationValidator);
    }

    /**
     * This method is called when user clicks on Provider Organisation Registration in Work around menu section.
     * @param providerOrganisationRegistrationForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.PROVIDER_ORG_REGISTRATION_LANDINGPAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/ProviderOrganisationRegistration")
    public String ProviderOrganisationRegistrationMenu(@ModelAttribute(MODEL_ATTRIBUTE)
        ProviderOrganisationRegistrationForm providerOrganisationRegistrationForm) {
        LOG.debug("Inside Provider Organisation Registration page");
        return MAIN_PAGE_LINK;
    }
    
    /**
     * This method is called when user clicks submit in the Workaround Operations section.
     * @param providerOrganisationRegistrationForm
     * @param result
     * @return
     * @throws RecoveryDAOException
     */
    @AuditBefore(AuditMessageConstants.GET_PROVIDER_ORG_REGISTRATION_LIST)
    @RequestMapping(method = RequestMethod.POST, params ="ProviderOrganisationRegistrationSubmit=Submit")
    public String getProviderOrganisationRegistrationList(@Valid
        @ModelAttribute(MODEL_ATTRIBUTE)
        ProviderOrganisationRegistrationForm providerOrganisationRegistrationForm, BindingResult result) throws RecoveryDAOException,
                                                                                       RecoveryServiceException {
        if (result.hasErrors()) {
            LOG.debug("Returning page to enter Date and errors -->" + result.hasErrors());
            return MAIN_PAGE_LINK;
        }
        LOG.debug("No Errors");
        providerOrganisationRegistrationForm = providerOrganisationRegistrationService.providerOrganisationRegistrationServiceMethod(providerOrganisationRegistrationForm);
        LOG.debug("Leaving Controller Class ");
        return FINAL_PAGE_LINK;
    }



    /**
     * This method is called when ServiceException occurs.
     * @param ex
     * @return model
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(Exception e) {
        LOG.info("DAO_Exception handler......");
        ModelAndView model = new ModelAndView(PAGE_EXCEPTION);
        model.addObject("errorMsg", e.getMessage());
        LOG.debug("e.getMessage().............." + e.getMessage());
        return model;
    }

   
   
}
