package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.form.AuditEntryMissingForm;
import au.gov.doha.pcehr.recovery.service.AuditEntryMissingService;
import au.gov.doha.pcehr.recovery.validation.AuditEntryMissingValidator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;


/**
 *
 * @author Vikash Kumar Singh
 * @since 06th April 2015
 * @version - X
 */
@Controller
@RequestMapping("/AuditEntryMissing**")
public class AuditEntryMissingController implements HandlerExceptionResolver  {
   
    private static Logger LOG = Logger.getLogger(AuditEntryMissingController.class);
    private  static final String AUDIT_ENTRY_MISSING_MODEL_ATTRIBUTE = "auditEntryMissingAttribute";
    private static final String LOAD_AUDIT_ENTRY_MISSING = "/NIO/AuditEntryMissing";
    private static final String EXCEPTION_PAGE = "NIO/Exception";
    
    @Autowired
    private AuditEntryMissingService auditEntryMissingService;
   
    @Autowired
    @Qualifier("auditEntryMissingValidator")
    private AuditEntryMissingValidator validator;
   
    @InitBinder(AUDIT_ENTRY_MISSING_MODEL_ATTRIBUTE)
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
   
   
     /**
     * This method loads the Audit Entry Missing page.
     * @param auditEntryMissingForm
     * @return LOAD_AUDIT_ENTRY_MISSING
     */
       @AuditBefore(AuditMessageConstants.AUDIT_ENTRY_MISSING_PAGE)
       @RequestMapping(method= {RequestMethod.GET} , value="/AuditEntryMissing") 
       public String loadAuditEntryMissingPage(@ModelAttribute(AUDIT_ENTRY_MISSING_MODEL_ATTRIBUTE)
                                               AuditEntryMissingForm auditEntryMissing ){
           LOG.info("Loading AuditEntryMissing landing page.");
           return LOAD_AUDIT_ENTRY_MISSING;
       }
     
     /**
     * This method calls the service on submitting the form.
     * Doing validation on binding object AuditEntryMissingForm 
     * @param auditEntryMissingForm
     * @return LOAD_AUDIT_ENTRY_MISSING
     */
     @AuditBefore(AuditMessageConstants.AUDIT_ENTRY_MISSING_OPERATION)
     @RequestMapping(method={RequestMethod.POST}, params = "auditEntrySubmit=Submit") 
     public String submit(@Valid @ModelAttribute(AUDIT_ENTRY_MISSING_MODEL_ATTRIBUTE)
                          AuditEntryMissingForm auditEntryMissing,BindingResult result,ModelMap map,HttpServletResponse response) throws Exception{
         LOG.info("Audit Entry Submit method");
         if(result.hasErrors()){
             LOG.info("Validation failed::"+result.hasErrors()+result.toString());
             map.addAttribute("InValidField", true);
             return LOAD_AUDIT_ENTRY_MISSING;
         }
        auditEntryMissing =  auditEntryMissingService.auditEntry(auditEntryMissing, response);
        if(auditEntryMissing.getDataFix().equals("OSB")){
         return null;
        }else{
         return LOAD_AUDIT_ENTRY_MISSING;
        }
     }
     
    /**
     * To handdle runtime exceptions and
     * handalling MaxUploadSizeExceededException specifically to prevent the upload limit to 100000 bytes
     * @param httpServletRequest
     * @param httpServletResponse
     * @param object
     * @param ex
     * @return
     */
    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest,
                                         HttpServletResponse httpServletResponse, Object object, Exception ex) {
        ModelAndView model = new ModelAndView(EXCEPTION_PAGE);
        if (ex instanceof MaxUploadSizeExceededException) {
            model.addObject("exception", "File size exceeded the limit of maximum size - 100000 Bytes");
        }
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex.getMessage());
        return model;
    }
}
