package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.HealthRecordExtForm;
import au.gov.doha.pcehr.recovery.service.HealthRecordExtService;
import au.gov.doha.pcehr.recovery.validation.HealthRecordExtValidator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/HealthRecordExt**")
public class HealthRecordExtController implements HandlerExceptionResolver{
    private static Logger LOG = Logger.getLogger(HealthRecordExtController.class);
    private static final String HEALTH_RECORD_EXT_ATTRIBUTE="HealthRecordExtAttribute";
    private static final String HEALTH_RECORD_EXT_LANDING_PAGE="/NIO/HealthRecordExtPage";
    private static final String EXCEPTION_PAGE = "NIO/Exception";
        
    @Autowired
    @Qualifier("healthRecordExtValidator")
    private HealthRecordExtValidator validator;
    
    @Autowired
    private HealthRecordExtService healthRecordExtService;
    
    @InitBinder(HEALTH_RECORD_EXT_ATTRIBUTE)
    protected void initBinder(WebDataBinder binder) {
        binder.setValidator(validator);
    }
    
    /**
    * This method loads the Audit Entry Missing page.
    * @param auditEntryMissingForm
    * @return LOAD_AUDIT_ENTRY_MISSING
    */
      @AuditBefore(AuditMessageConstants.AUDIT_HEALTH_RECORD_EXT_LANDING_PAGE)
      @RequestMapping(method= {RequestMethod.GET} , value="/HealthRecordExtContrl") 
      public String loadAuditEntryMissingPage(@ModelAttribute(HEALTH_RECORD_EXT_ATTRIBUTE)
                                              HealthRecordExtForm healthRecordExtForm ){
          LOG.info("Loading AuditEntryMissing landing page.");
          return HEALTH_RECORD_EXT_LANDING_PAGE;
      }
    
    
    @AuditBefore(AuditMessageConstants.AUDIT_HEALTH_RECORD_EXT_SUBMIT)
    @RequestMapping(method={RequestMethod.POST},value="/HealthRecordExtContrl" , params="HealthRecordExtSubmit=Submit")
    public String extractHealthView(@Valid @ModelAttribute(HEALTH_RECORD_EXT_ATTRIBUTE)   HealthRecordExtForm healthRecordExtForm,BindingResult bindingResult, ModelMap map) throws RecoveryServiceException {
        LOG.debug("Entering extractHealthView.");
        if (bindingResult.hasErrors()) {
            LOG.debug("Inside has errors");
            LOG.info("......"+bindingResult.hasErrors() + bindingResult.toString());
            return HEALTH_RECORD_EXT_LANDING_PAGE;
        }
        healthRecordExtForm = healthRecordExtService.extractViews(healthRecordExtForm);
        return HEALTH_RECORD_EXT_LANDING_PAGE; 
    } 

    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                                         Object object, Exception exception) {
        ModelAndView mav = new ModelAndView(EXCEPTION_PAGE);
        mav.addObject("errorMsg", exception.getMessage());
        return mav;
    }
}
