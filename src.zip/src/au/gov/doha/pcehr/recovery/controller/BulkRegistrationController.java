package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.BulkRegistrationForm;
import au.gov.doha.pcehr.recovery.service.BulkRegistrationService;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;
import au.gov.doha.pcehr.recovery.validation.BulkRegstrationValidator;
import au.gov.doha.pcehr.recovery.view.BulkRegistrationReconcileReportView;
import au.gov.doha.pcehr.recovery.view.BulkRegistrationStatusView;

import java.io.OutputStream;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import javax.validation.Valid;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Controller to perform allBulk registration for Opt Out related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 18 Nov 2015
 * @version Change-x
 */

@Controller
public class BulkRegistrationController {
    private static Logger LOG = Logger.getLogger(BulkRegistrationController.class);
    
    @Autowired
    BulkRegistrationService bulkRegistrationService;
    
    @Autowired 
    BulkRegstrationValidator bulkRegstrationValidator;
    
    @Autowired 
    BulkRegistrationStatusView bulkRegistrationStatusView;
    
    @Autowired 
    BulkRegistrationReconcileReportView bulkRegistrationReconcileReportView;
    
    @Value("${VALIDATE_IHI_SUCCESS_MESSAGE}")
    private String validateIhiSucessMessage;
    
    @Value("${VALIDATE_IHI_STOP_MESSAGE}")
    private String ValidateIhiStopMessage;
            
    @Value("${BULK_RECORD_SUCCESS_MESSAGE}")
    private String bulkRecordSuccessMessage;
        
    @Value("${BULK_RECORD_STOP_MESSAGE}")
    private String bulkRecordStopMessage;
     
    @Value("${VALIDATE_AND_CREATE_SUCCESS_MESSAGE}")
    private String validateAndCreateSuccessMessage;
    
    @Value("${validateAndCreateStopMessage}")    
    private String validateAndCreateStopMessage;
    
    private static final String VALIDATE_IHI_INFO_VAL1="Validate ALL IHIs";
    private static final String VALIDATE_IHI_INFO_VAL2="Select IHI List for Validation";
    private static final String VALIDATE_IHI_INFO_VAL3="Select Number of Rows for Validation";
    
    private static final String VALIDATE_BULK_ANDRECORD_VAL1="Validate and Register for ALL IHIs";
    private static final String VALIDATE_BULK_ANDRECORD_VAL2="Validate and Register for a List of IHIs";
    private static final String VALIDATE_BULK_ANDRECORD_VAL3="Validate and Register for Specified Number of Rows";
    
    
    private static final String BULK_RECORD_VAL1="Create Records for ALL IHIs";
    private static final String BULK_RECORD_VAL2="Create Record for List of IHIs";
    private static final String BULK_RECORD_VAL3="Create Records for a Specified Number of Rows";
    
    private static final String STATUS_TAB_VAL1="ALL IHI";
    private static final String STATUS_TAB_VAL2="List of IHIs";
    private static final String STATUS_TAB_VAL3="File Name";
    
    
   
    
    private static final String BULK_REGISTRATION_PAGE = "/NIO/BulkRegistration";
    private static final String BULK_REGISTRATION_ATTRIBUTE = "bulkRegistrationAttribute";
    

    private static final String VALIDATE_EXTRACT_OUTPUT="ValidateExtarctOutput";
    private static final String PUSH_TO_DB_OUTPUT="PushToDbOutput";
    
    @InitBinder(BULK_REGISTRATION_ATTRIBUTE)
    protected void initBinderMetricTypeConfig(WebDataBinder binder) {
            LOG.debug("Initialising the validator");
            binder.setValidator(bulkRegstrationValidator);
    }

    @RequestMapping(method = { RequestMethod.GET }, value = "/BulkRegistrationCntrl")

    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_LANDIGPAGE)
    public String loadBulkRegLandingPage(ModelMap map) {
        BulkRegistrationForm bulkRegistrationForm = new BulkRegistrationForm();
        map.addAttribute(BULK_REGISTRATION_ATTRIBUTE, bulkRegistrationForm);
        LOG.debug("inside bulk reg controller");
        return BULK_REGISTRATION_PAGE;
    }


    /**Author:Sumanta--ValidateAndExtract tab 
     * This method trigger validate extract.
     * @param bulkRegistrationForm
     * @return
     * @throws Exception
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_VALIDATE_EXTRACT)
    @RequestMapping(method = { RequestMethod.POST }, value = "/ValidateAndDataExtraction", params = "Validate=Validate")
    public String validateExtract(@Valid@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE) BulkRegistrationForm bulkRegistrationForm,BindingResult result) throws Exception {
        LOG.debug("Enetring validateExtract ");
        if (result.hasErrors()) {
           LOG.debug("Inside validateExtract has errors");
            return BULK_REGISTRATION_PAGE;
        }
        bulkRegistrationService.pefromValidateExtractFile(bulkRegistrationForm);
        LOG.debug("Leavinging validateExtract ");
        return BULK_REGISTRATION_PAGE;

    }

    /**Author:Sumanta--ValidateAndExtract tab 
     * This method trigger  push to DB.
     * @param bulkRegistrationForm
     * @return
     * @throws Exception
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_VALIDATE_PUSH_TO_DB)
    @RequestMapping(method = { RequestMethod.POST }, value = "/ValidateAndDataExtraction",
                    params = "PushToDatabase=Push To Database")
    public String validateExtractPushToDB(@Valid@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE) BulkRegistrationForm bulkRegistrationForm,BindingResult result) throws Exception {
        LOG.debug("entering validateExtractPushToDB ");
        if (result.hasErrors()) {
           LOG.debug("  Inside validateExtractPushToDB has errors");
            return BULK_REGISTRATION_PAGE;
        }
        bulkRegistrationService.triggerdataExtract(bulkRegistrationForm);
        LOG.debug("Leavinging validateExtractPushToDB ");
        return BULK_REGISTRATION_PAGE;

    }

    /** Author:Sumanta--ValidateAndExtract tab output link for validate
     *USed to download file from the output link
     * @param bulkRegistrationForm
     * @return
     * @throws Exception
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_OUTPIT_LINK_VALIDATE_EXTRACT)
    @RequestMapping(method = { RequestMethod.POST }, value = "/ValidateAndDataExtraction",
                    params = "OutputLinkSubmitValidateExtarction=OutputLinkSubmitValidateExtarction")
    public String validateExtractOutputLinkWindow(@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE)
                                                  BulkRegistrationForm bulkRegistrationForm,
                                                  HttpServletResponse response) throws Exception {
        LOG.debug("entering validateExtractOutputLinkWindow ");
        //calling service layer  to copy the local from linux box
        bulkRegistrationForm.setValidateDataExtract(VALIDATE_EXTRACT_OUTPUT);
        bulkRegistrationService.copyFiletoLocal(bulkRegistrationForm);
        LOG.debug("file copy status:::" + bulkRegistrationForm.getValidateExtractDownloadStatus());
        if (!(bulkRegistrationForm.getValidateExtractDownloadStatus() > 0)) {
            String outputString = bulkRegistrationService.getFileAsString(bulkRegistrationForm.getFileName());

            //setting response header Content-disposition as  attachment; so that it gets downloaded
            response.setHeader("Content-disposition",
                               "attachment; filename=\"" + bulkRegistrationForm.getFileName() + "\"");
            try {
                OutputStream outputStream = response.getOutputStream();
                outputStream.write(outputString.getBytes());
                outputStream.flush();
                outputStream.close();
                response.flushBuffer();
                return null;
            } catch (Exception e) {

                LOG.fatal("Exception... ", e);
            } finally {
                bulkRegistrationService.performRemoveFile(bulkRegistrationForm.getFileName());
            }
            LOG.debug("leaving validateExtractOutputLinkWindow ");
        }
        return BULK_REGISTRATION_PAGE;

    }



    /** Author:Sumanta--ValidateAndExtract tab output link for PushToDB
     *USed to download file from the output link
     * @param bulkRegistrationForm
     * @return
     * @throws Exception
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_OUTPIT_LINK_PUSH_TO_DB)
    @RequestMapping(method = { RequestMethod.POST }, value = "/ValidateAndDataExtraction",
                    params = "OutputLinkSubmitDataExtract=OutputLinkSubmitDataExtract")
    public String pushToDBOutputLinkWindow(@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE)
                                                  BulkRegistrationForm bulkRegistrationForm,
                                                  HttpServletResponse response) throws Exception {
        LOG.debug("entering pushToDBOutputLinkWindow ");
        //calling service layer  to copy the local from linux box
        LOG.debug("file name:::"+bulkRegistrationForm.getFileName());
        bulkRegistrationForm.setValidateDataExtract(PUSH_TO_DB_OUTPUT);
        bulkRegistrationService.copyFiletoLocal(bulkRegistrationForm);
        LOG.debug("file copy status:::" + bulkRegistrationForm.getValidateExtractDownloadStatus());
        if (!(bulkRegistrationForm.getValidateExtractDownloadStatus() > 0)) {
            String outputString = bulkRegistrationService.getFileAsString(bulkRegistrationForm.getFileName());
            
            //setting response header Content-disposition as  attachment; so that it gets downloaded
            response.setHeader("Content-disposition",
                               "attachment; filename=\"" + bulkRegistrationForm.getFileName() + "\"");
            try {
                OutputStream outputStream = response.getOutputStream();
                outputStream.write(outputString.getBytes());
                outputStream.flush();
                outputStream.close();
                response.flushBuffer();
                return null;
            } catch (Exception e) {

                LOG.fatal("Exception... ", e);
            } finally {
                bulkRegistrationService.performRemoveFile(bulkRegistrationForm.getFileName());
                
            }
            LOG.debug("leaving pushToDBOutputLinkWindow ");
        }
        return BULK_REGISTRATION_PAGE;

    }


    /**
     * This method triggers the stop validate ihi info.
     * @param bulkRegistrationForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_VALIDATE_STOP)
    @RequestMapping(method={RequestMethod.POST},value="/BulkRegistrationValidateIHI" , params="validateIHIInfoStop=Stop")
    public String validateExtractStop(@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE) BulkRegistrationForm bulkRegistrationForm, ModelMap map) throws RecoveryServiceException {
        LOG.debug("Entering Bulk regisration Validate IHI Info.");
        bulkRegistrationService.validateIHIInfoStop(bulkRegistrationForm);
        map.addAttribute("validateIHISuccess", ValidateIhiStopMessage);
        return BULK_REGISTRATION_PAGE; 
    } 

    /**
     * This method triggers the validate ihi info.
     * @param bulkRegistrationForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_VALIDATE)
    @RequestMapping(method={RequestMethod.POST},value="/BulkRegistrationValidateIHI")
    public String validateExtract(@Valid@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE) BulkRegistrationForm bulkRegistrationForm,BindingResult result, ModelMap map) throws RecoveryServiceException {
        LOG.debug("Entering Bulk regisration Validate IHI Info.");
        
        if (result.hasErrors()) {
           LOG.debug("Inside has errors");
          LOG.debug("validate IHI action:::"+bulkRegistrationForm.getValidateAction());
            return BULK_REGISTRATION_PAGE;
        }
        bulkRegistrationService.validateIHIInfo(bulkRegistrationForm);
        map.addAttribute("validateIHISuccess", validateIhiSucessMessage);
        return BULK_REGISTRATION_PAGE; 
    } 
    
    
        
    /**
     * Controller for  record creation.
     * @param bulkRegistrationForm
     * @param result
     * @return
     * @throws RecoveryServiceException
     */
        @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_RECORD_CREATION_STOP)
        @RequestMapping(method={RequestMethod.POST},value="/BulkRegistrationRecordCreation" , params="bulkRecordCreationStop=Stop")
        public String bulkRegistrationRecordCreationStop(@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE)BulkRegistrationForm bulkRegistrationForm, BindingResult result, ModelMap map) throws RecoveryServiceException {
            LOG.debug("Inside bulkRegistrationRecordCreationStop");
            bulkRegistrationService.bulkRecordCreationStop(bulkRegistrationForm);
            map.addAttribute("bulkRecordCreationSuccess", bulkRecordStopMessage);
            return BULK_REGISTRATION_PAGE;
        }
      
        
    /**
     * Controller for  record creation.
     * @param bulkRegistrationForm
     * @param result
     * @return
     * @throws RecoveryServiceException
     */
        @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_RECONSILE_DATA)
        @RequestMapping(method={RequestMethod.POST},value="/BulkRegistrationRecordCreation")
        public String bulkRegistrationRecordCreation(@Valid@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE)BulkRegistrationForm bulkRegistrationForm, BindingResult result, ModelMap map) throws RecoveryServiceException {
            LOG.debug("Inside bulkRegistrationRecordCreation");
            if (result.hasErrors()) {
               LOG.debug("Inside has errors");
                return BULK_REGISTRATION_PAGE;
            }
            bulkRegistrationService.bulkRecordCreationService(bulkRegistrationForm);
            map.addAttribute("bulkRecordCreationSuccess", bulkRecordSuccessMessage);
            return BULK_REGISTRATION_PAGE;
        }
        
        
    /**
     * Controller for Validate and record creation.
     * @param bulkRegistrationForm
     * @param result
     * @return
     * @throws RecoveryServiceException
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_RECORD_VALIDATE_AND_CREATION_STOP)
    @RequestMapping(method={RequestMethod.POST},value="/validateAndCreateRecord",params="validateAndCreateStop=Stop")
    public String validateAndCreateRecordStop(@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE)BulkRegistrationForm bulkRegistrationForm, BindingResult result, ModelMap map) throws RecoveryServiceException {
        LOG.debug("Inside validateAndCreateRecordStop");
        bulkRegistrationService.validateAndRecordCreationStop(bulkRegistrationForm);
        map.addAttribute("validateAndCreateSuccessMessage", validateAndCreateStopMessage);
        return BULK_REGISTRATION_PAGE;
    }
    /**
     * Controller for Validate and record creation.
     * @param bulkRegistrationForm
     * @param result
     * @return
     * @throws RecoveryServiceException
     */
        @AuditBefore(AuditMessageConstants.VALIDATE_AND_BULK_RECORD_CREATION)
        @RequestMapping(method={RequestMethod.POST},value="/validateAndCreateRecord")
        public String validateAndCreateRecord(@Valid@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE)BulkRegistrationForm bulkRegistrationForm, BindingResult result, ModelMap map) throws RecoveryServiceException {
            if (result.hasErrors()) {
               LOG.debug("Inside has errors");
                return BULK_REGISTRATION_PAGE;
            }
            bulkRegistrationService.validateAndRecordCreationService(bulkRegistrationForm);
            map.addAttribute("validateAndCreateSuccessMessage", validateAndCreateSuccessMessage);
            return BULK_REGISTRATION_PAGE;
       
    }

   
    /**
     *yet to start
     * @param bulkRegistrationForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_RECONSILE_DATA)
    @RequestMapping(method = { RequestMethod.POST }, value = "/GenerateReportCntrl")
    public ModelAndView generateReport(@ModelAttribute(BULK_REGISTRATION_ATTRIBUTE)BulkRegistrationForm bulkRegistrationForm,
                                   BindingResult result, HttpServletResponse response) throws RecoveryDAOException,
                                                                            RecoveryServiceException {
        
        if (result.hasErrors()) {
            LOG.debug("Inside has errors");
            LOG.info("......" + result.getAllErrors());
            return new ModelAndView(BULK_REGISTRATION_PAGE);
        }
        bulkRegistrationForm = bulkRegistrationService.executeReconcileReport(bulkRegistrationForm);
        Date date = new Date();
        DateTimeUtil fd=new DateTimeUtil();
        String currentDate = fd.getFormattedDate(date,"yyyyMMddhhmmss");
        Workbook wb =  bulkRegistrationReconcileReportView.buildExcelDocument(bulkRegistrationForm);
        if("reconcileRepo".equals(bulkRegistrationForm.getReconReportType())){
            response.setHeader("Content-disposition",
                               "attachment; filename=ReconciliationReport"+currentDate+".xlsx");
        }else if("discrepancyRepo".equals(bulkRegistrationForm.getReconReportType())){
            response.setHeader("Content-disposition",
                               "attachment; filename=DiscrepancyReport"+currentDate+".xlsx");
        }
        //response.setHeader("Content-disposition",
       //                    "attachment; filename=ReconcileDataReport"+FD+".xlsx");
        try {
            OutputStream outputStream = response.getOutputStream();
            wb.write(outputStream);
            
            outputStream.flush();
            outputStream.close();
            response.flushBuffer();
            return null;
        } catch (Exception e) {
            LOG.fatal("Exception... ", e);
            throw new RecoveryServiceException(e);
        }
    }


    /**
         * This method triggers the validate ihi info.
         * @param bulkRegistrationForm
         * @return
         */
        @AuditBefore(AuditMessageConstants.BULK_REGISTRATION_STATUS)
        @RequestMapping(method = { RequestMethod.POST }, value = "/BulkRegistrationStatus")
        public ModelAndView status(@Valid @ModelAttribute("bulkRegistrationAttribute")
                                   BulkRegistrationForm bulkRegistrationForm,
                                   BindingResult result, HttpServletResponse response) throws RecoveryServiceException {
            LOG.debug("Entering Bulk regisration Status.");
            if (result.hasErrors()) {
                LOG.debug("Inside has errors");
                LOG.info("......" + result.getAllErrors());
                return new ModelAndView(BULK_REGISTRATION_PAGE);
            }
            bulkRegistrationForm = bulkRegistrationService.bulkRegStatus(bulkRegistrationForm);

           Workbook wb =  bulkRegistrationStatusView.buildExcelDocument(bulkRegistrationForm.getBulkGenerationStatusReport(),bulkRegistrationForm.getStatusAction());
            response.setHeader("Content-disposition",
                               "attachment; filename=StatusReport.xlsx");
            try {
                OutputStream outputStream = response.getOutputStream();
                wb.write(outputStream);
                
                outputStream.flush();
                outputStream.close();
                response.flushBuffer();
                return null;
            } catch (Exception e) {
                LOG.fatal("Exception... ", e);
                throw new RecoveryServiceException(e);
                
            }
    }

    /**
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exception(ServiceException ex) {
        LOG.info("doaexception handler......");
        ModelAndView model = new ModelAndView(BULK_REGISTRATION_PAGE);
        model.addObject("errorMsg", ex.getMessage());
        LOG.debug("ex.getMessage().............." + ex);
        return model;
    }

    /**
     *
     * @return
     * @throws Exception
     */
    @ModelAttribute("ValidateIHIInfo")
    public List<String> validateIHIInfo() throws Exception {
        List<String> validateIHIInfo = new ArrayList<String>();

        validateIHIInfo.add(VALIDATE_IHI_INFO_VAL1);
        validateIHIInfo.add(VALIDATE_IHI_INFO_VAL2);
        validateIHIInfo.add(VALIDATE_IHI_INFO_VAL3);

        return validateIHIInfo;
    }
   
    
    //Action dropdown of 'Validate and Bulk Record Creation' Tab
    @ModelAttribute("ValidateAndBulkRecordCreation")
    public List<String> validateAndBulkRecordCreation() throws Exception {
        
        List<String> validateAndBulkList = new ArrayList<String>();
        validateAndBulkList.add(VALIDATE_BULK_ANDRECORD_VAL1);
        validateAndBulkList.add(VALIDATE_BULK_ANDRECORD_VAL2);
        validateAndBulkList.add(VALIDATE_BULK_ANDRECORD_VAL3);

        return validateAndBulkList;
    }
  
    /**
     *
     * @return
     * @throws Exception
     */
    @ModelAttribute("BulkRecordCreation")
    public List<String> bulkRecordCreation() throws Exception {
        List<String> bulkRecordList = new ArrayList<String>();

        bulkRecordList.add(BULK_RECORD_VAL1);
        bulkRecordList.add(BULK_RECORD_VAL2);
        bulkRecordList.add(BULK_RECORD_VAL3);
        return bulkRecordList;
    }
 
    /**
     * 
     * @return
     * @throws Exception
     */
    @ModelAttribute("StatusTab")
    public List<String> satusTab() throws Exception {
        List<String> statusTabList = new ArrayList<String>();

        statusTabList.add(STATUS_TAB_VAL1);
        statusTabList.add(STATUS_TAB_VAL2);
        statusTabList.add(STATUS_TAB_VAL3);

        return statusTabList;
    }

    /**
     *
     * @return
     */
    @ModelAttribute("ReconcileDistinctErrorCode")
    public List<String> getDistinctErrorCode(){
        
        return bulkRegistrationService.getDistinctErrorCode();
    }

}
