 package au.gov.doha.pcehr.recovery.controller;

import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.exception.RecoveryServiceException;
import au.gov.doha.pcehr.recovery.form.ProviderRegistrationOIDForm;
import au.gov.doha.pcehr.recovery.service.ProviderRegistrationOIDService;
import au.gov.doha.pcehr.recovery.validation.ProviderRegistrationOIDValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Controller class to perform all ProviderRegistrationOID related task.
 * Redirects to Provider Registration operations and later on submit to Provider Registration OID List.
 * @Since Apr 2015
 * @Author Dinesh Kaki, Operations, PCEHR
 * @version Change-x
 */
@Controller
@RequestMapping("/ProviderRegistrationOID**")
public class ProviderRegistrationOIDController {
        
        private static Logger LOG = Logger.getLogger(ProviderRegistrationOIDController.class);
        private static final String MAIN_PAGE_LINK = "/NIO/ProviderRegistrationOID";
        private static final String MODEL_ATTRIBUTE = "ProviderRegistrationOIDForm";
        private static final String FINAL_PAGE_LINK = "/NIO/ProviderRegistrationOIDList";
        private static final String PAGE_EXCEPTION = "NIO/Exception";
       

        @Autowired
        private ProviderRegistrationOIDService providerRegistrationOIDService;

        @Autowired
        private ProviderRegistrationOIDValidator  providerRegistrationOIDValidator;

        @InitBinder
        protected void initBinder(WebDataBinder binder) {
            binder.setValidator(providerRegistrationOIDValidator);
        }
         
     /**
     * This method is called when user clicks on Provider Registration in Work around menu section.
     * @param providerRegistrationOIDForm
     * @return
     */
     @AuditBefore(AuditMessageConstants.PROVIDER_REGISTRATION_OID_LANDINGPAGE)
        @RequestMapping(method = { RequestMethod.GET }, value = "/ ProviderRegistrationOID")
        public String ProviderRegistrationOIDMenu(@ModelAttribute(MODEL_ATTRIBUTE)
            ProviderRegistrationOIDForm  providerRegistrationOIDForm) {
            LOG.debug("Inside  provider Registration page");
            return MAIN_PAGE_LINK;
        }

     /**
     * This method is called when user clicks submit in the Workaround Operations section.
     * @param providerRegistrationOIDForm
     * @param result
     * @return
     * @throws RecoveryDAOException
     */
     @AuditBefore(AuditMessageConstants.GET_PROVIDER_REGISTRATION_OID_LIST)
        @RequestMapping(method = RequestMethod.POST, params ="ProviderRegistrationOIDSubmit=Submit")
        public String getProviderRegistrationOIDList(@Valid
            @ModelAttribute(MODEL_ATTRIBUTE)
            ProviderRegistrationOIDForm providerRegistrationOIDForm, BindingResult result) throws RecoveryDAOException,
                                                                              RecoveryServiceException {
            LOG.debug("After clicking submit");
            if (result.hasErrors()) {
                LOG.debug("Returning page to enter Date and errors -->" + result.hasErrors());
                return MAIN_PAGE_LINK;
            }
            LOG.debug("No Errors");
            providerRegistrationOIDForm = providerRegistrationOIDService.providerRegistrationOIDServiceMethod(providerRegistrationOIDForm);
            LOG.debug("Leaving Controller Class ");
            return FINAL_PAGE_LINK;
        }

        /**
         * This method is called when ServiceException occurs.
         * @param ex
         * @return model
         */
        @ExceptionHandler(Exception.class)
        public ModelAndView exception(Exception e) {
            LOG.info("DAO_Exception handler......");
            ModelAndView model = new ModelAndView(PAGE_EXCEPTION);
            model.addObject("errorMsg", e.getMessage());
            LOG.debug("e.getMessage().............." + e.getMessage());
            return model;
        }

}
