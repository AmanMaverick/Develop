package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.PNAStatusActiveInactiveBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.service.PNAStatusActiveInactiveService;

import javax.servlet.http.HttpServletRequest;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * The PNAStatusActiveInactive Controller is used to render
 * and perform operation for PCEHR Record Status Update Page.
 *
 * @author : VIkash Kumar Singh(10994193)
 * @since : 11 Aug 2014
 */
@Controller
public class PNAStatusActiveInactiveController {
    
    private static Logger LOG = Logger.getLogger(PNAStatusActiveInactiveController.class);
    
    @Autowired
    private PNAStatusActiveInactiveService pnaStatusActiveInactiveService;
    
//    @Autowired
//    @Qualifier("pnaStatuActiveInactiveValidaor")
//    private PNAStatuActiveInactiveValidator pnaStatuActiveInactiveValidator;
//    
//      @InitBinder("PNAStatusActiveInactiveBO")
//      protected void initBinder(WebDataBinder binder) {
//          binder.setValidator(pnaStatuActiveInactiveValidator);
//      }
    
    /**
     *
     * @param pnaStatusActiveInactiveBO
     * @return String
     * @see PCEHR Record Status Update Page
     */
     @AuditBefore(AuditMessageConstants.PNA_STATUS_UPDATE_PAGE)
    @RequestMapping(value="/PnaActiveInactiveCtrl", method=RequestMethod.GET)
    public String PnaActiveInactiveCtrl(@ModelAttribute("PNAStatusActiveInactiveBO" )PNAStatusActiveInactiveBO pnaStatusActiveInactiveBO){
        return "NIO/PnaActiveInactive";
    }
    
    /**
     *
     * @param request
     * @param pnaStatusActiveInactiveBO
     * @param map
     * @exception
     * @return 
     * @see PCEHR Record Status Update Page
     */
    @AuditBefore(AuditMessageConstants.PNA_STATUS_UPDATE_OPERATION)
    @RequestMapping(value="/pNAStatusActiveInactive", method=RequestMethod.POST)
    public String PNAStatusActiveInactive(@Valid @ModelAttribute("PNAStatusActiveInactiveBO" )PNAStatusActiveInactiveBO pnaStatusActiveInactiveBO,
                                         BindingResult result, HttpServletRequest request, ModelMap map){
        if (result.hasErrors()) {
            LOG.info("......"+result.hasErrors() + result.toString());
            return "NIO/PnaActiveInactive";
        }
        pnaStatusActiveInactiveBO.setInactiveReason(pnaStatusActiveInactiveBO.getReason());
        pnaStatusActiveInactiveBO.setOperatorName(pnaStatusActiveInactiveBO.getChangeBy());
        try{
            pnaStatusActiveInactiveBO = pnaStatusActiveInactiveService.getService(pnaStatusActiveInactiveBO);
            map.addAttribute("pnaStatusActiveInactiveBO", pnaStatusActiveInactiveBO);
        } catch (Exception e) {
            return "NIO/PnaActiveInactive";
        }
            return "NIO/PnaActiveInactive";
    }
}
