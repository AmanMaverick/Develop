package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.DocumentTransformationForm;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.dao.DocumentTransformationDAO;
import au.gov.doha.pcehr.recovery.service.DocumentTransformationService;
import au.gov.doha.pcehr.recovery.util.FileUtil;
import au.gov.doha.pcehr.recovery.validation.DocumentTransformationValidator;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;


/**
 * Controller to perform all DocTransformation related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 29 Dec 2014
 * @version Change-x
 */
@Controller
public class DocTransformationController implements HandlerExceptionResolver{
    public DocTransformationController() {
        super();
    }
    private static final String EXCEPTION_PAGE= "/NIO/Exception";
    private static final String DOCUMENT_TRANSFORMATION_PAGE ="/NIO/DocumentTransformationMain";
    private static final String DOCUMENT_TRANSFORMATION_ATTRIBUTE="DocumentTransformationAttribute";    

    private static Logger LOG = Logger.getLogger(DocTransformationController.class);
    @Autowired
    private DocumentTransformationService documentTransformationService;
    
    @Autowired
    @Qualifier("documentTransformationValidator")
    private DocumentTransformationValidator documentTransformationValidator;

    @InitBinder(DOCUMENT_TRANSFORMATION_ATTRIBUTE)
    protected void initBinderMetricTypeConfig(WebDataBinder binder) {
        binder.setValidator(documentTransformationValidator);
    }
    /**
     *to navigate the DocumentTransformationMain page
     * @param documentTransformationForm
     * @return
     */
    @AuditBefore(AuditMessageConstants.DOC_TRANSFORMATION_LANDING_PAGE)
    @RequestMapping(method = { RequestMethod.GET }, value = "/DocumentTransformationCntrl")
    public String loadMainPage (@ModelAttribute(DOCUMENT_TRANSFORMATION_ATTRIBUTE)
        DocumentTransformationForm documentTransformationForm){
        
        LOG.debug("here inside documentTransformationForm..");
       
        return DOCUMENT_TRANSFORMATION_PAGE;
    }
    /**
     *To perform the document Trafsformation functionality
     * @param documentTransformationForm
     * @param file
     * @return
     * @throws IOException
     */
     @AuditBefore(AuditMessageConstants.DOC_TRANSFORMATION_OPERATION)
    @RequestMapping(method = { RequestMethod.POST }, value="/docTransformationResults" )
    public String performDocTransformation(@Valid 
        @ModelAttribute(DOCUMENT_TRANSFORMATION_ATTRIBUTE)
        DocumentTransformationForm documentTransformationForm,BindingResult documentTransformationResult,@RequestParam("file") MultipartFile file,HttpServletResponse response,ModelMap map) throws IOException {
        FileUtil fileUtility = new FileUtil();
        LOG.debug("inside.... performDocTransformation");
        LOG.debug("enetring performDocTransformation.."+file.getName());
        if (documentTransformationResult.hasErrors()) {
          
            LOG.debug("validation error for performDocTransformation ...");
            return DOCUMENT_TRANSFORMATION_PAGE;
        }
        try{
            long lStartTime = new Date().getTime();
        MultipartFile a=documentTransformationForm.getFile();
        LOG.debug("enetring performDocTransformation..aaaaa"+a.getName());
        LOG.debug("enetring performDocTransformation..aaaaa"+documentTransformationForm.getDocumentType());
        
         documentTransformationForm=  documentTransformationService.performDocumentTransformation(documentTransformationForm);
       //
        
       
        if(documentTransformationForm.getZippedFileList()!=null){   
        LOG.debug("number of Zipped folder created in controller :::"+documentTransformationForm.getZippedFileList().size());
        
        }
            
            long lEndTime = new Date().getTime();
             
                    long difference = lEndTime - lStartTime;
            LOG.debug("time taken for the whole process in milliseconds::::......."+difference);
            
        }catch(Exception e){
            LOG.fatal("EXCEPTION occured..",e);
        }
        //
        //for the error csv download
         
       
         
         
     
        LOG.debug("leaving performDocTransformation");
     
        return DOCUMENT_TRANSFORMATION_PAGE;
    }
    /**
     *used to perform creating a list of Document Types which will be shown in the main page
     * @return
     * @throws Exception
     */
        @ModelAttribute("DocumentTypeAvailableList")
        public List<String> documentTypeAvailableList() throws Exception {
    DocumentTransformationDAO dao=new DocumentTransformationDAO();
  //  List<String> docEntry=dao.getDisplayClassCodeValues();
    List<String> documentTypeAvailableL = new ArrayList<String>();
    documentTypeAvailableL=dao.getDisplayClassCodeValues();
   
    if(documentTypeAvailableL!=null && documentTypeAvailableL.size()>0){
        LOG.debug("doc entry...."+documentTypeAvailableL.size());
    for(int i=0;i<documentTypeAvailableL.size();i++){
        LOG.debug("doc entry....values..."+documentTypeAvailableL.get(i));
    }
    }
            LOG.debug("here inside documentTypeAvailableList..");
           
            

            LOG.debug("leaving documentTypeAvailableList...");
            
            return documentTypeAvailableL;
}
    


/**
     *
     * @param httpServletRequest
     * @param httpServletResponse
     * @param object
     * @param exception
     * @return
     */
    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest,
      
                                         HttpServletResponse httpServletResponse, Object object, Exception exception) {
        LOG.info("doaexception handler......");
        Map<Object, Object> model = new HashMap<Object, Object>();
        ModelAndView modelandView = new ModelAndView(EXCEPTION_PAGE);
        if (exception instanceof MaxUploadSizeExceededException){
                          LOG.info("doaexception handler......1");
                       ModelAndView modelandViewFile = new ModelAndView(EXCEPTION_PAGE);
                         modelandViewFile.addObject("exception","File size exceeded the limit");  
                       
                                                  
                          return modelandViewFile;
                      } else{
                          modelandView.addObject("exception","Unexpected error: ");  
                         // model.put("errors", "Unexpected error: " + exception.getMessage());
                          return modelandView;
                      }
      
    
    }
}
