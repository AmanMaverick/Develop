package au.gov.doha.pcehr.recovery.controller;


import au.gov.doha.pcehr.recovery.audit.AuditBefore;
import au.gov.doha.pcehr.recovery.bo.ConfigureEndpointsBO;
import au.gov.doha.pcehr.recovery.constants.AuditMessageConstants;
import au.gov.doha.pcehr.recovery.service.ConfigureEndpointsService;
import au.gov.doha.pcehr.recovery.validation.ConfigureEndpointsValidator;

import javax.validation.Valid;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Controller  to perform all Configure  related task
 * @Author Sumanta Kumar Saha, Operations, PCEHR
 * @since 10 April 2015
 * @version Change-x
 */
@Controller
public class ConfigureEndpointsController {
    public ConfigureEndpointsController() {
        super();
    }
    private static final String CONFIGURE_ENDPOINTS_URL="NIO/ConfigureEndPointsHome";
    private static Logger LOG = Logger.getLogger(ConfigureEndpointsController.class);
    @Autowired
    @Qualifier("configureEndpointsValidator")
    private ConfigureEndpointsValidator configureEndpointsValidator;
    
    @InitBinder("ConfigureEndPointsAttribute")
    protected void initBinderMetricTypeConfig(WebDataBinder binder) {
        binder.setValidator(configureEndpointsValidator);
    }
    
    @Autowired
    private ConfigureEndpointsService configureEnpointsService;
    
    @AuditBefore(AuditMessageConstants.CONFIGURATION_ENDPOINT_PAGE)
    @RequestMapping(method={RequestMethod.GET},value="/ConfigureEndPointsCntrl")
    public String loadConfigureEnpoints(ModelMap map){
        LOG.debug("entering loadConfigureEnpoints..");
        ConfigureEndpointsBO configureEndpointsBO = new ConfigureEndpointsBO();
        configureEndpointsBO=  configureEnpointsService.getPropertiesValues(configureEndpointsBO);
        map.addAttribute("ConfigureEndPointsAttribute", configureEndpointsBO);
        LOG.debug("model attribute value..."+configureEndpointsBO.getAuditInsert());
        LOG.debug("leaving loadConfigureEnpoints..");
        return CONFIGURE_ENDPOINTS_URL;
    }
    /**
     *
     * @return
     */
    @AuditBefore(AuditMessageConstants.CONFIG_ENDPOINT_UPDATE_OPERATION)
    @RequestMapping(method={RequestMethod.POST},value="/configureEndPointsResult")
    public String performEnpoinstUpdate(@Valid @ModelAttribute("ConfigureEndPointsAttribute") ConfigureEndpointsBO configureEndpointsBO, BindingResult configureEndpointsResults){
        LOG.debug("entering performEnpoinstUpdate..");
        if(configureEndpointsResults.hasErrors()){
            LOG.debug("error in validation " ); 
            return CONFIGURE_ENDPOINTS_URL;
        }
        configureEndpointsBO=configureEnpointsService.updateEndpoints(configureEndpointsBO);
        
        LOG.debug("entering performEnpoinstUpdate..");
        return CONFIGURE_ENDPOINTS_URL;
    }
    
    
}
