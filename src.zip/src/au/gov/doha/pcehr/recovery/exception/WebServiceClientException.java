package au.gov.doha.pcehr.recovery.exception;


public class WebServiceClientException extends Exception{
    public WebServiceClientException(Throwable throwable) {
        super(throwable);
    }
    public WebServiceClientException(String string, Throwable throwable) {
        super(string, throwable);
    }

    public WebServiceClientException(String string) {
        super(string);
    }

    public WebServiceClientException() {
        super();
    }
}
