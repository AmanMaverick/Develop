package au.gov.doha.pcehr.recovery.exception;


public class RecoveryServiceException extends Exception {
    public RecoveryServiceException(Throwable throwable) {
        super(throwable);
    }

    public RecoveryServiceException(String string, Throwable throwable) {
        super(string, throwable);
    }

    public RecoveryServiceException(String string) {
        super(string);
    }

    public RecoveryServiceException() {
        super();
    }
}
