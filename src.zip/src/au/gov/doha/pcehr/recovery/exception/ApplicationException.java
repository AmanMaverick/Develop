package au.gov.doha.pcehr.recovery.exception;


public class ApplicationException extends Exception{
    private static final long serialVersionUID = 2679373303491050733L;
    public ApplicationException(String message, Throwable t){
          super(message, t);
    }
    
    public ApplicationException(String message){
     super(message);
    }
}
