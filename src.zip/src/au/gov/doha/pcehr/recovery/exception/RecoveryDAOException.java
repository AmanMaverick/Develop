package au.gov.doha.pcehr.recovery.exception;


public class RecoveryDAOException extends Exception {
    public RecoveryDAOException(Throwable throwable) {
        super(throwable);
    }

    public RecoveryDAOException(String string, Throwable throwable) {
        super(string, throwable);
    }

    public RecoveryDAOException(String string) {
        super(string);
    }

    public RecoveryDAOException() {
        super();
    }
}
