package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.form.AuditEntryMissingForm;
import au.gov.doha.pcehr.recovery.util.FileUtil;

import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * This validates the AuditEntryMissing page fields.
 */
public class AuditEntryMissingValidator implements Validator{   
    private static Logger LOG = Logger.getLogger(AuditEntryMissingValidator.class);
    
    @Autowired
    private FileUtil fileUtil;
        
    @Override
    public boolean supports(Class<?> class1) {
        return AuditEntryMissingForm.class.equals(class1);
    }
    
    /**
     * Validate method is overriden to validate the AuditEntryMissing fields.
     * @param object
     * @param errors
     */
    @Override
    public void validate(Object object, Errors errors) {
        LOG.info("Entered into the validate method");
        if(object instanceof AuditEntryMissingForm ){
            AuditEntryMissingForm auditEntryMissingForm = (AuditEntryMissingForm)object;
            try{
                if(auditEntryMissingForm.getDataFix()==null || auditEntryMissingForm.getDataFix().isEmpty()){
                    errors.rejectValue("dataFix","AuditEntryMissingAttribute.dataFix");
                }else{
                    LOG.info("One of the radiobutton is selected");
                }
                String fileName = auditEntryMissingForm.getFile().getOriginalFilename();
                if(auditEntryMissingForm.getFile().getSize()!=0){
                    LOG.info("Validate the csv file");
                    errors = validateAuditEntryMissingFile(auditEntryMissingForm,errors);
                }else if(fileName.equals("")){
                    errors.rejectValue("file","AuditEntryMissingAttribute.file");
                }else if(auditEntryMissingForm.getFile() != null){
                    List<String> docIdList = fileUtil.createList(auditEntryMissingForm.getFile());
                    if(docIdList.size() == 0){
                        errors.rejectValue("file","AuditEntryMissingAttribute.emptyFile");
                    }
                }
                
            }catch(Exception e){
                LOG.error("Exception occured",e);
            }
            
        }
        
    }
    
    /**
     * This method validates the uploaded file.
     * @param auditEntryMissingForm
     * @param errors
     * @return
     */
    private Errors validateAuditEntryMissingFile(AuditEntryMissingForm auditEntryMissingForm, Errors errors) throws Exception{
        String fileName = auditEntryMissingForm.getFile().getOriginalFilename();
        if(fileName.equals("")){
            LOG.info("File not found");
        }else if(!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv")){
            LOG.info("File format is not CSV");
            errors.rejectValue("file","AuditEntryMissingAttribute.InvalidFile");
        }else if(auditEntryMissingForm.getFile().getSize()>1000000){
            LOG.info("File size validation failed.");
            errors.rejectValue("file","AuditEntryMissingAttribute.InvalidFileSize");
        }else{
            LOG.info("file size :: "+auditEntryMissingForm.getFile().getSize());
        }
        
        return errors;        
    }
}
