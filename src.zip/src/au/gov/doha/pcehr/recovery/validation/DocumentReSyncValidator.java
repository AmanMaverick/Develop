package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.form.DocumentReSyncForm;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class DocumentReSyncValidator implements Validator {
    
    private static Logger LOG = Logger.getLogger(DocumentReSyncValidator.class);

    @Override
    public boolean supports(Class<?> c) {
        // TODO Implement this method
        return DocumentReSyncForm.class.equals(c);
    }

    @Override
    public void validate(Object object, Errors errors) {
        if(object instanceof DocumentReSyncForm){
            DocumentReSyncForm docReSyncObject = (DocumentReSyncForm)object;
            errors = validateDocumentReSync(docReSyncObject, errors);
        }else{
            LOG.fatal("");
            throw new IllegalArgumentException();
        }

    }

    private Errors validateDocumentReSync(DocumentReSyncForm docReSyncObject, Errors errors) {
        String fileName = docReSyncObject.getFile().getOriginalFilename();
        int fileSize = (int) docReSyncObject.getFile().getSize();
        if(fileName.equals("")){
            LOG.debug("File not found");
            errors.rejectValue("file", "ARTExtractionBO.fileNotFound");
        }else if (!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv")) {
            LOG.debug("file name validation failed");
            errors.rejectValue("file", "ARTExtractionBO.invalidFile");
        }else if(fileSize >= 0 && fileSize > 1000000){
            LOG.debug("FIle size validation failed");
            errors.rejectValue("file", "ARTExtractionBO.invalidFileSize");
        }
        return null;
    }
}
