package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.EmergencyExpiryForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


/**
 * Validates Date for Emergency Access Expiry by checking for empty date block and invalid date
 * @author Dinesh Kaki, Operations, PCEHR
 * @Since Jan 2015
 * @version Change-x
 */

public class EmergencyAccessExpiryValidator implements Validator {

    private static Logger LOG = Logger.getLogger(EmergencyAccessExpiryValidator.class);
    private static final String DATE_FORMAT="dd/MM/yyyy";
    
    @Autowired
    @Qualifier("dateTimeUtil")
    private DateTimeUtil dateTimeUtil;

    /**
     * Overriding supports method from Validator Interface
     * @param class1
     * @return
     */
    @Override
    public boolean supports(Class<?> class1) {
        return EmergencyExpiryForm.class.equals(class1);
    }

    /**
     * Overriding validate method from Validator Interface
     * @param object
     * @param errors
     */
    @Override
    public void validate(Object object, Errors errors) {

        if (object instanceof EmergencyExpiryForm) {
            EmergencyExpiryForm form = (EmergencyExpiryForm)object;
            LOG.debug("Validating the EmergencyExpiryBO ");
            try {
                errors = emergencyAccessValidationMethod(form, errors);
            } catch (Exception e) {
                LOG.error("Exception occured", e);
            }
        }
    }

    /**
     * 
     * Calls validatedate method from DateTimeUtil() class and validates date
     * @param form
     * @param errors
     * @return
     * @throws RecoveryDAOException
     */
    private Errors emergencyAccessValidationMethod(EmergencyExpiryForm form, Errors errors) throws RecoveryDAOException {
        LOG.debug("Inside validating Date method...");
        //checking for empty string in date
        
        ValidationUtils.rejectIfEmpty(errors, "date", "EmergencyExpiryBO.date");
        //Validating date format
   
        try{
        if (!dateTimeUtil.validatedate(form.getDate(),DATE_FORMAT)) {
            LOG.debug("DATE......");
            errors.rejectValue("date", "EmergencyExpiryBO.ValidDate");
        }
        }
        catch(Exception e){
            LOG.fatal("Exception inside Validator class.",e );
            throw new RecoveryDAOException(e);
        }
        return errors;
    }
}


