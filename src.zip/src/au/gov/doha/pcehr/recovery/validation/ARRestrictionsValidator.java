package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ARrestrictForm;
import au.gov.doha.pcehr.recovery.util.DateTimeUtil;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class ARRestrictionsValidator implements Validator{
    
    private static Logger LOG = Logger.getLogger(ReactivateAuthRepValidaor.class);
    @Autowired
    @Qualifier("dateTimeUtil")    
    DateTimeUtil dateTimeUtil;
    
    private  final String DATE_FORMAT="dd/MM/yyyy";
    

    
    @Override
    public boolean supports(Class<?> class1) {
        return ARrestrictForm.class.equals(class1);
    }

    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Inside ARRestrictionValidator");
        if(object instanceof ARrestrictForm){
            ARrestrictForm arRestrict = (ARrestrictForm)object;
            
            try{
                //errors = validateARrestrictOperation(arRestrict, errors);
                LOG.debug("Doing input validation for AR Restriction.");
                errors = validateARrestrictOperation(arRestrict, errors); 
            }catch(Exception e){
               LOG.error("Exception occured",e);
            }       
        }else {
            LOG.debug("Invalid parameter !!!");
        }
    }
    
    private Errors validateARrestrictOperation(ARrestrictForm arRestrict,Errors errors) throws RecoveryDAOException {
        LOG.debug("Inside validateARrestrictOperation...");
        //String operationType = arRestrict.getOperationType();
        //Null Validation
        //ValidationUtils.rejectIfEmpty(errors, "IHI", "ARrestrictBO");
        //ValidationUtils.rejectIfEmpty(errors, "expire_date", "ARrestrictBO");
        ValidationUtils.rejectIfEmpty(errors, "jira_id", "ARrestrictBO");
        ValidationUtils.rejectIfEmpty(errors, "operatorName", "ARrestrictBO");
        ValidationUtils.rejectIfEmpty(errors, "userID", "ARrestrictBO");
        if(arRestrict.getOperationType().equals("single")){
           //IHI - 16 digit validation
           ValidationUtils.rejectIfEmpty(errors, "IHI", "ARrestrictBO");
           ValidationUtils.rejectIfEmpty(errors, "expire_date", "ARrestrictBO");
            if(arRestrict.getIHI()!=null && (!arRestrict.getIHI().matches("[0-9]{16}"))){
                LOG.debug("IHI......Match.....");
                errors.rejectValue( "IHI", "ARrestrictBO.ihiLength");
            }
            
            //Date Validation
            boolean dateValidator = dateTimeUtil.validatedate(arRestrict.getExpire_date(), DATE_FORMAT);
            if (!dateValidator) {
                errors.rejectValue( "expire_date", "ARrestrictBO.invalidDate");
            }
        }
        if(arRestrict.getOperationType().equals("bulk")){
            LOG.debug("File Name :: " + arRestrict.getFile().getOriginalFilename());
            String name = arRestrict.getFile().getOriginalFilename();
            if(arRestrict.getFile().getOriginalFilename().equals("")){
                LOG.debug("File not found");
                errors.rejectValue("file", "ARRestriction.fileNotFound");
            }else if (!name.substring(name.indexOf('.'), name.length()).equalsIgnoreCase(".csv")) {
                LOG.debug("file name validation failed");
                errors.rejectValue("file", "ARRestriction.invalidFile");
            }else if(arRestrict.getFile().getSize()>=0 && arRestrict.getFile().getSize()> 1000000){
                LOG.debug("FIle size validation failed");
                errors.rejectValue("file", "ARRestriction.invalidFileSize");
            }
        }
         LOG.debug("Leaving  validateARrestrictOperation !!!");
       return errors;
    }
}
