package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.bo.DocumentReinstateBO;
import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;

import org.apache.log4j.Logger;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


/**
 * @author Sumantha kumar Shaha, Aman Sharma
 * Validates Remove & Re-instate Document data.
 * Validate File Input
 */
public class DocumnetRemovalValidator implements Validator{
    private static Logger LOG = Logger.getLogger(DocumnetRemovalValidator.class);
    private static final String ACTION_REMOVE_DOCUMENT="Remove Document";
    private static final String ACTION_UN_REMOVE_DOCUMENT="Reinstate Document";

    @Override
    public boolean supports(Class<?> class1) {      
        if(DocumentReinstateBO.class.equals(class1)){
            return true;
        }
        
        return DocumentRemovalBO.class.equals(class1);
    }

    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Validating the DocumentRemovalBO");
        DocumentRemovalBO form = (DocumentRemovalBO) object;
       // DocumentReinstateBO form1 = (DocumentReinstateBO) object;
        if(form!=null){
            LOG.debug("Validating the DocumentRemovalBO"+form.getAction());
            if(form.getAction()==null || form.getAction().length()<0){
                ValidationUtils.rejectIfEmpty(errors, "action", "DocumentRemovalAttribute");
            }else if(ACTION_REMOVE_DOCUMENT.equals(form.getAction())){
                LOG.debug("!!!!Inside!!!REMOVE DOC ");
                errors = validateRemove(form,errors);
            }else if(ACTION_UN_REMOVE_DOCUMENT.equals(form.getAction())){
                LOG.debug("!!!!Inside!!!REINSTATE DOC ");
                errors = validateUnRemove(form,errors);
            }
        }
        
        
    }
    
    /**
     * Validates data wrt document removal.
     * @param documentRemovalBO
     * @param errors
     * @return
     */
    private Errors validateRemove(DocumentRemovalBO documentRemovalBO, Errors errors){
        if(documentRemovalBO.getRemovalType().equals("single")){
            LOG.debug("single valdiation...");
            ValidationUtils.rejectIfEmpty(errors, "ihi", "DocumentRemovalAttribute");
            ValidationUtils.rejectIfEmpty(errors, "resonForRemoval", "DocumentRemovalAttribute");
            ValidationUtils.rejectIfEmpty(errors, "documentId", "DocumentRemovalAttribute");
            LOG.debug("IHI length"+documentRemovalBO.getIhi().length());
            if((documentRemovalBO.getIhi()!=null) && !documentRemovalBO.getIhi().matches("[0-9]{16}")){
                LOG.debug("IHI......Match.....");
                errors.rejectValue( "ihi", "DocumentRemovalAttribute.ihiLength");
            }
            
            return errors;
        }
        if(documentRemovalBO.getRemovalType().equals("bulk")){
            //errors.rejectValue( "ihi", "DocumentRemovalAttribute.reinstate");
            LOG.debug("bulk valdiation...");
            ValidationUtils.rejectIfEmpty(errors, "resonForRemoval", "DocumentRemovalAttribute");
            LOG.debug("File Name :: " + documentRemovalBO.getFile().getOriginalFilename());
            String name = documentRemovalBO.getFile().getOriginalFilename();
            if(documentRemovalBO.getFile().getOriginalFilename().equals("")){
                LOG.debug("File not found");
                errors.rejectValue("file", "DocumentRemoval.fileNotFound");
            }else if (!name.substring(name.indexOf('.'), name.length()).equalsIgnoreCase(".csv")) {
                LOG.debug("file name validation failed");
                errors.rejectValue("file", "DocumentRemoval.invalidFile");
            }else if(documentRemovalBO.getFile().getSize()>=0 && documentRemovalBO.getFile().getSize()> 100000){
                LOG.debug("FIle size validation failed");
                errors.rejectValue("file", "DocumentRemoval.invalidFileSize");
            }
            
        }
        LOG.debug("Leaving  DocumnetRemovalValidator !!!");
        return errors;
    }
    
    /**
     * Validates data wrt document unremoval.
     * @param documentRemovalBO
     * @param errors
     * @return
     */
    private Errors validateUnRemove(DocumentRemovalBO documentReinstateBO, Errors errors){
                    if(documentReinstateBO.getRemovalType().equals("single")){
                   LOG.debug("single valdiation...");
           ValidationUtils.rejectIfEmpty(errors, "ihi", "DocumentRemovalAttribute");
           ValidationUtils.rejectIfEmpty(errors, "documentId", "DocumentRemovalAttribute");
               if((documentReinstateBO.getIhi()!=null) && !documentReinstateBO.getIhi().matches("[0-9]{16}")){
                   LOG.debug("IHI......Match.....");
                   errors.rejectValue( "ihi", "DocumentRemovalAttribute.ihiLength");
               }
           return errors;
                   }
                   if(documentReinstateBO.getRemovalType().equals("bulk")){
                            LOG.debug("bulk valdiation...");
                            LOG.debug("File Name :: " + documentReinstateBO.getFile().getOriginalFilename());
                            String name = documentReinstateBO.getFile().getOriginalFilename();
                            if(documentReinstateBO.getFile().getOriginalFilename().equals("")){
                   LOG.debug("File not found");
                   errors.rejectValue("file", "DocumentReinstate.fileNotFound");
               }else if (!name.substring(name.indexOf('.'), name.length()).equalsIgnoreCase(".csv")) {
                   LOG.debug("file name validation failed");
                   errors.rejectValue("file", "DocumentReinstate.invalidFile");
               }else if(documentReinstateBO.getFile().getSize()>=0 && documentReinstateBO.getFile().getSize()> 100000){
                   LOG.debug("FIle size validation failed");
                   errors.rejectValue("file", "DocumentReinstate.invalidFileSize");
               }
                   }
                   LOG.debug("Leaving  DocumnetRemovalValidator !!!");
           return errors;
       }
}
