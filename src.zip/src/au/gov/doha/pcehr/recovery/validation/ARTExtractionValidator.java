package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.exception.RecoveryDAOException;
import au.gov.doha.pcehr.recovery.form.ARTExtractionForm;

import org.apache.log4j.Logger;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;


/**
 * Validator class for ARTExtraction form
 * @Author Vikash Kumar Singh, Operations, PCEHR
 * @since 24th Dec 2014
 * @version Change-x
 */
public class ARTExtractionValidator implements Validator{
    private static Logger LOG = Logger.getLogger(ARTExtractionValidator.class);
    @Override
    public boolean supports(Class<?> class1) {
        return ARTExtractionForm.class.equals(class1);
    }

    /**
     * Doing override validate method from Validator class to do ARTExtraction specific validation
     * @param object
     * @param errors
     */
    @Override
    public void validate(Object object, Errors errors){
        LOG.debug("Validating ARTExtraction");
        if(object instanceof ARTExtractionForm){
            ARTExtractionForm artExtraction = (ARTExtractionForm)object;
            try{
                if(artExtraction.getFile()==null){
                    LOG.debug("Doing input validation");
                    errors = validateARTExtractionInputs(artExtraction,errors); 
                }else{
                    LOG.debug("Doing file validation");
                    errors = validateARTExtractionFile(artExtraction,errors);
                }
                
            }catch(Exception e){
               LOG.error("Exception occured in ARTExtractionValidator",e);
            }       
        }else {
            LOG.debug("Invalid parameter !!!");
        }
    }
    
    /**
     * Doing validation for input fields - User Id and Identity Blob Document Id
     * @param inputForm
     * @param errors
     * @return
     * @throws RecoveryDAOException
     */
    private Errors validateARTExtractionInputs(ARTExtractionForm inputForm,Errors errors) throws Exception {
        if(inputForm.getUserId().trim().equals("") && inputForm.getBlobDocId().trim().equals("")){
            errors.rejectValue( "userId", "ARTExtractionBO.IsEmpty");
        }else if(!inputForm.getUserId().trim().equals("") && !inputForm.getUserId().matches("[0-9]+")){
            LOG.debug("User Id validation failed");
            errors.rejectValue( "userId", "ARTExtractionBO.UserIdInvalid");
        }else if(!inputForm.getBlobDocId().trim().equals("") && !inputForm.getBlobDocId().matches("[0-9]+")){
            errors.rejectValue( "blobDocId", "ARTExtractionBO.IdentityBlobDocIdInvalid");
        }
        
       return errors;
    }
    
    /**
     * Doing validation for file
     * @param fileForm
     * @param errors
     * @return
     * @throws Exception
     */
    private Errors validateARTExtractionFile(ARTExtractionForm fileForm, Errors errors) throws Exception {
        LOG.debug("File Name :: " + fileForm.getFile().getOriginalFilename());
        String name = fileForm.getFile().getOriginalFilename();
        if(fileForm.getFile().getOriginalFilename().equals("")){
            LOG.debug("File not found");
            errors.rejectValue("file", "ARTExtractionBO.fileNotFound");
        }else if (!name.substring(name.indexOf('.'), name.length()).equalsIgnoreCase(".csv")) {
            LOG.debug("file name validation failed");
            errors.rejectValue("file", "ARTExtractionBO.invalidFile");
        }else if(fileForm.getFile().getSize()>=0 && fileForm.getFile().getSize()> 1000000){
            LOG.debug("FIle size validation failed");
            errors.rejectValue("file", "ARTExtractionBO.invalidFileSize");
        }
        LOG.info("File Size is :: " + fileForm.getFile().getSize());
       return errors;
    }
    
    
}
