package au.gov.doha.pcehr.recovery.validation;


import au.gov.doha.pcehr.recovery.bo.PNAStatusActiveInactiveBO;
import au.gov.doha.pcehr.recovery.controller.PNAStatusActiveInactiveController;
import au.gov.doha.pcehr.recovery.wsclient.PNAPcehrAuthroseClient;

import org.apache.log4j.Logger;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


public class PNAStatuActiveInactiveValidator implements Validator{

    private static Logger LOG = Logger.getLogger(PNAStatusActiveInactiveController.class);
    @Override
    public boolean supports(Class class1) {
        return PNAStatusActiveInactiveBO.class.equals(class1);
    }

    /**
     *
     * @return
     */
    private PNAPcehrAuthroseClient createPNAPcehrAuthroseClientObject(){
        return new PNAPcehrAuthroseClient();
    }
    
    @Override
    public void validate(Object object, Errors errors) {
        PNAStatusActiveInactiveBO form = (PNAStatusActiveInactiveBO)object;
        LOG.debug("here in validate of PNAStatusActiveInactiveBO " + form.getIhi());
        LOG.debug("form value............" );
        ValidationUtils.rejectIfEmpty(errors, "name", "name.empty");
            
       
                errors = validatePNAStatusForm(form, errors);
                
        }


    private Errors validatePNAStatusForm(PNAStatusActiveInactiveBO form,
                                                            Errors errors) {
        //Blank validation for ihi, rep_ihi and rel_type
        ValidationUtils.rejectIfEmpty(errors, "ihi", "PNAStatusActiveInactiveBO");
        ValidationUtils.rejectIfEmpty(errors, "status", "PNAStatusActiveInactiveBO");
        if(form.getStatus()!=null && !form.getStatus().trim().equals("")){
            if(form.getStatus().equals("ACTIVE")){
                ValidationUtils.rejectIfEmpty(errors, "relationshipType", "PNAStatusActiveInactiveBO");
                ValidationUtils.rejectIfEmpty(errors, "changeBy", "PNAStatusActiveInactiveBO");
                ValidationUtils.rejectIfEmpty(errors, "userID", "PNAStatusActiveInactiveBO");
                if(form.getRelationshipType()!=null && !form.getRelationshipType().trim().equals("") 
                   && form.getRelationshipType().equals("Authorized Representative Relation")){
                    ValidationUtils.rejectIfEmpty(errors, "representativeIHI", "PNAStatusActiveInactiveBO");
                }
            }else if(form.getStatus().equals("IN_ACTIVE")){
                ValidationUtils.rejectIfEmpty(errors, "changeBy", "PNAStatusActiveInactiveBO");
                ValidationUtils.rejectIfEmpty(errors, "userID", "PNAStatusActiveInactiveBO");
            }else{
                ValidationUtils.rejectIfEmpty(errors, "changeBy", "PNAStatusActiveInactiveBO");
                ValidationUtils.rejectIfEmpty(errors, "userID", "PNAStatusActiveInactiveBO");
            }
        }
        return errors;
    }
}

