package au.gov.doha.pcehr.recovery.validation;

import au.gov.doha.pcehr.recovery.form.DisableEnableEntitiesForm;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class DisableEnableEntitiesValidator implements Validator{
    
    private static Logger LOG = Logger.getLogger(DisableEnableEntitiesValidator.class);
    
    @Override
    public boolean supports(Class<?> class1) {
        return DisableEnableEntitiesForm.class.equals(class1);
    }

    @Override
    public void validate(Object object, Errors errors) {
        LOG.debug("Inside ARRestrictionValidator");
        if(object instanceof DisableEnableEntitiesForm){
            DisableEnableEntitiesForm disableEnableEntities = (DisableEnableEntitiesForm)object;
            try{
                errors = validateDisableEnableForm(disableEnableEntities, errors); 
            }catch(Exception e){
               LOG.error("Exception occured",e);
            }       
        }else {
            LOG.debug("Invalid parameter !!!");
        }
    }

    private Errors validateDisableEnableForm(DisableEnableEntitiesForm inputForm, Errors errors) {
        LOG.debug("Doing validation -- Inside validateDisableEnableForm");
        String fileName = inputForm.getFile().getOriginalFilename();
        if(inputForm.getEntityType().equals("")){
            errors.rejectValue( "entityType", "DisableEnableEntitiesForm.entityTypeIsEmpty");
        }
        if(inputForm.getEntitiesID().equals("") && fileName.equals("")){
            errors.rejectValue( "entitiesID", "DisableEnableEntitiesForm.entitiesIdIsEmpty");
        }
        //if input is entered
        LOG.debug("single input entitiesID :: " + inputForm.getEntitiesID());
        if(!inputForm.getEntitiesID().equals("") && inputForm.getEntitiesID().contains("<")){
            errors.rejectValue( "entitiesID", "DisableEnableEntitiesForm.entitiesIdIsInvalid");
        }
        //if file exist..
        if(!fileName.equals("")){
             if (!fileName.substring(fileName.indexOf('.'), fileName.length()).equalsIgnoreCase(".csv")) {
                LOG.debug("file name validation failed");
                errors.rejectValue("file", "DisableEnableEntitiesForm.invalidFile");
             }
             if(inputForm.getFile().getSize()>=0 && inputForm.getFile().getSize()> 1000000){
                LOG.debug("File size validation failed");
                errors.rejectValue("file", "DisableEnableEntitiesForm.invalidFileSize");
            }
        }
        if(inputForm.getStatus()== null){
            errors.rejectValue( "status", "DisableEnableEntitiesForm.statusIsEmpty");
        }
        if(inputForm.getOperatorName().equals("")){
            errors.rejectValue( "operatorName", "DisableEnableEntitiesForm.operatorNameIsEmpty");
        }
        if(inputForm.getUserID().equals("")){
            errors.rejectValue( "userID", "DisableEnableEntitiesForm.userIdIsEmpty");
        }
        return errors;
    }
}
