package au.gov.doha.pcehr.recovery.bo;


public class DocumentTransformationRLSBO {
    public DocumentTransformationRLSBO() {
        super();
    }
    private String ihi;
    private String repositoryID;
    private String documentID;
    private String docmentType;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setRepositoryID(String repositoryID) {
        this.repositoryID = repositoryID;
    }

    public String getRepositoryID() {
        return repositoryID;
    }

    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    public String getDocumentID() {
        return documentID;
    }

    public void setDocmentType(String docmentType) {
        this.docmentType = docmentType;
    }

    public String getDocmentType() {
        return docmentType;
    }
}
