package au.gov.doha.pcehr.recovery.bo;

import java.util.List;


public class GetDocumentListClientBO {
   private String ihi;
   private String docEntryStatus; 
   
   private List<String> documentEntryPatientId;
   private List<String> documentEntryStatus;
   private String documentEntryServiceStartTimeFrom;
   private String documentEntryServiceStartTimeTo;
   private List<String> documentEntryTypeCode;
   private List<String> documentEntryUniqueId;
   //private String adhocQueryID;
   
   private String xDSDocumentEntryId;
   private String ihiOrDocID;
   private String  adhocQueryID;

    public void setAdhocQueryID(String adhocQueryID) {
        this.adhocQueryID = adhocQueryID;
    }

    public String getAdhocQueryID() {
        return adhocQueryID;
    }


    public void setXDSDocumentEntryId(String xDSDocumentEntryId) {
        this.xDSDocumentEntryId = xDSDocumentEntryId;
    }

    public String getXDSDocumentEntryId() {
        return xDSDocumentEntryId;
    }

    public void setIhiOrDocID(String ihiOrDocID) {
        this.ihiOrDocID = ihiOrDocID;
    }

    public String getIhiOrDocID() {
        return ihiOrDocID;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }


    public void setDocEntryStatus(String docEntryStatus) {
        this.docEntryStatus = docEntryStatus;
    }

    public String getDocEntryStatus() {
        return docEntryStatus;
    }

    public void setDocumentEntryPatientId(List<String> documentEntryPatientId) {
        this.documentEntryPatientId = documentEntryPatientId;
    }

    public List<String> getDocumentEntryPatientId() {
        return documentEntryPatientId;
    }

    public void setDocumentEntryStatus(List<String> documentEntryStatus) {
        this.documentEntryStatus = documentEntryStatus;
    }

    public List<String> getDocumentEntryStatus() {
        return documentEntryStatus;
    }

    public void setDocumentEntryServiceStartTimeFrom(String documentEntryServiceStartTimeFrom) {
        this.documentEntryServiceStartTimeFrom = documentEntryServiceStartTimeFrom;
    }

    public String getDocumentEntryServiceStartTimeFrom() {
        return documentEntryServiceStartTimeFrom;
    }

    public void setDocumentEntryServiceStartTimeTo(String documentEntryServiceStartTimeTo) {
        this.documentEntryServiceStartTimeTo = documentEntryServiceStartTimeTo;
    }

    public String getDocumentEntryServiceStartTimeTo() {
        return documentEntryServiceStartTimeTo;
    }

    public void setDocumentEntryTypeCode(List<String> documentEntryTypeCode) {
        this.documentEntryTypeCode = documentEntryTypeCode;
    }

    public List<String> getDocumentEntryTypeCode() {
        return documentEntryTypeCode;
    }

    public void setDocumentEntryUniqueId(List<String> documentEntryUniqueId) {
        this.documentEntryUniqueId = documentEntryUniqueId;
    }

    public List<String> getDocumentEntryUniqueId() {
        return documentEntryUniqueId;
    }

}
