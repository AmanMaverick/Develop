package au.gov.doha.pcehr.recovery.bo;

import au.gov.doha.pcehr.recovery.bo.DocumentRemovalBO;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;


public class DocumentReinstateBO extends DocumentRemovalBO {    
    public DocumentReinstateBO() {
        super();
    }

    private String description;
    List<DocumentReinstateErrorBO> listDocReinstateErrorBO=new ArrayList<DocumentReinstateErrorBO>();
    
    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
    
    public void setListDocReinstateErrorBO(List<DocumentReinstateErrorBO> listDocReinstateErrorBO) {
        this.listDocReinstateErrorBO = listDocReinstateErrorBO;
    }

    public List<DocumentReinstateErrorBO> getListDocReinstateErrorBO() {
        return listDocReinstateErrorBO;
    }
}
