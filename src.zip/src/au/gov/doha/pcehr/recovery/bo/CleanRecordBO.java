package au.gov.doha.pcehr.recovery.bo;


public class CleanRecordBO {
    private String ihi;
   
    private String operationOnRecord;
    private String systemOperator;
    private String responseCode;
    private String option;
    private String userID;
    private String ihiRestirctedStatus;
    private String docListSize;
    private String ihiStatus;
   private String auditStatusMessage;
    //private String cleanUpVerificationDetails;
//ResetIndPrf responses
    private String resetIndProfStatusCode;
    private String resetIndProfStatusDescription;
    //CleanUpPending Verification responses
    private String cleanupAuditStatusMessage;
    private String cleanupStatusMessage;
    //remove documents
    private String removeDocIhiStatus;
    private String removeDocIhiRestirctedStatus;
    private String removeDocDocumentListSize;
    private String removeDocDeletaionCsvFile;
    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setOperationOnRecord(String operationOnRecord) {
        this.operationOnRecord = operationOnRecord;
    }

    public String getOperationOnRecord() {
        return operationOnRecord;
    }

    public void setSystemOperator(String systemOperator) {
        this.systemOperator = systemOperator;
    }

    public String getSystemOperator() {
        return systemOperator;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setOption(String option) {
        this.option = option;
    }

    public String getOption() {
        return option;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setIhiRestirctedStatus(String ihiRestirctedStatus) {
        this.ihiRestirctedStatus = ihiRestirctedStatus;
    }

    public String getIhiRestirctedStatus() {
        return ihiRestirctedStatus;
    }

    public void setDocListSize(String docListSize) {
        this.docListSize = docListSize;
    }

    public String getDocListSize() {
        return docListSize;
    }

    public void setIhiStatus(String ihiStatus) {
        this.ihiStatus = ihiStatus;
    }

    public String getIhiStatus() {
        return ihiStatus;
    }

    public void setAuditStatusMessage(String auditStatusMessage) {
        this.auditStatusMessage = auditStatusMessage;
    }

    public String getAuditStatusMessage() {
        return auditStatusMessage;
    }

//    public void setCleanUpVerificationDetails(String cleanUpVerificationDetails) {
//        this.cleanUpVerificationDetails = cleanUpVerificationDetails;
//    }
//
//    public String getCleanUpVerificationDetails() {
//        return cleanUpVerificationDetails;
//    }

    public void setResetIndProfStatusCode(String cleanIndProfStatusCode) {
        this.resetIndProfStatusCode = cleanIndProfStatusCode;
    }

    public String getResetIndProfStatusCode() {
        return resetIndProfStatusCode;
    }

    public void setResetIndProfStatusDescription(String cleanIndProfStatusDescription) {
        this.resetIndProfStatusDescription = cleanIndProfStatusDescription;
    }

    public String getResetIndProfStatusDescription() {
        return resetIndProfStatusDescription;
    }

    public void setCleanupAuditStatusMessage(String cleanupAuditStatusMessage) {
        this.cleanupAuditStatusMessage = cleanupAuditStatusMessage;
    }

    public String getCleanupAuditStatusMessage() {
        return cleanupAuditStatusMessage;
    }

    public void setCleanupStatusMessage(String cleanupStatusMessage) {
        this.cleanupStatusMessage = cleanupStatusMessage;
    }

    public String getCleanupStatusMessage() {
        return cleanupStatusMessage;
    }

    public void setRemoveDocIhiStatus(String removeDocIhiStatus) {
        this.removeDocIhiStatus = removeDocIhiStatus;
    }

    public String getRemoveDocIhiStatus() {
        return removeDocIhiStatus;
    }

    public void setRemoveDocIhiRestirctedStatus(String removeDocIhiRestirctedStatus) {
        this.removeDocIhiRestirctedStatus = removeDocIhiRestirctedStatus;
    }

    public String getRemoveDocIhiRestirctedStatus() {
        return removeDocIhiRestirctedStatus;
    }

    public void setRemoveDocDocumentListSize(String removeDocDocumentCount) {
        this.removeDocDocumentListSize = removeDocDocumentCount;
    }

    public String getRemoveDocDocumentListSize() {
        return removeDocDocumentListSize;
    }

    public void setRemoveDocDeletaionCsvFile(String removeDocDeletaionCsvFile) {
        this.removeDocDeletaionCsvFile = removeDocDeletaionCsvFile;
    }

    public String getRemoveDocDeletaionCsvFile() {
        return removeDocDeletaionCsvFile;
    }
}
