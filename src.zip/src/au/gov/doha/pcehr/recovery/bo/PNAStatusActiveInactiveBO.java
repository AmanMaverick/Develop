package au.gov.doha.pcehr.recovery.bo;

import java.util.List;

public class PNAStatusActiveInactiveBO {
    
    private String ihi;
    private String status;
    private String isCleanRecord;
    private String relationshipType;
    private String representativeIHI;
    private String operatorName;
    private String userID;
    private String reason;
    private String suspensionReason;
    private String inactiveReason;
    private String validationMsg;
    private String recordId;
    private String recordStatus;
    private String recordDeactivationReason;   
    private String changeBy;
    private boolean validationStatus;
    private String recordIHI;
    private List<ReactivateAuthRepBO> reactivateAuthRepBO;
    private String userName;
    private String alertMessage;
    private String wsStatusMessage;
    private String soapMessage;


    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setIsCleanRecord(String isCleanRecord) {
        this.isCleanRecord = isCleanRecord;
    }

    public String getIsCleanRecord() {
        return isCleanRecord;
    }

    public void setRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
    }

    public String getRelationshipType() {
        return relationshipType;
    }

    public void setRepresentativeIHI(String representativeIHI) {
        this.representativeIHI = representativeIHI;
    }

    public String getRepresentativeIHI() {
        return representativeIHI;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return reason;
    }

    public void setValidationMsg(String validationMsg) {
        this.validationMsg = validationMsg;
    }

    public String getValidationMsg() {
        return validationMsg;
    }

    public void setSuspensionReason(String suspensionReason) {
        this.suspensionReason = suspensionReason;
    }

    public String getSuspensionReason() {
        return suspensionReason;
    }

    public void setInactiveReason(String inactiveReason) {
        this.inactiveReason = inactiveReason;
    }

    public String getInactiveReason() {
        return inactiveReason;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordDeactivationReason(String recordDeactivationReason) {
        this.recordDeactivationReason = recordDeactivationReason;
    }

    public String getRecordDeactivationReason() {
        return recordDeactivationReason;
    }

    public void setChangeBy(String changeBy) {
        this.changeBy = changeBy;
    }

    public String getChangeBy() {
        return changeBy;
    }

    public void setValidationStatus(boolean validationStatus) {
        this.validationStatus = validationStatus;
    }

    public boolean isValidationStatus() {
        return validationStatus;
    }

    public void setRecordIHI(String recordIHI) {
        this.recordIHI = recordIHI;
    }

    public String getRecordIHI() {
        return recordIHI;
    }

    public void setReactivateAuthRepBO(List<ReactivateAuthRepBO> reactivateAuthRepBO) {
        this.reactivateAuthRepBO = reactivateAuthRepBO;
    }

    public List<ReactivateAuthRepBO> getReactivateAuthRepBO() {
        return reactivateAuthRepBO;
    }

    public void setAlertMessage(String alertMessage) {
        this.alertMessage = alertMessage;
    }

    public String getAlertMessage() {
        return alertMessage;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setSoapMessage(String soapMessage) {
        this.soapMessage = soapMessage;
    }

    public String getSoapMessage() {
        return soapMessage;
    }


    public void setWsStatusMessage(String wsStatusMessage) {
        this.wsStatusMessage = wsStatusMessage;
    }

    public String getWsStatusMessage() {
        return wsStatusMessage;
    }
}
