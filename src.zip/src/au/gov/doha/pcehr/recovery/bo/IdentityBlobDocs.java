/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package com.accenture.pcehr.artconsentfileextraction.model;
package au.gov.doha.pcehr.recovery.bo;

import java.io.Serializable;

import java.sql.Blob;


/**
 *
 * @author subhrajyoti.majumder
 */
public class IdentityBlobDocs implements Serializable {

    private String checked;
    private long documentId;
    private long userId;
    private byte[] blobdocs;
    private String fileName;
    private String fileType;
    private long fileSize;
    private String filePath;
    private Blob blob;
    
    public String getChecked() {
            return checked;
    }
    public void setChecked(String checked) {
            this.checked = checked;
    }
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public byte[] getBlobdocs() {
        return blobdocs;
    }

    public void setBlobdocs(byte[] blobdocs) {
        this.blobdocs = blobdocs;
    }

    public long getDocumentId() {
        return documentId;
    }

    public void setDocumentId(long documentId) {
        this.documentId = documentId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public void setBlob(Blob blob) {
        this.blob = blob;
    }

    public Blob getBlob() {
        return blob;
    }
}
