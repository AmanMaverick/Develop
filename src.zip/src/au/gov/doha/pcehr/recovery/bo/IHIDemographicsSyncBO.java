package au.gov.doha.pcehr.recovery.bo;

import org.springframework.web.multipart.MultipartFile;

public class IHIDemographicsSyncBO {
    
    private MultipartFile file;
    private String userName;
    private String status;
    

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
