package au.gov.doha.pcehr.recovery.bo;


public class ConfigureEndpointsBO {
    public ConfigureEndpointsBO() {
        super();
    }
    private String persistAtomicData;
    private String deprecateAtomicData;
    private String updateDocumentStatus;
    private String getDocumentList;
        private String pnaOIMDisable;
    private String synchroniseIHI;
    private String pnaCreateAuthRep;
    private String auditInsert;
    private String pnaARRestrict;
    private String pnaAuthoriseRestrict;
    private String pnaCleanIndividualProfile;
    private String removeDocument;
    private String pnaUpdateNominated;
    private String unremoveDocument;
    private String pnaUpdateAuth;
    private String removeDocumentDevf;
    private String pnaEndPoint;
    private String getDocumentHTB;
    private String getDocumentOAG;
    private String osbDevfPassword;
    private String osbPassword;
    private String osbUsername;
    private String pnaAuthUsername;
    private String pnaPassword;
    private String pnaUsername;
    private String pnaAuthPassword;
    private String htbPassword;
    private String htbUsername;
    private String oagUsername;
    private String oagPassword;
    private String pnaOIMDisablePassword;
    private String pnaOIMDisableUsername;
    private String webLogicJndiNameHTB;
    private String webLogicJndiNamePNA;
    private String webLogicJndiNameRLS;
    private String webLogicJndiNameOSB;
    private String webLogicJndiNameOIM;
    private String initialContextFactory;
    private String hostName;
    private String webLogicProviderUrl;
    //new for TIP
        private String searchIHI;
        private String osbRegisterPcehr;
        
        //productVersion
       private String  productVersion;

    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getProductVersion() {
        return productVersion;
    }

    public void setSearchIHI(String searchIHI) {
        this.searchIHI = searchIHI;
    }

    public String getSearchIHI() {
        return searchIHI;
    }

    public void setOsbRegisterPcehr(String osbRegisterPcehr) {
        this.osbRegisterPcehr = osbRegisterPcehr;
    }

    public String getOsbRegisterPcehr() {
        return osbRegisterPcehr;
    }

    public void setConfigureEndpointsResponse(String configureEndpointsResponse) {
        this.configureEndpointsResponse = configureEndpointsResponse;
    }

    public String getConfigureEndpointsResponse() {
        return configureEndpointsResponse;
    }
    private String configureEndpointsResponse;

    public void setPersistAtomicData(String persistAtomicData) {
        this.persistAtomicData = persistAtomicData;
    }

    public String getPersistAtomicData() {
        return persistAtomicData;
    }

    public void setDeprecateAtomicData(String deprecateAtomicData) {
        this.deprecateAtomicData = deprecateAtomicData;
    }

    public String getDeprecateAtomicData() {
        return deprecateAtomicData;
    }

    public void setUpdateDocumentStatus(String updateDocumentStatus) {
        this.updateDocumentStatus = updateDocumentStatus;
    }

    public String getUpdateDocumentStatus() {
        return updateDocumentStatus;
    }

    public void setGetDocumentList(String getDocumentList) {
        this.getDocumentList = getDocumentList;
    }

    public String getGetDocumentList() {
        return getDocumentList;
    }

    public void setPnaOIMDisable(String pnaOIMDisable) {
        this.pnaOIMDisable = pnaOIMDisable;
    }

    public String getPnaOIMDisable() {
        return pnaOIMDisable;
    }

    public void setSynchroniseIHI(String synchroniseIHI) {
        this.synchroniseIHI = synchroniseIHI;
    }

    public String getSynchroniseIHI() {
        return synchroniseIHI;
    }

    public void setPnaCreateAuthRep(String pnaCreateAuthRep) {
        this.pnaCreateAuthRep = pnaCreateAuthRep;
    }

    public String getPnaCreateAuthRep() {
        return pnaCreateAuthRep;
    }

    public void setAuditInsert(String auditInsert) {
        this.auditInsert = auditInsert;
    }

    public String getAuditInsert() {
        return auditInsert;
    }

    public void setPnaARRestrict(String pnaARRestrict) {
        this.pnaARRestrict = pnaARRestrict;
    }

    public String getPnaARRestrict() {
        return pnaARRestrict;
    }

    public void setPnaAuthoriseRestrict(String pnaAuthoriseRestrict) {
        this.pnaAuthoriseRestrict = pnaAuthoriseRestrict;
    }

    public String getPnaAuthoriseRestrict() {
        return pnaAuthoriseRestrict;
    }

    public void setPnaCleanIndividualProfile(String pnaCleanIndividualProfile) {
        this.pnaCleanIndividualProfile = pnaCleanIndividualProfile;
    }

    public String getPnaCleanIndividualProfile() {
        return pnaCleanIndividualProfile;
    }

    public void setRemoveDocument(String removeDocument) {
        this.removeDocument = removeDocument;
    }

    public String getRemoveDocument() {
        return removeDocument;
    }

    public void setPnaUpdateNominated(String pnaUpdateNominated) {
        this.pnaUpdateNominated = pnaUpdateNominated;
    }

    public String getPnaUpdateNominated() {
        return pnaUpdateNominated;
    }

    public void setUnremoveDocument(String unremoveDocument) {
        this.unremoveDocument = unremoveDocument;
    }

    public String getUnremoveDocument() {
        return unremoveDocument;
    }

    public void setPnaUpdateAuth(String pnaUpdateAuth) {
        this.pnaUpdateAuth = pnaUpdateAuth;
    }

    public String getPnaUpdateAuth() {
        return pnaUpdateAuth;
    }

    public void setRemoveDocumentDevf(String removeDocumentDevf) {
        this.removeDocumentDevf = removeDocumentDevf;
    }

    public String getRemoveDocumentDevf() {
        return removeDocumentDevf;
    }

    public void setPnaEndPoint(String pnaEndPoint) {
        this.pnaEndPoint = pnaEndPoint;
    }

    public String getPnaEndPoint() {
        return pnaEndPoint;
    }

    public void setGetDocumentHTB(String getDocumentHTB) {
        this.getDocumentHTB = getDocumentHTB;
    }

    public String getGetDocumentHTB() {
        return getDocumentHTB;
    }

    public void setGetDocumentOAG(String getDocumentOAG) {
        this.getDocumentOAG = getDocumentOAG;
    }

    public String getGetDocumentOAG() {
        return getDocumentOAG;
    }

    public void setOsbDevfPassword(String osbDevfPassword) {
        this.osbDevfPassword = osbDevfPassword;
    }

    public String getOsbDevfPassword() {
        return osbDevfPassword;
    }

    public void setOsbPassword(String osbPassword) {
        this.osbPassword = osbPassword;
    }

    public String getOsbPassword() {
        return osbPassword;
    }

    public void setOsbUsername(String osbUsername) {
        this.osbUsername = osbUsername;
    }

    public String getOsbUsername() {
        return osbUsername;
    }

    public void setPnaAuthUsername(String pnaAuthUsername) {
        this.pnaAuthUsername = pnaAuthUsername;
    }

    public String getPnaAuthUsername() {
        return pnaAuthUsername;
    }

    public void setPnaPassword(String pnaPassword) {
        this.pnaPassword = pnaPassword;
    }

    public String getPnaPassword() {
        return pnaPassword;
    }

    public void setPnaUsername(String pnaUsername) {
        this.pnaUsername = pnaUsername;
    }

    public String getPnaUsername() {
        return pnaUsername;
    }

    public void setPnaAuthPassword(String pnaAuthPassword) {
        this.pnaAuthPassword = pnaAuthPassword;
    }

    public String getPnaAuthPassword() {
        return pnaAuthPassword;
    }

    public void setHtbPassword(String htbPassword) {
        this.htbPassword = htbPassword;
    }

    public String getHtbPassword() {
        return htbPassword;
    }

    public void setHtbUsername(String htbUsername) {
        this.htbUsername = htbUsername;
    }

    public String getHtbUsername() {
        return htbUsername;
    }

    public void setOagUsername(String oagUsername) {
        this.oagUsername = oagUsername;
    }

    public String getOagUsername() {
        return oagUsername;
    }

    public void setOagPassword(String oagPassword) {
        this.oagPassword = oagPassword;
    }

    public String getOagPassword() {
        return oagPassword;
    }

    public void setPnaOIMDisablePassword(String pnaOIMDisablePassword) {
        this.pnaOIMDisablePassword = pnaOIMDisablePassword;
    }

    public String getPnaOIMDisablePassword() {
        return pnaOIMDisablePassword;
    }

    public void setPnaOIMDisableUsername(String pnaOIMDisableUsername) {
        this.pnaOIMDisableUsername = pnaOIMDisableUsername;
    }

    public String getPnaOIMDisableUsername() {
        return pnaOIMDisableUsername;
    }

    public void setWebLogicJndiNameHTB(String webLogicJndiNameHTB) {
        this.webLogicJndiNameHTB = webLogicJndiNameHTB;
    }

    public String getWebLogicJndiNameHTB() {
        return webLogicJndiNameHTB;
    }

    public void setWebLogicJndiNamePNA(String webLogicJndiNamePNA) {
        this.webLogicJndiNamePNA = webLogicJndiNamePNA;
    }

    public String getWebLogicJndiNamePNA() {
        return webLogicJndiNamePNA;
    }

    public void setWebLogicJndiNameRLS(String webLogicJndiNameRLS) {
        this.webLogicJndiNameRLS = webLogicJndiNameRLS;
    }

    public String getWebLogicJndiNameRLS() {
        return webLogicJndiNameRLS;
    }

    public void setWebLogicJndiNameOSB(String webLogicJndiNameOSB) {
        this.webLogicJndiNameOSB = webLogicJndiNameOSB;
    }

    public String getWebLogicJndiNameOSB() {
        return webLogicJndiNameOSB;
    }

    public void setWebLogicJndiNameOIM(String webLogicJndiNameOIM) {
        this.webLogicJndiNameOIM = webLogicJndiNameOIM;
    }

    public String getWebLogicJndiNameOIM() {
        return webLogicJndiNameOIM;
    }

    public void setInitialContextFactory(String initialContextFactory) {
        this.initialContextFactory = initialContextFactory;
    }

    public String getInitialContextFactory() {
        return initialContextFactory;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getHostName() {
        return hostName;
    }

    public void setWebLogicProviderUrl(String webLogicProviderUrl) {
        this.webLogicProviderUrl = webLogicProviderUrl;
    }

    public String getWebLogicProviderUrl() {
        return webLogicProviderUrl;
    }
}
