package au.gov.doha.pcehr.recovery.bo;


public class DocumentTransformationStyleSheetBO {
    private String documentID;
    private String ihi;
    private String documnetType;

    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    public String getDocumentID() {
        return documentID;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocumnetType(String documnetType) {
        this.documnetType = documnetType;
    }

    public String getDocumnetType() {
        return documnetType;
    }
}
