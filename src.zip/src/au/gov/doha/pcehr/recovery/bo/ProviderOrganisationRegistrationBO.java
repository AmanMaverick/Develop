package au.gov.doha.pcehr.recovery.bo;


public class ProviderOrganisationRegistrationBO {

    private String accessing_org_id;
    private int countoim;
    private int countoid;
    
    public void setCountoim(int countoim) {
        this.countoim = countoim;
    }

    public int getCountoim() {
        return countoim;
    }

    public void setCountoid(int countoid) {
        this.countoid = countoid;
    }

    public int getCountoid() {
        return countoid;
    }
    
    public void setAccessing_org_id(String accessing_org_id) {
        this.accessing_org_id = accessing_org_id;
    }

    public String getAccessing_org_id() {
        return accessing_org_id;
    }

}
