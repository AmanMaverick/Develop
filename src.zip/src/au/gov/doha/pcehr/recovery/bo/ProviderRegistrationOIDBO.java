package au.gov.doha.pcehr.recovery.bo;

import java.util.Date;

public class ProviderRegistrationOIDBO {
   
    private String user_login;
    private Date date;

    public void setUser_login(String user_login) {
        this.user_login = user_login;
    }

    public String getUser_login() {
        return user_login;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDate() {
        return date;
    }
}
