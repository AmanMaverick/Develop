package au.gov.doha.pcehr.recovery.bo;

import java.util.List;


/**
 * Business object for Get View client.
 * @author  Aman Sharma
 * @since R 6.0.4
 */
public class GetViewClientBO {
    
    private String ihi;
    private String viewType;
    private String fromDate;
    private String toDate;
    private String soapResponse;
    private byte[] reposnseDcoument;
   HealthRecordExtractionErrorBO healthRecordExtractionErrorBO; 
    //private String responseStatus;
    private List<String> confidentialityCode;

    private String userId;
      private String familyName;
      private String lastName;
      private int sex;
      private String dob;
      private String medicareCardNumber;
      private String  ausAdressLine;
      private String unitType;
      private String unitNumber;
      private String addressSiteName;
      private String levelNumber;
      private String levelType;
      private String streetNumber;
      private String lotNumber;
      private String streetName;
      private String streetTypeCode;
      private String streetSuffixCode;
      private int indigenousStatus;
      private String veteranAdfStatus; 
      
    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setViewType(String viewType) {
        this.viewType = viewType;
    }

    public String getViewType() {
        return viewType;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setConfidentialityCode(List<String> confidentialityCode) {
        this.confidentialityCode = confidentialityCode;
    }

    public List<String> getConfidentialityCode() {
        return confidentialityCode;
    }

    public void setSoapResponse(String soapResponse) {
        this.soapResponse = soapResponse;
    }

    public String getSoapResponse() {
        return soapResponse;
    }


    public void setHealthRecordExtractionErrorBO(HealthRecordExtractionErrorBO healthRecordExtractionErrorBO) {
        this.healthRecordExtractionErrorBO = healthRecordExtractionErrorBO;
    }

    public HealthRecordExtractionErrorBO getHealthRecordExtractionErrorBO() {
        return healthRecordExtractionErrorBO;
    }

    public void setReposnseDcoument(byte[] reposnseDcoument) {
        this.reposnseDcoument = reposnseDcoument;
    }

    public byte[] getReposnseDcoument() {
        return reposnseDcoument;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getSex() {
        return sex;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getDob() {
        return dob;
    }

    public void setMedicareCardNumber(String medicareCardNumber) {
        this.medicareCardNumber = medicareCardNumber;
    }

    public String getMedicareCardNumber() {
        return medicareCardNumber;
    }

    public void setAusAdressLine(String ausAdressLine) {
        this.ausAdressLine = ausAdressLine;
    }

    public String getAusAdressLine() {
        return ausAdressLine;
    }

    public void setUnitType(String unitType) {
        this.unitType = unitType;
    }

    public String getUnitType() {
        return unitType;
    }

    public void setUnitNumber(String unitNumber) {
        this.unitNumber = unitNumber;
    }

    public String getUnitNumber() {
        return unitNumber;
    }

    public void setAddressSiteName(String addressSiteName) {
        this.addressSiteName = addressSiteName;
    }

    public String getAddressSiteName() {
        return addressSiteName;
    }

    public void setLevelNumber(String levelNumber) {
        this.levelNumber = levelNumber;
    }

    public String getLevelNumber() {
        return levelNumber;
    }

    public void setLevelType(String levelType) {
        this.levelType = levelType;
    }

    public String getLevelType() {
        return levelType;
    }

    public void setStreetNumber(String streetNumber) {
        this.streetNumber = streetNumber;
    }

    public String getStreetNumber() {
        return streetNumber;
    }

    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    public String getLotNumber() {
        return lotNumber;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetTypeCode(String streetTypeCode) {
        this.streetTypeCode = streetTypeCode;
    }

    public String getStreetTypeCode() {
        return streetTypeCode;
    }

    public void setStreetSuffixCode(String streetSuffixCode) {
        this.streetSuffixCode = streetSuffixCode;
    }

    public String getStreetSuffixCode() {
        return streetSuffixCode;
    }

    public void setIndigenousStatus(int indigenousStatus) {
        this.indigenousStatus = indigenousStatus;
    }

    public int getIndigenousStatus() {
        return indigenousStatus;
    }

    public void setVeteranAdfStatus(String veteranAdfStatus) {
        this.veteranAdfStatus = veteranAdfStatus;
    }

    public String getVeteranAdfStatus() {
        return veteranAdfStatus;
    }

}
