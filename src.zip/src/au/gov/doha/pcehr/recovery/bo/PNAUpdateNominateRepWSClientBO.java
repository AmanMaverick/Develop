package au.gov.doha.pcehr.recovery.bo;


public class PNAUpdateNominateRepWSClientBO {
    private String ihi;
    private String userID;
    private int acc_type;
    private String name;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserID() {
        return userID;
    }

    public void setAcc_type(int acc_type) {
        this.acc_type = acc_type;
    }

    public int getAcc_type() {
        return acc_type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
