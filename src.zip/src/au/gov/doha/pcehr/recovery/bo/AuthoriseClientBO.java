package au.gov.doha.pcehr.recovery.bo;


public class AuthoriseClientBO {
   
    private String ihi;
    private String transactionID;
    private String sourceSystemID;
    private String accessChannel;
    private String subjectID;
    private String subjectType;
    private String resourceDomain;
    private String resourceID;
    private String resourcePath;
    private String action;
    
    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setSourceSystemID(String sourceSystemID) {
        this.sourceSystemID = sourceSystemID;
    }

    public String getSourceSystemID() {
        return sourceSystemID;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setAccessChannel(String accessChannel) {
        this.accessChannel = accessChannel;
    }

    public String getAccessChannel() {
        return accessChannel;
    }

    public void setSubjectID(String subjectID) {
        this.subjectID = subjectID;
    }

    public String getSubjectID() {
        return subjectID;
    }

    public void setSubjectType(String subjectType) {
        this.subjectType = subjectType;
    }

    public String getSubjectType() {
        return subjectType;
    }

    public void setResourceID(String resourceID) {
        this.resourceID = resourceID;
    }

    public String getResourceID() {
        return resourceID;
    }

    public void setResourcePath(String resourcePath) {
        this.resourcePath = resourcePath;
    }

    public String getResourcePath() {
        return resourcePath;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setResourceDomain(String resourceDomain) {
        this.resourceDomain = resourceDomain;
    }

    public String getResourceDomain() {
        return resourceDomain;
    }

    
}
