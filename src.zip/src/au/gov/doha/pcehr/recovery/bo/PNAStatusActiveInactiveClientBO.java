package au.gov.doha.pcehr.recovery.bo;

import au.pcehr.ws.pna.pd.PDSetPCEHRStatusResponse;
import au.pcehr.ws.pna.pd.SetPCEHRStatusParameterList;

public class PNAStatusActiveInactiveClientBO {
    private SetPCEHRStatusParameterList pcehrStatusParameterList;
    private PDSetPCEHRStatusResponse setPCEHRStatusResponse ;
    private String soapReqRes;


    public void setPcehrStatusParameterList(SetPCEHRStatusParameterList pcehrStatusParameterList) {
        this.pcehrStatusParameterList = pcehrStatusParameterList;
    }

    public SetPCEHRStatusParameterList getPcehrStatusParameterList() {
        return pcehrStatusParameterList;
    }

    public void setSetPCEHRStatusResponse(PDSetPCEHRStatusResponse setPCEHRStatusResponse) {
        this.setPCEHRStatusResponse = setPCEHRStatusResponse;
    }

    public PDSetPCEHRStatusResponse getSetPCEHRStatusResponse() {
        return setPCEHRStatusResponse;
    }

    public void setSoapReqRes(String soapReqRes) {
        this.soapReqRes = soapReqRes;
    }

    public String getSoapReqRes() {
        return soapReqRes;
    }
}
