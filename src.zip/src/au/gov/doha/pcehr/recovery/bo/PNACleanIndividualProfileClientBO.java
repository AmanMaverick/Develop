package au.gov.doha.pcehr.recovery.bo;


public class PNACleanIndividualProfileClientBO {
    public PNACleanIndividualProfileClientBO() {
        super();
    }
    private String ihi;

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }
}
