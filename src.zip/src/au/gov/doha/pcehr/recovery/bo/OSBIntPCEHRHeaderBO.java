package au.gov.doha.pcehr.recovery.bo;

import au.gov.doha.pcehr.recovery.constants.EndPointsConstants;


public class OSBIntPCEHRHeaderBO {
    
    //User Header
    private String idType="LocalSystemIdentifier";
    private String id;
    private String role="PCEHR_SYSTEM_OPERATOR";
    private String userName;
    private boolean useRoleForAudit=false;
    
    private String headerIHI;
    
    //productType
    private String vendor="NIO";
    private String productName="NIO Ops Tool";
    private String productVersion=EndPointsConstants.PRODUCT_VERSION;
    private String platform="Windows";
    
    //clientSystem
    private String systemType;
    private String systemID=EndPointsConstants.HOST_NAME;
    
    //accessingOrganisation
    private String organisationID;
    private String organisationName;
    private String alternateOrganisationName;
    
    private boolean overrideLogLevel;


    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdType() {
        return idType;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUseRoleForAudit(boolean useRoleForAudit) {
        this.useRoleForAudit = useRoleForAudit;
    }

    public boolean isUseRoleForAudit() {
        return useRoleForAudit;
    }

    public void setIhi(String ihi) {
        this.headerIHI = ihi;
    }

    public String getIhi() {
        return headerIHI;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getVendor() {
        return vendor;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getProductVersion() {
        return productVersion;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getPlatform() {
        return platform;
    }

    public void setSystemType(String systemType) {
        this.systemType = systemType;
    }

    public String getSystemType() {
        return systemType;
    }

    public void setSystemID(String systemID) {
        this.systemID = systemID;
    }

    public String getSystemID() {
        return systemID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationName(String organisationName) {
        this.organisationName = organisationName;
    }

    public String getOrganisationName() {
        return organisationName;
    }

    public void setAlternateOrganisationName(String alternateOrganisationName) {
        this.alternateOrganisationName = alternateOrganisationName;
    }

    public String getAlternateOrganisationName() {
        return alternateOrganisationName;
    }

    public void setOverrideLogLevel(boolean overrideLogLevel) {
        this.overrideLogLevel = overrideLogLevel;
    }

    public boolean getOverrideLogLevel() {
        return overrideLogLevel;
    }

}
