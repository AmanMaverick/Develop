package au.gov.doha.pcehr.recovery.bo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;


public class DocumentRemovalBO {
    public DocumentRemovalBO() {
        super();
    }
    
    private String ihi;
    private String documentId;
    private String resonForRemoval;
    private String action;
    private String responseCode;
    private String responseDetails;
    private String username;
    private String responseDescription;
    private StringBuffer soapMessage;
    private StringBuffer alertMessage;
    //Added by aman.c.sharma
    private String removalType;
    private MultipartFile file;
    private String status;
    private String errorDescription;
    //for error hanling
    List<DocumentRemovalErrorBO> listDocRemovalErrorBO=new ArrayList<DocumentRemovalErrorBO>();

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String getErrorDescription() {
        return errorDescription;
    }


    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }


    private static final String COMMA_DELIMITER = ",";

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }


    public void setRemovalType(String removalType) {
        this.removalType = removalType;
    }

    public String getRemovalType() {
        return removalType;
    }

    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setResonForRemoval(String resonForRemoval) {
        this.resonForRemoval = resonForRemoval;
    }

    public String getResonForRemoval() {
        return resonForRemoval;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseDetails(String responseDetails) {
        this.responseDetails = responseDetails;
    }

    public String getResponseDetails() {
        return responseDetails;
    }

    public void setResponseDescription(String responseDescription) {
        this.responseDescription = responseDescription;
    }

    public String getResponseDescription() {
        return responseDescription;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public void setSoapMessage(StringBuffer soapMessage) {
        this.soapMessage = soapMessage;
    }

    public StringBuffer getSoapMessage() {
        return soapMessage;
    }

    public void setAlertMessage(StringBuffer alertMessage) {
        this.alertMessage = alertMessage;
    }

    public StringBuffer getAlertMessage() {
        return alertMessage;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
   
   

    public void setListDocRemovalErrorBO(List<DocumentRemovalErrorBO> listDocRemovalErrorBO) {
        this.listDocRemovalErrorBO = listDocRemovalErrorBO;
    }

    public List<DocumentRemovalErrorBO> getListDocRemovalErrorBO() {
        return listDocRemovalErrorBO;
    }
}
