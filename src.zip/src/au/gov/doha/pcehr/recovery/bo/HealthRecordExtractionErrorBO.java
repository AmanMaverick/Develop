package au.gov.doha.pcehr.recovery.bo;


public class HealthRecordExtractionErrorBO {
    private String iHI;
    private String statusDescription;
    private String viewType;
    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    public String getStatusDescription() {
        return statusDescription;
    }
   
    public void setIHI(String iHI) {
        this.iHI = iHI;
    }

    public String getIHI() {
        return iHI;
    }

  

    public HealthRecordExtractionErrorBO() {
        super();
    }
    
   

    public void setViewType(String viewType) {
        this.viewType = viewType;
    }

    public String getViewType() {
        return viewType;
    }

}
