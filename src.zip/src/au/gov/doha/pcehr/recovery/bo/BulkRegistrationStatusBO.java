package au.gov.doha.pcehr.recovery.bo;

import java.math.BigDecimal;

public class BulkRegistrationStatusBO { 
    
    public BulkRegistrationStatusBO(){
        this.loaded="0";
        this.omitted="0";
        this.validationCompleted="0";
        this.registrationCompleted="0";
        this.technicalError="0";
        this.functionalError="0";
        this.nulldata="0";
        this.totalIHI="0";
        this.fileName="0";
        
    }
     private BigDecimal IHI;
     private String error;
     private String state;
     
     //All IHI'S
     private String loaded;
     private String omitted;
     private String validationCompleted;
     private String registrationCompleted;
     private String technicalError;
     private String functionalError;
     private String nulldata;
     private String totalIHI;    
     private String fileName;
     
     
    public void setIHI(BigDecimal IHI) {
        this.IHI = IHI;
    }

    public BigDecimal getIHI() {
        return IHI;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getError() {
        return error;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setLoaded(String loaded) {
        this.loaded = loaded;
    }

    public String getLoaded() {
        return loaded;
    }

    public void setOmitted(String omitted) {
        this.omitted = omitted;
    }

    public String getOmitted() {
        return omitted;
    }

    public void setValidationCompleted(String validationCompleted) {
        this.validationCompleted = validationCompleted;
    }

    public String getValidationCompleted() {
        return validationCompleted;
    }

    public void setRegistrationCompleted(String registrationCompleted) {
        this.registrationCompleted = registrationCompleted;
    }

    public String getRegistrationCompleted() {
        return registrationCompleted;
    }

    public void setTechnicalError(String technicalError) {
        this.technicalError = technicalError;
    }

    public String getTechnicalError() {
        return technicalError;
    }

    public void setNulldata(String nulldata) {
        this.nulldata = nulldata;
    }

    public String getNulldata() {
        return nulldata;
    }

    public void setTotalIHI(String totalIHI) {
        this.totalIHI = totalIHI;
    }

    public String getTotalIHI() {
        return totalIHI;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFunctionalError(String functionalError) {
        this.functionalError = functionalError;
    }

    public String getFunctionalError() {
        return functionalError;
    }

    

    public String toString(){
        StringBuffer stringBuf = new StringBuffer();
        stringBuf.append( IHI+" "+state+" "+error);
        return stringBuf.toString();
    }
}
