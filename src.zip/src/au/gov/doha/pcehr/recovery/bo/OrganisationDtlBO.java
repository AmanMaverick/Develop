package au.gov.doha.pcehr.recovery.bo;


public class OrganisationDtlBO {
    private String inheritingOrgId;  
    private String accessingOrgId;    
    private String ihi;
    private String clinicalDocumentId;
    private String unknownDocumentId;
    private String unknownAuthor;

    public void setInheritingOrgId(String inheritingOrgId) {
        this.inheritingOrgId = inheritingOrgId;
    }

    public String getInheritingOrgId() {
        return inheritingOrgId;
    }


    public void setAccessingOrgId(String accessingOrgId) {
        this.accessingOrgId = accessingOrgId;
    }

    public String getAccessingOrgId() {
        return accessingOrgId;
    }


    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setClinicalDocumentId(String clinicalDocumentId) {
        this.clinicalDocumentId = clinicalDocumentId;
    }

    public String getClinicalDocumentId() {
        return clinicalDocumentId;
    }

    public void setUnknownDocumentId(String unknownDocumentId) {
        this.unknownDocumentId = unknownDocumentId;
    }

    public String getUnknownDocumentId() {
        return unknownDocumentId;
    }

    public void setUnknownAuthor(String unknownAuthor) {
        this.unknownAuthor = unknownAuthor;
    }

    public String getUnknownAuthor() {
        return unknownAuthor;
    }
}
