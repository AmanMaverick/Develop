package au.gov.doha.pcehr.recovery.bo;

public class FileTransferBO {
    public FileTransferBO() {
        super();
    }
    private String hostIp;
    private String hostUserName;
    private String fileName;
    private int transferStatus;
    private String transferOutputDescription;
    private String hostPassowrd;
    private int hostPort;
    private String sourceFolder;
    private String destinationFolder;
    //validateExtract output download sttaus and description
    private int validateExtractdownloadStatus;
    private String validateExtractdownloadDescription;
    
    //checksum
    private String checksumValueFromUI;
    private String checksumMethodFromUI;

    public void setValidateExtractdownloadStatus(int validateExtractdownloadStatus) {
        this.validateExtractdownloadStatus = validateExtractdownloadStatus;
    }

    public int getValidateExtractdownloadStatus() {
        return validateExtractdownloadStatus;
    }

    public void setValidateExtractdownloadDescription(String validateExtractdownloadDescription) {
        this.validateExtractdownloadDescription = validateExtractdownloadDescription;
    }

    public String getValidateExtractdownloadDescription() {
        return validateExtractdownloadDescription;
    }
    

    public void setTransferStatus(int transferStatus) {
        this.transferStatus = transferStatus;
    }

    public int getTransferStatus() {
        return transferStatus;
    }

    public void setTransferOutputDescription(String transferOutputDescription) {
        this.transferOutputDescription = transferOutputDescription;
    }

    public String getTransferOutputDescription() {
        return transferOutputDescription;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setHostIp(String hostIp) {
        this.hostIp = hostIp;
    }

    public String getHostIp() {
        return hostIp;
    }

    public void setHostUserName(String hostUserName) {
        this.hostUserName = hostUserName;
    }

    public String getHostUserName() {
        return hostUserName;
    }

    public void setHostPassowrd(String hostPassowrd) {
        this.hostPassowrd = hostPassowrd;
    }

    public String getHostPassowrd() {
        return hostPassowrd;
    }

    public void setHostPort(int hostPort) {
        this.hostPort = hostPort;
    }

    public int getHostPort() {
        return hostPort;
    }

    public void setSourceFolder(String sourceFolder) {
        this.sourceFolder = sourceFolder;
    }

    public String getSourceFolder() {
        return sourceFolder;
    }

    public void setDestinationFolder(String destinationFolder) {
        this.destinationFolder = destinationFolder;
    }

    public String getDestinationFolder() {
        return destinationFolder;
    }

    public void setChecksumValueFromUI(String checksumValueFromUI) {
        this.checksumValueFromUI = checksumValueFromUI;
    }

    public String getChecksumValueFromUI() {
        return checksumValueFromUI;
    }

    public void setChecksumMethodFromUI(String checksumMethodFromUI) {
        this.checksumMethodFromUI = checksumMethodFromUI;
    }

    public String getChecksumMethodFromUI() {
        return checksumMethodFromUI;
    }


}
