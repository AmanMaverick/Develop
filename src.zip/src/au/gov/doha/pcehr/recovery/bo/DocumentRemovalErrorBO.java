package au.gov.doha.pcehr.recovery.bo;


public class DocumentRemovalErrorBO {
    public DocumentRemovalErrorBO() {
        super();
    }
    
    private String ihi;
    private String documentID;
    private String status;
    private String description;


    public void setIhi(String ihi) {
        this.ihi = ihi;
    }

    public String getIhi() {
        return ihi;
    }

    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    public String getDocumentID() {
        return documentID;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
