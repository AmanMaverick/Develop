package au.gov.doha.pcehr.recovery.bo;

import java.math.BigDecimal;

public class ReconcileDataReportBO {
    private BigDecimal IHI;
    private BigDecimal count;
    private String record_required;
    private String record_not_required;
    private String bulkreg_message_id;
    private String bulkreg_integration_id;
    private String bulkreg_error_code;
    private String bulkreg_last_updated_date;
    private String bulkreg_flag;
    private String optout_flag;
    private String extract_file_name;
    private String bulkreg_state;
    private String bulkreg_error_desc;

    public void setBulkreg_state(String bulkreg_state) {
        this.bulkreg_state = bulkreg_state;
    }

    public String getBulkreg_state() {
        return bulkreg_state;
    }

    public void setIHI(BigDecimal IHI) {
        this.IHI = IHI;
    }

    public BigDecimal getIHI() {
        return IHI;
    }

    public void setCount(BigDecimal count) {
        this.count = count;
    }

    public BigDecimal getCount() {
        return count;
    }

    public void setRecord_required(String record_required) {
        this.record_required = record_required;
    }

    public String getRecord_required() {
        return record_required;
    }

    public void setRecord_not_required(String record_not_required) {
        this.record_not_required = record_not_required;
    }

    public String getRecord_not_required() {
        return record_not_required;
    }

    public void setBulkreg_message_id(String bulkreg_message_id) {
        this.bulkreg_message_id = bulkreg_message_id;
    }

    public String getBulkreg_message_id() {
        return bulkreg_message_id;
    }

    public void setBulkreg_integration_id(String bulkreg_integration_id) {
        this.bulkreg_integration_id = bulkreg_integration_id;
    }

    public String getBulkreg_integration_id() {
        return bulkreg_integration_id;
    }

    public void setBulkreg_error_code(String bulkreg_error_code) {
        this.bulkreg_error_code = bulkreg_error_code;
    }

    public String getBulkreg_error_code() {
        return bulkreg_error_code;
    }

    public void setBulkreg_last_updated_date(String bulkreg_last_updated_date) {
        this.bulkreg_last_updated_date = bulkreg_last_updated_date;
    }

    public String getBulkreg_last_updated_date() {
        return bulkreg_last_updated_date;
    }

    public void setBulkreg_flag(String bulkreg_flag) {
        this.bulkreg_flag = bulkreg_flag;
    }

    public String getBulkreg_flag() {
        return bulkreg_flag;
    }

    public void setOptout_flag(String optout_flag) {
        this.optout_flag = optout_flag;
    }

    public String getOptout_flag() {
        return optout_flag;
    }

    public void setExtract_file_name(String extract_file_name) {
        this.extract_file_name = extract_file_name;
    }

    public String getExtract_file_name() {
        return extract_file_name;
    }

    public void setBulkreg_error_desc(String bulkreg_error_desc) {
        this.bulkreg_error_desc = bulkreg_error_desc;
    }

    public String getBulkreg_error_desc() {
        return bulkreg_error_desc;
    }

}
