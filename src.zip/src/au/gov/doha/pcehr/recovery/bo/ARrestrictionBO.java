package au.gov.doha.pcehr.recovery.bo;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author Vikash.c.kumar.singh Operations  MyHealthRecord
 *
 */
public class ARrestrictionBO {
    private String ihi;
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String nsw_QldID;
    private String expireDate;
    private String operatorName;
    private String userId;
    private String status;
    private StringBuilder comments;
    private String actionType;
    private String jiraId;
    private String myHealthRecordStatus;
    private String myHealthRecord;
    private MultipartFile file;
    
    private boolean wsStatus;
    
    public enum myHealthecordFound{
        YES("Yes"), NO("No");
        private String option;

        public String getOption() {
           return option;
        }
        myHealthecordFound(String option){
            this.option = option;
        }
    }

    private static final String COMMA_DELIMITER = ",";
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setIHI(String ihi) {
        this.ihi = ihi;
    }

    public String getIHI() {
        return ihi;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setNsw_QldID(String nsw_QldID) {
        this.nsw_QldID = nsw_QldID;
    }

    public String getNsw_QldID() {
        return nsw_QldID;
    }

    public void setExpireDate(String expireDate) {
        this.expireDate = expireDate;
    }

    public String getExpireDate() {
        return expireDate;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getActionType() {
        return actionType;
    }

    public void setJiraId(String jiraId) {
        this.jiraId = jiraId;
    }

    public String getJiraId() {
        return jiraId;
    }

    public void setComments(StringBuilder comments) {
        this.comments = comments;
    }

    public StringBuilder getComments() {
        return comments;
    }

    public void setMyHealthRecordStatus(String myHealthRecordStatus) {
        this.myHealthRecordStatus = myHealthRecordStatus;
    }

    public String getMyHealthRecordStatus() {
        return myHealthRecordStatus;
    }

    public void setMyHealthRecord(String myHealthRecord) {
        this.myHealthRecord = myHealthRecord;
    }

    public String getMyHealthRecord() {
        return myHealthRecord;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setWsStatus(boolean wsStatus) {
        this.wsStatus = wsStatus;
    }

    public boolean isWsStatus() {
        return wsStatus;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("");
        sb.append(this.ihi).append(COMMA_DELIMITER)
            .append(this.firstName).append(COMMA_DELIMITER)
            .append(this.lastName).append(COMMA_DELIMITER)
            .append(this.dateOfBirth).append(COMMA_DELIMITER)
            .append(this.nsw_QldID).append(COMMA_DELIMITER)
            .append(this.expireDate).append(COMMA_DELIMITER)
            .append(this.myHealthRecord).append(COMMA_DELIMITER)
            .append(this.myHealthRecordStatus).append(COMMA_DELIMITER)
            .append(this.status).append(COMMA_DELIMITER)
            .append(this.comments).append("\n");
        return String.valueOf(sb);
    }
}
