 function checkStatus() {
var actionValue = $('#action').val();
if (actionValue == "Remove Document") {
  $('#submitID').attr('name', 'Remove');
  $('#resonForRemoval').prop('disabled', false);
}
else {
  $('#submitID').attr('name', 'Reinstate');

  $('#resonForRemoval').prop('disabled', true);
}
if (document.getElementById("alertMessage").value != '') {
    $('#FileShow').hide();
    $('#filelSizeSpan').hide();
    alert(document.getElementById("alertMessage").value);
}
}
$(document).ready(function () {

    $('#IHIShow').show();
    $('#DocShow').show();
    $('#ReasonShow').show();
    $('#FileShow').hide();
    $('#filelSizeSpan').hide();
	
     
    if($('input:radio[name=removalType]:checked').val() == "bulk"){
        $("#action option[value='Reinstate Document']");
        $('#submitID').attr('name', 'Remove');
        $('#IHIShow').hide();
        $('#DocShow').hide();
        $('#ReasonShow').show();
        $('#FileShow').show();
        $('#filelSizeSpan').show();
        $('#textArea').hide();
        $('#selectAction').show();
        $("#soapMessage").val('');
		
        
    }else if($('input:radio[name=removalType]:checked').val() == "single"){
        $('#IHIShow').show();
        $('#DocShow').show();
        $('#ReasonShow').show();
        $('#FileShow').hide();
        $('#filelSizeSpan').hide();
        $('#selectAction').show();
        $('#textArea').show();
        $("#soapMessage").show();
		
    }
   
    $('#reset').click(function (e) {
        $('input:text').val('');
        $("#action").val($("#action option:first").val());
        $("#resonForRemoval").val($("#resonForRemoval option:first").val());
        $("#soapMessage").val('');
        $('#ihiId').val('');
        $('#userID').val('');
        $('#documentId').val('');
        $('#resonForRemoval').val('');
        $('#textArea').val('');
        $('#errormessageId').hide('');
        $('#FileShow').val('');
		
        e.preventDefault();
    });
	
//to toggle between two tables for remove document
        $("input[name='removalType']").click(function(){
            if($('input:radio[name=removalType]:checked').val() == "bulk"){
				$('#action').val('Remove Document');
				$("#action option[value='Reinstate Document']");
				$('#resonForRemoval').prop('disabled', false);
				$('#submitID').attr('name', 'Remove');
				$('#IHIShow').hide();
				$('#DocShow').hide();
				$('#ReasonShow').show();
				$('#FileShow').show();
				$('#filelSizeSpan').show();
				$('#soapResponse').hide();
				$('#errormessageId').hide('');
				$('#selectAction').show();
				$("#soapMessage").val('');
                
            }else if($('input:radio[name=removalType]:checked').val() == "single"){
				var flag=false;
				 $('#action option').each(function(){
				 if(this.value=='Reinstate Document')
				 {
					 flag=true;
				 }
				 });
				 if(flag==false){
                    $("#action").append('<option value="Reinstate Document">Reinstate Document</option>');
				 }
                $('#IHIShow').show();
				$('#DocShow').show();
				$('#ReasonShow').show();
				$('#soapResponse').show();
                $("#soapMessage").show();
				$('#FileShow').hide();
				$('#filelSizeSpan').hide();
				$('#errormessageId').hide('');
				$('#selectAction').show();
            }
        });
		
	//This method is used to show the span and file size in bytes
    $("#filelUpload").change(function (){
     var iSize = ($("#filelUpload")[0].files[0].size / 1024);
     var f=this.files[0];
     $('#filelSizeSpan').show();
     var val = f.size||f.fileSize ;
      $("#lblSize").html(val + " bytes");
  }); 

$('#submitID').click(function (e) {

  var actionValue = $('#action').val().trim().length;
  if (actionValue == 0) {
      alert("Please select Action type");
      e.preventDefault();
      return false;
  }

});

$('#action').change(function () {
  var x = $(this).val();

  if (x == "Remove Document") {
      $('#submitID').attr('name', 'Remove');
      $('#resonForRemoval').prop('disabled', false);

  }
  else {
      $('#submitID').attr('name', 'Reinstate');

      $('#resonForRemoval').prop('disabled', true);
      $('#resonForRemoval').val("");
  }

});

});