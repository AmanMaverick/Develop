$(document).ready(function() {
    $( "#viewTypeId" ).change(function() {
        $('#toDate').val('');
        $('#fromDate').val('');        
        if($("#viewTypeId option:selected").index() == 3){
            $('#dateDIV').hide();
        }else{
            $('#dateDIV').show();
        }
    });
    $( "#reset" ).click(function() {
        $('#toDate').val('');
        $('#fromDate').val('');
        $('#viewTypeId option[value=""]').attr('selected','selected');
        $('#dateDIV').show();
        $('#inputError').hide();
        $('#messageId').hide();
    });
});