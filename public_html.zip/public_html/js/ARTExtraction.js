//@Author Vikash Kumar Singh    Operations    PCEHR
//@version - 1.0.0.0
$(document).ready(function() {
        $('#flSizeSpan').hide()
        //To show required option on page load
        if($("#fileError" ).text()== ""){
            $('#BulkFileTable-wrapper').hide();
            $('#singleInputTable-wrapper').show();
        }else{
            $('#BulkFileTable-wrapper').show();
            $('#singleInputTable-wrapper').hide();
            $('input[name=type][value=bulk_file]').prop("checked",true);
        }

        //to toggle between two tables for ART search operation
        $("#switchTable input[name='type']").click(function(){
        $("#fileError" ).hide(); // to hide any error message once change the view using radio button.
        $("#inputError" ).hide();
        $("#fileException").hide();
            if($('input:radio[name=type]:checked').val() == "bulk_file"){
                $('#BulkFileTable-wrapper').show();
                $('#singleInputTable-wrapper').hide();
                
            }else if($('input:radio[name=type]:checked').val() == "single_input"){
                $('#BulkFileTable-wrapper').hide();
                $('#singleInputTable-wrapper').show();
            }
        });
  
    //ART Extraction Tool - toggle handler - Start
    $('#userid').focus(function() {
        $('#userid').removeAttr( "readonly" );
        $('#documentid').css("background-color", "#D1D1D1");
        $('#userid').css("background-color", "#FFFFFF");
        $('#documentid').val('');
        $('#documentid').prop('readonly', true);
    });
    $('#documentid').focus(function() {
        $('#documentid').removeAttr( "readonly" );
        $('#userid').css("background-color", "#D1D1D1");
        $('#documentid').css("background-color", "#FFFFFF");
        $('#userid').val('');
        $('#userid').prop('readonly', true);
    });
    //ART Extraction Tool - toggle handler - End
    
    //ART Extraction Search Result - For Select all checkbox - Start
    $('#selectAll').click(function(event) {  //on click
        if(this.checked) { // check select status
            $('.docId').each(function() { //loop through each checkbox
                this.checked = true;  //select all checkboxes with class "docId"              
            });
        }else{
            $('.docId').each(function() { //loop through each checkbox
                this.checked = false; //deselect all checkboxes with class "docId"                      
            });        
        }
    });
    
     //ART Extraction Search Result - For Select all checkbox - Start
    
    $("#myform").submit(function(e){
        if($('.docId:checkbox:checked').length != 0){
            //alert('Checkbox is checked!!');
        }else{
            alert("Please select the document");
            return false;
        }
  });
  
    //This method is used to show the span and file size in bytes
    $("#flUpload").change(function (){
     var iSize = ($("#flUpload")[0].files[0].size / 1024);
     var f=this.files[0];
     $('#flSizeSpan').show();
     var val = f.size||f.fileSize ;
      $("#lblSize").html(val + " bytes");
  }); 
});

