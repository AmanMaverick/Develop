$(document).ready(function () {
    $('#reset').click(function () {
        $('#inputError').hide();
        $('#entitiesID').val('');
        $('#OperatorNameId').val('');
        $('#userId').val('');
        $('#soapMessageId').val('');
        $('input[name="status"]').prop('checked', false);
        $("#entityType").val($("#entityType option:first").val());
        $("#filename").val("");
        $("#alertMessageId").hide();
    });

});