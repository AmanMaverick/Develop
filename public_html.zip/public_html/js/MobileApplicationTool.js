//@Author Aman.c.sharma   Operations    PCEHR
//@version - 1.0.0.0
$(document).ready(function () {
    $('#errormessage').hide();
    disableMinor();

    if ($('#VAMantab').val() == 'VAMangValue') {
        clearMobileAppregForm();

        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 2 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 2 + ")").addClass("active");
        //$("#vendorAppRegDiv").hide();
    }
    if ($('#VARegistrationtab').val() == 'VARegistrationValue') {
        clearMobileAppManForm();

        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + 1 + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + 1 + ")").addClass("active");
        //  $("#vendorAppManDiv").hide();
    }

    //tab switch function 
    $("ul#tabs li").click(function (e) {
        if (!$(this).hasClass("active")) {
            var tabNum = $(this).index();
            var nthChild = tabNum + 1;
            $("ul#tabs li.active").removeClass("active");
            $(this).addClass("active");
            $("ul#tab li.active").removeClass("active");
            $("ul#tab li:nth-child(" + nthChild + ")").addClass("active");
        }
    });
    $.fn.diplayCurrentTab = function (tabNum) {
        $("ul#tabs li.active").removeClass("active");
        $("ul#tabs li:nth-child(" + tabNum + ")").addClass("active");
        $("ul#tab li.active").removeClass("active");
        $("ul#tab li:nth-child(" + tabNum + ")").addClass("active");
    }
//clear registration form
    function clearMobileAppregForm() {
  
    //applist chekbox 
    $('[id^=apilistReg]').removeAttr('checked');
        
    
       // $('input:checkbox').removeAttr('checked');
        $('#applicationId').val('');
        $('#vendorNameId').val('');
        $('#fullNameSecId').val('');
        $('#appNameId').val('');
        $('#phoneSecId').val('');
        $('#alternateNameId').val('');
        $('#mobileSecId').val('');
        $('#versionId').val('');
        $('#emailSecId').val('');
        $('#callbackURLId').val('');
        $('#businessAddressSecId').val('');
        $('#intentID').val('');
        $('#suburbSecId').val('');
        $('#osId').val('');
        $('#postcodeSecId').val('');
        $('#stateSecId').val('');
        $('#fullNameId').val('');
        $('#phoneId').val('');
        $('#mobileId').val('');
        $('#emailId').val('');
        $('#businessAddressId').val('');
        $('#suburbId').val('');
        $('#postcodeId').val('');
        $('#stateId').val('');
        $('#ipRangeId').val('');
        $('#submissionDateID').val('');
        $('#applicationStatusId').val('');
        $('#callbackURLNotiId').val('');
        $('#callbackURLId').val('');
        $('#ipRangeManId').val('');
          $('input[id=intModelID1]').prop('checked',true)
        //inteaction model
         //$('input[name=intModel][value=1]').prop('checked',true)
     
    }
//clear updation  form
    function clearMobileAppManForm() {
      //applist chekbox 
        $('[id^=apilistMan]').removeAttr('checked');
  
        $('#applicationListIdMan').val('');
      //  $('input:checkbox').removeAttr('checked');
        $('#applicationIdMan').val('');
        $('#vendorNameIdMan').val('');
        $('#fullNameSecIdMan').val('');
        $('#appNameIdMan').val('');
        $('#phoneSecIdMan').val('');
        $('#alternateNameIdMan').val('');
        $('#mobileSecIdMan').val('');
        $('#versionIdMan').val('');
        $('#emailSecIdMan').val('');
        $('#callbackURLIdMan').val('');
        $('#businessAddressSecIdMan').val('');
        $('#intentIDMan').val('');
        $('#suburbSecIdMan').val('');
        $('#osIdMan').val('');
        $('#postcodeSecIdMan').val('');
        $('#stateSecIdMan').val('');
        $('#fullNameIdMan').val('');
        $('#phoneIdMan').val('');
        $('#mobileIdMan').val('');
        $('#emailIdMan').val('');
        $('#businessAddressIdMan').val('');
        $('#suburbIdMan').val('');
        $('#postcodeIdMan').val('');
        $('#stateIdMan').val('');
        $('#groupIDMan').val('');
        $('#ipRangeManId').val('');
        $('#submissionDateIDMan').val('');
        $('#applicationStatusIdMan').val('');
        $('#callbackURLNotiIdMan').val('');
        $('#callbackURLManId').val('');
        $('#ipRangeManIdMan').val('');
         
           $('input[id=intModelManID1]').prop('checked',true)
           $('input[name=intMajor][value=YES]').prop('checked',true)

    }
    $('#reset').click(function () {
        clearMobileAppregForm();
        $('input[name=intModel][value=1]').prop('checked',true)
    });
    $('#clear').click(function () {
        clearMobileAppManForm();
        $('input[name=intModel][value=1]').prop('checked',true)
    });

    function disableMinor() {
     $('#submitVAManagement').val('Update Application');
        $('#groupIDMan').prop('readOnly', true);
        $('#applicationIdMan').prop('readOnly', true);
        //$('#intModelManID1').prop('disabled', true);
        //$('#intModelManID2').prop('disabled', true);
       // $('#intModelManID4').prop('disabled', true);

       // $('table#tab1 input[type=checkbox]').attr('disabled', 'true');
      
       //$('[id^=apilistMan]').css('color', 'red');
       // $('#apilistMan0').css('background-color','#FF0000');
	//
       document.getElementById('intModelManID1').style.backgroundColor  = "#696E6E";
	   document.getElementById('intModelManID2').style.backgroundColor  = "#696E6E";
	   document.getElementById('intModelManID4').style.backgroundColor  = "#696E6E";
	   
        $('#groupIDMan').css('background-color', '#d9d9d9');

        $('#applicationIdMan').css('background-color', '#d9d9d9');

      
    }

    function disableMajor() {
       $('#submitVAManagement').val('Re-Register Application');

        $('#groupIDMan').prop('readOnly', true);

        $('#applicationIdMan').prop('readOnly', false);
        //$('#intModelManID1').prop('disabled', false);

        //$('#intModelManID2').prop('disabled', false);

       // $('#intModelManID4').prop('disabled', false);

      //$('table#tab1 input[type=checkbox]').removeAttr('disabled');
      // $('[id^=apilistMan]').css('background-color', 'white');
        $('#groupIDMan').css('background-color', '#d9d9d9');

        $('#applicationIdMan').css('background-color', 'white');
		       document.getElementById('intModelManID1').style.backgroundColor = "white";
	   document.getElementById('intModelManID2').style.backgroundColor = "white";
	   document.getElementById('intModelManID4').style.backgroundColor = "white";

    }

    //tab switch fix
    $('#submitVAManagement').click(function () {
        $('#VAMantab').val('VAMangValue');

    });
    $('#submitVARegistration').click(function () {
        $('#VARegistrationtab').val('VARegistrationValue');

    });

    //aman chnages

    $('#intMinorID').click(function () {
      
        disableMinor();

    });

    $('#intMajorID').click(function () {
        disableMajor();

    });
    //hiding Errors on list change
    $('#activeID1,#inActiveID1').click(function () {
        $('#vendorAppRegErrorsDiv').hide();
        $('#vendorAppManErrorsDiv').hide();
    });
    //disable input text fields

    $('#applicationListIdMan').change(function () {
        if ($('#applicationListIdMan').val().length > 0) {
            var appIdVal = $('#applicationListIdMan').val();

            $('#appIdMan').val(appIdVal);
            enableManFileds(false, "white");

            majorMinorDisableEnable();
        }
        else {
            enableManFileds(true, "#d9d9d9");
            clearMobileAppManForm();
        }

    });
    $('#inActiveID1').click(function () {
        majorMinorDisableEnable();

        $('#applicationListIdMan').attr('disabled', false).css("background-color", "white");
        if ($('#applicationListIdMan').val().length > 0) {
            enableManFileds(false, "white");
            //callMajorMinor();
            majorMinorDisableEnable();
        }
        else {
            enableManFileds(true, "#d9d9d9");
        }
    });

    $('#activeID1').click(function () {
        $('input').attr('disabled', false);
        $('input, textarea, select').not(':input[type=button], :input[type=submit], :input[type=reset]').css("background-color", "white");
        // $("input").css("background-color", "white");
    });

    function enableManFileds(state, color) {
        $('input').attr('disabled', state);
        $('input, textarea').not(':input[type=button], :input[type=submit], :input[type=reset]').css("background-color", color);
        $('#stateIdMan').prop('disabled', state);
        $('#stateSecIdMan').prop('disabled', state);
          $('#applicationStatusIdMan').prop('disabled', state);

    }

    majorMinorDisableEnable();
    //function to disbale and enable fieilds based on major minor selection
    function majorMinorDisableEnable() {

        if ($("#intMajorID").is(":checked")) {
            disableMajor();

        }
        if ($("#intMinorID").is(":checked")) {
            disableMinor();

        }
    }
  $('[id^=apilistMan]').click(function(){
    if ($("#intMajorID").is(":checked")) {
       
     return true;
    }
     if ($("#intMinorID").is(":checked")) {
     
      
      return false;
     }
     
  });
   $('[id^=intModelMan]').click(function(){
    if ($("#intMajorID").is(":checked")) {
   
    
     return true;
    }
     if ($("#intMinorID").is(":checked")) {
     
      $('input[name=intModel][value=' + $('#interactionHidden').val() + ']').prop('checked',true)
      
     
     }
     
  });
});