$(document).ready(function (){
     var output='';
      if($( "#accOrgID" ).val()!==''){
           output="CSV file for documents Uploaded by Accessing Org Created at "+$('#accOrgID').val()+" \n\n";
       }
       if($( "#inheritOrgID" ).val()!==''){
           output = output + "TXT file for documents Uploaded by Inheriting Org Created at "+$('#inheritOrgID').val()+ "\n\n";
       }
       if($( "#unknownDocID" ).val()!==''){
           output =  output + "Unknown DocumentId Exists Please see file " + $('#unknownDocID').val()+ "\n\n";
       }
       if($( "#unknownAuthID" ).val()!==''){
           output = output + "Author Information doesnot Exists Please see file " + $('#unknownAuthID').val() + "\n\n";
       }
       if(output!='' || !output.empty()){
            alert(output);
       }
       
       $("#reset").on("click", function() {
       $("#inputError").hide();
       });
   });