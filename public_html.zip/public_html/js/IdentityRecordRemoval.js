$(document).ready(function () {

    $('#ihiLastNameShow').show();
    $('#sexDOBShow').show();
    $('#fileShow').hide();
    $('#flSizeSpan').hide();
    
    if($('input:radio[name=operationTypeRemoval]:checked').val() == "bulkInput"){
        $('#ihiLastNameShow').hide();
        $('#sexDOBShow').hide();
        $('#fileShow').show();
        $('#flSizeSpan').show();
        //alert("bulkInput");
        $('#errormessage').hide();
        $('#deleteSuccessConfirmationId').hide();
        
    }else if($('input:radio[name=operationTypeRemoval]:checked').val() == "singleInput"){
        $('#ihiLastNameShow').show();
        $('#sexDOBShow').show();
        $('#fileShow').hide();
        $('#flSizeSpan').hide();
        //alert("singleInput");
        $('#errormessage').hide();
        $('#messageId').hide();
        
    }
    
    
     //to toggle between two tables for Identity Record Removal 
        $("input[name='operationTypeRemoval']").click(function(){
            if($('input:radio[name=operationTypeRemoval]:checked').val() == "bulkInput"){
                $('#ihiLastNameShow').hide();
                $('#sexDOBShow').hide();
                $('#fileShow').show();
                $('#flSizeSpan').show();
                //alert("bulkInput");
                $('#errormessage').hide();
                $('#deleteSuccessConfirmationId').hide();
                
            }else if($('input:radio[name=operationTypeRemoval]:checked').val() == "singleInput"){
                $('#ihiLastNameShow').show();
                $('#sexDOBShow').show();
                $('#fileShow').hide();
                $('#flSizeSpan').hide();
                //alert("singleInput");
                $('#errormessage').hide();
                $('#messageId').hide();
                
            }
        });
    
    $('#reset').click(function () {
        $('#ihiID').val('');
        $('#lastName').val('');
        $('#dob').val('');
        $('#userID').val('');
        $('#operatorName').val('');
        $("#sex").val($("#sex option:first").val());
        $("#action_type").val($("#action_type option:first").val());
        $('#error').hide();
        $('#deleteRecordConfirmationId').hide();
        $('#deleteSuccessConfirmationId').hide();
        $('#errormessage').hide();
        $('#messageId').hide();
        $('#lblSize').empty();
        $('#flUpload').replaceWith($('#flUpload').val('').clone(true));
    });
    
    //This method is used to show the span and file size in bytes
    $("#flUpload").change(function (){
     var iSize = ($("#flUpload")[0].files[0].size / 1024);
     var f=this.files[0];
     $('#flSizeSpan').show();
     var val = f.size||f.fileSize ;
      $("#lblSize").html(val + " bytes");
  }); 
});