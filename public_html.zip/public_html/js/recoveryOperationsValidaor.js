$(document).ready(function () {
    $('#submitID').click(function (e) {
        var fromDate = $('#From_Transaction_Date').val().trim();
        var toDate = $('#To_Transaction_Date').val().trim();
        var ihiLength = $('#ihiID').val().trim().length;
        if (ihiLength > 0 && (ihiLength < 16 || !$.isNumeric($('#ihiID').val()))) {
            alert("IHI must be 16digit numeric");
            e.preventDefault();
        }
        else if (!$('#From_Transaction_Date').val().trim() || !$('#To_Transaction_Date').val().trim()) {
            alert("Date field is mandatory to provide");
            e.preventDefault();
        }
        else if (!$(this).isDate(fromDate)) {
            alert("Enter valid From Transaction Date");
            e.preventDefault();
        }
        else if (!$(this).isDate(toDate)) {
            alert("Enter valid To Transaction Date");
            e.preventDefault();
        }
        else if (!$(this).dateCheck(fromDate, toDate)) {
            alert("To date should be grater than or equal to from date.");
            e.preventDefault();
        }

    });
    //Date format check.
    (function ($) {
        $.fn.isDate = function (txtDate) {
            var currVal = txtDate;
            if (currVal == '')
                return false;

            //Declare Regex  
            var rxDatePattern = /^(\d{2})(\d{2})(\d{4})$/;
            var dtArray = currVal.match(rxDatePattern);// is format OK?
            if (dtArray == null)
                return false;

            //Checks for dd/mm/yyyy format.
            dtDay = dtArray[1];
            dtMonth = dtArray[2];
            dtYear = dtArray[3];

            if (dtMonth < 1 || dtMonth > 12)
                return false;
            else if (dtDay < 1 || dtDay > 31)
                return false;
            else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
                return false;
            else if (dtMonth == 2) {
                var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
                if (dtDay > 29 || (dtDay == 29 && !isleap))
                    return false;
            }
            return true;
        };
    })(jQuery);

    //To check whether to date is grater than the from date.
(function ($) {
        $.fn.dateCheck = function (fromTransactionDate, toTransactionDate) {
            var fromDate = fromTransactionDate;
            var toDate = toTransactionDate;

            var rxDatePattern = /^(\d{2})(\d{2})(\d{4})$/;
            var fromDateArray = fromDate.match(rxDatePattern);
            fromDtDay = fromDateArray[1];
            fromDtMonth = fromDateArray[2];
            fromDtYear = fromDateArray[3];

            var toDateArray = toDate.match(rxDatePattern);
            toDtDay = toDateArray[1];
            toDtMonth = toDateArray[2];
            toDtYear = toDateArray[3];

            //to date should be grater than from date.
            if (toDtYear < fromDtYear) {
                return false;
            }
            else if (toDtYear == fromDtYear) {
                if (toDtMonth < fromDtMonth) {
                    return false;
                }
                else if (toDtMonth == fromDtMonth) {
                    if (toDtDay < fromDtDay) {
                        return false
                    }
                    else {
                        return true;
                    }
                }
            }
            else {
                return true;
            }

        };
    })(jQuery);

});